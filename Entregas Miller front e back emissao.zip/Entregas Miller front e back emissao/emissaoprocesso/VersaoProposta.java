/******************************************************************************* 
 * Copyright (c) 2014-2014, 2015 Porto Seguro Seguros S.A., Inc. All Rights Reserved.
 *
 * Este software contém informações confidenciais e de propriedade da Porto Seguro Seguros S.A. ("Informações Confidenciais").
 * Você não deve divulgar qualquer tipo de informações confidenciais e deve usá-las apenas, de acordo com os termos do
 * contrato de licença firmado com a Porto Seguro.
 *
 * A Porto Seguro não faz declarações ou garantias sobre a adequação do software, expressa ou implicitamente, incluindo,
 * mas não se limitando, a garantias de comercialização, adequação para um determinado fim ou qualquer tipo de violação.
 *
 * A PORTO SEGURO NÃO SERÁ RESPONSÁVEL POR QUAISQUER DANOS SOFRIDOS PELO LICENCIADO EM DECORRÊNCIA DO USO, MODIFICAÇÃO
 * OU DISTRIBUIÇÃO DESTE SOFTWARE OU SEUS DERIVADOS.
 *
 *
 * Criado em(Created on): 10/22/2015
 * Autor(Author)        : emil.e.alvarez@accenture.com
 *
 * -----------------------------------------------------------------------------
 * Histórico da Revisão (Revision History) - Release 1.0.0
 * -----------------------------------------------------------------------------
 *  VERSÃO      DATA           AUTOR                DESCRIÇÃO DA MUDANÇA
 * (VERSION)   (DATE)         (AUTHOR)             (DESCRIPTION OF CHANGE)
 * -----------------------------------------------------------------------------
 * 1.0.0   | 10/22/2015 | emil.e.alvarez  | Criação Inicial (Initial Create)
 * --------|------------|--------------------|----------------------------------
 *******************************************************************************/
package com.porto.re.emissaoprocesso.entity;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.porto.re.administrativo.entity.FrequenciaFatoramento;
import com.porto.re.emissaocadastro.entity.SubvencaoCorretorVersaoProposta;

// TODO: Auto-generated Javadoc
/**
 * The persistent class for the REEMPRPVRS database table.
 */
@NamedQueries({ @NamedQuery(
	name = VersaoProposta.GET_MAX_NUMERO_VERSAO_PROPOSTA,
	query = "SELECT MAX(vp.identificador.numeroVersaoProposta) FROM VersaoProposta vp WHERE" +
	" vp.identificador.numeroProposta = :NUMERO_PROPOSTA"), @NamedQuery(
		name = VersaoProposta.FIND_BY_ANTERIOR_AND_STATUS,
		query = "SELECT vp FROM VersaoProposta vp JOIN vp.versaoOrcamento vo JOIN vp.statusVersaoPropostas svp " +
			" WHERE vo.numeroApoliceAnterior = :numeroApoliceAnterior AND svp.dataFimStatusProposta IS NULL " +
		" AND svp.identificador.codigoStatusProposta in (:codigoStatusProposta) "
				+ " AND vp.identificador.numeroVersaoProposta IN "
				+ "	(SELECT max(vp2.identificador.numeroVersaoProposta) "
				+ " 	FROM VersaoProposta vp2 "
				+ "		WHERE vp2.identificador.numeroProposta = vp.identificador.numeroProposta)"),
		@NamedQuery(
			name = VersaoProposta.GET_PROPOSTA_OF_ORCAMENTO, query = "SELECT vp FROM VersaoProposta vp" +
				" WHERE vp.versaoOrcamento.identificador.numeroOrcamento = :NUM_ORC " +
				" AND vp.versaoOrcamento.identificador.numeroVersaoOrcamento = :NUM_VER_ORC " +
				" AND vp.identificador.numeroVersaoProposta = " +
				"(SELECT MAX(vp2.identificador.numeroVersaoProposta) FROM VersaoProposta vp2 " +
				" WHERE vp2.versaoOrcamento.identificador.numeroOrcamento = :NUM_ORC " +
			" AND vp2.versaoOrcamento.identificador.numeroVersaoOrcamento = :NUM_VER_ORC) "), @NamedQuery(
				name = VersaoProposta.GET_PROPOSTA_OF_ORCAMENTO2,
				query = "SELECT vp FROM VersaoProposta AS vp " + " JOIN vp.versaoOrcamento AS vo " +
					" WHERE vo.identificador.numeroOrcamento = :NUM_ORC " +
					" AND vo.identificador.numeroVersaoOrcamento = :NUM_VER_ORC " +
					" AND vp.identificador.numeroVersaoProposta" +
					" = (SELECT MAX(vp2.identificador.numeroVersaoProposta) " +
					" FROM VersaoProposta vp2 JOIN vp2.statusVersaoPropostas svp" +
					" WHERE vp.identificador.numeroProposta = " +
					" vp2.identificador.numeroProposta " +
				" AND svp.identificador.codigoStatusProposta != 9 AND svp.dataFimStatusProposta IS NULL) "),
	@NamedQuery(
		name = VersaoProposta.GET_PROPOSTA_BY_NUMERO_ORCAMENTO, query = "SELECT vp FROM VersaoProposta vp" +
			" WHERE vp.versaoOrcamento.identificador.numeroOrcamento = :NUM_ORC " +
			" AND vp.identificador.numeroVersaoProposta = " +
			"(SELECT MAX(vp2.identificador.numeroVersaoProposta) FROM VersaoProposta vp2 " +
			" WHERE vp2.versaoOrcamento.identificador.numeroOrcamento = :NUM_ORC) " +
		"order by vp.identificador.numeroProposta desc"),
	@NamedQuery(
		name = VersaoProposta.GET_PROP_ANT_BY_NUMERO_PROP_ATUAL, query = 
		"SELECT vp FROM VersaoProposta vp JOIN vp.apolices apl WHERE apl.numeroApolice = " + 
			" (SELECT vo.numeroApoliceAnterior FROM VersaoOrcamento vo WHERE vo.identificador.numeroOrcamento IN (" +
			" SELECT vp2.versaoOrcamento.identificador.numeroOrcamento FROM VersaoProposta vp2 " + 
			" WHERE vp2.identificador.numeroProposta = :numeroProposta " + 
			" AND vp2.identificador.numeroVersaoProposta = :numeroVersaoProposta) " + 
			" AND vo.identificador.numeroVersaoOrcamento IN (" +
			" SELECT vp3.versaoOrcamento.identificador.numeroVersaoOrcamento FROM VersaoProposta vp3 " + 
			" WHERE vp3.identificador.numeroProposta = :numeroProposta " + 
		" AND vp3.identificador.numeroVersaoProposta = :numeroVersaoProposta))"),
	@NamedQuery(
		name = VersaoProposta.GET_PROPOSTA_PROTOCOLADA_BY_RAMO_MODALIDADE,
		query = "SELECT vp FROM VersaoProposta vp JOIN vp.versaoOrcamento versaoOrcamento" +
			" JOIN versaoOrcamento.orcamento orcamento " + " WHERE versaoOrcamento.codigoPessoa = :COD_PESSOA " +
			" AND orcamento.codigoRamo = :CODIGO_RAMO AND orcamento.codigoModalidade = :CODIGO_MODALIDADE" +
		" AND vp.dataProtocolo IS NOT NULL"),
	@NamedQuery(
		name = VersaoProposta.GET_PROPOSTA_ENDOSSO_PENDENTE_EMISSAO,
		query = "SELECT vp.identificador.numeroProposta FROM VersaoProposta vp "
			+ "JOIN vp.versaoOrcamento vo "
			+ "JOIN vp.statusVersaoPropostas svp "
			+ "WHERE vo.identificador.numeroOrcamento IN (:numerosOrcamento) "
			+ "AND svp.dataFimStatusProposta IS NULL "
			+ "AND svp.identificador.codigoStatusProposta IN (1,2,3,4,5,6) "
			+ "AND vp.dataProtocolo IS NOT NULL"),
	@NamedQuery(
		name = VersaoProposta.GET_PROPOSTA_BY_RAMO_MODALIDADE_PESSOA,
		query = "SELECT vp FROM VersaoProposta vp JOIN vp.versaoOrcamento versaoOrcamento" +
			" JOIN versaoOrcamento.orcamento orcamento " + " WHERE versaoOrcamento.codigoPessoa = :COD_PESSOA " +
		" AND orcamento.codigoRamo = :CODIGO_RAMO AND orcamento.codigoModalidade = :CODIGO_MODALIDADE"),
	@NamedQuery(
		name = VersaoProposta.GET_PROPOSTA_BY_PESSOA,
		query = "SELECT vp FROM VersaoProposta vp JOIN vp.versaoOrcamento versaoOrcamento" +
			" JOIN versaoOrcamento.orcamento orcamento " + " WHERE versaoOrcamento.codigoPessoa = :COD_PESSOA "),
	@NamedQuery(
			name = VersaoProposta.GET_ULTIMA_PROPOSTA_ENDOSSO_PENDENTE_EMISSAO,
			query = "SELECT vp.identificador.numeroProposta FROM VersaoProposta vp "
				+ "JOIN vp.versaoOrcamento vo "
				+ "JOIN vp.statusVersaoPropostas svp "
				+ "WHERE vo.identificador.numeroOrcamento IN (:numerosOrcamento) "
				+ "AND svp.dataFimStatusProposta IS NULL "
				+ "AND svp.identificador.codigoStatusProposta IN (1,2,3,4,5,6) "
				+ "AND vp.dataProtocolo IS NOT NULL "
				+ "AND vp.identificador.numeroVersaoProposta IN "
				+ "	(SELECT max(vp2.identificador.numeroVersaoProposta) "
				+ " 	FROM VersaoProposta vp2 "
				+ "		WHERE vp2.identificador.numeroProposta = vp.identificador.numeroProposta)")
})
@Entity
@Table(name = "REEMPRPVRS")
@SuppressWarnings({ "PMD.ExcessivePublicCount", "PMD.TooManyFields", "PMD.NullAssignment" })
public class VersaoProposta implements Serializable {

	/**
	 * default serial version versaoProposta, required for serializable classes.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Mapped By constant.
	 */
	private static final String MAPPED_BY = "versaoProposta";

	/**
	 * Get max numero versao proposta NamedQuery.
	 */
	public static final String GET_MAX_NUMERO_VERSAO_PROPOSTA = "VersaoProposta.getMaxNumeroVersaoProposta";

	/**
	 * Get versao proposta list by anterior and status.
	 */
	public static final String FIND_BY_ANTERIOR_AND_STATUS = "VersaoProposta.findVersionByAnteriorAndStatus";

	/** Get versao proposta of Orcamento. */
	public static final String GET_PROPOSTA_OF_ORCAMENTO = "VersaoProposta.getPropostaOfOrcamento";

	/** Get versao proposta of Orcamento. */
	public static final String GET_PROPOSTA_OF_ORCAMENTO2 = "VersaoProposta.getPropostaOfOrcamento2";

	/** Get versao proposta by numeroOrcamento Orcamento. */
	public static final String GET_PROPOSTA_BY_NUMERO_ORCAMENTO = "VersaoProposta.getPropostaByNumeroOrcamento";

	/**
	 * Get versao proposta by numeroOrcamento, codigoRamo and codigoModalidade
	 * Orcamento.
	 */
	public static final String GET_PROPOSTA_PROTOCOLADA_BY_RAMO_MODALIDADE =
		"VersaoProposta.getPropostaByNumeroOrcamentoAndRamoModalidade";

	/** The Constant GET_PROP_ANT_BY_NUMERO_PROP_ATUAL. */
	public static final String GET_PROP_ANT_BY_NUMERO_PROP_ATUAL = 
		"VersaoProposta.getPropostaAnteriorByNumeroPropostaAtual";

	/**
	 * Get versao proposta by numeroOrcamento, codigoRamo and codigoModalidade
	 * Orcamento.
	 */
	public static final String GET_PROPOSTA_BY_RAMO_MODALIDADE_PESSOA =
		"VersaoProposta.getPropostaByRamoModalidadePessoa";

	/**
	 * Get versao proposta by numeroOrcamento, and codPessoa
	 * Orcamento.
	 */
	public static final String GET_PROPOSTA_BY_PESSOA =
		"VersaoProposta.getPropostaByPessoa";

	/** Get versaoProposta. */
	public static final String VERSAO_PROPOSTA = "versaoProposta";

	/** Named query. */
	public static final String GET_PROPOSTA_ENDOSSO_PENDENTE_EMISSAO = "versaoProposta.getPropostaEndossoPendenteEmissao";

	/** Named query. */
	public static final String GET_ULTIMA_PROPOSTA_ENDOSSO_PENDENTE_EMISSAO =
			"versaoProposta.getUltimaPropostaEndossoPendenteEmissao";
	
	/**
	 * Mapping field name for versaoPropostaPK.
	 */
	@EmbeddedId
	private VersaoPropostaPK identificador;

	/**
	 * Mapping field name for dataUltimaAlteracao.
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ALTULTDAT", nullable = false)
	private Date dataUltimaAlteracao;

	/**
	 * Mapping field name for codigoEmpresaUsuarioUltimaAlteracao.
	 */
	@Column(name = "ALTULTUSREMPCOD", nullable = false, length = 2)
	private String codigoEmpresaUsuarioUltimaAlteracao;

	/**
	 * Mapping field name for codigoMatriculaUsuarioUltimaAlteracao.
	 */
	@Column(name = "ALTULTUSRMATCOD", nullable = false, length = 6)
	private String codigoMatriculaUsuarioUltimaAlteracao;

	/**
	 * Mapping field name for codigoTipoUsuarioUltimaAlteracao.
	 */
	@Column(name = "ALTULTUSRTIPCOD", nullable = false, length = 1)
	private String codigoTipoUsuarioUltimaAlteracao;

	/**
	 * Mapping field name for numeroPropostaAutomovel.
	 */
	@Column(name = "AUTPRPNUM", nullable = true, length = 20)
	private String numeroPropostaAutomovel;

	/**
	 * Mapping field name for flagPossuiBeneficiario.
	 */
	@Column(name = "BFOPSIFLG", nullable = false, length = 1)
	private String flagPossuiBeneficiario;

	/**
	 * Mapping field name for flagEnvioEmailCorretor.
	 */
	@Column(name = "COREMAENVFLG", nullable = false, length = 1)
	private String flagEnvioEmailCorretor;

	/**
	 * Mapping field name for flagEnvioEmailImobiliaria.
	 */
	//@Column(name = "IMBEMAENVFLG", nullable = false, length = 1)
	@Transient
	private String flagEnvioEmailImobiliaria = "S";

	/**
	 * Mapping field name for flagPrimeiraCompraCartaoEmpresa.
	 */
	@Column(name = "EMPCRTAQSPRIFLG", nullable = false, length = 1)
	private String flagPrimeiraCompraCartaoEmpresa;

	/**
	 * Mapping field name for dataEmissao.
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "EMSDAT", nullable = true)
	private Date dataEmissao;

	/**
	 * Mapping field name for dataMelhorDataPrimeiraParcela.
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "PARPRIDATMLHDAT", nullable = true)
	private Date dataMelhorDataPrimeiraParcela;

	/** The data integracao fenseg. */
	@Temporal(TemporalType.TIME)
	@Column(name = "FSGINTDAT", nullable = true)
	private Date dataIntegracaoFenseg;

	/**
	 * Mapping field name for dataProtocolo.
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "PCLDAT", nullable = true)
	private Date dataProtocolo;

	// /**
	// * bi-directional many-to-one association to TipoDistribuicaoPagamento.
	// */
	// @ManyToOne
	// @JoinColumn(name = "PGTDTBTIPCOD", insertable = false, updatable = false)
	// private TipoDistribuicaoPagamento tipoDistribuicaoPagamento;

	/**
	 * bi-directional many-to-one association to Endereco.
	 */
	// @ManyToOne(fetch=FetchType.LAZY)
	@ManyToOne
	@JoinColumn(name = "PGTFRMCOD", nullable = true)
	private FormaPagamento formaPagamento;

	/**
	 * Mapping field name for flagPossuiCorretorSecundario.
	 */
	@Column(name = "SCUCORPSIFLG", nullable = false, length = 1)
	private String flagPossuiCorretorSecundario;

	/**
	 * Mapping field name for flagPossuiSinistro.
	 */
	@Column(name = "SINPSIFLG", nullable = false, length = 1)
	private String flagPossuiSinistro;

	/**
	 * Mapping field name for dataFimVigencia.
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "VIGFIMDAT")
	private Date dataFimVigencia;

	/**
	 * Mapping field name for dataInicioVigencia.
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "VIGINIDAT", nullable = false)
	private Date dataInicioVigencia;

	// /**
	// * bi-directional many-to-one association to
	// TipoOrganizacaoPessoaJuridica.
	// */
	// @ManyToOne
	// @JoinColumn(name = "OZNTIPCOD", insertable = false, updatable = false)
	// private TipoOrganizacaoPessoaJuridica tipoOrganizacaoPessoaJuridica;

	/** codigoTipoOrganizacaoPessoaJuridica. */
	@Column(name = "OZNTIPCOD", nullable = true, precision = 15)
	private Long codigoTipoOrganizacaoPessoaJuridica;

	/**
	 * flagRenovacaoAutomatico.
	 */
	@Column(name = "ATMRNVFLG", nullable = false, length = 1)
	private String flagRenovacaoAutomatico;

	/**
	 * nomeProcessoSistemaGerenciamentoProcesso.
	 */
	@Column(name = "PCSGERSISPCSNOM", length = 100)
	private String nomeProcessoSistemaGerenciamentoProcesso;

	/**
	 * flagBloqueio.
	 */
	@Column(name = "BLQFLG", nullable = false, length = 1)
	private String flagBloqueio;

	/**
	 * Mapping field name for dataBloqueio.
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "BLQDAT")
	private Date dataBloqueio;

	/**
	 * codigoTipoUsuarioBloqueio.
	 */
	@Column(name = "BLQUSRTIPCOD", length = 1)
	private String codigoTipoUsuarioBloqueio;

	/**
	 * codigoEmpresaUsuarioBloqueio.
	 */
	@Column(name = "BLQUSREMPCOD", length = 2)
	private String codigoEmpresaUsuarioBloqueio;

	/**
	 * codigoMatriculaUsuarioBloqueio.
	 */
	@Column(name = "BLQUSRMATCOD", length = 6)
	private String codigoMatriculaUsuarioBloqueio;

	/**
	 * Mapping field name for flagEndossoAlteracaoDadoCadastralSegurado.
	 */
	@Column(name = "SEGCDLDADALTEDSFLG", nullable = false, length = 1)
	private String flagEndossoAlteracaoDadoCadastralSegurado;

	/**
	 * bi-directional many-to-one association to Apolice.
	 */
	@OneToMany(mappedBy = MAPPED_BY)
	private List<Apolice> apolices;

	/**
	 * bi-directional many-to-one association to SolicitacaoCarta.
	 */
	@OneToMany(mappedBy = MAPPED_BY)
	private List<SolicitacaoCarta> solicitacaoCartas;

	/**
	 * bi-directional many-to-one association to
	 * DocumentoSolicitacaoSegundoViaDocumento.
	 */
	@OneToMany(mappedBy = MAPPED_BY)
	private List<DocumentoSolicitacaoSegundoViaDocumento> documentoSolicitacaoSegundoViaDocumentos;

	/**
	 * bi-directional many-to-one association to VersaoOrcamento.
	 */
	@ManyToOne
	@JoinColumns({ @JoinColumn(name = "ORCNUM", referencedColumnName = "ORCNUM", nullable = false), @JoinColumn(
		name = "ORCVRSNUM", referencedColumnName = "ORCVRSNUM", nullable = false) })
	private VersaoOrcamento versaoOrcamento;

	/**
	 * bi-directional many-to-one association to Proposta.
	 */
	@ManyToOne
	@JoinColumn(name = "PRPNUM", nullable = false, insertable = false, updatable = false)
	private Proposta proposta;

	/**
	 * bi-directional many-to-one association to FrequenciaFatoramento.
	 */
	@ManyToOne
	@JoinColumn(name = "FTMFQCCOD")
	private FrequenciaFatoramento frequenciaFatoramento;

	/**
	 * Mapping field name for codigoPrazoAverbacao.
	 */
	@Column(name = "AVBPZOCOD")
	private Integer codigoPrazoAverbacao;

	/**
	 * Mapping field name for codigoEnderecoCorrespondencia.
	 */
	@Column(name = "CRRENDCOD", nullable = true, precision = 15)
	private Long codigoEnderecoCorrespondencia;

	/**
	 * bi-directional many-to-one association to AnaliseVersaoProposta.
	 */
	@OneToMany(mappedBy = MAPPED_BY)
	private List<AnaliseVersaoProposta> analiseVersaoPropostas;

	/**
	 * bi-directional many-to-one association to BeneficiarioVersaoProposta.
	 */
	@OneToMany(mappedBy = MAPPED_BY)
	private List<BeneficiarioVersaoProposta> beneficiarioVersaoPropostas;

	/**
	 * bi-directional many-to-one association to CriticaVersaoProposta.
	 */
	@OneToMany(mappedBy = MAPPED_BY)
	private List<CriticaSeguroVersaoProposta> criticaVersaoPropostas;

	/**
	 * bi-directional many-to-one association to IntervenienteVersaoProposta.
	 */
	@OneToMany(mappedBy = MAPPED_BY)
	private List<IntervenienteVersaoProposta> intervenienteVersaoPropostas;

	/** The vencimento fatura transport versao proposta. */
	@OneToMany(mappedBy = MAPPED_BY)
	private List<VencimentoFaturaTransporteVersaoProposta> vencimentoFaturaTransportVersaoProposta;

	/**
	 * bi-directional many-to-one association to ItemVersaoProposta.
	 */
	@OneToMany(mappedBy = MAPPED_BY)
	private List<ItemVersaoProposta> itemVersaoPropostas;

	/**
	 * bi-directional many-to-one association to PendenciaVersaoProposta.
	 */
	@OneToMany(mappedBy = MAPPED_BY)
	private List<PendenciaVersaoProposta> pendenciaVersaoPropostas;

	/**
	 * bi-directional many-to-one association to PagadorVersaoProposta.
	 */
	@OneToMany(mappedBy = MAPPED_BY)
	private List<PagadorVersaoProposta> pagadorVersaoPropostas;

	/**
	 * bi-directional many-to-one association to StatusVersaoProposta.
	 */
	@OneToMany(mappedBy = MAPPED_BY)
	private List<StatusVersaoProposta> statusVersaoPropostas;

	/**
	 * bi-directional many-to-one association to corretorVersaoPropostas.
	 */
	@OneToMany(mappedBy = MAPPED_BY)
	private List<CorretorVersaoProposta> corretorVersaoPropostas;

	/** The solicitacao cartao credito. */
	// bi-directional many-to-one association to Reemcrdcrtsol
	@OneToMany(mappedBy = MAPPED_BY)
	private List<SolicitacaoCartaoCredito> solicitacaoCartaoCredito;

	/**
	 * Mapping field name for flagPossuiTituloCapitalizacao.
	 */
	@Column(name = "CPTTITPSIFLG", nullable = false, length = 1)
	private String flagPossuiTituloCapitalizacao;

	/**
	 * Mapping field name for numeroSorteTituloCapitalizacao.
	 */
	@Column(name = "CPTTITSORNUM", nullable = true, length = 18)
	private Long numeroSorteTituloCapitalizacao;

	/**
	 * numero sequencia registro titulo capitalizacao.
	 */
	@Column(name = "cpttitregseqnum", nullable = true)
	private Long numeroSequenciaRegistroTituloCapitalizacao;

	/**
	 * flagSolicitacaoCartaoCredito.
	 */
	@Column(name = "crdcrtsolflg", nullable = false, length = 1)
	private String flagSolicitacaoCartaoCredito;

	/** NumeroApolice. */
	@Transient
	private transient BigInteger numeroApolice;

	/**
	 * Mapping field name for oldNumeroProposta.
	 */
	@Transient
	private transient Long oldNumeroProposta = null;

	/**
	 * Mapping field name for oldNumeroVersaoProposta.
	 */
	@Transient
	private transient Long oldNumeroVersaoProposta = null;

	/** SM 760 - Codigo Sucursal protocolo, que pode vim via canal PevWeb. */
	@Transient
	private transient BigInteger codigoSucursalProtocolo;

	/** SM 760 - Codigo Setor protocolo, que pode vim via canal PevWeb. */
	@Transient
	private transient BigInteger codigoSetorProtocolo;

	/** The codigo tipo destinario. */
	@Column(name = "DSTTIPCOD", nullable = true, length = 5)
	private Short codigoTipoDestinario;

	/** The integracao subvencao lista. */
	// bi-directional many-to-one association to IntegracaoSubvencao
	@OneToMany(mappedBy = VERSAO_PROPOSTA)
	private List<LogIntegracaoSubvencao> integracaoSubvencaoLista;

	// bi-directional many-to-one association to
	/** The subvencao pessoa seguro list. */
	// SubvencaoPessoaSeguroVersaoProposta
	@OneToMany(mappedBy = VERSAO_PROPOSTA)
	private List<SubvencaoPessoaSeguroVersaoProposta> subvencaoPessoaSeguroList;

	/**
	 * Mapping field name for oldNumeroVersaoProposta.
	 */
	@Transient
	private SubvencaoCorretorVersaoProposta subvencaoCorretorVersaoProposta;

	/**
	 * Mapping field name for flagPossuiBeneficiario.
	 */
	@Column(name = "JURCBRFLG", nullable = false, length = 1)
	private String flagCobrancaJuro;

	/**
	 * One-to-many association to SolicitacaoResgatePontoCartaoCredito.
	 */
	@OneToMany(mappedBy = VERSAO_PROPOSTA)
	private List<SolicitacaoResgatePontoCartaoCredito> solicitacaoResgatePonto;

	/**
	 * Getter method for versaoPropostaPK.
	 *
	 * @return the id.
	 */
	public VersaoPropostaPK getIdentificador() {
		return identificador;
	}

	/**
	 * Setter method for versaoPropostaPK.
	 *
	 * @param identificador
	 *            the versaoPropostaPK to set.
	 */
	public void setIdentificador(final VersaoPropostaPK identificador) {
		this.identificador = identificador;
	}

	/**
	 * Gets the frequencia fatoramento.
	 *
	 * @return the frequencia fatoramento
	 */
	public FrequenciaFatoramento getFrequenciaFatoramento() {
		return frequenciaFatoramento;
	}

	/**
	 * Sets the frequencia fatoramento.
	 *
	 * @param frequenciaFatoramento
	 *            the new frequencia fatoramento
	 */
	public void setFrequenciaFatoramento(final FrequenciaFatoramento frequenciaFatoramento) {
		this.frequenciaFatoramento = frequenciaFatoramento;
	}

	/**
	 * Getter method for dataUltimaAlteracao.
	 *
	 * @return the dataUltimaAlteracao.
	 */
	public Date getDataUltimaAlteracao() {
		Date dataUltimaAlteracao = null;
		if (this.dataUltimaAlteracao != null) {
			dataUltimaAlteracao = (Date) this.dataUltimaAlteracao.clone();
		}
		return dataUltimaAlteracao;
	}

	/**
	 * Setter method for dataUltimaAlteracao.
	 *
	 * @param dataUltimaAlteracao
	 *            the dataUltimaAlteracao to set.
	 */
	public void setDataUltimaAlteracao(final Date dataUltimaAlteracao) {
		if (!(dataUltimaAlteracao == null)) {
			this.dataUltimaAlteracao = (Date) dataUltimaAlteracao.clone();
		}
	}

	/**
	 * Getter method for codigoEmpresaUsuarioUltimaAlteracao.
	 *
	 * @return the codigoEmpresaUsuarioUltimaAlteracao.
	 */
	public String getCodigoEmpresaUsuarioUltimaAlteracao() {
		return codigoEmpresaUsuarioUltimaAlteracao;
	}

	/**
	 * Setter method for codigoEmpresaUsuarioUltimaAlteracao.
	 *
	 * @param codigoEmpresaUsuarioUltimaAlteracao
	 *            the codigoEmpresaUsuarioUltimaAlteracao to set.
	 */
	public void setCodigoEmpresaUsuarioUltimaAlteracao(final String codigoEmpresaUsuarioUltimaAlteracao) {
		this.codigoEmpresaUsuarioUltimaAlteracao = codigoEmpresaUsuarioUltimaAlteracao;
	}

	/**
	 * Getter method for codigoMatriculaUsuarioUltimaAlteracao.
	 *
	 * @return the codigoMatriculaUsuarioUltimaAlteracao.
	 */
	public String getCodigoMatriculaUsuarioUltimaAlteracao() {
		return codigoMatriculaUsuarioUltimaAlteracao;
	}

	/**
	 * Setter method for codigoMatriculaUsuarioUltimaAlteracao.
	 *
	 * @param codigoMatriculaUsuarioUltimaAlteracao
	 *            the codigoMatriculaUsuarioUltimaAlteracao to set.
	 */
	public void setCodigoMatriculaUsuarioUltimaAlteracao(final String codigoMatriculaUsuarioUltimaAlteracao) {
		this.codigoMatriculaUsuarioUltimaAlteracao = codigoMatriculaUsuarioUltimaAlteracao;
	}

	/**
	 * Getter method for codigoTipoUsuarioUltimaAlteracao.
	 *
	 * @return the codigoTipoUsuarioUltimaAlteracao.
	 */
	public String getCodigoTipoUsuarioUltimaAlteracao() {
		return codigoTipoUsuarioUltimaAlteracao;
	}

	/**
	 * Setter method for codigoTipoUsuarioUltimaAlteracao.
	 *
	 * @param codigoTipoUsuarioUltimaAlteracao
	 *            the codigoTipoUsuarioUltimaAlteracao to set.
	 */
	public void setCodigoTipoUsuarioUltimaAlteracao(final String codigoTipoUsuarioUltimaAlteracao) {
		this.codigoTipoUsuarioUltimaAlteracao = codigoTipoUsuarioUltimaAlteracao;
	}

	/**
	 * Getter method for numeroPropostaAutomovel.
	 *
	 * @return the numeroPropostaAutomovel.
	 */
	public String getNumeroPropostaAutomovel() {
		return numeroPropostaAutomovel;
	}

	/**
	 * Setter method for numeroPropostaAutomovel.
	 *
	 * @param numeroPropostaAutomovel
	 *            the numeroPropostaAutomovel to set.
	 */
	public void setNumeroPropostaAutomovel(final String numeroPropostaAutomovel) {
		this.numeroPropostaAutomovel = numeroPropostaAutomovel;
	}

	/**
	 * Getter method for flagPossuiBeneficiario.
	 *
	 * @return the flagPossuiBeneficiario.
	 */
	public String getFlagPossuiBeneficiario() {
		return flagPossuiBeneficiario;
	}

	/**
	 * Setter method for flagPossuiBeneficiario.
	 *
	 * @param flagPossuiBeneficiario
	 *            the flagPossuiBeneficiario to set.
	 */
	public void setFlagPossuiBeneficiario(final String flagPossuiBeneficiario) {
		this.flagPossuiBeneficiario = flagPossuiBeneficiario;
	}

	/**
	 * Getter method for flagEnvioEmailCorretor.
	 *
	 * @return the flagEnvioEmailCorretor.
	 */
	public String getFlagEnvioEmailCorretor() {
		return flagEnvioEmailCorretor;
	}

	/**
	 * Setter method for flagEnvioEmailCorretor.
	 *
	 * @param flagEnvioEmailCorretor
	 *            the flagEnvioEmailCorretor to set.
	 */
	public void setFlagEnvioEmailCorretor(final String flagEnvioEmailCorretor) {
		this.flagEnvioEmailCorretor = flagEnvioEmailCorretor;
	}

	/**
	 * Getter method for flagEnvioEmailImobiliaria.
	 *
	 * @return the flagEnvioEmailImobiliaria.
	 */
	public String getFlagEnvioEmailImobiliaria() {
		return flagEnvioEmailImobiliaria;
	}

	/**
	 * Setter method for flagEnvioEmailImobiliaria.
	 *
	 * @param flagEnvioEmailImobiliaria
	 *            the flagEnvioEmailImobiliaria to set.
	 */
	public void setFlagEnvioEmailImobiliaria(final String flagEnvioEmailImobiliaria) {
		this.flagEnvioEmailImobiliaria = flagEnvioEmailImobiliaria;
	}

	/**
	 * Getter method for flagPrimeiraCompraCartaoEmpresa.
	 *
	 * @return the flagPrimeiraCompraCartaoEmpresa.
	 */
	public String getFlagPrimeiraCompraCartaoEmpresa() {
		return flagPrimeiraCompraCartaoEmpresa;
	}

	/**
	 * Setter method for flagPrimeiraCompraCartaoEmpresa.
	 *
	 * @param flagPrimeiraCompraCartaoEmpresa
	 *            the flagPrimeiraCompraCartaoEmpresa to set.
	 */
	public void setFlagPrimeiraCompraCartaoEmpresa(final String flagPrimeiraCompraCartaoEmpresa) {
		this.flagPrimeiraCompraCartaoEmpresa = flagPrimeiraCompraCartaoEmpresa;
	}

	/**
	 * Getter method for dataEmissao.
	 *
	 * @return the dataEmissao.
	 */
	public Date getDataEmissao() {

		Date dataEmissao = null;

		if (this.dataEmissao != null) {
			dataEmissao = (Date) this.dataEmissao.clone();
		}

		return dataEmissao;
	}

	/**
	 * Setter method for dataEmissao.
	 *
	 * @param dataEmissao
	 *            the dataEmissao to set.
	 */
	public void setDataEmissao(final Date dataEmissao) {
		if (dataEmissao == null) {
			// Para criacao de uma proposta de endosso a data emissao deve ser
			// null.
			this.dataEmissao = null;
		} else {
			this.dataEmissao = (Date) dataEmissao.clone();
		}
	}

	/**
	 * Getter method for dataMelhorDataPrimeiraParcela.
	 *
	 * @return the dataMelhorDataPrimeiraParcela.
	 */
	public Date getDataMelhorDataPrimeiraParcela() {

		Date dataMelhorDataPrimeiraParcela = null;

		if (this.dataMelhorDataPrimeiraParcela != null) {
			dataMelhorDataPrimeiraParcela = (Date) this.dataMelhorDataPrimeiraParcela.clone();
		}

		return dataMelhorDataPrimeiraParcela;
	}

	/**
	 * Setter method for dataMelhorDataPrimeiraParcela.
	 *
	 * @param dataMelhorDataPrimeiraParcela
	 *            the dataMelhorDataPrimeiraParcela to set.
	 */
	public void setDataMelhorDataPrimeiraParcela(final Date dataMelhorDataPrimeiraParcela) {
		if (!(dataMelhorDataPrimeiraParcela == null)) {
			this.dataMelhorDataPrimeiraParcela = (Date) dataMelhorDataPrimeiraParcela.clone();
		}
	}

	/**
	 * Getter method for dataProtocolo.
	 *
	 * @return the dataProtocolo.
	 */
	public Date getDataProtocolo() {

		Date dataProtocolo = null;

		if (this.dataProtocolo != null) {
			dataProtocolo = (Date) this.dataProtocolo.clone();
		}

		return dataProtocolo;
	}

	/**
	 * Setter method for dataProtocolo.
	 *
	 * @param dataProtocolo
	 *            the dataProtocolo to set.
	 */
	public void setDataProtocolo(final Date dataProtocolo) {
		if (dataProtocolo == null) {
			// Para criacao de uma proposta de endosso a data protocolo deve ser
			// null.
			this.dataProtocolo = null;
		} else {
			this.dataProtocolo = (Date) dataProtocolo.clone();
		}
	}

	// /**
	// * Getter method for codigoTipoDistribuicaoPagamento.
	// *
	// * @return the codigoTipoDistribuicaoPagamento.
	// */
	// public BigDecimal getCodigoTipoDistribuicaoPagamento() {
	// return codigoTipoDistribuicaoPagamento;
	// }
	//
	// /**
	// * Setter method for codigoTipoDistribuicaoPagamento.
	// *
	// * @param codigoTipoDistribuicaoPagamento
	// * the codigoTipoDistribuicaoPagamento to set.
	// */
	// public void setCodigoTipoDistribuicaoPagamento(
	// final BigDecimal codigoTipoDistribuicaoPagamento) {
	// this.codigoTipoDistribuicaoPagamento = codigoTipoDistribuicaoPagamento;
	// }

	/**
	 * Gets the forma pagamento.
	 *
	 * @return formaPagamento
	 */
	public FormaPagamento getFormaPagamento() {
		return formaPagamento;
	}

	/**
	 * Set Forma Pagamento.
	 *
	 * @param formaPagamento
	 *            - the formaPagamento
	 */
	public void setFormaPagamento(final FormaPagamento formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	/**
	 * Getter method for flagPossuiCorretorSecundario.
	 *
	 * @return the flagPossuiCorretorSecundario.
	 */
	public String getFlagPossuiCorretorSecundario() {
		return flagPossuiCorretorSecundario;
	}

	/**
	 * Setter method for flagPossuiCorretorSecundario.
	 *
	 * @param flagPossuiCorretorSecundario
	 *            the flagPossuiCorretorSecundario to set.
	 */
	public void setFlagPossuiCorretorSecundario(final String flagPossuiCorretorSecundario) {
		this.flagPossuiCorretorSecundario = flagPossuiCorretorSecundario;
	}

	/**
	 * Getter method for flagPossuiSinistro.
	 *
	 * @return the flagPossuiSinistro.
	 */
	public String getFlagPossuiSinistro() {
		return flagPossuiSinistro;
	}

	/**
	 * Setter method for flagPossuiSinistro.
	 *
	 * @param flagPossuiSinistro
	 *            the flagPossuiSinistro to set.
	 */
	public void setFlagPossuiSinistro(final String flagPossuiSinistro) {
		this.flagPossuiSinistro = flagPossuiSinistro;
	}

	/**
	 * Getter method for dataFimVigencia.
	 *
	 * @return the dataFimVigencia.
	 */
	public Date getDataFimVigencia() {

		Date dataFimVigencia = null;

		if (this.dataFimVigencia != null) {
			dataFimVigencia = (Date) this.dataFimVigencia.clone();
		}

		return dataFimVigencia;
	}

	/**
	 * Setter method for dataFimVigencia.
	 *
	 * @param dataFimVigencia
	 *            the dataFimVigencia to set.
	 */
	public void setDataFimVigencia(final Date dataFimVigencia) {
		if (!(dataFimVigencia == null)) {
			this.dataFimVigencia = (Date) dataFimVigencia.clone();
		}
	}

	/**
	 * Getter method for dataInicioVigencia.
	 *
	 * @return the dataInicioVigencia.
	 */
	public Date getDataInicioVigencia() {

		Date dataInicioVigencia = null;

		if (this.dataInicioVigencia != null) {
			dataInicioVigencia = (Date) this.dataInicioVigencia.clone();
		}

		return dataInicioVigencia;
	}

	/**
	 * Setter method for dataInicioVigencia.
	 *
	 * @param dataInicioVigencia
	 *            the dataInicioVigencia to set.
	 */
	public void setDataInicioVigencia(final Date dataInicioVigencia) {
		if (!(dataInicioVigencia == null)) {
			this.dataInicioVigencia = (Date) dataInicioVigencia.clone();
		}
	}

	// /**
	// * @return the codigoTipoOrganizacao
	// */
	// public Long getCodigoTipoOrganizacao() {
	// return codigoTipoOrganizacao;
	// }
	//
	// /**
	// * @param codigoTipoOrganizacao the codigoTipoOrganizacao to set
	// */
	// public void setCodigoTipoOrganizacao(final Long codigoTipoOrganizacao) {
	// this.codigoTipoOrganizacao = codigoTipoOrganizacao;
	// }

	/**
	 * Gets the flag renovacao automatico.
	 *
	 * @return the flagRenovacaoAutomatico
	 */
	public String getFlagRenovacaoAutomatico() {
		return flagRenovacaoAutomatico;
	}

	/**
	 * Sets the flag renovacao automatico.
	 *
	 * @param flagRenovacaoAutomatico
	 *            the flagRenovacaoAutomatico to set
	 */
	public void setFlagRenovacaoAutomatico(final String flagRenovacaoAutomatico) {
		this.flagRenovacaoAutomatico = flagRenovacaoAutomatico;
	}

	/**
	 * Gets the nome processo sistema gerenciamento processo.
	 *
	 * @return the nomeProcessoSistemaGerenciamentoProcesso
	 */
	public String getNomeProcessoSistemaGerenciamentoProcesso() {
		return nomeProcessoSistemaGerenciamentoProcesso;
	}

	/**
	 * Sets the nome processo sistema gerenciamento processo.
	 *
	 * @param nomeProcessoSistemaGerenciamentoProcesso
	 *            the nomeProcessoSistemaGerenciamentoProcesso to set
	 */
	public void setNomeProcessoSistemaGerenciamentoProcesso(final String nomeProcessoSistemaGerenciamentoProcesso) {
		this.nomeProcessoSistemaGerenciamentoProcesso = nomeProcessoSistemaGerenciamentoProcesso;
	}

	/**
	 * Gets the flag bloqueio.
	 *
	 * @return the flagBloqueio
	 */
	public String getFlagBloqueio() {
		return flagBloqueio;
	}

	/**
	 * Sets the flag bloqueio.
	 *
	 * @param flagBloqueio
	 *            the flagBloqueio to set
	 */
	public void setFlagBloqueio(final String flagBloqueio) {
		this.flagBloqueio = flagBloqueio;
	}

	/**
	 * Gets the flag endosso alteracao dado cadastral segurado.
	 *
	 * @return the flagEndossoAlteracaoDadoCadastralSegurado
	 */
	public String getFlagEndossoAlteracaoDadoCadastralSegurado() {
		return flagEndossoAlteracaoDadoCadastralSegurado;
	}

	/**
	 * Sets the flag endosso alteracao dado cadastral segurado.
	 *
	 * @param flagEndossoAlteracaoDadoCadastralSegurado
	 *            the flagEndossoAlteracaoDadoCadastralSegurado to set
	 */
	public void setFlagEndossoAlteracaoDadoCadastralSegurado(final String flagEndossoAlteracaoDadoCadastralSegurado) {
		this.flagEndossoAlteracaoDadoCadastralSegurado = flagEndossoAlteracaoDadoCadastralSegurado;
	}

	/**
	 * Gets the data bloqueio.
	 *
	 * @return the dataBloqueio
	 */
	public Date getDataBloqueio() {

		Date dataBloqueio = null;

		if (this.dataBloqueio != null) {
			dataBloqueio = (Date) this.dataBloqueio.clone();
		}

		return dataBloqueio;
	}

	/**
	 * Sets the data bloqueio.
	 *
	 * @param dataBloqueio
	 *            the dataBloqueio to set
	 */
	public void setDataBloqueio(final Date dataBloqueio) {
		if (!(dataBloqueio == null)) {
			this.dataBloqueio = (Date) dataBloqueio.clone();
		}
	}

	/**
	 * Gets the codigo tipo usuario bloqueio.
	 *
	 * @return the codigoTipoUsuarioBloqueio
	 */
	public String getCodigoTipoUsuarioBloqueio() {
		return codigoTipoUsuarioBloqueio;
	}

	/**
	 * Sets the codigo tipo usuario bloqueio.
	 *
	 * @param codigoTipoUsuarioBloqueio
	 *            the codigoTipoUsuarioBloqueio to set
	 */
	public void setCodigoTipoUsuarioBloqueio(final String codigoTipoUsuarioBloqueio) {
		this.codigoTipoUsuarioBloqueio = codigoTipoUsuarioBloqueio;
	}

	/**
	 * Gets the codigo empresa usuario bloqueio.
	 *
	 * @return the codigoEmpresaUsuarioBloqueio
	 */
	public String getCodigoEmpresaUsuarioBloqueio() {
		return codigoEmpresaUsuarioBloqueio;
	}

	/**
	 * Sets the codigo empresa usuario bloqueio.
	 *
	 * @param codigoEmpresaUsuarioBloqueio
	 *            the codigoEmpresaUsuarioBloqueio to set
	 */
	public void setCodigoEmpresaUsuarioBloqueio(final String codigoEmpresaUsuarioBloqueio) {
		this.codigoEmpresaUsuarioBloqueio = codigoEmpresaUsuarioBloqueio;
	}

	/**
	 * Gets the codigo matricula usuario bloqueio.
	 *
	 * @return the codigoMatriculaUsuarioBloqueio
	 */
	public String getCodigoMatriculaUsuarioBloqueio() {
		return codigoMatriculaUsuarioBloqueio;
	}

	/**
	 * Sets the codigo matricula usuario bloqueio.
	 *
	 * @param codigoMatriculaUsuarioBloqueio
	 *            the codigoMatriculaUsuarioBloqueio to set
	 */
	public void setCodigoMatriculaUsuarioBloqueio(final String codigoMatriculaUsuarioBloqueio) {
		this.codigoMatriculaUsuarioBloqueio = codigoMatriculaUsuarioBloqueio;
	}

	/**
	 * Getter method for apolices.
	 *
	 * @return the apolices.
	 */
	public List<Apolice> getApolices() {
		return apolices;
	}

	/**
	 * Setter method for apolices.
	 *
	 * @param apolices
	 *            the apolices to set.
	 */
	public void setApolices(final List<Apolice> apolices) {
		this.apolices = apolices;
	}

	/**
	 * Getter method for solicitacaoCartas.
	 *
	 * @return the solicitacaoCartas.
	 */
	public List<SolicitacaoCarta> getSolicitacaoCartas() {
		return solicitacaoCartas;
	}

	/**
	 * Setter method for solicitacaoCartas.
	 *
	 * @param solicitacaoCartas
	 *            the solicitacaoCartas to set.
	 */
	public void setSolicitacaoCartas(final List<SolicitacaoCarta> solicitacaoCartas) {
		this.solicitacaoCartas = solicitacaoCartas;
	}

	/**
	 * Getter method for documentoSolicitacaoSegundoViaDocumentos.
	 *
	 * @return the documentoSolicitacaoSegundoViaDocumentos.
	 */
	public List<DocumentoSolicitacaoSegundoViaDocumento> getDocumentoSolicitacaoSegundoViaDocumentos() {
		return documentoSolicitacaoSegundoViaDocumentos;
	}

	/**
	 * Setter method for documentoSolicitacaoSegundoViaDocumentos.
	 *
	 * @param documentoSolicitacaoSegundoViaDocumentos
	 *            the documentoSolicitacaoSegundoViaDocumentos to set.
	 */
	public void setDocumentoSolicitacaoSegundoViaDocumentos(
		final List<DocumentoSolicitacaoSegundoViaDocumento> documentoSolicitacaoSegundoViaDocumentos) {
		this.documentoSolicitacaoSegundoViaDocumentos = documentoSolicitacaoSegundoViaDocumentos;
	}

	/**
	 * Getter method for versaoOrcamento.
	 *
	 * @return the versaoOrcamento.
	 */
	public VersaoOrcamento getVersaoOrcamento() {
		return versaoOrcamento;
	}

	/**
	 * Setter method for versaoOrcamento.
	 *
	 * @param versaoOrcamento
	 *            the versaoOrcamento to set.
	 */
	public void setVersaoOrcamento(final VersaoOrcamento versaoOrcamento) {
		this.versaoOrcamento = versaoOrcamento;
	}

	/**
	 * Getter method for proposta.
	 *
	 * @return the proposta.
	 */
	public Proposta getProposta() {
		return proposta;
	}

	/**
	 * Setter method for proposta.
	 *
	 * @param proposta
	 *            the proposta to set.
	 */
	public void setProposta(final Proposta proposta) {
		this.proposta = proposta;
	}

	/**
	 * Getter Method for codigoEnderecoCorrespondencia.
	 *
	 * @return the codigoEnderecoCorrespondencia
	 */
	public Long getCodigoEnderecoCorrespondencia() {
		return codigoEnderecoCorrespondencia;
	}

	/**
	 * Setter Method for codigoEnderecoCorrespondencia.
	 *
	 * @param codigoEnderecoCorrespondencia
	 *            the codigoEnderecoCorrespondencia to set
	 */
	public void setCodigoEnderecoCorrespondencia(final Long codigoEnderecoCorrespondencia) {
		this.codigoEnderecoCorrespondencia = codigoEnderecoCorrespondencia;
	}

	/**
	 * Getter method for analiseVersaoPropostas.
	 *
	 * @return the analiseVersaoPropostas.
	 */
	public List<AnaliseVersaoProposta> getAnaliseVersaoPropostas() {
		return analiseVersaoPropostas;
	}

	/**
	 * Setter method for analiseVersaoPropostas.
	 *
	 * @param analiseVersaoPropostas
	 *            the analiseVersaoPropostas to set.
	 */
	public void setAnaliseVersaoPropostas(final List<AnaliseVersaoProposta> analiseVersaoPropostas) {
		this.analiseVersaoPropostas = analiseVersaoPropostas;
	}

	/**
	 * Getter method for beneficiarioVersaoPropostas.
	 *
	 * @return the beneficiarioVersaoPropostas.
	 */
	public List<BeneficiarioVersaoProposta> getBeneficiarioVersaoPropostas() {
		return beneficiarioVersaoPropostas;
	}

	/**
	 * Setter method for beneficiarioVersaoPropostas.
	 *
	 * @param beneficiarioVersaoPropostas
	 *            the beneficiarioVersaoPropostas to set.
	 */
	public void setBeneficiarioVersaoPropostas(final List<BeneficiarioVersaoProposta> beneficiarioVersaoPropostas) {
		this.beneficiarioVersaoPropostas = beneficiarioVersaoPropostas;
	}

	/**
	 * Getter method for criticaVersaoPropostas.
	 *
	 * @return the criticaVersaoPropostas.
	 */
	public List<CriticaSeguroVersaoProposta> getCriticaVersaoPropostas() {
		return criticaVersaoPropostas;
	}

	/**
	 * Setter method for criticaVersaoPropostas.
	 *
	 * @param criticaVersaoPropostas
	 *            the criticaVersaoPropostas to set.
	 */
	public void setCriticaVersaoPropostas(final List<CriticaSeguroVersaoProposta> criticaVersaoPropostas) {
		this.criticaVersaoPropostas = criticaVersaoPropostas;
	}

	/**
	 * Getter method for intervenienteVersaoPropostas.
	 *
	 * @return the intervenienteVersaoPropostas.
	 */
	public List<IntervenienteVersaoProposta> getIntervenienteVersaoPropostas() {
		return intervenienteVersaoPropostas;
	}

	/**
	 * Setter method for intervenienteVersaoPropostas.
	 *
	 * @param intervenienteVersaoPropostas
	 *            the intervenienteVersaoPropostas to set.
	 */
	public void setIntervenienteVersaoPropostas(final List<IntervenienteVersaoProposta> intervenienteVersaoPropostas) {
		this.intervenienteVersaoPropostas = intervenienteVersaoPropostas;
	}

	/**
	 * Getter method for itemVersaoPropostas.
	 *
	 * @return the itemVersaoPropostas.
	 */
	public List<ItemVersaoProposta> getItemVersaoPropostas() {
		return itemVersaoPropostas;
	}

	/**
	 * Setter method for itemVersaoPropostas.
	 *
	 * @param itemVersaoPropostas
	 *            the itemVersaoPropostas to set.
	 */
	public void setItemVersaoPropostas(final List<ItemVersaoProposta> itemVersaoPropostas) {
		this.itemVersaoPropostas = itemVersaoPropostas;
	}

	/**
	 * Getter method for pendenciaVersaoPropostas.
	 *
	 * @return the pendenciaVersaoPropostas.
	 */
	public List<PendenciaVersaoProposta> getPendenciaVersaoPropostas() {
		return pendenciaVersaoPropostas;
	}

	/**
	 * Setter method for pendenciaVersaoPropostas.
	 *
	 * @param pendenciaVersaoPropostas
	 *            the pendenciaVersaoPropostas to set.
	 */
	public void setPendenciaVersaoPropostas(final List<PendenciaVersaoProposta> pendenciaVersaoPropostas) {
		this.pendenciaVersaoPropostas = pendenciaVersaoPropostas;
	}

	/**
	 * Getter method for pagadorVersaoPropostas.
	 *
	 * @return the pagadorVersaoPropostas.
	 */
	public List<PagadorVersaoProposta> getPagadorVersaoPropostas() {
		return pagadorVersaoPropostas;
	}

	/**
	 * Setter method for pagadorVersaoPropostas.
	 *
	 * @param pagadorVersaoPropostas
	 *            the pagadorVersaoPropostas to set.
	 */
	public void setPagadorVersaoPropostas(final List<PagadorVersaoProposta> pagadorVersaoPropostas) {
		this.pagadorVersaoPropostas = pagadorVersaoPropostas;
	}

	/**
	 * Getter method for statusVersaoPropostas.
	 *
	 * @return the statusVersaoPropostas.
	 */
	public List<StatusVersaoProposta> getStatusVersaoPropostas() {
		return statusVersaoPropostas;
	}

	/**
	 * Setter method for statusVersaoPropostas.
	 *
	 * @param statusVersaoPropostas
	 *            the statusVersaoPropostas to set.
	 */
	public void setStatusVersaoPropostas(final List<StatusVersaoProposta> statusVersaoPropostas) {
		this.statusVersaoPropostas = statusVersaoPropostas;
	}

	/**
	 * Getter method for corretorVersaoPropostas.
	 *
	 * @return the corretorVersaoPropostas.
	 */
	public List<CorretorVersaoProposta> getCorretorVersaoPropostas() {
		return corretorVersaoPropostas;
	}

	/**
	 * Setter method for corretorVersaoPropostas.
	 *
	 * @param corretorVersaoPropostas
	 *            the corretorVersaoPropostas to set.
	 */
	public void setCorretorVersaoPropostas(final List<CorretorVersaoProposta> corretorVersaoPropostas) {
		this.corretorVersaoPropostas = corretorVersaoPropostas;
	}

	// /**
	// * @return the respostaPendenciaVersaoPropostas
	// */
	// public List<RespostaPendenciaVersaoProposta>
	// getRespostaPendenciaVersaoPropostas() {
	// return respostaPendenciaVersaoPropostas;
	// }
	//
	// /**
	// * @param respostaPendenciaVersaoPropostas the
	// respostaPendenciaVersaoPropostas to set
	// */
	// public void setRespostaPendenciaVersaoPropostas(
	// final List<RespostaPendenciaVersaoProposta>
	// respostaPendenciaVersaoPropostas) {
	// this.respostaPendenciaVersaoPropostas = respostaPendenciaVersaoPropostas;
	// }

	/**
	 * Getter method for flagPossuiTituloCapitalizacao.
	 *
	 * @return the flagPossuiTituloCapitalizacao.
	 */
	public String getFlagPossuiTituloCapitalizacao() {
		return flagPossuiTituloCapitalizacao;
	}

	/**
	 * Setter method for flagPossuiTituloCapitalizacao.
	 *
	 * @param flagPossuiTituloCapitalizacao
	 *            the flagPossuiTituloCapitalizacao to set.
	 */
	public void setFlagPossuiTituloCapitalizacao(final String flagPossuiTituloCapitalizacao) {
		this.flagPossuiTituloCapitalizacao = flagPossuiTituloCapitalizacao;
	}

	/**
	 * Getter method for numeroSorteTituloCapitalizacao.
	 *
	 * @return the numeroSorteTituloCapitalizacao.
	 */
	public Long getNumeroSorteTituloCapitalizacao() {
		return numeroSorteTituloCapitalizacao;
	}

	/**
	 * Setter method for numeroSorteTituloCapitalizacao.
	 *
	 * @param numeroSorteTituloCapitalizacao
	 *            the numeroSorteTituloCapitalizacao to set.
	 */
	public void setNumeroSorteTituloCapitalizacao(final Long numeroSorteTituloCapitalizacao) {
		this.numeroSorteTituloCapitalizacao = numeroSorteTituloCapitalizacao;
	}

	/**
	 * Get numeroApolice.
	 *
	 * @return the numeroApolice
	 */
	public BigInteger getNumeroApolice() {
		return numeroApolice;
	}

	/**
	 * Set numeroApolice.
	 *
	 * @param numeroApolice
	 *            the numeroApolice to set
	 */
	public void setNumeroApolice(final BigInteger numeroApolice) {
		this.numeroApolice = numeroApolice;
	}

	/**
	 * Getter method for oldNumeroProposta.
	 *
	 * @return oldNumeroProposta
	 */
	public Long getOldNumeroProposta() {
		return oldNumeroProposta;
	}

	/**
	 * Setter method for oldNumeroProposta.
	 *
	 * @param oldNumeroProposta
	 *            parameter
	 */
	public void setOldNumeroProposta(final Long oldNumeroProposta) {
		this.oldNumeroProposta = oldNumeroProposta;
	}

	/**
	 * Getter method for oldNumeroVersaoProposta.
	 *
	 * @return oldNumeroVersaoProposta
	 */
	public Long getOldNumeroVersaoProposta() {
		return oldNumeroVersaoProposta;
	}

	/**
	 * Gets the codigo prazo averbacao.
	 *
	 * @return the codigo prazo averbacao
	 */
	public Integer getCodigoPrazoAverbacao() {
		return codigoPrazoAverbacao;
	}

	/**
	 * Sets the codigo prazo averbacao.
	 *
	 * @param codigoPrazoAverbacao
	 *            the new codigo prazo averbacao
	 */
	public void setCodigoPrazoAverbacao(final Integer codigoPrazoAverbacao) {
		this.codigoPrazoAverbacao = codigoPrazoAverbacao;
	}

	/**
	 * Setter method for oldNumeroVersaoProposta.
	 *
	 * @param oldNumeroVersaoProposta
	 *            parameter
	 */
	public void setOldNumeroVersaoProposta(final Long oldNumeroVersaoProposta) {
		this.oldNumeroVersaoProposta = oldNumeroVersaoProposta;
	}

	/**
	 * Gets the codigo tipo destinario.
	 *
	 * @return the codigo tipo destinario
	 */
	public Short getCodigoTipoDestinario() {
		return codigoTipoDestinario;
	}

	/**
	 * Get numeroSequenciaRegistroTituloCapitalizacao.
	 * 
	 * @return numeroSequenciaRegistroTituloCapitalizacao
	 */
	public Long getNumeroSequenciaRegistroTituloCapitalizacao() {
		return numeroSequenciaRegistroTituloCapitalizacao;
	}

	/**
	 * Set numeroSequenciaRegistroTituloCapitalizacao.
	 *
	 * @param numeroSequenciaRegistroTituloCapitalizacao
	 *            the new numero sequencia registro titulo capitalizacao
	 */
	public void setNumeroSequenciaRegistroTituloCapitalizacao(final Long numeroSequenciaRegistroTituloCapitalizacao) {
		this.numeroSequenciaRegistroTituloCapitalizacao = numeroSequenciaRegistroTituloCapitalizacao;
	}

	/**
	 * Get flagSolicitacaoCartaoCredito.
	 *
	 * @return flagSolicitacaoCartaoCredito
	 */
	public String getFlagSolicitacaoCartaoCredito() {
		return flagSolicitacaoCartaoCredito;
	}

	/**
	 * Set flagSolicitacaoCartaoCredito.
	 *
	 * @param flagSolicitacaoCartaoCredito
	 *            the new flag solicitacao cartao credito
	 */
	public void setFlagSolicitacaoCartaoCredito(final String flagSolicitacaoCartaoCredito) {
		this.flagSolicitacaoCartaoCredito = flagSolicitacaoCartaoCredito;
	}

	/**
	 * Sets the codigo tipo destinario.
	 *
	 * @param codigoTipoDestinario
	 *            the new codigo tipo destinario
	 */
	public void setCodigoTipoDestinario(final Short codigoTipoDestinario) {
		this.codigoTipoDestinario = codigoTipoDestinario;
	}

	/**
	 * get solicitacaoCartaoCredito.
	 *
	 * @return solicitacaoCartaoCredito
	 */
	public List<SolicitacaoCartaoCredito> getSolicitacaoCartaoCredito() {
		return solicitacaoCartaoCredito;
	}

	/**
	 * set solicitacaoCartaoCredito.
	 *
	 * @param solicitacaoCartaoCredito
	 *            the new solicitacao cartao credito
	 */
	public void setSolicitacaoCartaoCredito(final List<SolicitacaoCartaoCredito> solicitacaoCartaoCredito) {
		this.solicitacaoCartaoCredito = solicitacaoCartaoCredito;
	}

	/**
	 * get integracaoSubvencaoLista.
	 * 
	 * @return List<LogIntegracaoSubvencao>
	 */
	public List<LogIntegracaoSubvencao> getIntegracaoSubvencaoLista() {
		return integracaoSubvencaoLista;
	}

	/**
	 * set integracaoSubvencaoLista.
	 *
	 * @param integracaoSubvencaoLista
	 *            the new integracao subvencao lista
	 */
	public void setIntegracaoSubvencaoLista(final List<LogIntegracaoSubvencao> integracaoSubvencaoLista) {
		this.integracaoSubvencaoLista = integracaoSubvencaoLista;
	}

	/**
	 * get subvencaoPessoaSeguroList.
	 * 
	 * @return List<SubvencaoPessoaSeguroVersaoProposta>
	 */
	public List<SubvencaoPessoaSeguroVersaoProposta> getSubvencaoPessoaSeguroList() {
		return subvencaoPessoaSeguroList;
	}

	/**
	 * Gets the data integracao fenseg.
	 *
	 * @return the data integracao fenseg
	 */
	public Date getDataIntegracaoFenseg() {
		Date dataIntegracaoFenseg = null;
		if (this.dataIntegracaoFenseg != null) {
			dataIntegracaoFenseg = (Date) this.dataIntegracaoFenseg.clone();
		}
		return dataIntegracaoFenseg;
	}

	/**
	 * Sets the data integracao fenseg.
	 *
	 * @param dataIntegracaoFenseg
	 *            the new data integracao fenseg
	 */
	@SuppressWarnings("PMD.NullAssignment")
	public void setDataIntegracaoFenseg(final Date dataIntegracaoFenseg) {
		if (dataIntegracaoFenseg == null) {
			this.dataIntegracaoFenseg = null;
		} else {
			this.dataIntegracaoFenseg = (Date) dataIntegracaoFenseg.clone();
		}
	}

	/**
	 * set subvencaoPessoaSeguroList.
	 *
	 * @param subvencaoPessoaSeguroList
	 *            the new subvencao pessoa seguro list
	 */
	public void setSubvencaoPessoaSeguroList(final List<SubvencaoPessoaSeguroVersaoProposta> subvencaoPessoaSeguroList) {
		this.subvencaoPessoaSeguroList = subvencaoPessoaSeguroList;
	}

	/**
	 * Gets the subvencao corretor versao proposta.
	 *
	 * @return the subvencaoCorretorVersaoProposta
	 */
	public SubvencaoCorretorVersaoProposta getSubvencaoCorretorVersaoProposta() {
		return subvencaoCorretorVersaoProposta;
	}

	/**
	 * Sets the subvencao corretor versao proposta.
	 *
	 * @param subvencaoCorretorVersaoProposta
	 *            the subvencaoCorretorVersaoProposta to set
	 */
	public void setSubvencaoCorretorVersaoProposta(final SubvencaoCorretorVersaoProposta subvencaoCorretorVersaoProposta) {
		this.subvencaoCorretorVersaoProposta = subvencaoCorretorVersaoProposta;
	}

	/**
	 * flagCobrancaJuro.
	 * 
	 * @return flagCobrancaJuro.
	 */
	public String getFlagCobrancaJuro() {
		return flagCobrancaJuro;
	}

	/**
	 * setFlagCobrancaJuro.
	 * 
	 * @param flagCobrancaJuro
	 *            param.
	 */
	public void setFlagCobrancaJuro(final String flagCobrancaJuro) {
		this.flagCobrancaJuro = flagCobrancaJuro;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@SuppressWarnings({ "avoidinlineconditionals" })
	@Override
	public int hashCode() {

		final int prime = 31;
		int result = 1;
		result = (prime * result) + ((identificador == null) ? 0 : identificador.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@SuppressWarnings({ "PMD.IfStmtsMustUseBraces", "PMD.OnlyOneReturn", "PMD.MethodArgumentCouldBeFinal", "finalparameters",
	"needbraces" })
	@Override
	public boolean equals(final Object obj) {

		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final VersaoProposta other = (VersaoProposta) obj;
		if (identificador == null) {
			if (other.identificador != null) {
				return false;
			}
		} else if (!identificador.equals(identificador)) {
			return false;
		}
		return true;
	}

	/** Gets the vencimento fatura transport versao proposta.
	 * @return the vencimentoFaturaTransportVersaoProposta */
	public List<VencimentoFaturaTransporteVersaoProposta> getVencimentoFaturaTransportVersaoProposta() {
		return vencimentoFaturaTransportVersaoProposta;
	}

	/** Sets the vencimento fatura transport versao proposta.
	 * @param vencimentoFaturaTransportVersaoProposta the vencimentoFaturaTransportVersaoProposta to set */
	public void setVencimentoFaturaTransportVersaoProposta(
		final List<VencimentoFaturaTransporteVersaoProposta> vencimentoFaturaTransportVersaoProposta) {
		this.vencimentoFaturaTransportVersaoProposta = vencimentoFaturaTransportVersaoProposta;
	}

	/** Gets the codigo tipo organizacao pessoa juridica.
	 * @return the codigo tipo organizacao pessoa juridica */
	public Long getCodigoTipoOrganizacaoPessoaJuridica() {
		return codigoTipoOrganizacaoPessoaJuridica;
	}

	/** Sets the codigo tipo organizacao pessoa juridica.
	 * @param codigoTipoOrganizacaoPessoaJuridica the new codigo tipo organizacao pessoa juridica */
	public void setCodigoTipoOrganizacaoPessoaJuridica(final Long codigoTipoOrganizacaoPessoaJuridica) {
		this.codigoTipoOrganizacaoPessoaJuridica = codigoTipoOrganizacaoPessoaJuridica;
	}

	/**
	 * Codigo Sucursal protocolo, que pode vim via canal PevWeb.
	 * @return the codigoSucursalProtocolo codigo Sucursal Protocolo
	 */
	public BigInteger getCodigoSucursalProtocolo() {
		return codigoSucursalProtocolo;
	}

	/**
	 * Codigo Sucursal protocolo, que pode vim via canal PevWeb.
	 * @param codigoSucursalProtocolo the codigoSucursalProtocolo to set
	 */
	public void setCodigoSucursalProtocolo(final BigInteger codigoSucursalProtocolo) {
		this.codigoSucursalProtocolo = codigoSucursalProtocolo;
	}

	/**
	 * Codigo Setor protocolo, que pode vim via canal PevWeb.
	 * @return the codigoSetorProtocolo
	 */
	public BigInteger getCodigoSetorProtocolo() {
		return codigoSetorProtocolo;
	}

	/**
	 * Codigo Setor protocolo, que pode vim via canal PevWeb.
	 * @param codigoSetorProtocolo the codigoSetorProtocolo to set
	 */
	public void setCodigoSetorProtocolo(final BigInteger codigoSetorProtocolo) {
		this.codigoSetorProtocolo = codigoSetorProtocolo;
	}

	/**
	 * Gets the solicitacao resgate ponto.
	 *
	 * @return the solicitacaoResgatePonto
	 */
	public List<SolicitacaoResgatePontoCartaoCredito> getSolicitacaoResgatePonto() {
		return solicitacaoResgatePonto;
	}

	/**
	 * Sets the solicitacao resgate ponto.
	 *
	 * @param solicitacaoResgatePonto the solicitacaoResgatePonto to set
	 */
	public void setSolicitacaoResgatePonto(
		final List<SolicitacaoResgatePontoCartaoCredito> solicitacaoResgatePonto) {
		this.solicitacaoResgatePonto = solicitacaoResgatePonto;
	}
}

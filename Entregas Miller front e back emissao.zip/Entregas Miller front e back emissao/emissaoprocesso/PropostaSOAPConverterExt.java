/******************************************************************************* 
 * Copyright (c) 2014-2014, 2015 Porto Seguro Seguros S.A., Inc. All Rights Reserved.
 * 
 * Este software contém informações confidenciais e de propriedade da Porto Seguro Seguros S.A.
 * ("Informações Confidenciais"). Você não deve divulgar qualquer tipo de informações confidenciais
 * e deve usá-las apenas, de acordo com os termos do contrato de licença firmado com a Porto Seguro.
 * 
 * A Porto Seguro não faz declarações ou garantias sobre a adequação do software, expressa ou
 * implicitamente, incluindo, mas não se limitando, a garantias de comercialização, adequação para
 * um determinado fim ou qualquer tipo de violação.
 * 
 * A PORTO SEGURO NÃO SERÁ RESPONSÁVEL POR QUAISQUER DANOS SOFRIDOS PELO LICENCIADO EM DECORRÊNCIA
 * DO USO, MODIFICAÇÃO OU DISTRIBUIÇÃO DESTE SOFTWARE OU SEUS DERIVADOS.
 * 
 * 
 * Criado em(Created on): 06/08/2015 Autor(Author) : winnie.arlene.t.dy@accenture.com
 * 
 * ----------------------------------------------------------------------------- Histórico da
 * Revisão (Revision History) - Release 1.0.0
 * ----------------------------------------------------------------------------- VERSÃO DATA AUTOR
 * DESCRIÇÃO DA MUDANÇA (VERSION) (DATE) (AUTHOR) (DESCRIPTION OF CHANGE)
 * ----------------------------------------------------------------------------- 1.0.0 | 06/08/2015
 * | | Criação Inicial (Initial Create)
 * --------|------------|-------------------------|----------------------------------
 * 1.0.0   | 01/07/2016 |  dan.e.s.molenilla      | Criação Inicial (Initial Create)
 *******************************************************************************/
package com.porto.re.emissaoprocesso.converter;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.porto.re.administrativo.entity.MotivoAusenciaCnpjCpf;
import com.porto.re.administrativo.entity.StatusParecer;
import com.porto.re.administrativo.entity.TipoAtualizacao;
import com.porto.re.administrativo.entity.TipoExposicaoPessoa;
import com.porto.re.administrativo.entity.TipoInterveniente;
import com.porto.re.administrativo.entity.TipoParecer;
import com.porto.re.administrativo.entity.TipoPessoa;
import com.porto.re.administrativo.entity.TipoVinculoPessoa;
import com.porto.re.common.AssertUtil;
import com.porto.re.common.CollectionUtils;
import com.porto.re.common.ConvertTypes;
import com.porto.re.common.EmissaoConvertTypes;
import com.porto.re.common.TipoAtualizacaoEnum;
import com.porto.re.emissaocadastro.entity.Devolutiva;
import com.porto.re.emissaoprocesso.converter.interfaces.IOrcamentoSOAPConverter;
import com.porto.re.emissaoprocesso.converter.interfaces.IPropostaSOAPConverterExt;
import com.porto.re.emissaoprocesso.entity.AnaliseVersaoProposta;
import com.porto.re.emissaoprocesso.entity.BeneficiarioVersaoProposta;
import com.porto.re.emissaoprocesso.entity.BeneficiarioVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.CoberturaItemBeneficiarioVersaoProposta;
import com.porto.re.emissaoprocesso.entity.CoberturaItemBeneficiarioVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.CoberturaItemVersaoOrcamento;
import com.porto.re.emissaoprocesso.entity.CoberturaItemVersaoOrcamentoPK;
import com.porto.re.emissaoprocesso.entity.CoberturaItemVersaoProposta;
import com.porto.re.emissaoprocesso.entity.CoberturaItemVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.ComponenteListaItemVersaoProposta;
import com.porto.re.emissaoprocesso.entity.ComponenteListaItemVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.CorretorVersaoProposta;
import com.porto.re.emissaoprocesso.entity.CriticaSeguroItemVersaoProposta;
import com.porto.re.emissaoprocesso.entity.CriticaSeguroItemVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.ExposicaoIntervenienteVersaoProposta;
import com.porto.re.emissaoprocesso.entity.ExposicaoIntervenienteVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.IntervenienteVersaoProposta;
import com.porto.re.emissaoprocesso.entity.IntervenienteVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.ItemVersaoProposta;
import com.porto.re.emissaoprocesso.entity.ItemVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.ListaItemVersaoProposta;
import com.porto.re.emissaoprocesso.entity.ListaItemVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.Orcamento;
import com.porto.re.emissaoprocesso.entity.PagadorParcelaVersaoProposta;
import com.porto.re.emissaoprocesso.entity.PagadorParcelaVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.PagadorVersaoProposta;
import com.porto.re.emissaoprocesso.entity.PagadorVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.PendenciaVersaoProposta;
import com.porto.re.emissaoprocesso.entity.Proposta;
import com.porto.re.emissaoprocesso.entity.RespostaPendenciaVersaoProposta;
import com.porto.re.emissaoprocesso.entity.SolicitacaoResgatePontoCartaoCredito;
import com.porto.re.emissaoprocesso.entity.StatusCriticaSeguroItemVersaoProposta;
import com.porto.re.emissaoprocesso.entity.StatusCriticaSeguroItemVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.VencimentoFaturaTransporteVersaoProposta;
import com.porto.re.emissaoprocesso.entity.VersaoOrcamento;
import com.porto.re.emissaoprocesso.entity.VersaoProposta;
import com.porto.re.exception.EnvironmentException;

import br.com.portoseguro.ramoselementares.emissao.analiseemissaoebo.v1.AnaliseEBO;
import br.com.portoseguro.ramoselementares.emissao.criticaemissaoebo.v1.CriticaEBO;
import br.com.portoseguro.ramoselementares.emissao.criticaemissaoebo.v1.DevolutivaEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.AuditoriaEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.CorretorEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.DiaVencimento;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.DocumentoEmissaoEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ExposicaoEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.IntervenienteEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaAnalisesEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaCorretoresEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaExposicoesEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaHistoricoPagadorParcelaEndossoEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaIntervenientesEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaItemDocumentoEmissaoEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaPagadorParcelaEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaPagadoresEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaPendenciasEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaRespostaPendenciaEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.PagadorEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.PagadorParcelaEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.PendenciaEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.RespostaPendenciaEBO;
import br.com.portoseguro.ramoselementares.emissao.itemdocumentoemissaoebo.v1.BeneficiarioEBO;
import br.com.portoseguro.ramoselementares.emissao.itemdocumentoemissaoebo.v1.BeneficiarioItemDocumentoEBO;
import br.com.portoseguro.ramoselementares.emissao.itemdocumentoemissaoebo.v1.CoberturaItemDocumentoEBO;
import br.com.portoseguro.ramoselementares.emissao.itemdocumentoemissaoebo.v1.CoberturasItemEBO;
import br.com.portoseguro.ramoselementares.emissao.itemdocumentoemissaoebo.v1.ComponenteListaItemEBO;
import br.com.portoseguro.ramoselementares.emissao.itemdocumentoemissaoebo.v1.ComponentesListaItemEBO;
import br.com.portoseguro.ramoselementares.emissao.itemdocumentoemissaoebo.v1.ItemDocumentoEmissaoEBO;
import br.com.portoseguro.ramoselementares.emissao.itemdocumentoemissaoebo.v1.ListaCoberturaItemEBO;
import br.com.portoseguro.ramoselementares.emissao.itemdocumentoemissaoebo.v1.ListaCriticasItensEBO;
import br.com.portoseguro.ramoselementares.emissao.itemdocumentoemissaoebo.v1.ListaItensEBO;
import br.com.portoseguro.ramoselementares.pessoa.enderecoebo.v1.EnderecoEBO;
import br.com.portoseguro.ramoselementares.pessoa.pessoaebo.v1.PessoaEBO;

// TODO: Auto-generated Javadoc
/**
 * DocumentoEmissaoTypeConverter. Type -> Entity and vice versa.
 */
@SuppressWarnings({ "PMD.ExcessiveParameterList", "PMD.ExcessiveImports", "PMD.TooManyMethods","PMD.CyclomaticComplexity",
	"checkstyle:com.puppycrawl.tools.checkstyle.checks.metrics.CyclomaticComplexityCheck"})
@Named
@ApplicationScoped
public class PropostaSOAPConverterExt implements IPropostaSOAPConverterExt {
	
	/**
	 * LOGGER.
	 */
	private final static Logger LOGGER = LoggerFactory.getLogger(PropostaSOAPConverterExt.class.getName());

	/** FLAG_S. */
	private static final String FLAG_S = "S";
	
	/** The Constant NUMERO_UM. */
	private static final Integer NUMERO_UM = 1;
	
	/**
     * DatatypeFactory a ser reusado de forma segura e performatica.
     */
    private static final DatatypeFactory DATATYPE_FACTORY = initilizeDataFactory();
   
    /**
     * DatatypeFactory.newInstance e uma operacao muito pessada.
     * Ela envolve busca no atual classloader por classes.
     * O objetivo desta funcao e suportar o reuso da mesma.
     *
     * @return datatype factory
     */
    private static DatatypeFactory initilizeDataFactory() {
        try {
            return DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException e) {
            throw new EnvironmentException("Erro de inicializacao", e);
        }
    }
	
	/** OrcamentoSoapTypeConverter. */
	@Inject
	private transient IOrcamentoSOAPConverter iOrcamentoSOAPConverter;

	/**
	 * Method used to convert Proposta to Type.
	 * 
	 * @param proposta
	 *            - The proposta object
	 * @param convertedDocumentoEmissao
	 *            - The convertedDocumentoEmissao to convert.
	 */
	@Override
	public void convertProposta(final Proposta proposta, final DocumentoEmissaoEBO convertedDocumentoEmissao) {

		final AuditoriaEBO auditoriaEBO = new AuditoriaEBO();

		convertedDocumentoEmissao.setAuditoria(auditoriaEBO);
		convertedDocumentoEmissao.setNumeroProposta(proposta.getNumeroProposta());
		convertedDocumentoEmissao.setNumeroSequenciaProposta(proposta.getNumeroSequenciaProposta());
		convertedDocumentoEmissao.setCodigoOrigemEmissao(EmissaoConvertTypes.convertIntToBigInt(proposta
			.getCodigoOrigemEmissao()));
		convertedDocumentoEmissao.setNumeroOrcamento(proposta.getNumeroOrcamento());
		convertedDocumentoEmissao.getAuditoria().setCodigoEmpresaUsuarioUltimaAlteracao(proposta
			.getCodigoEmpresaUsuarioUltimaAlteracao());
		convertedDocumentoEmissao.getAuditoria().setCodigoMatriculaUsuarioUltimaAlteracao(proposta
			.getCodigoMatriculaUsuarioUltimaAlteracao());
		convertedDocumentoEmissao.getAuditoria().setCodigoTipoUsuarioUltimaAlteracao(proposta
			.getCodigoTipoUsuarioUltimaAlteracao());
		convertedDocumentoEmissao.getAuditoria().setDataUltimaAlteracao(EmissaoConvertTypes.convertDateToXMLGreg(proposta
			.getDataUltimaAlteracao()));

		// convertedDocumentoEmissao.setCodigoTipoDestinario(proposta.getVersaoPropostas().get(0).getCodigoTipoDestinario());
	}

	/**
	 * Method used to convert CorretorVersaoProposta to Type.
	 * 
	 * @param corretorVersaoProposta
	 *            - The corretorVersaoProposta to convert
	 * @return entityClasses - the entity class List form.
	 */
	@Override
	public ListaCorretoresEBO convertCorretorToType(final List<CorretorVersaoProposta> corretorVersaoProposta) {
		final ListaCorretoresEBO listaCorretoresType = new ListaCorretoresEBO();

		if (CollectionUtils.hasContents(corretorVersaoProposta)) {
			for (final CorretorVersaoProposta selected : corretorVersaoProposta) {
				listaCorretoresType.getCorretor().add(convertCorretorToType(selected));
			}
		}

		return listaCorretoresType;
	}

	/**
	 * Convert Corretor to Type.
	 * 
	 * @param corretorVersaoProposta
	 *            parameter
	 * @return CorretorEBO
	 */
	@Override
	public CorretorEBO convertCorretorToType(final CorretorVersaoProposta corretorVersaoProposta) {
		final CorretorEBO corretor = new CorretorEBO();

		if ((corretorVersaoProposta != null) && (corretorVersaoProposta.getIdentificador() != null) &&
			(corretorVersaoProposta.getIdentificador().getCodigoCorretor() != null)) {

			corretor.setCodigoCorretor(corretorVersaoProposta.getIdentificador().getCodigoCorretor().toString());

			if ((corretorVersaoProposta.getSucursal() != null) && (corretorVersaoProposta.getSucursal()
				.getIdentificador() != null)) {
				corretor.setCodigoSucursal(EmissaoConvertTypes.convertIntToBigInt(corretorVersaoProposta.getSucursal()
					.getIdentificador().getCodigoSucursal()));
			}

			if (corretorVersaoProposta.getValorComissao() != null) {
				corretor.setValorComissao(corretorVersaoProposta.getValorComissao());
			}

			corretor.setFlagPrincipal(corretorVersaoProposta.getFlagPrincipal());
			corretor.setPercentualParticipacao(corretorVersaoProposta.getPercentualParticipacao());
			corretor.setFlagAtivo(corretorVersaoProposta.getFlagAtivo());
		}

		// R4
		if (AssertUtil.isNotNull(corretorVersaoProposta) && AssertUtil.isNotNull
				(corretorVersaoProposta.getFlagImpressaoCorretor())) {
			corretor.setFlagImpressaoCorretor(corretorVersaoProposta.getFlagImpressaoCorretor());
		} else {
			corretor.setFlagImpressaoCorretor(FLAG_S);
		}

		// R4

		return corretor;
	}

	/**
	 * Convert List of CoberturaItemVersaoProposta.
	 * 
	 * @param coberturaItemVersaoPropostas
	 *            parameter
	 * @return ListaCoberturaItemEBO
	 */
	@Override
	public ListaCoberturaItemEBO convertCoberturaItemVersaoPropostas(
		final List<CoberturaItemVersaoProposta> coberturaItemVersaoPropostas) {

		final ListaCoberturaItemEBO listaCobItm = new ListaCoberturaItemEBO();

		for (final CoberturaItemVersaoProposta cobItmVersProp : coberturaItemVersaoPropostas) {

			final CoberturaItemDocumentoEBO cobItmDocType = new CoberturaItemDocumentoEBO();
			final BeneficiarioItemDocumentoEBO beneficiarioItemDocumentoEBO = new BeneficiarioItemDocumentoEBO();

			if (CollectionUtils.hasContents(cobItmVersProp.getCoberturaItemBeneficiarioVersaoPropostas())) {
				for (final CoberturaItemBeneficiarioVersaoProposta cobItmBenVersProp : cobItmVersProp
					.getCoberturaItemBeneficiarioVersaoPropostas()) {

					final BeneficiarioVersaoProposta beneficiarioEntity = cobItmBenVersProp.getBeneficiarioVersaoProposta();

					final BeneficiarioEBO beneficiarioType = new BeneficiarioEBO();

					beneficiarioType.setCodigoBeneficiario(EmissaoConvertTypes.convertIntToBigInt(beneficiarioEntity
						.getIdentificador().getCodigoBeneficiario()));

					if (cobItmBenVersProp.getCodigoListaItem() != null) {

						beneficiarioType.setCodigoListaItem(EmissaoConvertTypes.convertIntToBigInt(cobItmBenVersProp
							.getCodigoListaItem()));
					}

					beneficiarioType.setCodigoTipoBem(EmissaoConvertTypes.convertIntToBigInt(cobItmBenVersProp
						.getCodigoTipoBem()));

					beneficiarioType.setValorTipoBem(cobItmBenVersProp.getValorTipoBem());

					// PERFORMANCE
					// IT WAS MISSING THE CODIGO TIPO ATUALIZACAO
					if ((cobItmBenVersProp.getBeneficiarioVersaoProposta() != null) && (cobItmBenVersProp
						.getBeneficiarioVersaoProposta().getCodigoTipoAtualizacao() != null)) {
						beneficiarioType.setCodigoTipoAtualizacao(EmissaoConvertTypes.convertLongToBigInt(cobItmBenVersProp
							.getBeneficiarioVersaoProposta().getCodigoTipoAtualizacao()));
					}

					final PessoaEBO pessoa = new PessoaEBO();
					pessoa.setCodigoPessoa(beneficiarioEntity.getCodigoPessoa());
					beneficiarioType.setDadosPessoa(pessoa);

					beneficiarioItemDocumentoEBO.getBeneficiario().add(beneficiarioType);
				}
			}
			cobItmDocType.setBeneficiarios(beneficiarioItemDocumentoEBO);

			if ((cobItmVersProp.getIdentificador() != null) && (cobItmVersProp.getIdentificador()
				.getCodigoCobertura() != null)) {
				cobItmDocType.setCodigoCobertura(EmissaoConvertTypes.convertIntToBigInt(cobItmVersProp.getIdentificador()
					.getCodigoCobertura()));
			}
			listaCobItm.getCoberturaItemDocumento().add(cobItmDocType);
		}

		return listaCobItm;
	}

	/**
	 * Convert List of ComponenteListaItemVersaoProposta to List of
	 * ComponenteListaItemEBO.
	 * 
	 * @param componenteListaItemVersaoPropostas
	 *            parameter
	 * @return List<ComponenteListaItemEBO>
	 */
	@Override
	public List<ComponenteListaItemEBO> convertToComponenteListaItemEBOs(
		final List<ComponenteListaItemVersaoProposta> componenteListaItemVersaoPropostas) {

		final List<ComponenteListaItemEBO> componenteListaItemEBOs = new ArrayList<>();

		for (final ComponenteListaItemVersaoProposta selectedComponenteLista : componenteListaItemVersaoPropostas) {

			final ComponenteListaItemEBO componenteListaItemType = new ComponenteListaItemEBO();

			componenteListaItemType.setCodigoComponenteListaItem(EmissaoConvertTypes.convertIntToBigInt(
				selectedComponenteLista.getIdentificador().getCodigoComponenteListaItem()));

			componenteListaItemType.setNomeComponenteListaItem(selectedComponenteLista.getNomeComponenteListaItem());

			componenteListaItemType.setQuantidadeComponenteListaItem(selectedComponenteLista
				.getQuantidadeComponenteListaItem().toBigInteger());

			componenteListaItemType.setValorComponenteListaItem(selectedComponenteLista.getValorComponenteListaItem());

			componenteListaItemEBOs.add(componenteListaItemType);
		}

		return componenteListaItemEBOs;
	}

	/**
	 * Method used to convert IntervenienteVersaoProposta to Type.
	 * 
	 * @param entityClasses
	 *            - The intervenienteVersaoPropostas to convert
	 * @return intVersaoPropostaType - the entity class List form.
	 */
	@Override
	public ListaIntervenientesEBO convertIntervenienteVersaoPropostaToType(
		final List<IntervenienteVersaoProposta> entityClasses) {

		final ListaIntervenientesEBO intVersaoPropostaType = new ListaIntervenientesEBO();

		if (CollectionUtils.hasContents(entityClasses)) {

			for (final IntervenienteVersaoProposta entityClass : entityClasses) {

				if (entityClass != null) {
					convertIntervenienteItemToType(intVersaoPropostaType, entityClass);
				}
			}
		}

		return intVersaoPropostaType;
	}

	/**
	 * Method used to convert IntervenienteVersaoProposta to Type.
	 * 
	 * @param intVersaoPropostaType
	 *            - the type form.
	 * @param entityClass
	 *            - the entity class form.
	 */
	private void convertIntervenienteItemToType(final ListaIntervenientesEBO intVersaoPropostaType,
		final IntervenienteVersaoProposta entityClass) {
		
		if (AssertUtil.isNotNull(entityClass)) {
			if (AssertUtil.isNull(entityClass.getTipoAtualizacao()) || 
					(AssertUtil.isNotNull(entityClass.getTipoAtualizacao().getCodigoTipoAtualizacao())
					&& !entityClass.getTipoAtualizacao().getCodigoTipoAtualizacao().equals(
							TipoAtualizacaoEnum.EXCLUSAO.getValue()))) {
				final IntervenienteEBO typeClass = new IntervenienteEBO();
				
				if ((entityClass.getIdentificador() != null) 
						&& (entityClass.getIdentificador().getCodigoInterveniente() != null)) {
					
					typeClass.setCodigoInterveniente(EmissaoConvertTypes.convertIntToBigInt(
							entityClass.getIdentificador().getCodigoInterveniente()));
					
				}
				
				if ((entityClass.getTipoInterveniente() != null) && (entityClass.getTipoInterveniente()
						.getCodigoTipoInterveniente() != null)) {
					
					typeClass.setCodigoTipoInterveniente(EmissaoConvertTypes.convertIntToBigInt(
							entityClass.getTipoInterveniente().getCodigoTipoInterveniente()));
					
				}
				
				if ((entityClass.getTipoPessoa() != null) && (entityClass.getTipoPessoa().getCodigoTipoPessoa() != null)) {
					
					typeClass.setCodigoTipoPessoa(EmissaoConvertTypes.convertIntToBigInt(entityClass.getTipoPessoa()
							.getCodigoTipoPessoa()));
					
				}
				
				typeClass.setNumeroCnpjCpf(entityClass.getNumeroCnpjCpf());
				typeClass.setNomeInterveniente(entityClass.getNomeInterveniente());
				if (AssertUtil.isNotNull(entityClass.getTipoAtualizacao())
						&& AssertUtil.isNotNull(entityClass.getTipoAtualizacao().getCodigoTipoAtualizacao())) {
					typeClass.setCodigoTipoAtualizacao(
							BigInteger.valueOf(entityClass.getTipoAtualizacao().getCodigoTipoAtualizacao()));
				}
				if ((entityClass.getTipoExposicaoPessoa() != null) && (entityClass.getTipoExposicaoPessoa()
						.getCodigoTipoExposicaoPessoa() != null)) {
					
					typeClass.setCodigoTipoExposicaoPessoa(EmissaoConvertTypes.convertIntToBigInt(entityClass
							.getTipoExposicaoPessoa().getCodigoTipoExposicaoPessoa()));
				}
				
				if ((entityClass.getMotivoAusenciaCnpjCpf() != null) && (entityClass.getMotivoAusenciaCnpjCpf()
						.getCodigoMotivoAusenciaCnpjCpf() != null)) {
					
					typeClass.setCodigoMotivoAusenciaCnpjCpf(EmissaoConvertTypes.convertIntToBigInt(entityClass
							.getMotivoAusenciaCnpjCpf().getCodigoMotivoAusenciaCnpjCpf()));
				}
				
				typeClass.setPercentualParticipacao(entityClass.getPercentualParticipacao());
				typeClass.setFlagAtivo(entityClass.getFlagAtivo());
				
				if (entityClass.getCodigoPessoa() != null) {
					
					final PessoaEBO pessoaEBO = new PessoaEBO();
					pessoaEBO.setCodigoPessoa(entityClass.getCodigoPessoa());
					typeClass.setDadosPessoaInterveniente(pessoaEBO);
				}
				
				if (CollectionUtils.hasContents(entityClass.getExposicaoIntervenienteVersaoPropostas())) {
					
					typeClass.setExposicoes(convertExposicaoIntervenienteVersaoPropostaToType(entityClass
							.getExposicaoIntervenienteVersaoPropostas()));
				} else {
					ListaExposicoesEBO exposicaoList = new ListaExposicoesEBO();
					typeClass.setExposicoes(exposicaoList);
				}
				
				intVersaoPropostaType.getInterveniente().add(typeClass);
			}
		}

	}

	/**
	 * Method used to convert ExposicaoIntervenienteVersaoProposta to Type.
	 * 
	 * @param entityClasses
	 *            - The exposicaointervenienteVersaoPropostas to convert
	 * @return listaExposicoes - the list of type classes.
	 */
	@Override
	public ListaExposicoesEBO convertExposicaoIntervenienteVersaoPropostaToType(
		final List<ExposicaoIntervenienteVersaoProposta> entityClasses) {

		final ListaExposicoesEBO listaExposicoes = new ListaExposicoesEBO();

		for (final ExposicaoIntervenienteVersaoProposta entityClass : entityClasses) {

			final ExposicaoEBO typeClass = new ExposicaoEBO();

			typeClass.setCodigoExposicaoInterveniente(EmissaoConvertTypes.convertIntToBigInt(entityClass.getId()
				.getCodigoExposicaoInterveniente()));

			if ((entityClass.getTipoVinculoPessoa() != null) && (entityClass.getTipoVinculoPessoa()
				.getCodigoTipoVinculo() != null)) {

				typeClass.setCodigoTipoVinculo(EmissaoConvertTypes.convertIntToBigInt(entityClass.getTipoVinculoPessoa()
					.getCodigoTipoVinculo()));
			}

			typeClass.setCodigoPessoaExposto(entityClass.getCodigoPessoaExposto());

			if ((entityClass.getTipoPessoa() != null) && (entityClass.getTipoPessoa().getCodigoTipoPessoa() != null)) {

				typeClass.setCodigoTipoPessoaExposto(EmissaoConvertTypes.convertIntToBigInt(entityClass.getTipoPessoa()
					.getCodigoTipoPessoa()));
			}

			typeClass.setNumeroCnpjCpfPessoaExposto(entityClass.getNumeroCnpjCpfPessoaExposto());
			typeClass.setNomePessoaExposto(entityClass.getNomePessoaExposto());
			typeClass.setFlagAtivo(entityClass.getFlagAtivo());
			listaExposicoes.getExposicao().add(typeClass);
		}

		return listaExposicoes;
	}

	/**
	 * Method used to convert PagadorParcelaVersaoProposta to Type.
	 * 
	 * @param pagadorParcelVersaoPropostas
	 *            - The pagadorParcelaVersaoPropostas to convert
	 * @return listaPagadoresType - the entity class List form.
	 */
	@Override
	public ListaPagadorParcelaEBO convertPagadoresParcela(
		final List<PagadorParcelaVersaoProposta> pagadorParcelVersaoPropostas) {

		final ListaPagadorParcelaEBO listaPagadoresType = new ListaPagadorParcelaEBO();

		for (final PagadorParcelaVersaoProposta selectedPagadorVersao : pagadorParcelVersaoPropostas) {

			final PagadorParcelaEBO pagadorParcelEBO = new PagadorParcelaEBO();

			/*************** ADDED BY SITNIK ON 2016-05-03 ***************/
			/************* this field is mandatory on the EBO ************/
			/*** was causing contract error when calling aceitarRiscos ***/
			final ListaHistoricoPagadorParcelaEndossoEBO hitoricoPagadorParcela =
				new ListaHistoricoPagadorParcelaEndossoEBO();
			pagadorParcelEBO.setHitoricoPagadorParcela(hitoricoPagadorParcela);
			/************ END OF ADDED BY SITNIK ON 2016-05-03 ************/

			Integer codigoBanco = null;
			Integer numeroAgenciaBancaria = null;
			if (null != selectedPagadorVersao.getAgenciaBancaria()) {
				codigoBanco = selectedPagadorVersao.getAgenciaBancaria().getIdentificador().getCodigoBanco();
				numeroAgenciaBancaria = Integer.valueOf(selectedPagadorVersao.getAgenciaBancaria().getIdentificador()
					.getNumeroAgenciaBancaria());
			}

			if (codigoBanco != null) {
				pagadorParcelEBO.setCodigoBanco(BigInteger.valueOf(codigoBanco));
			}

			if (null != selectedPagadorVersao.getStatusParcela()) {
				EmissaoConvertTypes.convertIntToBigInt(selectedPagadorVersao.getStatusParcela().getCodigoStatusParcela());
			}

			pagadorParcelEBO.setCodigoIdentificacaoCartao(selectedPagadorVersao.getCodigoIdentificacaoCartao());

			// SM 4098 ALM - Trafegar informação da bandeira do cartão pelo
			// atributo do tipo cartão.
			if (selectedPagadorVersao.getBandeiraCartao() != null) {
				pagadorParcelEBO.setCodigoTipoCartao(BigInteger.valueOf(selectedPagadorVersao.getBandeiraCartao()
					.getCodigoBandeiraCartao().longValue()));
			}

			final PessoaEBO pessaoEBO = new PessoaEBO();
			final PagadorParcelaVersaoPropostaPK pgdPrcVrsPrpId = selectedPagadorVersao.getIdentificador();

			if (pgdPrcVrsPrpId != null) {
				pessaoEBO.setCodigoPessoa(pgdPrcVrsPrpId.getCodigoPessoa());
			}
			pagadorParcelEBO.setNumeroContaBancaria(selectedPagadorVersao.getNumeroContaBancaria());
			pagadorParcelEBO.setDadosPessoaPagadorParcela(pessaoEBO);
			pagadorParcelEBO.setDataVencimento(EmissaoConvertTypes.convertDateToXMLGreg(selectedPagadorVersao
				.getDataVencimento()));
			pagadorParcelEBO.setDigitoContaBancaria(selectedPagadorVersao.getDigitoContaBancaria());

			pagadorParcelEBO.setDataPagamento(EmissaoConvertTypes.convertDateToXMLGreg(selectedPagadorVersao
				.getDataCancelamento()));
			pagadorParcelEBO.setDataPagamentoContabilizado(EmissaoConvertTypes.convertDateToXMLGreg(selectedPagadorVersao
				.getDataPagamentoContabilizado()));
			pagadorParcelEBO.setDataCancelamento(EmissaoConvertTypes.convertDateToXMLGreg(selectedPagadorVersao
				.getDataCancelamento()));

			if ((selectedPagadorVersao.getStatusParcela() != null) && (selectedPagadorVersao.getStatusParcela()
				.getCodigoStatusParcela() != null)) {
				pagadorParcelEBO.setCodigoStatusParcela(EmissaoConvertTypes.convertIntToBigInt(selectedPagadorVersao
					.getStatusParcela().getCodigoStatusParcela()));
			}

			// stubbed dataPrazoCobertura
			pagadorParcelEBO.setDataPrazoCobertura(EmissaoConvertTypes.convertDateToXMLGreg(new Date()));

			if (numeroAgenciaBancaria != null) {

				pagadorParcelEBO.setNumeroAgenciaBancaria(BigInteger.valueOf(numeroAgenciaBancaria));
			}

			if (pgdPrcVrsPrpId != null) {

				pagadorParcelEBO.setNumeroParcela(BigInteger.valueOf(pgdPrcVrsPrpId.getNumeroParcela()));
			}

			pagadorParcelEBO.setValorParcela(selectedPagadorVersao.getValorParcela());
			pagadorParcelEBO.setTextoComentario(selectedPagadorVersao.getTextoComentario());

			listaPagadoresType.getPagadorParcela().add(pagadorParcelEBO);
		}

		return listaPagadoresType;
	}

	/**
	 * Convert ExposicaoIntervenienteVersaoProposta to Entity.
	 *
	 * @param typeClasses
	 *            - The documentEmissaoExposicaoList to convert
	 * @param numeroProposta
	 *            - The numeroVersaoProposta parameter
	 * @param numeroVersaoProposta
	 *            - The numeroVersaoProposta parameter
	 * @param codigoInterveniente
	 *            the codigoInterveniente parameter
	 * @return entityClasses - the entity class List form.
	 */
	private List<ExposicaoIntervenienteVersaoProposta> convertExposicaoIntervenienteVersaoPropostaToEntity(
		final List<ExposicaoEBO> typeClasses, final Long numeroProposta, final Long numeroVersaoProposta,
		final Integer codigoInterveniente) {

		final List<ExposicaoIntervenienteVersaoProposta> entityClasses = new ArrayList<>();

		for (final ExposicaoEBO typeClass : typeClasses) {

			final ExposicaoIntervenienteVersaoProposta entityClass = new ExposicaoIntervenienteVersaoProposta();
			final ExposicaoIntervenienteVersaoPropostaPK eivpPk = new ExposicaoIntervenienteVersaoPropostaPK();
			eivpPk.setNumeroProposta(numeroProposta);
			eivpPk.setNumeroVersaoProposta(numeroVersaoProposta);
			eivpPk.setCodigoInterveniente(codigoInterveniente);
			eivpPk.setCodigoExposicaoInterveniente(EmissaoConvertTypes.convertBigIntToInt(typeClass
				.getCodigoExposicaoInterveniente()));
			entityClass.setId(eivpPk);

			if (typeClass.getCodigoPessoaExposto() != null) {

				entityClass.setCodigoPessoaExposto(typeClass.getCodigoPessoaExposto());
			}

			if (typeClass.getCodigoTipoPessoaExposto() != null) {

				final TipoPessoa tipoPessoa = new TipoPessoa();
				tipoPessoa.setCodigoTipoPessoa(EmissaoConvertTypes.convertBigIntToInt(typeClass
					.getCodigoTipoPessoaExposto()));
				entityClass.setTipoPessoa(tipoPessoa);
			}

			entityClass.setNumeroCnpjCpfPessoaExposto(typeClass.getNumeroCnpjCpfPessoaExposto());
			entityClass.setNomePessoaExposto(typeClass.getNomePessoaExposto());
			entityClass.setFlagAtivo(typeClass.getFlagAtivo());

			if (typeClass.getCodigoTipoVinculo() != null) {

				final TipoVinculoPessoa tipoVinculoPessoa = new TipoVinculoPessoa();
				tipoVinculoPessoa.setCodigoTipoVinculo(EmissaoConvertTypes.convertBigIntToInt(typeClass
					.getCodigoTipoVinculo()));
				entityClass.setTipoVinculoPessoa(tipoVinculoPessoa);
			}

			entityClasses.add(entityClass);
		}

		return entityClasses;
	}

	/**
	 * A method used to convert a list of PagadorVersaoProposta type to a list
	 * of PagadorVersaoProposta entity.
	 * 
	 * @param numeroProposta
	 *            - The numeroProposta to convert
	 * @param numeroVersaoProposta
	 *            - The numeroVersaoProposta to convert
	 * @param pagador
	 *            - The pagador to convert
	 * @return entityClasses - the entity class List form.
	 */
	@Override
	public List<PagadorVersaoProposta> convertPagadorToEntity(final Long numeroProposta, final Long numeroVersaoProposta,
		final List<PagadorEBO> pagador) {

		final List<PagadorVersaoProposta> pagadorVersaoPropostas = convertPagadorVersaoPropostaType(pagador, numeroProposta,
			numeroVersaoProposta);

		return pagadorVersaoPropostas;
	}

	/**
	 * A method used to convert a list of PagadorVersaoProposta entity to a list
	 * of PagadorVersaoProposta type.
	 * 
	 * @param pagadorVersaoProposta
	 *            - The pagador to convert
	 * @return documentoEmissao - The converted documentoEmissao.
	 */
	@Override
	public DocumentoEmissaoEBO convertPagadorToType(final List<PagadorVersaoProposta> pagadorVersaoProposta) {

		final DocumentoEmissaoEBO documentoEmissao = new DocumentoEmissaoEBO();
		documentoEmissao.setPagadores(convertPagadores(pagadorVersaoProposta));
		return documentoEmissao;
	}

	/**
	 * A method used to convert a list of ItemVersaoProposta type to a list of
	 * ItemVersaoProposta entity.
	 * 
	 * @param numeroProposta
	 *            - The numeroProposta to convert
	 * @param numeroVersaoProposta
	 *            - The numeroVersaoProposta to convert
	 * @param itemDocumento
	 *            - The itemDocumento to convert
	 * @return entityClasses - the entity class List form.
	 */
	@Override
	public List<ItemVersaoProposta> convertBeneficiarioToEntity(final Long numeroProposta, final Long numeroVersaoProposta,
		final List<ItemDocumentoEmissaoEBO> itemDocumento) {

		final List<ItemVersaoProposta> itemVersaoPropostas = convertComponenteListaItemType(itemDocumento, numeroProposta,
			numeroVersaoProposta);

		return itemVersaoPropostas;
	}

	/**
	 * A method used to convert a list of ItemVersaoProposta entity to a list of
	 * ItemVersaoProposta type.
	 * 
	 * @param itemVersaoProposta
	 *            - The itemVersaoProposta to convert
	 * @return DocumentoEmissaoEBO - The converted documentoEmissao.
	 */
	@Override
	public DocumentoEmissaoEBO convertBeneficiarioToType(final List<ItemVersaoProposta> itemVersaoProposta) {

		final DocumentoEmissaoEBO documentoEmissao = new DocumentoEmissaoEBO();
		documentoEmissao.setItensDocumentoEmissao(convertItemVersaoProposta(itemVersaoProposta));

		return documentoEmissao;
	}

	/**
	 * Used to convert a list of Beneficiario entity to list of
	 * ItemDocumentoEmissaoEBO.
	 * 
	 * @param entityClasses
	 *            parameters.
	 * @return List<ItemDocumentoEmissaoEBO> converted object.
	 */
	@Override
	public List<ItemDocumentoEmissaoEBO> convertBeneficiariosToType(final List<ItemVersaoProposta> entityClasses) {

		final List<ItemDocumentoEmissaoEBO> typeClasses = new ArrayList<>();

		for (final ItemVersaoProposta entityClass : entityClasses) {

			final ItemDocumentoEmissaoEBO typeClass = new ItemDocumentoEmissaoEBO();

			typeClass.setNumeroProposta(entityClass.getIdentificador().getNumeroProposta());
			typeClass.setNumeroVersaoProposta(entityClass.getIdentificador().getNumeroVersaoProposta());
			typeClass.setNumeroItemVersaoProposta(EmissaoConvertTypes.convertIntToBigInt(entityClass.getIdentificador()
				.getNumeroItemVersaoProposta()));

			typeClass.setNumeroVersaoOrcamento(typeClass.getNumeroVersaoOrcamento());

			if (CollectionUtils.hasContents(entityClass.getCriticaItemVersaoPropostas())) {

				final ListaCriticasItensEBO listaCriticasItens = convertToCriticasItem(entityClass
					.getCriticaItemVersaoPropostas());
				typeClass.setCriticasItem(listaCriticasItens);
			}

			if (CollectionUtils.hasContents(entityClass.getListaItemVersaoPropostas())) {

				final ListaItensEBO listaItens = convertToListaItens(entityClass.getListaItemVersaoPropostas());

				typeClass.setListaItens(listaItens);
			}

			if (CollectionUtils.hasContents(entityClass.getCoberturaItemVersaoPropostas())) {

				final ListaCoberturaItemEBO listaCobItm = convertCoberturaItemVersaoPropostas(entityClass
					.getCoberturaItemVersaoPropostas());

				final CoberturasItemEBO cobItmType = new CoberturasItemEBO();
				cobItmType.setListaCoberturasItem(listaCobItm);
				typeClass.setCoberturasItem(cobItmType);
			}

			typeClasses.add(typeClass);
		}

		return typeClasses;
	}

	/**
	 * Convert CriticaItemVersaoProposta to CriticaEBO.
	 * 
	 * @param criticaItemVersaoPropostas
	 *            parameter
	 * @return ListaCriticasItensEBO
	 */
	@Override
	public ListaCriticasItensEBO convertToCriticasItem(
		final List<CriticaSeguroItemVersaoProposta> criticaItemVersaoPropostas) {

		final ListaCriticasItensEBO listaCriticaItens = new ListaCriticasItensEBO();
		final List<CriticaEBO> criticaItems = new ArrayList<>();

		for (final CriticaSeguroItemVersaoProposta criticaItemVersaoProposta : criticaItemVersaoPropostas) {

			final CriticaEBO criticaItem = new CriticaEBO();

			criticaItem.setCodigoCritica(BigInteger.valueOf(criticaItemVersaoProposta.getIdentificador()
				.getCodigoCritica()));

			if (CollectionUtils.hasContents(criticaItemVersaoProposta.getStatusCriticaItemVersaoPropostas())) {

				final StatusCriticaSeguroItemVersaoProposta statusCritica = criticaItemVersaoProposta
					.getStatusCriticaItemVersaoPropostas().get(0);

				criticaItem.setCodigoStatusCritica(BigInteger.valueOf(statusCritica.getIdentificador()
					.getCodigoStatusCritica()));
			}

			criticaItems.add(criticaItem);
		}

		return listaCriticaItens;
	}

	/**
	 * Convert List of ListaItemVersaoProposta.
	 * 
	 * @param listaItemVersaoProposta
	 *            parameter
	 * @return ListItens
	 */
	@Override
	public ListaItensEBO convertToListaItens(final List<ListaItemVersaoProposta> listaItemVersaoProposta) {

		final ListaItensEBO listaItens = new ListaItensEBO();

		for (final ListaItemVersaoProposta selectedListaItemVersaoProposta : listaItemVersaoProposta) {

			final List<ComponenteListaItemVersaoProposta> componenteListaItemVersaoPropostas =
				selectedListaItemVersaoProposta.getComponenteListaItemVersaoPropostas();

			final ComponentesListaItemEBO componentesListaItem = new ComponentesListaItemEBO();

			if (CollectionUtils.hasContents(componenteListaItemVersaoPropostas)) {

				final List<ComponenteListaItemEBO> componenteListaItemEBOs = convertToComponenteListaItemEBOs(
					componenteListaItemVersaoPropostas);

				componentesListaItem.getComponentesListaItem().addAll(componenteListaItemEBOs);

			}

			listaItens.setCodigoListaItem(EmissaoConvertTypes.convertIntToBigInt(selectedListaItemVersaoProposta
				.getIdentificador().getCodigoListaItem()));

			listaItens.setNomeListaItem(selectedListaItemVersaoProposta.getNomeListaItem());
			listaItens.setComponentesListaItem(componentesListaItem);
		}

		return listaItens;
	}

	/**
	 * Method used to convert ItemVersaoProposta to Type.
	 * 
	 * @param itemVersaoProposta
	 *            - The itemVersaoProposta to convert.
	 * @return listaItemDocumentoEmissaoType - The entity class List form.
	 */
	@Override
	public ListaItemDocumentoEmissaoEBO convertItemVersaoProposta(final List<ItemVersaoProposta> itemVersaoProposta) {

		final ListaItemDocumentoEmissaoEBO listaItemDocumentoEmissaoType = new ListaItemDocumentoEmissaoEBO();

		final List<ItemDocumentoEmissaoEBO> itemDocumentoEmissao = convertBeneficiariosToType(itemVersaoProposta);

		listaItemDocumentoEmissaoType.getItemDocumentoEmissao().addAll(itemDocumentoEmissao);

		return listaItemDocumentoEmissaoType;
	}

	/**
	 * Convert PagadorVersaoProposta Type to Entity.
	 * 
	 * @param pagadorList
	 *            parameter
	 * @param numeroProposta
	 *            parameter
	 * @param numeroVersaoProposta
	 *            parameter
	 * @return List of PagadorVersaoProposta
	 */
	@Override
	public List<PagadorVersaoProposta> convertPagadorVersaoPropostaType(final List<PagadorEBO> pagadorList,
		final Long numeroProposta, final Long numeroVersaoProposta) {

		final List<PagadorVersaoProposta> pagadorVersaoPropostas = new ArrayList<>();
		for (final PagadorEBO selectedPagador : pagadorList) {

			if ((selectedPagador.getDadosPessoaPagador() != null) && (selectedPagador.getDadosPessoaPagador()
				.getCodigoPessoa() != null)) {

				final PagadorVersaoProposta pagadorVersaoProposta = new PagadorVersaoProposta();

				final PagadorVersaoPropostaPK pagadorVersaoPropostaPK = new PagadorVersaoPropostaPK();

				pagadorVersaoPropostaPK.setCodigoPessoa(selectedPagador.getDadosPessoaPagador().getCodigoPessoa());
				pagadorVersaoPropostaPK.setNumeroProposta(numeroProposta);
				pagadorVersaoPropostaPK.setNumeroVersaoProposta(numeroVersaoProposta);

				pagadorVersaoProposta.setIdentificador(pagadorVersaoPropostaPK);

				if ((selectedPagador.getEnderecoCobranca() != null) && (null != selectedPagador.getEnderecoCobranca()
					.getCodigoEndereco())) {

					pagadorVersaoProposta.setCodigoEnderecoCobranca(selectedPagador.getEnderecoCobranca()
						.getCodigoEndereco());
				}

				pagadorVersaoPropostas.add(pagadorVersaoProposta);
			}
		}
		return pagadorVersaoPropostas;
	}

	/** Convert Pagadores.
	 * @param pagadorVersaoProposta parameter
	 * @return List of PagadorVersaoProposta */
	@Override
	public ListaPagadoresEBO convertPagadores(final List<PagadorVersaoProposta> pagadorVersaoProposta) {

		final ListaPagadoresEBO listaPagadoresType = new ListaPagadoresEBO();

		for (final PagadorVersaoProposta selected : pagadorVersaoProposta) {

			final PagadorEBO pagador = new PagadorEBO();
			final PessoaEBO pessoaEBO = new PessoaEBO();
			pagador.setDadosPessoaPagador(pessoaEBO);

			final Long codigoPessoa = selected.getIdentificador().getCodigoPessoa();
			if (codigoPessoa != null) {
				pagador.getDadosPessoaPagador().setCodigoPessoa(codigoPessoa);
			}

			final EnderecoEBO enderecoEBO = new EnderecoEBO();
			final Long endereco = selected.getCodigoEnderecoCobranca();
			if (endereco != null) {
				enderecoEBO.setCodigoEndereco(endereco);
			}

			pagador.setEnderecoCobranca(enderecoEBO);

			final List<PagadorParcelaVersaoProposta> pagadorParcelaVersaoPropostas = selected
				.getPagadorParcelaVersaoPropostas();

			if (CollectionUtils.hasContents(pagadorParcelaVersaoPropostas)) {
				final ListaPagadorParcelaEBO listarPagador = convertPagadoresParcela(pagadorParcelaVersaoPropostas);
				pagador.setPagadoresParcela(listarPagador);
			}

			listaPagadoresType.getPagador().add(pagador);
		}

		return listaPagadoresType;
	}

	/** Convert Componente Lista Item to Entity.
	 * @param itemDocumentoEmissaoList - The itemDocumentoEmissaoList to convert
	 * @param numeroProposta - The numeroProposta
	 * @param numeroVersaoProposta - The numeroVersaoProposta
	 * @return List<ItemVersaoProposta> - the entity class List form. */
	@Override
	public List<ItemVersaoProposta> convertComponenteListaItemType(
		final List<ItemDocumentoEmissaoEBO> itemDocumentoEmissaoList, final Long numeroProposta,
		final Long numeroVersaoProposta) {

		final List<ItemVersaoProposta> itemVersaoPropostas = new ArrayList<>();

		for (final ItemDocumentoEmissaoEBO itemDocumentoEmissao : itemDocumentoEmissaoList) {

			// final ItemDocumentoEmissaoEBO itemDocumentoEmissao =
			// itemDocumentoEmissaoList.get(0);
			final List<ListaItemVersaoProposta> listaItemVersaoPropostas = new ArrayList<>();
			final ListaItemVersaoProposta listaItemVersaoProposta = new ListaItemVersaoProposta();
			final ListaItemVersaoPropostaPK listaItemVersaoPropostaPK = new ListaItemVersaoPropostaPK();
			// ComponenteListaItemEBO
			if (itemDocumentoEmissao.getListaItens() != null) {

				convertListaItemToEntity(itemDocumentoEmissaoList, numeroProposta, numeroVersaoProposta,
					itemDocumentoEmissao, listaItemVersaoPropostas, listaItemVersaoProposta, listaItemVersaoPropostaPK);
			}

			final ItemVersaoProposta itemVersaoProposta = new ItemVersaoProposta();

			if ((itemDocumentoEmissao.getCoberturasItem() != null) && (itemDocumentoEmissao.getCoberturasItem()
				.getListaCoberturasItem() != null) && (itemDocumentoEmissao.getCoberturasItem().getListaCoberturasItem()
					.getCoberturaItemDocumento() != null)) {

				final List<CoberturaItemDocumentoEBO> coberturaItems = itemDocumentoEmissao.getCoberturasItem()
					.getListaCoberturasItem().getCoberturaItemDocumento();

				final List<CoberturaItemVersaoProposta> coberturaItemVersaoPropostas = new ArrayList<>();

				convertCobItemDocEBOToCobItemVerProp(itemDocumentoEmissao, coberturaItems,
					coberturaItemVersaoPropostas);

				itemVersaoProposta.setCoberturaItemVersaoPropostas(coberturaItemVersaoPropostas);
			}

			if ((itemDocumentoEmissao.getCriticasItem() != null) && CollectionUtils.hasContents(itemDocumentoEmissao
				.getCriticasItem().getCriticaItem())) {

				final List<CriticaSeguroItemVersaoProposta> criticaItems = convertCriticaItemEBOToEntity(
					itemDocumentoEmissao, numeroProposta, numeroVersaoProposta);

				itemVersaoProposta.setCriticaItemVersaoPropostas(criticaItems);
			}

			itemVersaoProposta.setNumeroOrcamento(itemDocumentoEmissao.getNumeroOrcamento());

			itemVersaoProposta.setNumeroVersaoOrcamento(itemDocumentoEmissao.getNumeroVersaoOrcamento());

			final ItemVersaoPropostaPK itemVersaoPropostaPK = new ItemVersaoPropostaPK();
			itemVersaoPropostaPK.setNumeroProposta(itemDocumentoEmissao.getNumeroProposta());

			itemVersaoPropostaPK.setNumeroVersaoProposta(itemDocumentoEmissao.getNumeroVersaoProposta());

			if (AssertUtil.isNotNull(itemDocumentoEmissao.getNumeroItemVersaoProposta())) {
				itemVersaoPropostaPK.setNumeroItemVersaoProposta(EmissaoConvertTypes.convertBigIntToInt(itemDocumentoEmissao
					.getNumeroItemVersaoProposta()));
			}else {
				itemVersaoPropostaPK.setNumeroItemVersaoProposta(EmissaoConvertTypes.convertBigIntToInt(itemDocumentoEmissao
					.getNumeroItemVersaoOrcamento()));
			}

			itemVersaoProposta.setIdentificador(itemVersaoPropostaPK);

			itemVersaoProposta.setListaItemVersaoPropostas(listaItemVersaoPropostas);

			itemVersaoPropostas.add(itemVersaoProposta);
		}

		return itemVersaoPropostas;
	}

	/** Convert CriticaEBO to Entity.
	 * @param itemDocumentoEmissao parameter
	 * @param numeroProposta parameter
	 * @param numeroVersaoProposta parameter
	 * @return List<CriticaSeguroItemVersaoProposta> */
	private List<CriticaSeguroItemVersaoProposta> convertCriticaItemEBOToEntity(
		final ItemDocumentoEmissaoEBO itemDocumentoEmissao, final Long numeroProposta, final Long numeroVersaoProposta) {

		final List<CriticaSeguroItemVersaoProposta> criticasVersaoPropsota = new ArrayList<>();
		for (final CriticaEBO critica : itemDocumentoEmissao.getCriticasItem().getCriticaItem()) {

			final CriticaSeguroItemVersaoProposta criticaSeguroVerProp = new CriticaSeguroItemVersaoProposta();
			criticaSeguroVerProp.setDataCritica(EmissaoConvertTypes.convertXMLGregToDate(critica.getDataCritica()));

			final CriticaSeguroItemVersaoPropostaPK criticaPK = new CriticaSeguroItemVersaoPropostaPK();
			if (critica.getCodigoCritica() != null) {
				criticaPK.setCodigoCritica(critica.getCodigoCritica().intValue());
			}
			criticaPK.setNumeroProposta(numeroProposta);
			criticaPK.setNumeroVersaoProposta(numeroVersaoProposta);

			if (itemDocumentoEmissao.getNumeroItemVersaoProposta() != null) {
				criticaPK.setNumeroItemVersaoProposta(EmissaoConvertTypes.convertBigIntToInt(itemDocumentoEmissao
					.getNumeroItemVersaoProposta()));
			}

			criticaSeguroVerProp.setIdentificador(criticaPK);

			criticaSeguroVerProp.setNomPerfPrincSistemGerencProcess(critica
				.getNomePerfilPrincipalSistemaGerenciamentoProcesso());

			criticaSeguroVerProp.setTxtPerfParticSistemGerencProcess(critica
				.getTextoPerfilParticipanteSistemaGerenciamentoProcesso());

			criticaSeguroVerProp.setTextoRetornoCritica(critica.getTextoRetornoCritica());

			final StatusCriticaSeguroItemVersaoProposta statusCritica = new StatusCriticaSeguroItemVersaoProposta();
			final StatusCriticaSeguroItemVersaoPropostaPK statusCriticaPK = new StatusCriticaSeguroItemVersaoPropostaPK();

			if (critica.getCodigoCritica() != null) {
				statusCriticaPK.setCodigoCritica(critica.getCodigoCritica().intValue());
			}

			if (critica.getCodigoStatusCritica() != null) {
				statusCriticaPK.setCodigoStatusCritica(critica.getCodigoStatusCritica().intValue());
			}

			if (itemDocumentoEmissao.getNumeroItemVersaoProposta() != null) {
				statusCriticaPK.setNumeroItemVersaoProposta(EmissaoConvertTypes.convertBigIntToInt(itemDocumentoEmissao
					.getNumeroItemVersaoProposta()));
			}

			statusCriticaPK.setNumeroProposta(numeroProposta);
			statusCriticaPK.setNumeroVersaoProposta(numeroVersaoProposta);

			statusCritica.setIdentificador(statusCriticaPK);

			final List<StatusCriticaSeguroItemVersaoProposta> statusCriticaList = new ArrayList<>();
			statusCriticaList.add(statusCritica);

			criticaSeguroVerProp.setStatusCriticaItemVersaoPropostas(statusCriticaList);

			criticasVersaoPropsota.add(criticaSeguroVerProp);
		}
		return criticasVersaoPropsota;
	}

	/** Convert to CoberturaItemVersaoOrcamento.
	 * @param itemDocumentoEmissao parameter
	 * @param selectedCoberturaItem parameter
	 * @return CoberturaItemVersaoOrcamento */
	private CoberturaItemVersaoOrcamento convertToCoberturaItemVersaoOrcamento(
		final ItemDocumentoEmissaoEBO itemDocumentoEmissao, final CoberturaItemDocumentoEBO selectedCoberturaItem) {
		final CoberturaItemVersaoOrcamentoPK civoPK = new CoberturaItemVersaoOrcamentoPK();

		civoPK.setNumeroItemVersaoOrcamento(EmissaoConvertTypes.convertBigIntToInt(itemDocumentoEmissao
			.getNumeroItemVersaoOrcamento()));

		civoPK.setNumeroOrcamento(itemDocumentoEmissao.getNumeroOrcamento());

		civoPK.setNumeroVersaoOrcamento(itemDocumentoEmissao.getNumeroVersaoOrcamento());

		civoPK.setCodigoCobertura(EmissaoConvertTypes.convertBigIntToInt(selectedCoberturaItem.getCodigoCobertura()));

		final CoberturaItemVersaoOrcamento civo = new CoberturaItemVersaoOrcamento();
		civo.setIdentificador(civoPK);
		return civo;
	}

	/** Convert Beneficiario Type To Entity.
	 * @param itemDocumentoEmissao parameter
	 * @param selectedCoberturaItem parameter
	 * @param coberturaItemBeneficiarioVersaoProposta parameter
	 * @param beneficiario the beneficiario */
	private void convertBeneficiarioTypeToEntity(final ItemDocumentoEmissaoEBO itemDocumentoEmissao,
		final CoberturaItemDocumentoEBO selectedCoberturaItem,
		final CoberturaItemBeneficiarioVersaoProposta coberturaItemBeneficiarioVersaoProposta,
		final BeneficiarioEBO beneficiario) {

		final BeneficiarioVersaoProposta beneficiarioVersaoProposta = new BeneficiarioVersaoProposta();
		final BeneficiarioVersaoPropostaPK beneficiarioVersaoPropostaPK = new BeneficiarioVersaoPropostaPK();
		beneficiarioVersaoPropostaPK.setCodigoBeneficiario(EmissaoConvertTypes.convertBigIntToInt(beneficiario
			.getCodigoBeneficiario()));
		beneficiarioVersaoPropostaPK.setNumeroProposta(itemDocumentoEmissao.getNumeroProposta());
		beneficiarioVersaoPropostaPK.setNumeroVersaoProposta(itemDocumentoEmissao.getNumeroVersaoProposta());
		beneficiarioVersaoProposta.setIdentificador(beneficiarioVersaoPropostaPK);

		beneficiarioVersaoProposta.setCodigoPessoa(beneficiario.getDadosPessoa().getCodigoPessoa());
		beneficiarioVersaoProposta.setIdentificador(beneficiarioVersaoPropostaPK);

		coberturaItemBeneficiarioVersaoProposta.setBeneficiarioVersaoProposta(beneficiarioVersaoProposta);

		coberturaItemBeneficiarioVersaoProposta.setCodigoListaItem(EmissaoConvertTypes.convertBigIntToInt(beneficiario
			.getCodigoListaItem()));

		coberturaItemBeneficiarioVersaoProposta.setCodigoTipoBem(EmissaoConvertTypes.convertBigIntToInt(beneficiario
			.getCodigoTipoBem()));

		if (null != beneficiario.getValorTipoBem()) {

			coberturaItemBeneficiarioVersaoProposta.setValorTipoBem(beneficiario.getValorTipoBem());
		}

		contConvertBeneficiarioTypeToEntity(itemDocumentoEmissao, selectedCoberturaItem,
			coberturaItemBeneficiarioVersaoProposta, beneficiario);

	}

	/** Continue Convert Beneficiario Type To Entity.
	 * @param itemDocumentoEmissao parameter
	 * @param selectedCoberturaItem parameter
	 * @param coberturaItemBeneficiarioVersaoProposta parameter
	 * @param beneficiario parameter */
	private void contConvertBeneficiarioTypeToEntity(final ItemDocumentoEmissaoEBO itemDocumentoEmissao,
		final CoberturaItemDocumentoEBO selectedCoberturaItem,
		final CoberturaItemBeneficiarioVersaoProposta coberturaItemBeneficiarioVersaoProposta,
		final BeneficiarioEBO beneficiario) {

		final CoberturaItemBeneficiarioVersaoPropostaPK cobItmBenVersPropPK =
			new CoberturaItemBeneficiarioVersaoPropostaPK();

		cobItmBenVersPropPK.setCodigoBeneficiario(EmissaoConvertTypes.convertBigIntToInt(beneficiario
			.getCodigoBeneficiario()));

		cobItmBenVersPropPK.setCodigoCobertura(EmissaoConvertTypes.convertBigIntToInt(selectedCoberturaItem
			.getCodigoCobertura()));

		cobItmBenVersPropPK.setNumeroProposta(itemDocumentoEmissao.getNumeroProposta());

		cobItmBenVersPropPK.setNumeroVersaoProposta(itemDocumentoEmissao.getNumeroVersaoProposta());

		cobItmBenVersPropPK.setNumeroItemVersaoProposta(EmissaoConvertTypes.convertBigIntToInt(itemDocumentoEmissao
			.getNumeroItemVersaoProposta()));

		coberturaItemBeneficiarioVersaoProposta.setIdentificador(cobItmBenVersPropPK);
	}

	/** Convert Lista Item Type To Entity.
	 * @param itemDocumentoEmissaoList parameter
	 * @param numeroProposta parameter
	 * @param numeroVersaoProposta parameter
	 * @param itemDocumentoEmissao parameter
	 * @param listaItemVersaoPropostas parameter
	 * @param listaItemVersaoProposta parameter
	 * @param listaItemVersaoPropostaPK parameter */
	private void convertListaItemToEntity(final List<ItemDocumentoEmissaoEBO> itemDocumentoEmissaoList,
		final Long numeroProposta, final Long numeroVersaoProposta, final ItemDocumentoEmissaoEBO itemDocumentoEmissao,
		final List<ListaItemVersaoProposta> listaItemVersaoPropostas, final ListaItemVersaoProposta listaItemVersaoProposta,
		final ListaItemVersaoPropostaPK listaItemVersaoPropostaPK) {

		final ListaItensEBO listaItens = itemDocumentoEmissao.getListaItens();

		if (listaItens != null) {

			listaItemVersaoPropostaPK.setCodigoListaItem(EmissaoConvertTypes.convertBigIntToInt(listaItens
				.getCodigoListaItem()));

			if ((listaItens.getComponentesListaItem() != null) && CollectionUtils.hasContents(listaItens
				.getComponentesListaItem().getComponentesListaItem())) {

				final List<ComponenteListaItemEBO> documentoEmissaoComponente = listaItens.getComponentesListaItem()
					.getComponentesListaItem();

				final List<ComponenteListaItemVersaoProposta> componenteListaItemVersaoPropostas = new ArrayList<>();

				for (final ComponenteListaItemEBO selectedDocEmCompontente : documentoEmissaoComponente) {

					final ComponenteListaItemVersaoProposta componenteListaItemVersaoProposta =
						new ComponenteListaItemVersaoProposta();
					final ComponenteListaItemVersaoPropostaPK componenteListaItemVersaoPropostaPK =
						new ComponenteListaItemVersaoPropostaPK();

					// set index 0
					componenteListaItemVersaoPropostaPK.setNumeroProposta(numeroProposta);
					componenteListaItemVersaoPropostaPK.setNumeroVersaoProposta(numeroVersaoProposta);
					componenteListaItemVersaoPropostaPK.setCodigoListaItem(getCodigoListaItem(itemDocumentoEmissaoList));
					componenteListaItemVersaoPropostaPK.setCodigoComponenteListaItem(EmissaoConvertTypes.convertBigIntToInt(
						selectedDocEmCompontente.getCodigoComponenteListaItem()));
					componenteListaItemVersaoProposta.setIdentificador(componenteListaItemVersaoPropostaPK);
					componenteListaItemVersaoProposta.setNomeComponenteListaItem(selectedDocEmCompontente
						.getNomeComponenteListaItem());

					if (selectedDocEmCompontente.getQuantidadeComponenteListaItem() != null) {
						final String quantidadeComponenteListaItem = String.valueOf(selectedDocEmCompontente
							.getQuantidadeComponenteListaItem());
						componenteListaItemVersaoProposta.setQuantidadeComponenteListaItem(new BigDecimal(
							quantidadeComponenteListaItem));
					}

					if (selectedDocEmCompontente.getValorComponenteListaItem() != null) {
						final String valorComponenteListaItem = String.valueOf(selectedDocEmCompontente
							.getValorComponenteListaItem());
						componenteListaItemVersaoProposta.setValorComponenteListaItem(new BigDecimal(
							valorComponenteListaItem));
					}

					componenteListaItemVersaoPropostas.add(componenteListaItemVersaoProposta);
				}

				listaItemVersaoProposta.setComponenteListaItemVersaoPropostas(componenteListaItemVersaoPropostas);
			}
		}

		listaItemVersaoProposta.setIdentificador(listaItemVersaoPropostaPK);

		if (CollectionUtils.hasContents(itemDocumentoEmissaoList)
				&& AssertUtil.isNotNull(itemDocumentoEmissaoList.get(0).getListaItens())) {
			listaItemVersaoProposta.setNomeListaItem(itemDocumentoEmissaoList.get(0).getListaItens().getNomeListaItem());
		}

		listaItemVersaoPropostas.add(listaItemVersaoProposta);
	}

	/** Convert CoberturaItemDocumentoEBO to CoberturaItemVersaoProposta.
	 * @param itemDocumentoEmissao parameter
	 * @param coberturaItems parameter
	 * @param coberturaItemVersaoPropostas parameter */
	private void convertCobItemDocEBOToCobItemVerProp(final ItemDocumentoEmissaoEBO itemDocumentoEmissao,
		final List<CoberturaItemDocumentoEBO> coberturaItems,
		final List<CoberturaItemVersaoProposta> coberturaItemVersaoPropostas) {

		for (final CoberturaItemDocumentoEBO selectedCoberturaItem : coberturaItems) {
			
			List<CoberturaItemBeneficiarioVersaoProposta> coberturaItemBeneficiarioVersaoPropostas = 
					new ArrayList<CoberturaItemBeneficiarioVersaoProposta>();
			
			final CoberturaItemVersaoProposta coberturaItemVersaoProposta = new CoberturaItemVersaoProposta();

			final BeneficiarioItemDocumentoEBO beneficiarios = selectedCoberturaItem.getBeneficiarios();

			if ((beneficiarios != null) && CollectionUtils.hasContents(beneficiarios.getBeneficiario())) {
				for (BeneficiarioEBO beneficiario : beneficiarios.getBeneficiario()) {
					
					CoberturaItemBeneficiarioVersaoProposta coberturaItemBeneficiarioVersaoProposta = new 
							CoberturaItemBeneficiarioVersaoProposta();
					coberturaItemBeneficiarioVersaoProposta.setCoberturaItemVersaoProposta(coberturaItemVersaoProposta);
					convertBeneficiarioTypeToEntity(itemDocumentoEmissao, selectedCoberturaItem,
						coberturaItemBeneficiarioVersaoProposta, beneficiario);
					coberturaItemBeneficiarioVersaoPropostas.add(coberturaItemBeneficiarioVersaoProposta);
					
				}
			}
			
			coberturaItemVersaoProposta.setCoberturaItemBeneficiarioVersaoPropostas(
				coberturaItemBeneficiarioVersaoPropostas);

			final CoberturaItemVersaoPropostaPK coberturaItemVersaoPropostaPK = new CoberturaItemVersaoPropostaPK();

			coberturaItemVersaoPropostaPK.setCodigoCobertura(EmissaoConvertTypes.convertBigIntToInt(selectedCoberturaItem
				.getCodigoCobertura()));

			coberturaItemVersaoPropostaPK.setNumeroProposta(itemDocumentoEmissao.getNumeroProposta());

			coberturaItemVersaoPropostaPK.setNumeroVersaoProposta(itemDocumentoEmissao.getNumeroVersaoProposta());

			coberturaItemVersaoPropostaPK.setNumeroItemVersaoProposta(EmissaoConvertTypes.convertBigIntToInt(
				itemDocumentoEmissao.getNumeroItemVersaoProposta()));

			coberturaItemVersaoProposta.setIdentificador(coberturaItemVersaoPropostaPK);

			final CoberturaItemVersaoOrcamento civo = convertToCoberturaItemVersaoOrcamento(itemDocumentoEmissao,
				selectedCoberturaItem);
			coberturaItemVersaoProposta.setCoberturaItemVersaoOrcamento(civo);

			coberturaItemVersaoProposta.setNumeroOrcamento(itemDocumentoEmissao.getNumeroOrcamento());

			coberturaItemVersaoProposta.setNumeroVersaoOrcamento(itemDocumentoEmissao.getNumeroVersaoOrcamento());

			coberturaItemVersaoPropostas.add(coberturaItemVersaoProposta);
		}
	}

	/** A method used to convert a list of IntervenienteVersaoProposta type to a list of IntervenienteVersaoProposta entity.
	 * @param numeroProposta - The numeroProposta to convert
	 * @param numeroVersaoProposta - The numeroVersaoProposta to convert
	 * @param typeClasses - The interveniente to convert
	 * @return entityClasses - the entity class List form. */
	@Override
	public List<IntervenienteVersaoProposta> convertIntervenienteVersaoPropostaToEntity(final Long numeroProposta,
		final Long numeroVersaoProposta, final List<IntervenienteEBO> typeClasses) {

		final List<IntervenienteVersaoProposta> entityClasses = new ArrayList<>();

		for (final IntervenienteEBO typeClass : typeClasses) {

			final IntervenienteVersaoProposta entityClass = new IntervenienteVersaoProposta();
			final IntervenienteVersaoPropostaPK ivpPk = new IntervenienteVersaoPropostaPK();

			final Integer codigoInterveniente = EmissaoConvertTypes.convertBigIntToInt(typeClass.getCodigoInterveniente());

			ivpPk.setNumeroProposta(numeroProposta);
			ivpPk.setNumeroVersaoProposta(numeroVersaoProposta);
			ivpPk.setCodigoInterveniente(codigoInterveniente);
			entityClass.setIdentificador(ivpPk);
			if (AssertUtil.isNotNull(typeClass.getCodigoTipoAtualizacao())) {
				TipoAtualizacao tipo = new TipoAtualizacao();
				tipo.setCodigoTipoAtualizacao(typeClass.getCodigoTipoAtualizacao().intValue());
				entityClass.setTipoAtualizacao(tipo);
			}
			if (typeClass.getCodigoTipoInterveniente() != null) {

				final TipoInterveniente tipoInterveniente = new TipoInterveniente();
				tipoInterveniente.setCodigoTipoInterveniente(EmissaoConvertTypes.convertBigIntToInt(typeClass
					.getCodigoTipoInterveniente()));
				entityClass.setTipoInterveniente(tipoInterveniente);
			}

			if ((typeClass.getDadosPessoaInterveniente() != null) && (typeClass.getDadosPessoaInterveniente()
				.getCodigoPessoa() != null)) {
				entityClass.setCodigoPessoa(typeClass.getDadosPessoaInterveniente().getCodigoPessoa());
			}

			if (typeClass.getCodigoTipoPessoa() != null) {

				final TipoPessoa tipoPessoa = new TipoPessoa();
				tipoPessoa.setCodigoTipoPessoa(EmissaoConvertTypes.convertBigIntToInt(typeClass.getCodigoTipoPessoa()));
				entityClass.setTipoPessoa(tipoPessoa);
			}

			entityClass.setNumeroCnpjCpf(typeClass.getNumeroCnpjCpf());
			entityClass.setNomeInterveniente(typeClass.getNomeInterveniente());

			if (typeClass.getCodigoTipoExposicaoPessoa() != null) {

				final TipoExposicaoPessoa tipoExposicaoPessoa = new TipoExposicaoPessoa();
				tipoExposicaoPessoa.setCodigoTipoExposicaoPessoa(EmissaoConvertTypes.convertBigIntToInt(typeClass
					.getCodigoTipoExposicaoPessoa()));
				entityClass.setTipoExposicaoPessoa(tipoExposicaoPessoa);
			}

			if (typeClass.getCodigoMotivoAusenciaCnpjCpf() != null) {

				final MotivoAusenciaCnpjCpf motivoAusenciaCnpjCpf = new MotivoAusenciaCnpjCpf();
				motivoAusenciaCnpjCpf.setCodigoMotivoAusenciaCnpjCpf(EmissaoConvertTypes.convertBigIntToInt(typeClass
					.getCodigoMotivoAusenciaCnpjCpf()));
				entityClass.setMotivoAusenciaCnpjCpf(motivoAusenciaCnpjCpf);
			}

			entityClass.setPercentualParticipacao(typeClass.getPercentualParticipacao());
			entityClass.setFlagAtivo(typeClass.getFlagAtivo());

			if ((typeClass.getExposicoes() != null) && CollectionUtils.hasContents(typeClass.getExposicoes()
				.getExposicao())) {

				entityClass.setExposicaoIntervenienteVersaoPropostas(convertExposicaoIntervenienteVersaoPropostaToEntity(
					typeClass.getExposicoes().getExposicao(), numeroProposta, numeroVersaoProposta, codigoInterveniente));
			}

			entityClasses.add(entityClass);
		}

		return entityClasses;
	}

	/** Convert list dia vencimento to type.
	 * @param listVencimentoFaturaTranspVrsPrp the list vencimento fatura transp vrs prp
	 * @return the list */
	public List<DiaVencimento> convertListDiaVencimentoToType(
		final List<VencimentoFaturaTransporteVersaoProposta> listVencimentoFaturaTranspVrsPrp) {

		List<DiaVencimento> listVencimentoConvert = new ArrayList<>();

		if (AssertUtil.isNotNullAndEmpty(listVencimentoFaturaTranspVrsPrp)) {

			for (VencimentoFaturaTransporteVersaoProposta vencimentoFaturaTranp : listVencimentoFaturaTranspVrsPrp) {

				DiaVencimento diaVencimento = new DiaVencimento();

				if ((vencimentoFaturaTranp.getEntityPK() != null)) {
					diaVencimento.setCodigoDiaVencimento(ConvertTypes.convertLongToBigInt(vencimentoFaturaTranp.getEntityPK()
						.getCodigoDiaVencimentoFaturaTransporte()));
					listVencimentoConvert.add(diaVencimento);
				}
			}
		}
		return listVencimentoConvert;
	}
	
	/** Convert Devolutiva.
	 * @param devolutiva parameter
	 * @return DevolutivaEBO */
	public DevolutivaEBO convertDevolutiva(final Devolutiva devolutiva) {
		final DevolutivaEBO devolutivaType = new DevolutivaEBO();
		if (AssertUtil.isNotNull(devolutiva)) {
			devolutivaType.setCodigoDevolutiva(EmissaoConvertTypes.convertIntToBigInt(devolutiva.getCodigoDevolutiva()));
			devolutivaType.setNomeDevolutiva(devolutiva.getNomeDevolutiva());
			devolutivaType.setNomeResumidoDevolutiva(devolutiva.getNomeResumidoDevolutiva());
			if (null != devolutiva.getTipoDevolutiva()) {
				devolutivaType.setCodigoTipoDevolutiva(EmissaoConvertTypes.convertIntToBigInt(devolutiva.getTipoDevolutiva()
					.getCodigoTipoDevolutiva()));
			}
			if (devolutiva.getModeloCarta() != null) {
				devolutivaType.setCodigoModeloCarta(EmissaoConvertTypes.convertIntToBigInt(devolutiva.getModeloCarta()
					.getCodigoModeloCarta()));
			}
			devolutivaType.setFlagAtivo(devolutiva.getFlagAtivo());
			devolutivaType.setTextoComentario(devolutiva.getTextoComentario());
		}

		return devolutivaType;
	}

	/** Convert Pendencias.
	 * @param pendenciaVersaoPropostas - The pendenciaVersaoPropostas to convert
	 * @return entityClasses - the entity class List form. */
	@Override
	public ListaPendenciasEBO convertPendencias(final List<PendenciaVersaoProposta> pendenciaVersaoPropostas) {

		final ListaPendenciasEBO pendenciaVersaoPropostaType = new ListaPendenciasEBO();

		for (final PendenciaVersaoProposta selected : pendenciaVersaoPropostas) {

			final PendenciaEBO pendenciaType = new PendenciaEBO();

			if (selected.getPendencia() != null) {
				pendenciaType.setCodigoPendencia(EmissaoConvertTypes.convertIntToBigInt(selected.getPendencia()
					.getCodigoPendencia()));
			}

			pendenciaType.setNumeroSequenciaPendencia(EmissaoConvertTypes.convertIntToBigInt(selected.getIdentificador()
				.getNumeroSequenciaPendencia()));

			if (selected.getStatusPendencia() != null) {
				pendenciaType.setCodigoStatusPendencia(EmissaoConvertTypes.convertIntToBigInt(selected.getStatusPendencia()
					.getCodigoStatusPendencia()));
			}

			if (selected.getDevolutiva() != null) {
				pendenciaType.setCodigoDevolutiva(EmissaoConvertTypes.convertIntToBigInt(selected.getDevolutiva()
					.getCodigoDevolutiva()));
			}

			pendenciaType.setCodigoCorretor(selected.getCodigoCorretor());
			pendenciaType.setTextoPendencia(selected.getTextoPendencia());

			if (selected.getDataRegistroAbertura() != null) {
				pendenciaType.setDataRegistroAbertura(EmissaoConvertTypes.convertDateToXMLGreg(selected
					.getDataRegistroAbertura()));
			}

			final List<RespostaPendenciaVersaoProposta> respostaPendencias = selected.getRespostaPendenciaVersaoPropostas();

			final ListaRespostaPendenciaEBO respostaPendenciaVesaoPropostaType = new ListaRespostaPendenciaEBO();

			if (respostaPendencias != null) {
				convertListOfRespostaPendenciaVersaoProposta(respostaPendencias, respostaPendenciaVesaoPropostaType);
			}

			pendenciaType.setListaRespostasPendencia(respostaPendenciaVesaoPropostaType);
			pendenciaVersaoPropostaType.getPendencia().add(pendenciaType);
		}

		return pendenciaVersaoPropostaType;
	}

	/** Convert RespostaPendenciaVersaoProposta to RespostaPendenciaVersaoProposta.
	 * @param respostaPendencias parameter
	 * @param respostaPendenciaVesaoPropostaType parameter */
	private void convertListOfRespostaPendenciaVersaoProposta(final List<RespostaPendenciaVersaoProposta> respostaPendencias,
		final ListaRespostaPendenciaEBO respostaPendenciaVesaoPropostaType) {

		if (respostaPendencias != null) {
			for (final RespostaPendenciaVersaoProposta selectedRespostaPendencia : respostaPendencias) {

				final RespostaPendenciaEBO respostaPendenciaType = new RespostaPendenciaEBO();

				respostaPendenciaType.setNumeroSequenciaRespostaPendencia(EmissaoConvertTypes.convertIntToBigInt(
					selectedRespostaPendencia.getIdentificador().getNumeroSequenciaRespostaPendencia()));

				if (selectedRespostaPendencia.getDataResposta() != null) {
					respostaPendenciaType.setDataResposta(EmissaoConvertTypes.convertDateToXMLGreg(selectedRespostaPendencia
						.getDataResposta()));
				}

				respostaPendenciaType.setTextoRespostaPendencia(selectedRespostaPendencia.getTextoRespostaPendencia());

				respostaPendenciaType.setFlagPossuiAnexo(selectedRespostaPendencia.getFlagPossuiAnexo());

				respostaPendenciaType.setCodigoIdentificacaoDocumento(selectedRespostaPendencia
					.getCodigoIdentificacaoDocumento());

				final AuditoriaEBO auditoria = new AuditoriaEBO();

				auditoria.setCodigoEmpresaUsuarioUltimaAlteracao(selectedRespostaPendencia
					.getCodigoEmpresaUsuarioUltimaAlteracao());

				auditoria.setCodigoMatriculaUsuarioUltimaAlteracao(selectedRespostaPendencia
					.getCodigoEmpresaUsuarioUltimaAlteracao());

				auditoria.setCodigoTipoUsuarioUltimaAlteracao(selectedRespostaPendencia
					.getCodigoTipoUsuarioUltimaAlteracao());

				auditoria.setDataUltimaAlteracao(EmissaoConvertTypes.convertDateToXMLGreg(selectedRespostaPendencia
					.getDataUltimaAlteracao()));

				respostaPendenciaType.setAuditoria(auditoria);

				respostaPendenciaVesaoPropostaType.getRespostaPendencia().add(respostaPendenciaType);
			}
		}

	}

	/** Method used to convert VersaoProposta to Type.
	 * @param convertedDocumentoEmissao - The convertedDocumentoEmissao to convert
	 * @param selected - The VersaoProposta object. */
	public void convertVersaoProposta(final DocumentoEmissaoEBO convertedDocumentoEmissao, final VersaoProposta selected) {

		if ((selected.getIdentificador() != null) && (selected.getIdentificador().getNumeroVersaoProposta() != null)) {
			convertedDocumentoEmissao.setNumeroVersaoProposta(selected.getIdentificador().getNumeroVersaoProposta());
			convertedDocumentoEmissao.setNumeroProposta(selected.getIdentificador().getNumeroProposta());
		}

		if (selected.getProposta() != null) {
			convertProposta(selected.getProposta(), convertedDocumentoEmissao);
		}

		convertVersaoPropostaFields(convertedDocumentoEmissao, selected);
		getSolicitacaoRestgatePontos(convertedDocumentoEmissao, selected);
		// if (selected.getNumeroSorteTituloCapitalizacao() != null) {
		// convertedDocumentoEmissao.setNumeroSorteTituloCapitalizacao(selected.getNumeroSorteTituloCapitalizacao()
		// .longValue());
		// }

		final EnderecoEBO enderecoType = new EnderecoEBO();

		if (selected.getCodigoEnderecoCorrespondencia() != null) {

			enderecoType.setCodigoEndereco(selected.getCodigoEnderecoCorrespondencia());
			convertedDocumentoEmissao.setEnderecoCorrespondencia(enderecoType);
		}

		// Missing attributes from DocumentoEmissaoEBO
		// flagRenovacaoAutomatico
		// codigoTipoOrganizacao

		convertedDocumentoEmissao.setFlagEndossoAlteracaoDadoCadastralSegurado(selected
			.getFlagEndossoAlteracaoDadoCadastralSegurado());
		convertedDocumentoEmissao.setNomeProcessoSistemaGerenciamentoProcesso(selected
			.getNomeProcessoSistemaGerenciamentoProcesso());

		if ((selected.getAnaliseVersaoPropostas() != null) && !selected.getAnaliseVersaoPropostas().isEmpty()) {
			convertedDocumentoEmissao.setAnalises(convertAnalise(selected.getAnaliseVersaoPropostas())); // FIX
		}

		if (selected.getVersaoOrcamento() != null) {
			final Orcamento orcamento = selected.getVersaoOrcamento().getOrcamento();
			List<VersaoOrcamento> listaVersaoOrcamento = new ArrayList<>();
			listaVersaoOrcamento.add(selected.getVersaoOrcamento());
			orcamento.setVersaoOrcamentos(listaVersaoOrcamento);
			iOrcamentoSOAPConverter.convertToType(orcamento, convertedDocumentoEmissao);
			iOrcamentoSOAPConverter.convertVersaoOrcamentoToType(
					selected.getVersaoOrcamento(), convertedDocumentoEmissao, Boolean.FALSE);
		}

		// Moved for Locking functionality Functional Design Update
		convertedDocumentoEmissao.setFlagBloqueio(selected.getFlagBloqueio());
		convertedDocumentoEmissao.setDataBloqueio(EmissaoConvertTypes.convertDateToXMLGreg(selected.getDataBloqueio()));
		convertedDocumentoEmissao.setCodigoTipoUsuarioBloqueio(selected.getCodigoTipoUsuarioBloqueio());
		convertedDocumentoEmissao.setCodigoEmpresaUsuarioBloqueio(selected.getCodigoEmpresaUsuarioBloqueio());
		convertedDocumentoEmissao.setCodigoMatriculaUsuarioBloqueio(selected.getCodigoMatriculaUsuarioBloqueio());

		// FIX 5382 Campo não existe no ebo 99.48.27
		convertedDocumentoEmissao.setDataProtocoloImpressao(EmissaoConvertTypes.convertDateToXMLGreg(selected
			.getDataProtocolo()));

		/*
		 * DocumentoEmissaoEBO only needs the PK of VersaoOrcamento to be
		 * converted. NOTE: Removed 20160819
		 */
		if (selected.getVersaoOrcamento() != null) {
			convertedDocumentoEmissao.setNumeroOrcamento(selected.getVersaoOrcamento().getIdentificador()
				.getNumeroOrcamento());
			convertedDocumentoEmissao.setNumeroVersaoOrcamento(selected.getVersaoOrcamento().getIdentificador()
				.getNumeroVersaoOrcamento());
			if (!(selected.getVersaoOrcamento().getOrcamento() == null)) {
				convertedDocumentoEmissao.setCodigoOferta(selected.getVersaoOrcamento().getOrcamento().getCodigoOferta());
				convertedDocumentoEmissao.setNumeroVersaoOferta(selected.getVersaoOrcamento().getOrcamento()
					.getNumeroVersaoOferta());
				convertedDocumentoEmissao.setNumeroSequenciaVersaoOferta(BigInteger.valueOf(selected.getVersaoOrcamento()
					.getOrcamento().getNumeroSequenciaVersaoOferta()));
				convertedDocumentoEmissao.setCodigoRamo(BigInteger.valueOf(selected.getVersaoOrcamento().getOrcamento()
					.getCodigoRamo()));
				convertedDocumentoEmissao.setCodigoEmpresa(BigInteger.valueOf(selected.getVersaoOrcamento().getOrcamento()
					.getCodigoEmpresa()));
				convertedDocumentoEmissao.setCodigoModalidade(BigInteger.valueOf(selected.getVersaoOrcamento().getOrcamento()
					.getCodigoModalidade()));
				convertedDocumentoEmissao.setCodigoGrupoComercial(EmissaoConvertTypes.convertIntToBigInt(selected
					.getVersaoOrcamento().getOrcamento().getCodigoGrupoComercial()));
			}
			if (selected.getVersaoOrcamento().getOnus() != null) {
				convertedDocumentoEmissao.setCodigoOnus(EmissaoConvertTypes.convertIntToBigInt(selected.getVersaoOrcamento()
					.getOnus().getCodigoOnus()));
			}

			if ((selected.getAnaliseVersaoPropostas() != null) && !selected.getAnaliseVersaoPropostas().isEmpty()) {
				convertAnalise(selected.getAnaliseVersaoPropostas());
				convertedDocumentoEmissao.setAnalises(convertAnalise(selected.getAnaliseVersaoPropostas())); // FIX
																												// 5286
			}
		}
	}
	
	/**
	 * Gets the solicitacao restgate pontos.
	 *
	 * @param convertedDocumentoEmissao the converted documento emissao
	 * @param selected the selected
	 */
	private void getSolicitacaoRestgatePontos(
			final DocumentoEmissaoEBO convertedDocumentoEmissao, final VersaoProposta selected){
		if (AssertUtil.isNotEmptyList(selected.getSolicitacaoResgatePonto())) {
			for (final SolicitacaoResgatePontoCartaoCredito solPonto : selected.getSolicitacaoResgatePonto()) {
				if (AssertUtil.isNotNull(solPonto) 
						&& AssertUtil.isNotNullAndEmpty(solPonto.getCodigoFaixaResgatePonto())) {
					convertedDocumentoEmissao.setCodigoFaixaResgatePonto(solPonto.getCodigoFaixaResgatePonto());
				}
			}
		}
	}

	/** Convert VersaoProposta fields.
	 * @param convertedDocumentoEmissao parameter
	 * @param selected parameter */
	private void convertVersaoPropostaFields(final DocumentoEmissaoEBO convertedDocumentoEmissao,
		final VersaoProposta selected) {

		if ((selected.getFormaPagamento() != null) && (selected.getFormaPagamento().getCodigoFormaPagamento() != null)) {

			convertedDocumentoEmissao.setCodigoFormaPagamento(EmissaoConvertTypes.convertIntToLong(selected
				.getFormaPagamento().getCodigoFormaPagamento()));
		}

		convertedDocumentoEmissao.setDataProtocolo(EmissaoConvertTypes.convertDateToXMLGreg(selected.getDataProtocolo()));
		convertedDocumentoEmissao.setDataEmissao(EmissaoConvertTypes.convertDateToXMLGreg(selected.getDataEmissao()));
		convertedDocumentoEmissao.setNumeroPropostaAutomovel(selected.getNumeroPropostaAutomovel());
		convertedDocumentoEmissao.setFlagPossuiCorretorSecundario(selected.getFlagPossuiCorretorSecundario());
		convertedDocumentoEmissao.setFlagPossuiBeneficiario(selected.getFlagPossuiBeneficiario());
		convertedDocumentoEmissao.setFlagPossuiSinistro(selected.getFlagPossuiSinistro());
		// convertedDocumentoEmissao.setFlagPrimeiraCompraCartaoEmpresa(selected.getFlagPrimeiraCompraCartaoEmpresa());
		convertedDocumentoEmissao.setFlagEnvioEmailCorretor(selected.getFlagEnvioEmailCorretor());
		if(selected.getFlagEnvioEmailImobiliaria() == "S" && selected.getFlagEnvioEmailCorretor() == "S") {
			convertedDocumentoEmissao.setFlagEnvioEmailCorretor("T");
		}
		else if(selected.getFlagEnvioEmailImobiliaria() == "S" && selected.getFlagEnvioEmailCorretor() == "N") {
			convertedDocumentoEmissao.setFlagEnvioEmailCorretor("I");
		}
		
		convertedDocumentoEmissao.setFlagPossuiTituloCapitalizacao(selected.getFlagPossuiTituloCapitalizacao());
		convertedDocumentoEmissao.setDataInicioVigencia(EmissaoConvertTypes.convertDateToXMLGreg(selected
			.getDataInicioVigencia()));
		convertedDocumentoEmissao.setDataFimVigencia(EmissaoConvertTypes.convertDateToXMLGreg(selected
			.getDataFimVigencia()));
		convertedDocumentoEmissao.setDataMelhorDataPrimeiraParcela(EmissaoConvertTypes.convertDateToXMLGreg(selected
			.getDataMelhorDataPrimeiraParcela()));

		// Impressao emissao - convert dados de versaoOrcamento 12/05/2016
		// danilo.da.silva
		if (selected.getVersaoOrcamento() != null) {
			iOrcamentoSOAPConverter.convertVersaoOrcamentoToType(
					selected.getVersaoOrcamento(), convertedDocumentoEmissao, Boolean.FALSE);
		}
	}

	/** Convert Corretor to Type.
	 * @param numeroProposta parameter
	 * @param numeroVersaoProposta parameter
	 * @param corretorVersaoProposta parameter
	 * @return DocumentoEmissaoEBO */
	@Override
	public DocumentoEmissaoEBO convertCorretorToType(final Long numeroProposta, final Long numeroVersaoProposta,
		final List<CorretorVersaoProposta> corretorVersaoProposta) {

		final ListaCorretoresEBO listaCorretoresType = convertCorretorToType(corretorVersaoProposta);

		final DocumentoEmissaoEBO newDocumentoEmissao = new DocumentoEmissaoEBO();

		if (CollectionUtils.hasContents(listaCorretoresType.getCorretor())) {
			newDocumentoEmissao.setNumeroProposta(numeroProposta);
			newDocumentoEmissao.setNumeroVersaoProposta(numeroVersaoProposta);
			newDocumentoEmissao.setCorretores(listaCorretoresType);
		}
		return newDocumentoEmissao;
	}

	/** Convert Pagador to Type.
	 * @param numeroProposta parameter
	 * @param numeroVersaoProposta parameter
	 * @param pagadorVersaoProposta parameter
	 * @return DocumentoEmissaoEBO */
	@Override
	public DocumentoEmissaoEBO convertPagadorToType(final Long numeroProposta, final Long numeroVersaoProposta,
		final List<PagadorVersaoProposta> pagadorVersaoProposta) {
		final ListaPagadoresEBO listaPagadoresType = new ListaPagadoresEBO();
		for (final PagadorVersaoProposta selected : pagadorVersaoProposta) {
			listaPagadoresType.getPagador().add(convertPagadorToType(selected));
		}
		final DocumentoEmissaoEBO newDocumentoEmissao = new DocumentoEmissaoEBO();
		newDocumentoEmissao.setNumeroProposta(numeroProposta);
		newDocumentoEmissao.setNumeroVersaoProposta(numeroVersaoProposta);
		newDocumentoEmissao.setPagadores(listaPagadoresType);
		return newDocumentoEmissao;
	}

	/** Convert Pagador to Type.
	 * @param pagadorVersaoProposta parameter
	 * @return PagadorEBO */
	@Override
	public PagadorEBO convertPagadorToType(final PagadorVersaoProposta pagadorVersaoProposta) {
		final PagadorEBO pagador = new PagadorEBO();
		if ((pagadorVersaoProposta != null) && (pagadorVersaoProposta.getIdentificador() != null) && (pagadorVersaoProposta
			.getIdentificador().getCodigoPessoa() != null)) {
			final PessoaEBO pessoaEBO = new PessoaEBO();
			pessoaEBO.setCodigoPessoa(pagadorVersaoProposta.getIdentificador().getCodigoPessoa());
			pagador.setDadosPessoaPagador(pessoaEBO);
			final EnderecoEBO enderecoEBO = new EnderecoEBO();
			enderecoEBO.setCodigoEndereco(pagadorVersaoProposta.getCodigoEnderecoCobranca());
			pagador.setEnderecoCobranca(enderecoEBO);
			final ListaPagadorParcelaEBO listarPagador = convertPagadoresParcela(
				pagadorVersaoProposta.getPagadorParcelaVersaoPropostas());

			pagador.setPagadoresParcela(listarPagador);
		}
		return pagador;
	}

	/** Method used to convert AnaliseVersaoProposta to Type.
	 * @param analiseVersaoPropostas - The analiseVersaoPropostas to convert
	 * @return listaAnalisesType - The entity class List form. */
	@Override
	public ListaAnalisesEBO convertAnalise(final List<AnaliseVersaoProposta> analiseVersaoPropostas) {

		final ListaAnalisesEBO listaAnalisesType = new ListaAnalisesEBO();
		for (final AnaliseVersaoProposta selected : analiseVersaoPropostas) {
			final AnaliseEBO analiseType = new AnaliseEBO();
			analiseType.setNumeroSequenciaAnalise(EmissaoConvertTypes.convertIntToBigInt(selected.getId()
				.getNumeroSequenciaAnalise()));
			final StatusParecer statusParecer = selected.getStatusParecer();
			if (statusParecer != null) {
				analiseType.setCodigoStatusParecer(EmissaoConvertTypes.convertIntToBigInt(statusParecer
					.getCodigoStatusParecer()));
			}
			final TipoParecer tipoParecer = selected.getTipoParecer();
			if (tipoParecer != null) {
				analiseType.setCodigoTipoParecer(EmissaoConvertTypes.convertIntToBigInt(tipoParecer.getCodigoTipoParecer()));
			}
			analiseType.setTextoAnalise(selected.getTextoAnalise());
			analiseType.setCodigoEmpresaUsuarioUltimaAlteracao(selected.getCodigoEmpresaUsuarioUltimaAlteracao());
			analiseType.setCodigoMatriculaUsuarioUltimaAlteracao(selected.getCodigoMatriculaUsuarioUltimaAlteracao());
			analiseType.setCodigoTipoUsuarioUltimaAlteracao(selected.getCodigoTipoUsuarioUltimaAlteracao());
			try {
				setDataUltimaAlteracaoInFormatXmlGregorian(selected, analiseType);
			} catch (DatatypeConfigurationException e) {
				LOGGER.info(e.getMessage());
			}
			listaAnalisesType.getAnalise().add(analiseType);
		}

		return listaAnalisesType;
	}

	/** Sets the data ultima alteracao in format xml gregorian.
	 * @param analiseVersaoProposta the analise versao proposta
	 * @param analiseEBO the analise EBO
	 * @throws DatatypeConfigurationException the datatype configuration exception */
	private void setDataUltimaAlteracaoInFormatXmlGregorian(final AnaliseVersaoProposta analiseVersaoProposta,
		final AnaliseEBO analiseEBO) throws DatatypeConfigurationException {
		GregorianCalendar gregorianCalendar = new GregorianCalendar();
		gregorianCalendar.setTime(analiseVersaoProposta.getDataUltimaAlteracao());
		// PERFORMANCE - ADT Defect 6925
		XMLGregorianCalendar calendar = DATATYPE_FACTORY.newXMLGregorianCalendar(gregorianCalendar);
		analiseEBO.setDataUltimaAlteracao(calendar);
	}

	/** Convert versao orcamento.
	 * @param documentoEmissaoEbo the documento emissao ebo
	 * @return the long */
	public Long convertVersaoOrcamento(final DocumentoEmissaoEBO documentoEmissaoEbo) {
		Long numeroVersaoProposta = 0L;

		if ((documentoEmissaoEbo != null) && (documentoEmissaoEbo.getNumeroVersaoProposta() != null)) {
			numeroVersaoProposta = documentoEmissaoEbo.getNumeroVersaoProposta();
		}
		return numeroVersaoProposta;
	}

	/**
	 * Gets the codigo lista item.
	 * @param itemDocumentoEmissaoList the item documento emissao list
	 * @return the codigo lista item
	 */
	private Integer getCodigoListaItem(final List<ItemDocumentoEmissaoEBO> itemDocumentoEmissaoList) {
		Integer codigoListaItem = NUMERO_UM;
		if (AssertUtil.isNotEmptyList(itemDocumentoEmissaoList) && AssertUtil.isNotNull(itemDocumentoEmissaoList.get(0))
				&& AssertUtil.isNotNull(itemDocumentoEmissaoList.get(0).getListaItens())
				&& AssertUtil.isNotNull(itemDocumentoEmissaoList.get(0).getListaItens().getCodigoListaItem())) {
			codigoListaItem = EmissaoConvertTypes
					.convertBigIntToInt(itemDocumentoEmissaoList.get(0).getListaItens().getCodigoListaItem());
		}

		return codigoListaItem;
	}
}
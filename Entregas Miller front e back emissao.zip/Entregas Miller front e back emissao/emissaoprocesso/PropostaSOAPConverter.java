//CHECKSTYLE:OFF: checkstyle:filelengths
/*******************************************************************************
 * Copyright (c) 2014-2014, 2015 Porto Seguro Seguros S.A., Inc. All Rights Reserved.
 *
 * Este software contém informações confidenciais e de propriedade da Porto Seguro Seguros S.A. ("Informações Confidenciais").
 * Você não deve divulgar qualquer tipo de informações confidenciais e deve usá-las apenas, de acordo com os termos do
 * contrato de licença firmado com a Porto Seguro.
 *
 * A Porto Seguro não faz declarações ou garantias sobre a adequação do software, expressa ou implicitamente, incluindo,
 * mas não se limitando, a garantias de comercialização, adequação para um determinado fim ou qualquer tipo de violação.
 *
 * A PORTO SEGURO NÃO SERÁ RESPONSÁVEL POR QUAISQUER DANOS SOFRIDOS PELO LICENCIADO EM DECORRÊNCIA DO USO, MODIFICAÇÃO
 * OU DISTRIBUIÇÃO DESTE SOFTWARE OU SEUS DERIVADOS.
 *
 *
 * Criado em(Created on): 28/07/2017
 * Autor(Author)        : gilson.tavares.filho@accenture.com
 *
 * -----------------------------------------------------------------------------
 * Histórico da Revisão (Revision History) - Release 1.0.0
 * -----------------------------------------------------------------------------
 *  VERSÃO      DATA           AUTOR                DESCRIÇÃO DA MUDANÇA
 * (VERSION)   (DATE)         (AUTHOR)             (DESCRIPTION OF CHANGE)
 * -----------------------------------------------------------------------------
 * 1.0.0   | 28/07/2017 | gilson.tavares.filh| Criação Inicial (Initial Create)
 * --------|------------|--------------------|----------------------------------
 *******************************************************************************/
package com.porto.re.emissaoprocesso.converter;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.porto.re.administrativo.entity.AgenciaBancaria;
import com.porto.re.administrativo.entity.AgenciaBancariaPK;
import com.porto.re.administrativo.entity.BandeiraCartao;
import com.porto.re.administrativo.entity.Canal;
import com.porto.re.administrativo.entity.FrequenciaFatoramento;
import com.porto.re.administrativo.entity.PrazoAverbacao;
import com.porto.re.administrativo.entity.StatusParcela;
import com.porto.re.administrativo.entity.StatusParecer;
import com.porto.re.administrativo.entity.Sucursal;
import com.porto.re.administrativo.entity.SucursalPK;
import com.porto.re.administrativo.entity.TipoParecer;
import com.porto.re.administrativo.entity.TipoPessoa;
import com.porto.re.common.AssertUtil;
import com.porto.re.common.CollectionUtils;
import com.porto.re.common.Constants;
import com.porto.re.common.ConvertTypes;
import com.porto.re.common.EmissaoConvertTypes;
import com.porto.re.common.Util;
import com.porto.re.emissaocadastro.entity.Devolutiva;
import com.porto.re.emissaoprocesso.converter.interfaces.IOrcamentoSOAPConverter;
import com.porto.re.emissaoprocesso.converter.interfaces.IPropostaSOAPConverter;
import com.porto.re.emissaoprocesso.entity.AnaliseVersaoProposta;
import com.porto.re.emissaoprocesso.entity.AnaliseVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.CorretorVersaoProposta;
import com.porto.re.emissaoprocesso.entity.CorretorVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.CriticaSeguro;
import com.porto.re.emissaoprocesso.entity.CriticaSeguroItemVersaoProposta;
import com.porto.re.emissaoprocesso.entity.CriticaSeguroItemVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.CriticaSeguroVersaoProposta;
import com.porto.re.emissaoprocesso.entity.CriticaSeguroVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.FormaPagamento;
import com.porto.re.emissaoprocesso.entity.IntervenienteVersaoProposta;
import com.porto.re.emissaoprocesso.entity.ItemVersaoProposta;
import com.porto.re.emissaoprocesso.entity.ItemVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.Orcamento;
import com.porto.re.emissaoprocesso.entity.PagadorParcelaVersaoProposta;
import com.porto.re.emissaoprocesso.entity.PagadorParcelaVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.PagadorVersaoProposta;
import com.porto.re.emissaoprocesso.entity.PagadorVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.PendenciaVersaoProposta;
import com.porto.re.emissaoprocesso.entity.Proposta;
import com.porto.re.emissaoprocesso.entity.RespostaPendenciaVersaoProposta;
import com.porto.re.emissaoprocesso.entity.SolicitacaoResgatePontoCartaoCredito;
import com.porto.re.emissaoprocesso.entity.StatusCriticaSeguroItemVersaoProposta;
import com.porto.re.emissaoprocesso.entity.StatusCriticaSeguroItemVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.StatusCriticaSeguroVersaoProposta;
import com.porto.re.emissaoprocesso.entity.StatusCriticaSeguroVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.StatusVersaoProposta;
import com.porto.re.emissaoprocesso.entity.StatusVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.VencimentoFaturaTransporteVersaoProposta;
import com.porto.re.emissaoprocesso.entity.VencimentoFaturaTransporteVersaoPropostaPK;
import com.porto.re.emissaoprocesso.entity.VersaoOrcamento;
import com.porto.re.emissaoprocesso.entity.VersaoOrcamentoPK;
import com.porto.re.emissaoprocesso.entity.VersaoProposta;
import com.porto.re.emissaoprocesso.entity.VersaoPropostaPK;

import br.com.portoseguro.ramoselementares.emissao.analiseemissaoebo.v1.AnaliseEBO;
import br.com.portoseguro.ramoselementares.emissao.criticaemissaoebo.v1.CriticaEBO;
import br.com.portoseguro.ramoselementares.emissao.criticaemissaoebo.v1.DevolutivaEBO;
import br.com.portoseguro.ramoselementares.emissao.criticaemissaoebo.v1.ListaDevolutivaEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.AuditoriaEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.CorretorEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.DiaVencimento;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.DiasVencimento;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.DocumentoEmissaoEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.FormaPagamentoEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaAnalisesEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaCorretoresEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaCriticasEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaIntervenientesEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaPagadorParcelaEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaPagadoresEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaPendenciasEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.ListaRespostaPendenciaEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.PagadorEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.PagadorParcelaEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.PendenciaEBO;
import br.com.portoseguro.ramoselementares.emissao.documentoemissaoebo.v1.RespostaPendenciaEBO;
import br.com.portoseguro.ramoselementares.emissao.itemdocumentoemissaoebo.v1.CoberturaItemDocumentoEBO;
import br.com.portoseguro.ramoselementares.emissao.itemdocumentoemissaoebo.v1.CoberturasItemEBO;
import br.com.portoseguro.ramoselementares.emissao.itemdocumentoemissaoebo.v1.ItemDocumentoEmissaoEBO;
import br.com.portoseguro.ramoselementares.emissao.itemdocumentoemissaoebo.v1.ListaCoberturaItemEBO;
import br.com.portoseguro.ramoselementares.emissao.itemdocumentoemissaoebo.v1.ListaCriticasItensEBO;
import br.com.portoseguro.ramoselementares.emissao.itemdocumentoemissaoebo.v1.ListaItensEBO;
import br.com.portoseguro.ramoselementares.pessoa.enderecoebo.v1.EnderecoEBO;
import br.com.portoseguro.ramoselementares.pessoa.pessoaebo.v1.PessoaEBO;

/** DocumentoEmissaoTypeConverter. Type -> Entity and vice versa. */
@SuppressWarnings({ "PMD.ExcessiveImports", "PMD.CyclomaticComplexity", "PMD.TooManyMethods",
	"checkstyle:cyclomaticcomplexity", "filelength", "PMD.ExcessiveClassLength", "PMD.CouplingBetweenObjects" })
@Named
@ApplicationScoped
public class PropostaSOAPConverter implements IPropostaSOAPConverter {

	/** LOGGER. */
	private final static Logger LOGGER = LoggerFactory.getLogger(PropostaSOAPConverter.class.getName());

	/** FLAG_S. */
	private static final String FLAG_S = "S";

	/** OrcamentoSoapTypeConverter. */
	@Inject
	private transient IOrcamentoSOAPConverter iOrcamentoSOAPConverter;

	/** Proposta - DocumentoEmissaoEBO converter. */
	@Inject
	private transient PropostaSOAPConverterExt propostaTypeConverterExt;

	/** ZERO. */
	private static final int ZERO = 0;

	/**
	 * Convert to Entity.
	 *
	 * @param documentEmissao
	 *            parameter
	 * @return Proposta
	 */
	@Override
	public Proposta convertToEntity(final DocumentoEmissaoEBO documentEmissao) {
		final Proposta proposta = new Proposta();

		proposta.setNumeroProposta(documentEmissao.getNumeroProposta());
		proposta.setNumeroSequenciaProposta(documentEmissao.getNumeroSequenciaProposta());
		proposta.setCodigoOrigemEmissao(EmissaoConvertTypes.convertBigIntToInt(documentEmissao.getCodigoOrigemEmissao()));
		proposta.setNumeroOrcamento(documentEmissao.getNumeroOrcamento());

		final VersaoProposta versaoProposta = convertVersaoPropostaType(documentEmissao, proposta);

		Long numeroProposta = null;
		Long numeroVersaoProposta = null;
		final VersaoPropostaPK vrsPropostaId = versaoProposta.getIdentificador();

		if ((versaoProposta != null) && (vrsPropostaId != null)) {
			numeroProposta = vrsPropostaId.getNumeroProposta();
			numeroVersaoProposta = vrsPropostaId.getNumeroVersaoProposta();
		}
		if (documentEmissao.getCodigoStatusProposta() != null) {
			convertStatusVersaoPropostaType(documentEmissao, versaoProposta);
		}
		if ((documentEmissao.getIntervenientes() != null) && CollectionUtils.hasContents(documentEmissao.getIntervenientes()
			.getInterveniente())) {
			final List<IntervenienteVersaoProposta> intervenienteVersaoPropostas = propostaTypeConverterExt
				.convertIntervenienteVersaoPropostaToEntity(numeroProposta, numeroVersaoProposta, documentEmissao
					.getIntervenientes().getInterveniente());
			versaoProposta.setIntervenienteVersaoPropostas(intervenienteVersaoPropostas);
		}
		contConvertToEntity(documentEmissao, versaoProposta, numeroProposta, numeroVersaoProposta);
		convertVersaoOrcamentoToEntity(documentEmissao, versaoProposta);

		if (null != documentEmissao.getCodigoFormaPagamento()) {
			final FormaPagamento formaPagamento = new FormaPagamento();

			formaPagamento.setCodigoFormaPagamento(EmissaoConvertTypes.convertLongToInt(documentEmissao
				.getCodigoFormaPagamento()));

			if (((documentEmissao.getCodigoCanal() != null) && (documentEmissao.getCodigoCanal().intValue() == 2) ||
					(documentEmissao.getCodigoCanal() != null) && (documentEmissao.getCodigoCanal().intValue() == 7)) &&
				(documentEmissao.getFormasPagamento() != null)) {

				FormaPagamentoEBO formaPagamentoEBO = documentEmissao.getFormasPagamento().getFormaPagamento().get(ZERO);
				formaPagamento.setQuantidadeParcela(EmissaoConvertTypes.convertBigIntToInt(formaPagamentoEBO
					.getQuantidadeParcela()));
				formaPagamento.setCodigoMeioPagamentoPrimeiraParcela(EmissaoConvertTypes.convertBigIntToInt(formaPagamentoEBO
					.getCodigoMeioPagamentoPrimeiraParcela()));
				formaPagamento.setCodigoMeioPagamentoDemaisParcela(EmissaoConvertTypes.convertBigIntToInt(formaPagamentoEBO
					.getCodigoMeioPagamentoDemaisParcela()));
				formaPagamento.setNomeFormaPagamento(formaPagamentoEBO.getNomeFormaPagamento());
				formaPagamento.setFlagAtivo(formaPagamentoEBO.getFlagAtivo());
				formaPagamento.setNomeResumidoFormaPagamento(formaPagamentoEBO.getNomeResumidoFormaPagamento());
				formaPagamento.setTextoComentario(formaPagamentoEBO.getTextoComentario());
			}
			versaoProposta.setFormaPagamento(formaPagamento);
		}
		if ((documentEmissao.getCodigoCanal() != null) && (documentEmissao.getCodigoCanal().intValue() == 2) ||
				(documentEmissao.getCodigoCanal() != null) && (documentEmissao.getCodigoCanal().intValue() == 7)) {
			convertPagadorParcelaEntity(versaoProposta, documentEmissao);
		}
		proposta.getVersaoPropostas().add(versaoProposta);

		if (documentEmissao.getCodigoTipoDestinario() != null) {
			proposta.getVersaoPropostas().get(ZERO).setCodigoTipoDestinario(documentEmissao.getCodigoTipoDestinario());
		}
		if (documentEmissao.getFlagBloqueio() != null) {
			proposta.getVersaoPropostas().get(ZERO).setFlagBloqueio(documentEmissao.getFlagBloqueio());
		}
		return proposta;
	}

	/**
	 * Convert Pagador Parcela entity.
	 *
	 * @param versaoProposta
	 *            - Versao Proposta entity
	 * @param documentEmissao
	 *            - Documento Emissao EBO
	 */
	@SuppressWarnings("PMD.AvoidDeeplyNestedIfStmts")
	private void convertPagadorParcelaEntity(final VersaoProposta versaoProposta,
		final DocumentoEmissaoEBO documentEmissao) {

		List<PagadorVersaoProposta> pagadorVersaoPropostas = new ArrayList<>();

		final Long numeroProposta = versaoProposta.getIdentificador().getNumeroProposta();
		final Long numeroVersaoProposta = versaoProposta.getIdentificador().getNumeroVersaoProposta();

		if (documentEmissao.getPagadores() != null) {
			final List<PagadorEBO> pagador = documentEmissao.getPagadores().getPagador();

			for (PagadorEBO pagadorEBO : pagador) {
				List<PagadorParcelaVersaoProposta> pagadorParcelaVersaoPropostas = new ArrayList<>();
				PagadorVersaoProposta pagadorVersaoProposta = new PagadorVersaoProposta();
				PagadorVersaoPropostaPK pagadorVersaoPropostaPK = new PagadorVersaoPropostaPK();
				pagadorVersaoProposta.setIdentificador(pagadorVersaoPropostaPK);

				PessoaEBO dadosPessoaPagador = pagadorEBO.getDadosPessoaPagador();

				pagadorVersaoPropostaPK.setCodigoPessoa(dadosPessoaPagador.getCodigoPessoa());
				pagadorVersaoPropostaPK.setNumeroProposta(numeroProposta);
				pagadorVersaoPropostaPK.setNumeroVersaoProposta(numeroVersaoProposta);

				final EnderecoEBO enderecoCobranca = pagadorEBO.getEnderecoCobranca();

				if (enderecoCobranca != null) {
					pagadorVersaoProposta.setCodigoEnderecoCobranca(enderecoCobranca.getCodigoEndereco());
					pagadorVersaoProposta.setVersaoProposta(versaoProposta);
				}
				if (pagadorEBO.getPagadoresParcela() != null) {

					final List<PagadorParcelaEBO> pagadorParcela = pagadorEBO.getPagadoresParcela().getPagadorParcela();
					for (PagadorParcelaEBO pagadorParcelaEBO : pagadorParcela) {

						PagadorParcelaVersaoProposta pagadorParcelaVersaoProposta = new PagadorParcelaVersaoProposta();

						PagadorParcelaVersaoPropostaPK pagadorParcelaVersaoPropostaPK = new PagadorParcelaVersaoPropostaPK();
						pagadorParcelaVersaoPropostaPK.setNumeroParcela(EmissaoConvertTypes.convertBigIntToInt(
							pagadorParcelaEBO.getNumeroParcela()));
						if (AssertUtil.isNotNull(pagadorParcelaEBO.getDadosPessoaPagadorParcela())
								&& AssertUtil.isNotNull(
										pagadorParcelaEBO.getDadosPessoaPagadorParcela().getCodigoPessoa())) {
							pagadorParcelaVersaoPropostaPK.setCodigoPessoa(
									pagadorParcelaEBO.getDadosPessoaPagadorParcela().getCodigoPessoa());
						}else {
							pagadorParcelaVersaoPropostaPK.setCodigoPessoa(dadosPessoaPagador.getCodigoPessoa());
						}
						pagadorParcelaVersaoPropostaPK.setNumeroProposta(numeroProposta);
						pagadorParcelaVersaoPropostaPK.setNumeroVersaoProposta(numeroVersaoProposta);
						pagadorParcelaVersaoProposta.setIdentificador(pagadorParcelaVersaoPropostaPK);
						if (pagadorParcelaEBO.getValorParcela() != null) {
							pagadorParcelaVersaoProposta.setValorParcela(pagadorParcelaEBO.getValorParcela());
						}
						if (pagadorParcelaEBO.getCodigoTipoCartao() != null) {
							final BandeiraCartao bandeiraCartao = new BandeiraCartao();
							bandeiraCartao.setCodigoBandeiraCartao(pagadorParcelaEBO.getCodigoTipoCartao().intValue());
							// SM 4098
							/*
							 * TipoCartao tipoCartao = new TipoCartao();
							 * tipoCartao.setCodigoTipoCartao(
							 * EmissaoConvertTypes.convertBigIntToLong(
							 * pagadorParcelaEBO .getCodigoTipoCartao()));
							 * pagadorParcelaVersaoProposta.setTipoCartao(
							 * tipoCartao);
							 */
							pagadorParcelaVersaoProposta.setBandeiraCartao(bandeiraCartao);
						}
						StatusParcela statusParcela = new StatusParcela();
						statusParcela.setCodigoStatusParcela(EmissaoConvertTypes.convertBigIntToInt(pagadorParcelaEBO
							.getCodigoStatusParcela()));
						pagadorParcelaVersaoProposta.setStatusParcela(statusParcela);

						pagadorParcelaVersaoProposta.setCodigoIdentificacaoCartao(pagadorParcelaEBO
							.getCodigoIdentificacaoCartao());
						pagadorParcelaVersaoProposta.setAgenciaBancaria(convertAgenciaBancariaEntity(pagadorParcelaEBO));
						pagadorParcelaVersaoProposta.setDataCancelamento(EmissaoConvertTypes.convertXMLGregToDate(
							pagadorParcelaEBO.getDataCancelamento()));
						pagadorParcelaVersaoProposta.setDataPagamento(EmissaoConvertTypes.convertXMLGregToDate(
							pagadorParcelaEBO.getDataPagamento()));
						pagadorParcelaVersaoProposta.setDataPagamentoContabilizado(EmissaoConvertTypes.convertXMLGregToDate(
							pagadorParcelaEBO.getDataPagamentoContabilizado()));
						pagadorParcelaVersaoProposta.setDataPrazoCobertura(EmissaoConvertTypes.convertXMLGregToDate(
							pagadorParcelaEBO.getDataPrazoCobertura()));
						pagadorParcelaVersaoProposta.setDataVencimento(EmissaoConvertTypes.convertXMLGregToDate(
							pagadorParcelaEBO.getDataVencimento()));
						pagadorParcelaVersaoProposta.setDigitoContaBancaria(pagadorParcelaEBO.getDigitoContaBancaria());
						pagadorParcelaVersaoProposta.setFlagBloqueio(pagadorParcelaEBO.getFlagBloqueio());
						pagadorParcelaVersaoProposta.setNumeroContaBancaria(pagadorParcelaEBO.getNumeroContaBancaria());
						if (pagadorParcelaEBO.getDadosPessoaPagadorParcela() != null) {
							pagadorParcelaVersaoProposta.setNumeroCnpjCpfTitularCartao(pagadorParcelaEBO
								.getDadosPessoaPagadorParcela().getNumeroCnpjCpf());
						}

						pagadorParcelaVersaoProposta.setTextoComentario(pagadorParcelaEBO.getTextoComentario());

						pagadorParcelaVersaoPropostas.add(pagadorParcelaVersaoProposta);
					}
				}
				pagadorVersaoProposta.setPagadorParcelaVersaoPropostas(pagadorParcelaVersaoPropostas);
				pagadorVersaoPropostas.add(pagadorVersaoProposta);
			}
		}

		if ((pagadorVersaoPropostas != null) && !pagadorVersaoPropostas.isEmpty()) {
			versaoProposta.setPagadorVersaoPropostas(pagadorVersaoPropostas);
		}
	}

	/**
	 * Convert Agencia Bancaria entity.
	 *
	 * @param pagadorParcelaEBO
	 *            - Pagador Parcela EBO
	 * @return AgenciaBancaria
	 */
	private AgenciaBancaria convertAgenciaBancariaEntity(final PagadorParcelaEBO pagadorParcelaEBO) {

		AgenciaBancaria agenciaBancaria = new AgenciaBancaria();
		AgenciaBancariaPK pkAgencia = new AgenciaBancariaPK();
		pkAgencia.setCodigoBanco(EmissaoConvertTypes.convertBigIntToInt(pagadorParcelaEBO.getCodigoBanco()));

		if (pagadorParcelaEBO.getNumeroAgenciaBancaria() != null) {
			pkAgencia.setNumeroAgenciaBancaria(pagadorParcelaEBO.getNumeroAgenciaBancaria().toString());
		}
		agenciaBancaria.setIdentificador(pkAgencia);
		return agenciaBancaria;
	}

	/**
	 * Convert to CriticaSeguroVersaoProposta.
	 *
	 * @param criticas
	 *            parameter
	 * @return List<CriticaSeguroVersaoProposta>
	 */
	public List<CriticaSeguroVersaoProposta> convertToCriticaSeguroVersaoProposta(final List<CriticaEBO> criticas) {

		final List<CriticaSeguroVersaoProposta> criticaSeguroList = new ArrayList<>(criticas.size());

		for (final CriticaEBO criticaEBO : criticas) {
			final CriticaSeguroVersaoProposta criticaSeguro = convertToCriticaSeguroVersaoProposta(criticaEBO);

			criticaSeguroList.add(criticaSeguro);
		}
		return criticaSeguroList;
	}

	/**
	 * Convert to CriticaSeguroVersaoProposta.
	 *
	 * @param critica
	 *            parameter
	 * @return CriticaSeguroVersaoProposta
	 */
	public CriticaSeguroVersaoProposta convertToCriticaSeguroVersaoProposta(final CriticaEBO critica) {
		final CriticaSeguroVersaoProposta criticaSeguro = new CriticaSeguroVersaoProposta();
		final CriticaSeguroVersaoPropostaPK criticaSeguroPK = new CriticaSeguroVersaoPropostaPK();

		if (critica.getCodigoCritica() != null) {
			criticaSeguroPK.setCodigoCritica(critica.getCodigoCritica().intValue());
		}
		criticaSeguro.setIdentificador(criticaSeguroPK);
		if (critica.getDataCritica() != null) {
			criticaSeguro.setDataCritica(EmissaoConvertTypes.convertXMLGregToDate(critica.getDataCritica()));
		}
		criticaSeguro.setNomPerfPrincSistemGerencProcess(critica.getNomePerfilPrincipalSistemaGerenciamentoProcesso());

		critica.getCodigoStatusCritica();

		if (critica.getCodigoStatusCritica() != null) {

			final List<StatusCriticaSeguroVersaoProposta> statusCriticaVerProps = new ArrayList<>();
			final StatusCriticaSeguroVersaoProposta statusCritica = new StatusCriticaSeguroVersaoProposta();
			final StatusCriticaSeguroVersaoPropostaPK statusPK = new StatusCriticaSeguroVersaoPropostaPK();

			statusPK.setCodigoCritica(criticaSeguroPK.getCodigoCritica());
			if (critica.getCodigoStatusCritica() != null) {
				statusPK.setCodigoStatusCritica(critica.getCodigoStatusCritica().intValue());
			}
			statusCritica.setIdentificador(statusPK);
			statusCriticaVerProps.add(statusCritica);
			criticaSeguro.setStatusCriticaVersaoPropostas(statusCriticaVerProps);
		}

		criticaSeguro.setTxtPerfParticSistemGerencProcess(critica.getTextoPerfilParticipanteSistemaGerenciamentoProcesso());

		criticaSeguro.setTextoRetornoCritica(criticaSeguro.getTextoRetornoCritica());

		final CriticaSeguro criticaSeg = new CriticaSeguro();

		if (AssertUtil.isNotNull(critica.getCodigoCritica())) {
			criticaSeg.setCodigoCritica(critica.getCodigoCritica().intValue());
		}
		if (AssertUtil.isNotNull(critica.getTextoCritica())) {
			criticaSeg.setTextoCritica(critica.getTextoCritica());
		}
		if (AssertUtil.isNotNull(critica.getFlagJustificativaLiberacaoObrigatorio())) {
			criticaSeg.setFlagJustificativaLiberacaoObrigatorio(critica.getFlagJustificativaLiberacaoObrigatorio());
		}
		if (AssertUtil.isNotNull(critica.getTextoComentario())) {
			criticaSeg.setTextoComentario(critica.getTextoComentario());
		}
		criticaSeguro.setCritica(criticaSeg);

		return criticaSeguro;
	}

	/**
	 * Continue Convert to entity.
	 *
	 * @param documentEmissao
	 *            parameter
	 * @param versaoProposta
	 *            parameter
	 * @param numeroProposta
	 *            parameter
	 * @param numeroVersaoProposta
	 *            parameter
	 */
	private void contConvertToEntity(final DocumentoEmissaoEBO documentEmissao, final VersaoProposta versaoProposta,
		final Long numeroProposta, final Long numeroVersaoProposta) {

		List<PagadorVersaoProposta> pgdVrsPrps = null;

		if ((documentEmissao.getPagadores() != null) && CollectionUtils.hasContents(documentEmissao.getPagadores()
			.getPagador())) {

			pgdVrsPrps = new ArrayList<>();

			for (final PagadorEBO pagadorEBO : documentEmissao.getPagadores().getPagador()) {
				convertPagadorPropostaToEntity(numeroProposta, numeroVersaoProposta, pgdVrsPrps, pagadorEBO);
			}
		}

		versaoProposta.setPagadorVersaoPropostas(pgdVrsPrps);

		if ((documentEmissao.getItensDocumentoEmissao() != null) && CollectionUtils.hasContents(documentEmissao
			.getItensDocumentoEmissao().getItemDocumentoEmissao())) {
			final List<ItemVersaoProposta> itemVersaoPropostas = propostaTypeConverterExt.convertComponenteListaItemType(
				documentEmissao.getItensDocumentoEmissao().getItemDocumentoEmissao(), numeroProposta, numeroVersaoProposta);
			versaoProposta.setFlagPossuiBeneficiario(documentEmissao.getFlagPossuiBeneficiario());
			versaoProposta.setItemVersaoPropostas(itemVersaoPropostas);
		}
		if ((documentEmissao.getCorretores() != null) && CollectionUtils.hasContents(documentEmissao.getCorretores()
			.getCorretor())) {
			final List<CorretorVersaoProposta> corretorVersaoPropostas = convertCorretorToEntity(numeroProposta,
				numeroVersaoProposta, documentEmissao.getCorretores().getCorretor());
			versaoProposta.setCorretorVersaoPropostas(corretorVersaoPropostas);
		}
		if ((documentEmissao.getAnalises() != null) && CollectionUtils.hasContents(documentEmissao.getAnalises()
			.getAnalise())) {
			final List<AnaliseVersaoProposta> analiseVersaoPropostas = convertAnaliseToEntity(numeroProposta,
				numeroVersaoProposta, documentEmissao.getAnalises().getAnalise());
			versaoProposta.setAnaliseVersaoPropostas(analiseVersaoPropostas);
		}
	}

	/**
	 * Convert List of Corretor to Entity.
	 *
	 * @param documentEBO
	 *            - The corretorVersaoProposta to convert
	 * @return entityClasses - the entity class List form.
	 */
	public List<CorretorVersaoProposta> convertAnaliseToEntity(final DocumentoEmissaoEBO documentEBO) {

		final List<CorretorVersaoProposta> entityList = convertCorretorToEntity(documentEBO.getNumeroProposta(), documentEBO
			.getNumeroVersaoProposta(), documentEBO.getCorretores().getCorretor());

		return entityList;
	}

	/**
	 * Convert AnaliseVersaoProposta to Entity.
	 *
	 * @param numeroProposta
	 *            - The numeroProposta
	 * @param numeroVersaoProposta
	 *            - The numeroVersaoProposta
	 * @param docEmAnaliseList
	 *            - The docEmAnaliseList
	 * @return entityClasses - the entity class List form.
	 */
	public List<AnaliseVersaoProposta> convertAnaliseToEntity(final Long numeroProposta, final Long numeroVersaoProposta,
		final List<AnaliseEBO> docEmAnaliseList) {

		final List<AnaliseVersaoProposta> analiseVersaoPropostas = new ArrayList<>();

		for (final AnaliseEBO currentItem : docEmAnaliseList) {

			analiseVersaoPropostas.add(convertAnaliseToEntity(numeroProposta, numeroVersaoProposta, currentItem));
		}
		return analiseVersaoPropostas;
	}

	/**
	 * Convert Analise to Entity.
	 *
	 * @param numeroProposta
	 *            parameter
	 * @param numeroVersaoProposta
	 *            parameter
	 * @param docEmAnalise
	 *            parameter
	 * @return AnaliseVersaoProposta
	 */
	public AnaliseVersaoProposta convertAnaliseToEntity(final Long numeroProposta, final Long numeroVersaoProposta,
		final AnaliseEBO docEmAnalise) {

		AnaliseVersaoProposta analiseVersaoProposta = null;
		StatusParecer statusParecer = null;
		TipoParecer tipoParecer = null;

		if (docEmAnalise != null) {

			analiseVersaoProposta = new AnaliseVersaoProposta();
			AnaliseVersaoPropostaPK analiseVersaoPropostaPK = null;

			analiseVersaoPropostaPK = new AnaliseVersaoPropostaPK();
			analiseVersaoPropostaPK.setNumeroProposta(numeroProposta);
			analiseVersaoPropostaPK.setNumeroVersaoProposta(numeroVersaoProposta);

			analiseVersaoPropostaPK.setNumeroSequenciaAnalise(EmissaoConvertTypes.convertBigIntToInt(docEmAnalise
				.getNumeroSequenciaAnalise()));

			analiseVersaoProposta.setAnaliseVersaoPropostaPK(analiseVersaoPropostaPK);

			analiseVersaoProposta.setTextoAnalise(docEmAnalise.getTextoAnalise());

			statusParecer = new StatusParecer();
			statusParecer.setCodigoStatusParecer(EmissaoConvertTypes.convertBigIntToInt(docEmAnalise
				.getCodigoStatusParecer()));
			analiseVersaoProposta.setStatusParecer(statusParecer);

			tipoParecer = new TipoParecer();
			tipoParecer.setCodigoTipoParecer(EmissaoConvertTypes.convertBigIntToInt(docEmAnalise.getCodigoTipoParecer()));
			analiseVersaoProposta.setTipoParecer(tipoParecer);

			analiseVersaoProposta.setCodigoEmpresaUsuarioUltimaAlteracao(
					docEmAnalise.getCodigoEmpresaUsuarioUltimaAlteracao());
			analiseVersaoProposta.setCodigoMatriculaUsuarioUltimaAlteracao(
					docEmAnalise.getCodigoMatriculaUsuarioUltimaAlteracao());
			analiseVersaoProposta.setCodigoTipoUsuarioUltimaAlteracao(
					docEmAnalise.getCodigoTipoUsuarioUltimaAlteracao());
			analiseVersaoProposta.setDataUltimaAlteracao(
					EmissaoConvertTypes.convertXMLGregToDate(docEmAnalise.getDataUltimaAlteracao()));

		}
		return analiseVersaoProposta;
	}

	/**
	 * Convert Pagador Proposta Type to Entity.
	 *
	 * @param numeroProposta
	 *            primary key of versao proposta
	 * @param numeroVersaoProposta
	 *            primary key of versao proposta
	 * @param pgdVrsPrps
	 *            list of pagador to be converted
	 * @param pagadorEBO
	 *            contains type to be converted
	 */
	@SuppressWarnings("PMD.AvoidDeeplyNestedIfStmts")
	private void convertPagadorPropostaToEntity(final Long numeroProposta, final Long numeroVersaoProposta,
		final List<PagadorVersaoProposta> pgdVrsPrps, final PagadorEBO pagadorEBO) {

		Long codigoPessoa = null;

		if (pagadorEBO != null) {
			final PagadorVersaoProposta pgdrVrsPrp = new PagadorVersaoProposta();

			if (pagadorEBO.getDadosPessoaPagador() != null) {
				codigoPessoa = pagadorEBO.getDadosPessoaPagador().getCodigoPessoa();
			}
			if (pagadorEBO.getEnderecoCobranca() != null) {
				final EnderecoEBO enderecoPagador = pagadorEBO.getEnderecoCobranca();

				if (enderecoPagador.getCodigoEndereco() != null) {
					pgdrVrsPrp.setCodigoEnderecoCobranca(enderecoPagador.getCodigoEndereco());
				}
			}
			if (pgdrVrsPrp != null) {
				contConvertPagadorPropostaToEntity(codigoPessoa, pgdrVrsPrp, numeroProposta, numeroVersaoProposta,
					pagadorEBO);
			}
			pgdVrsPrps.add(pgdrVrsPrp);
		}
	}

	/**
	 * Continue convert PagadorProposta to Entity.
	 *
	 * @param codigoPessoa
	 *            parameter
	 * @param pgdrVrsPrp
	 *            parameter
	 * @param numeroProposta
	 *            parameter
	 * @param numeroVersaoProposta
	 *            parameter
	 * @param pagadorEBO
	 *            parameter
	 */
	private void contConvertPagadorPropostaToEntity(final Long codigoPessoa, final PagadorVersaoProposta pgdrVrsPrp,
		final Long numeroProposta, final Long numeroVersaoProposta, final PagadorEBO pagadorEBO) {

		PagadorVersaoPropostaPK pgdVrsPrpId = null;
		if (codigoPessoa != null) {
			pgdVrsPrpId = new PagadorVersaoPropostaPK();
			pgdVrsPrpId.setCodigoPessoa(codigoPessoa);
			pgdVrsPrpId.setNumeroProposta(numeroProposta);
			pgdVrsPrpId.setNumeroVersaoProposta(numeroVersaoProposta);
		}
		pgdrVrsPrp.setIdentificador(pgdVrsPrpId);
		List<PagadorParcelaVersaoProposta> pgdPrcVrsPrps = null;

		if ((pagadorEBO.getPagadoresParcela() != null) && CollectionUtils.hasContents(pagadorEBO.getPagadoresParcela()
			.getPagadorParcela())) {
			pgdPrcVrsPrps = new ArrayList<>();
			for (final PagadorParcelaEBO pagadorParcelaEBO : pagadorEBO.getPagadoresParcela().getPagadorParcela()) {
				convertPagadorParcelaToEntity(pgdPrcVrsPrps, pagadorParcelaEBO);
			}
			pgdrVrsPrp.setPagadorParcelaVersaoPropostas(pgdPrcVrsPrps);
		}
	}

	/**
	 * Converts Pagador Parcela from type to Entity.
	 *
	 * @param pgdPrcVrsPrps
	 *            contains pagador parcela list
	 * @param pagadorParcelaEBO
	 *            to be converted
	 */
	private void convertPagadorParcelaToEntity(final List<PagadorParcelaVersaoProposta> pgdPrcVrsPrps,
		final PagadorParcelaEBO pagadorParcelaEBO) {

		PagadorParcelaVersaoProposta pgdPrcVrsPrp = null;

		if (pagadorParcelaEBO != null) {

			pgdPrcVrsPrp = new PagadorParcelaVersaoProposta();

			final PessoaEBO pessoaParcel = pagadorParcelaEBO.getDadosPessoaPagadorParcela();

			contConvertPagadorParcelaToEntity(pagadorParcelaEBO, pgdPrcVrsPrp, pessoaParcel);
		}
		pgdPrcVrsPrps.add(pgdPrcVrsPrp);
	}

	/**
	 * Continue convert PagadorParcela to entity.
	 *
	 * @param pagadorParcelaEBO
	 *            parameter
	 * @param pgdPrcVrsPrp
	 *            parameter
	 * @param pessoaParcel
	 *            parameter
	 */
	private void contConvertPagadorParcelaToEntity(final PagadorParcelaEBO pagadorParcelaEBO,
		final PagadorParcelaVersaoProposta pgdPrcVrsPrp, final PessoaEBO pessoaParcel) {
		final PagadorParcelaVersaoPropostaPK pgdPrcVrsPrpId = new PagadorParcelaVersaoPropostaPK();

		if (pgdPrcVrsPrp != null) {
			pgdPrcVrsPrpId.setCodigoPessoa(pessoaParcel.getCodigoPessoa());
			final BigInteger numeroParcela = pagadorParcelaEBO.getNumeroParcela();
			if (numeroParcela != null) {
				pgdPrcVrsPrpId.setNumeroParcela(numeroParcela.intValue());
			}
			final BigInteger codigoBanco = pagadorParcelaEBO.getCodigoBanco();

			final BigInteger numeroAgenciaBancaria = pagadorParcelaEBO.getNumeroAgenciaBancaria();

			if ((codigoBanco != null) && (null != numeroAgenciaBancaria)) {

				final AgenciaBancaria agenciaBancaria = new AgenciaBancaria();
				final AgenciaBancariaPK agenciaBancariaPK = new AgenciaBancariaPK();
				agenciaBancariaPK.setCodigoBanco(EmissaoConvertTypes.convertBigIntToInt(codigoBanco));
				agenciaBancariaPK.setNumeroAgenciaBancaria(numeroAgenciaBancaria.toString());
				agenciaBancaria.setIdentificador(agenciaBancariaPK);

				pgdPrcVrsPrp.setAgenciaBancaria(agenciaBancaria);
			}
			pgdPrcVrsPrp.setCodigoIdentificacaoCartao(pagadorParcelaEBO.getCodigoIdentificacaoCartao());
			pgdPrcVrsPrp.setNomePessoaTitularCartao(pessoaParcel.getNomePessoa());
			pgdPrcVrsPrp.setNumeroCnpjCpfTitularCartao(pessoaParcel.getNumeroCnpjCpf());

			/* TipoCartao tipoCartao = null; */
			final BigInteger codigoTipoCartao = pagadorParcelaEBO.getCodigoTipoCartao();
			if (codigoTipoCartao != null) {

				// SM 4098 - Utilizar o Tipo Cartao para trafegar a informação
				// da bandeira cartão.
				final BandeiraCartao bandeiraCartao = new BandeiraCartao();
				bandeiraCartao.setCodigoBandeiraCartao(codigoTipoCartao.intValue());
				pgdPrcVrsPrp.setBandeiraCartao(bandeiraCartao);

				/*
				 * tipoCartao = new TipoCartao();
				 * tipoCartao.setCodigoTipoCartao(codigoTipoCartao.longValue());
				 */
			}
			/* pgdPrcVrsPrp.setTipoCartao(tipoCartao); */

			pgdPrcVrsPrp.setDataVencimento(EmissaoConvertTypes.convertXMLGregToDate(pagadorParcelaEBO.getDataVencimento()));

			if ((null != pagadorParcelaEBO.getNumeroContaBancaria()) && (null != pagadorParcelaEBO.getDigitoContaBancaria())) {
				pgdPrcVrsPrp.setNumeroContaBancaria(pagadorParcelaEBO.getNumeroContaBancaria());
				pgdPrcVrsPrp.setDigitoContaBancaria(pagadorParcelaEBO.getDigitoContaBancaria());
			}
			pgdPrcVrsPrp.setDataPagamento(EmissaoConvertTypes.convertXMLGregToDate(pagadorParcelaEBO.getDataPagamento()));
			pgdPrcVrsPrp.setDataPagamentoContabilizado(EmissaoConvertTypes.convertXMLGregToDate(pagadorParcelaEBO
				.getDataPagamentoContabilizado()));
			pgdPrcVrsPrp.setDataCancelamento(EmissaoConvertTypes.convertXMLGregToDate(pagadorParcelaEBO
				.getDataCancelamento()));
			pgdPrcVrsPrp.setDataPrazoCobertura(EmissaoConvertTypes.convertXMLGregToDate(pagadorParcelaEBO
				.getDataPrazoCobertura()));

			final BigDecimal valorParcela = pagadorParcelaEBO.getValorParcela();
			if (valorParcela != null) {
				pgdPrcVrsPrp.setValorParcela(valorParcela);
			}
			pgdPrcVrsPrp.setIdentificador(pgdPrcVrsPrpId);

			pgdPrcVrsPrp.setDataPrazoCobertura(EmissaoConvertTypes.convertXMLGregToDate(pagadorParcelaEBO
				.getDataPrazoCobertura()));
			pgdPrcVrsPrp.setDataPagamento(EmissaoConvertTypes.convertXMLGregToDate(pagadorParcelaEBO.getDataPagamento()));
			pgdPrcVrsPrp.setDataPagamentoContabilizado(EmissaoConvertTypes.convertXMLGregToDate(pagadorParcelaEBO
				.getDataPagamentoContabilizado()));
			pgdPrcVrsPrp.setDataCancelamento(EmissaoConvertTypes.convertXMLGregToDate(pagadorParcelaEBO
				.getDataCancelamento()));
			if (pagadorParcelaEBO.getCodigoStatusParcela() != null) {
				final StatusParcela statusParcela = new StatusParcela();
				statusParcela.setCodigoStatusParcela(EmissaoConvertTypes.convertBigIntToInt(pagadorParcelaEBO
					.getCodigoStatusParcela()));
				pgdPrcVrsPrp.setStatusParcela(statusParcela);
			}
			pgdPrcVrsPrp.setTextoComentario(pagadorParcelaEBO.getTextoComentario());
		}
	}

	/**
	 * Convert VersaoOrcamento to Entity.
	 *
	 * @param documentEmissao
	 *            - The documentEmissao to convert.
	 * @param versaoProposta
	 *            - The versaoProposta.
	 */
	private void convertVersaoOrcamentoToEntity(final DocumentoEmissaoEBO documentEmissao,
		final VersaoProposta versaoProposta) {

		final VersaoOrcamento versaoOrcamento = new VersaoOrcamento();
		final VersaoOrcamentoPK versaoOrcamentoPK = new VersaoOrcamentoPK();
		versaoOrcamentoPK.setNumeroOrcamento(documentEmissao.getNumeroOrcamento());
		versaoOrcamentoPK.setNumeroVersaoOrcamento(documentEmissao.getNumeroVersaoOrcamento());
		versaoOrcamento.setIdentificador(versaoOrcamentoPK);

		if(documentEmissao.getNomePessoaProponente() != null){
			versaoOrcamento.setNomePessoaProponente(documentEmissao.getNomePessoaProponente());
		}
		
		// R4

		if (documentEmissao.getCodigoTipoPessoaProponente() != null) {
			versaoOrcamento.setTipoPessoaProponete(createTipoPessoaProponente(documentEmissao));
		}

		if (documentEmissao.getCodigoPrazoAverbacaoAdendo() != null) {
			versaoOrcamento.setPrazoAverbacao(createPrazoAverbacao(documentEmissao));
		}

		if (documentEmissao.getValorPremioMinimo() != null) {
			versaoOrcamento.setValorPremioMinimo(documentEmissao.getValorPremioMinimo());
		}

		if (documentEmissao.getValorPremioDepositoInicial() != null) {
			versaoOrcamento.setValorPremioDepositoInicial(documentEmissao.getValorPremioDepositoInicial());
		}

		if (documentEmissao.getFlagCobrancaPremioDeposito() != null) {
			versaoOrcamento.setFlagCobrancaPremioDepIniAdendo(documentEmissao.getFlagCobrancaPremioDeposito());
		}

		if (documentEmissao.getValorAjustePremioMinimo() != null) {
			versaoOrcamento.setValorAjustePremioMinimo(documentEmissao.getValorAjustePremioMinimo());
		}

		if (documentEmissao.getFlagEndossoRetroativo() != null) {
			versaoOrcamento.setFlagEndossoRetroativo(documentEmissao.getFlagEndossoRetroativo());
		}

		if (documentEmissao.getFlagPossuiAverbacao() != null) {
			versaoOrcamento.setFlagPossuiAverbacao(documentEmissao.getFlagPossuiAverbacao());
		}

		if (documentEmissao.getFlagPossuiEmbarcador() != null) {
			versaoOrcamento.setFlagPossuiEmbarcador(documentEmissao.getFlagPossuiEmbarcador());
		}

		if (documentEmissao.getNumeroApoliceAssociado() != null) {
			versaoOrcamento.setNumeroApoliceAssociado(documentEmissao.getNumeroApoliceAssociado());
		}

		if (documentEmissao.getNumeroVersaoOrcamentoAssociado() != null) {
			versaoOrcamento.setNumeroVersaoOrcamentoAssociado(documentEmissao.getNumeroVersaoOrcamentoAssociado()
				.longValue());
		}

		if (documentEmissao.getNumeroOrcamentoAssociado() != null) {
			versaoOrcamento.setNumeroOrcamentoAssociado(documentEmissao.getNumeroOrcamentoAssociado().longValue());
		}

		if (documentEmissao.getCodigoPrazoAverbacao() != null) {
			versaoProposta.setCodigoPrazoAverbacao(documentEmissao.getCodigoPrazoAverbacao().intValue());
		}

		if (documentEmissao.getCodigoFrequenciaFaturamento() != null) {
			versaoProposta.setFrequenciaFatoramento(createFrequenciaFaturamento(documentEmissao));
		}

		if (documentEmissao.getFlagCobrancaJuro() == null) {
			versaoProposta.setFlagCobrancaJuro(FLAG_S);
		} else {
			versaoProposta.setFlagCobrancaJuro(documentEmissao.getFlagCobrancaJuro());
		}
		if (documentEmissao.getDescontosAgravoOrigemDestino() != null) {
			versaoOrcamento.setDescAgravoOrgDestTranspVersaoOrcamento(iOrcamentoSOAPConverter
				.convertDscAgrvOrgDestTransListToEntity(documentEmissao));
		}
		versaoProposta.setVersaoOrcamento(versaoOrcamento);
		Canal canal = new Canal();
		canal.setCodigoCanal(EmissaoConvertTypes.convertBigIntToInt(documentEmissao.getCodigoCanal()));
		versaoOrcamento.setCanal(canal);

		// Artificio provisorio - Flag utilizada para bloqueio de
		// orcamento/proposta
		if (AssertUtil.isNotNullAndEmpty(documentEmissao.getFlagSimulacao())) {
			versaoOrcamento.setFlagBloqueioEdicaoCorretor(documentEmissao.getFlagSimulacao());
		}
		if (documentEmissao.getDadosPessoaSegurado() != null) {
			versaoOrcamento.setCodigoPessoa(documentEmissao.getDadosPessoaSegurado().getCodigoPessoa());
		}
		// NEW
		if ((documentEmissao.getCriticas() != null) && CollectionUtils.hasContents(documentEmissao.getCriticas()
			.getCritica())) {

			final List<CriticaSeguroVersaoProposta> criticaSeguroVerProps = convertToCriticaSeguroVersaoProposta(
				documentEmissao.getCriticas().getCritica());

			versaoProposta.setCriticaVersaoPropostas(criticaSeguroVerProps);
		}
		versaoProposta.setFlagBloqueio(documentEmissao.getFlagBloqueio());
		// NEW
		if ((documentEmissao.getItensDocumentoEmissao() != null) && CollectionUtils.hasContents(documentEmissao
			.getItensDocumentoEmissao().getItemDocumentoEmissao())) {

			// final List<ItemVersaoProposta> itemVersaoPropostas
			// = convertToItemVersaoProposta(documentEmissao
			// .getItensDocumentoEmissao().getItemDocumentoEmissao());

			final List<ItemVersaoProposta> itemVersaoPropostas = propostaTypeConverterExt.convertComponenteListaItemType(
				documentEmissao.getItensDocumentoEmissao().getItemDocumentoEmissao(), null, null);

			versaoProposta.setItemVersaoPropostas(itemVersaoPropostas);

		}

	}

	/**
	 * createFrequenciaFaturamento.
	 *
	 * @param documentEmissao
	 *            param.
	 * @return FrequenciaFatoramento.
	 */
	private FrequenciaFatoramento createFrequenciaFaturamento(final DocumentoEmissaoEBO documentEmissao) {
		final FrequenciaFatoramento frequenciaFatoramento = new FrequenciaFatoramento();
		frequenciaFatoramento.setCodigoFrequenciaFaturamento(documentEmissao.getCodigoFrequenciaFaturamento().intValue());
		return frequenciaFatoramento;
	}

	/**
	 * createPrazoAverbacao.
	 *
	 * @param documentEmissao
	 *            param.
	 * @return the prazo averbacao
	 */
	private PrazoAverbacao createPrazoAverbacao(final DocumentoEmissaoEBO documentEmissao) {
		final PrazoAverbacao prazoAverbacao = new PrazoAverbacao();
		prazoAverbacao.setCodigoPrazoAverbacao(documentEmissao.getCodigoPrazoAverbacaoAdendo().longValue());
		return prazoAverbacao;
	}

	/**
	 * createTipoPessoaProponente.
	 *
	 * @param documentEmissao
	 *            the document emissao
	 * @return TipoPessoa.
	 */
	private TipoPessoa createTipoPessoaProponente(final DocumentoEmissaoEBO documentEmissao) {

		final TipoPessoa tipoPessoa = new TipoPessoa();
		tipoPessoa.setCodigoTipoPessoa(documentEmissao.getCodigoTipoPessoaProponente().intValue());

		return tipoPessoa;
	}

	/**
	 * Convert to ItemVersaoProposta.
	 *
	 * @param items
	 *            parameter
	 * @return List<ItemVersaoProposta>
	 */
	public List<ItemVersaoProposta> convertToItemVersaoProposta(final List<ItemDocumentoEmissaoEBO> items) {

		final List<ItemVersaoProposta> itemVersaoPropostas = new ArrayList<>(items.size());

		for (final ItemDocumentoEmissaoEBO itemDoc : items) {

			final ItemVersaoProposta item = convertToItemVersaoProposta(itemDoc);
			itemVersaoPropostas.add(item);
		}
		return itemVersaoPropostas;

	}

	/**
	 * Convert to ItemVersaoProposta.
	 *
	 * @param itemDoc
	 *            parameter
	 * @return ItemVersaoProposta
	 */
	public ItemVersaoProposta convertToItemVersaoProposta(final ItemDocumentoEmissaoEBO itemDoc) {

		final ItemVersaoProposta item = new ItemVersaoProposta();
		final ItemVersaoPropostaPK itemPK = new ItemVersaoPropostaPK();
		if (itemDoc.getNumeroItemVersaoProposta() != null) {
			itemPK.setNumeroItemVersaoProposta(itemDoc.getNumeroItemVersaoProposta().intValue());
		}
		item.setIdentificador(itemPK);
		if ((itemDoc.getCriticasItem() != null) && CollectionUtils.hasContents(itemDoc.getCriticasItem().getCriticaItem())) {

			final List<CriticaSeguroItemVersaoProposta> criticaSeguroItems = convertToCriticaSeguroItemVersaoProposta(itemDoc
				.getCriticasItem().getCriticaItem());

			item.setCriticaItemVersaoPropostas(criticaSeguroItems);
		}
		return item;
	}

	/**
	 * Convert to CriticaSeguroVersaoProposta.
	 *
	 * @param criticas
	 *            parameter
	 * @return List<CriticaSeguroItemVersaoProposta>
	 */
	public List<CriticaSeguroItemVersaoProposta> convertToCriticaSeguroItemVersaoProposta(final List<CriticaEBO> criticas) {

		final List<CriticaSeguroItemVersaoProposta> criticaSeguroList = new ArrayList<>(criticas.size());

		for (final CriticaEBO criticaEBO : criticas) {

			final CriticaSeguroItemVersaoProposta criticaSeguro = convertToCriticaSeguroItemVersaoProposta(criticaEBO);

			criticaSeguroList.add(criticaSeguro);
		}
		return criticaSeguroList;
	}

	/**
	 * Convert to CriticaSeguroVersaoProposta.
	 *
	 * @param critica
	 *            parameter
	 * @return CriticaSeguroItemVersaoProposta
	 */
	public CriticaSeguroItemVersaoProposta convertToCriticaSeguroItemVersaoProposta(final CriticaEBO critica) {

		final CriticaSeguroItemVersaoProposta criticaSeguro = new CriticaSeguroItemVersaoProposta();
		final CriticaSeguroItemVersaoPropostaPK criticaSeguroPK = new CriticaSeguroItemVersaoPropostaPK();

		if (critica.getCodigoCritica() != null) {
			criticaSeguroPK.setCodigoCritica(critica.getCodigoCritica().intValue());
		}
		criticaSeguro.setIdentificador(criticaSeguroPK);

		if (critica.getDataCritica() != null) {
			criticaSeguro.setDataCritica(EmissaoConvertTypes.convertXMLGregToDate(critica.getDataCritica()));
		}
		criticaSeguro.setNomPerfPrincSistemGerencProcess(critica.getNomePerfilPrincipalSistemaGerenciamentoProcesso());

		critica.getCodigoStatusCritica();

		if (critica.getCodigoStatusCritica() != null) {

			final List<StatusCriticaSeguroItemVersaoProposta> statusCriticaVerProps = new ArrayList<>();
			final StatusCriticaSeguroItemVersaoProposta statusCritica = new StatusCriticaSeguroItemVersaoProposta();
			final StatusCriticaSeguroItemVersaoPropostaPK statusPK = new StatusCriticaSeguroItemVersaoPropostaPK();

			statusPK.setCodigoCritica(criticaSeguroPK.getCodigoCritica());
			if (critica.getCodigoStatusCritica() != null) {
				statusPK.setCodigoStatusCritica(critica.getCodigoStatusCritica().intValue());
			}

			statusCritica.setIdentificador(statusPK);

			statusCriticaVerProps.add(statusCritica);

			criticaSeguro.setStatusCriticaItemVersaoPropostas(statusCriticaVerProps);
		}
		criticaSeguro.setTxtPerfParticSistemGerencProcess(critica.getTextoPerfilParticipanteSistemaGerenciamentoProcesso());

		criticaSeguro.setTextoRetornoCritica(criticaSeguro.getTextoRetornoCritica());

		return criticaSeguro;
	}

	/**
	 * Convert Corretor to Entity.
	 *
	 * @param numeroProposta
	 *            - The numeroProposta
	 * @param numeroVersaoProposta
	 *            - The numeroVersaoProposta
	 * @param docEmCorretorList
	 *            - The docEmCorretorList
	 * @return entityClasses - the entity class List form.
	 */
	@Override
	public List<CorretorVersaoProposta> convertCorretorToEntity(final Long numeroProposta, final Long numeroVersaoProposta,
		final List<CorretorEBO> docEmCorretorList) {

		final List<CorretorVersaoProposta> corretorVersaoPropostas = new ArrayList<>();

		for (final CorretorEBO currentItem : docEmCorretorList) {

			corretorVersaoPropostas.add(convertCorretorToEntity(numeroProposta, numeroVersaoProposta, currentItem));

		}
		return corretorVersaoPropostas;
	}

	/**
	 * Convert Corretor to Entity.
	 *
	 * @param numeroProposta
	 *            parameter
	 * @param numeroVersaoProposta
	 *            parameter
	 * @param docEmCorretor
	 *            parameter
	 * @return CorretorVersaoProposta
	 */
	@Override
	public CorretorVersaoProposta convertCorretorToEntity(final Long numeroProposta, final Long numeroVersaoProposta,
		final CorretorEBO docEmCorretor) {

		CorretorVersaoProposta corretorVersaoProposta = null;
		if (docEmCorretor != null) {

			corretorVersaoProposta = new CorretorVersaoProposta();
			CorretorVersaoPropostaPK corretorVersaoPropostaPK = null;

			if ((docEmCorretor.getCodigoCorretor() != null) && !docEmCorretor.getCodigoCorretor().trim().isEmpty()) {

				corretorVersaoPropostaPK = new CorretorVersaoPropostaPK();
				corretorVersaoPropostaPK.setNumeroProposta(numeroProposta);
				corretorVersaoPropostaPK.setNumeroVersaoProposta(numeroVersaoProposta);
				corretorVersaoPropostaPK.setCodigoCorretor(docEmCorretor.getCodigoCorretor());
				corretorVersaoProposta.setIdentificador(corretorVersaoPropostaPK);
			}
			corretorVersaoProposta.setFlagPrincipal(docEmCorretor.getFlagPrincipal());

			if (docEmCorretor.getPercentualParticipacao() != null) {

				corretorVersaoProposta.setPercentualParticipacao(docEmCorretor.getPercentualParticipacao());
			}
			if (docEmCorretor.getValorComissao() != null) {

				corretorVersaoProposta.setValorComissao(docEmCorretor.getValorComissao());
			}
			if (docEmCorretor.getCodigoSucursal() != null) {

				final SucursalPK sucursalPK = new SucursalPK();
				sucursalPK.setCodigoSucursal(EmissaoConvertTypes.convertBigIntToInt(docEmCorretor.getCodigoSucursal()));

				final Sucursal sucursal = new Sucursal();
				sucursal.setIdentificador(sucursalPK);

				corretorVersaoProposta.setSucursal(sucursal);
			}
			corretorVersaoProposta.setFlagAtivo(docEmCorretor.getFlagAtivo());
		}

		// R4
		if (corretorVersaoProposta != null) {
			if (AssertUtil.isNotNull(docEmCorretor.getFlagImpressaoCorretor())) {
				corretorVersaoProposta.setFlagImpressaoCorretor(docEmCorretor.getFlagImpressaoCorretor());
			} else {
				corretorVersaoProposta.setFlagImpressaoCorretor(FLAG_S);
			}
			
			corretorVersaoProposta.setFlagImpressaoCoCorretagem(Constants.COMMONS.FLAG_NAO);
		}
		return corretorVersaoProposta;
	}

	/**
	 * Convert StatusVersaoProposta Type.
	 *
	 * @param documentEmissao
	 *            - The documentEmissao to convert
	 * @param versaoProposta
	 *            - The versaoProposta.
	 */
	@Override
	public void convertStatusVersaoPropostaType(final DocumentoEmissaoEBO documentEmissao,
		final VersaoProposta versaoProposta) {
		final StatusVersaoProposta statusVersaoProposta = new StatusVersaoProposta();
		final StatusVersaoPropostaPK statusVersaoPropostaPK = new StatusVersaoPropostaPK();
		final VersaoPropostaPK vrsPropostaId = versaoProposta.getIdentificador();
		statusVersaoPropostaPK.setNumeroProposta(vrsPropostaId.getNumeroProposta());
		statusVersaoPropostaPK.setNumeroVersaoProposta(vrsPropostaId.getNumeroVersaoProposta());

		statusVersaoPropostaPK.setCodigoStatusProposta(EmissaoConvertTypes.convertBigIntToInt(documentEmissao
			.getCodigoStatusProposta()));

		statusVersaoProposta.setIdentificador(statusVersaoPropostaPK);
		statusVersaoProposta.setDataInicioStatusProposta(EmissaoConvertTypes.convertXMLGregToDate(documentEmissao
			.getDataInicioStatusProposta()));
		statusVersaoProposta.setDataFimStatusProposta(EmissaoConvertTypes.convertXMLGregToDate(documentEmissao
			.getDataFimStatusProposta()));
		final List<StatusVersaoProposta> statusVersaoPropostas = new ArrayList<>();
		statusVersaoPropostas.add(statusVersaoProposta); // added codes-dan
		versaoProposta.setStatusVersaoPropostas(statusVersaoPropostas);
	}

	/**
	 * Convert Versaoproposta Type.
	 *
	 * @param documentEmissao
	 *            - The documentEmissao to convert
	 * @param proposta
	 *            - The proposta object
	 * @return entityClasses - the entity class.
	 */
	private VersaoProposta convertVersaoPropostaType(final DocumentoEmissaoEBO documentEmissao, final Proposta proposta) {

		final List<VersaoProposta> versaoPropostas = new ArrayList<>();
		final VersaoProposta versaoProposta = new VersaoProposta();

		proposta.setVersaoPropostas(versaoPropostas);
		versaoProposta.setProposta(proposta);

		final VersaoPropostaPK versaoPropostaPK = new VersaoPropostaPK();
		versaoPropostaPK.setNumeroProposta(documentEmissao.getNumeroProposta());
		versaoPropostaPK.setNumeroVersaoProposta(documentEmissao.getNumeroVersaoProposta());
		versaoProposta.setIdentificador(versaoPropostaPK);

		if (null != documentEmissao.getCodigoFormaPagamento()) {
			if ((documentEmissao.getFormasPagamento() != null) && (documentEmissao.getFormasPagamento()
				.getFormaPagamento() != null) && (documentEmissao.getFormasPagamento().getFormaPagamento().size() > 0)) {
	
				FormaPagamento formaPagamento = null;
	
				for (final FormaPagamentoEBO formaPagamentoEBO : documentEmissao.getFormasPagamento().getFormaPagamento()) {
					if(documentEmissao.getCodigoFormaPagamento().equals(formaPagamentoEBO.getCodigoFormaPagamento())){
						if (formaPagamentoEBO.getFlagAtivo().equals(FLAG_S)) {
							formaPagamento = convertFormaPagamentoToEntity(formaPagamentoEBO);
						}	
					}
				}
				if (formaPagamento == null) {
					formaPagamento = convertFormaPagamentoToEntity(documentEmissao.getFormasPagamento().getFormaPagamento().get(
						0));
				}
				versaoProposta.setFormaPagamento(formaPagamento);
			}
		}

		if ((documentEmissao.getEnderecoCorrespondencia() != null) && (documentEmissao.getEnderecoCorrespondencia()
			.getCodigoEndereco() != null)) {

			versaoProposta.setCodigoEnderecoCorrespondencia(documentEmissao.getEnderecoCorrespondencia()
				.getCodigoEndereco());
		}
		versaoProposta.setFlagEndossoAlteracaoDadoCadastralSegurado(documentEmissao
			.getFlagEndossoAlteracaoDadoCadastralSegurado());
		versaoProposta.setNomeProcessoSistemaGerenciamentoProcesso(documentEmissao
			.getNomeProcessoSistemaGerenciamentoProcesso());
		versaoProposta.setFlagBloqueio(documentEmissao.getFlagBloqueio());
		versaoProposta.setDataBloqueio(EmissaoConvertTypes.convertXMLGregToDate(documentEmissao.getDataBloqueio()));
		versaoProposta.setCodigoTipoUsuarioBloqueio(documentEmissao.getCodigoTipoUsuarioBloqueio());
		versaoProposta.setCodigoEmpresaUsuarioBloqueio(documentEmissao.getCodigoEmpresaUsuarioBloqueio());
		versaoProposta.setCodigoMatriculaUsuarioBloqueio(documentEmissao.getCodigoMatriculaUsuarioBloqueio());
		versaoProposta.setCodigoTipoDestinario(documentEmissao.getCodigoTipoDestinario());
		versaoProposta.setDataProtocolo(EmissaoConvertTypes.convertXMLGregToDate(documentEmissao.getDataProtocolo()));
		Util.logDataProtocolo(versaoProposta);
		versaoProposta.setDataEmissao(EmissaoConvertTypes.convertXMLGregToDate(documentEmissao.getDataEmissao()));
		versaoProposta.setNumeroPropostaAutomovel(documentEmissao.getNumeroPropostaAutomovel());
		versaoProposta.setFlagPossuiCorretorSecundario(documentEmissao.getFlagPossuiCorretorSecundario());
		versaoProposta.setFlagPossuiBeneficiario(documentEmissao.getFlagPossuiBeneficiario());
		versaoProposta.setFlagPossuiSinistro(documentEmissao.getFlagPossuiSinistro());
		// versaoProposta.setFlagPrimeiraCompraCartaoEmpresa(documentEmissao.getFlagPrimeiraCompraCartaoEmpresa());
		//versaoProposta.setFlagEnvioEmailCorretor(documentEmissao.getFlagEnvioEmailCorretor());
		
		if(documentEmissao.getFlagEnvioEmailCorretor() == "T") {
			versaoProposta.setFlagEnvioEmailCorretor("S");
			versaoProposta.setFlagEnvioEmailImobiliaria("S");
		} else if(documentEmissao.getFlagEnvioEmailCorretor() == "I") {
			versaoProposta.setFlagEnvioEmailCorretor("N");
			versaoProposta.setFlagEnvioEmailImobiliaria("S");
		} else {
			versaoProposta.setFlagEnvioEmailCorretor(documentEmissao.getFlagEnvioEmailCorretor());
			versaoProposta.setFlagEnvioEmailImobiliaria("N");
		}
		
		versaoProposta.setFlagPossuiTituloCapitalizacao(documentEmissao.getFlagPossuiTituloCapitalizacao());

		versaoProposta.setNomeProcessoSistemaGerenciamentoProcesso(documentEmissao
			.getNomeProcessoSistemaGerenciamentoProcesso());
		versaoProposta.setFlagBloqueio(documentEmissao.getFlagBloqueio());

		if (documentEmissao.getDataBloqueio() != null) {

			versaoProposta.setDataBloqueio(EmissaoConvertTypes.convertXMLGregToDate(documentEmissao.getDataBloqueio()));
		}
		if (documentEmissao.getDataProtocolo() != null) {

			versaoProposta.setDataProtocolo(EmissaoConvertTypes.convertXMLGregToDate(documentEmissao.getDataProtocolo()));
		}
		if (documentEmissao.getDataEmissao() != null) {

			versaoProposta.setDataEmissao(EmissaoConvertTypes.convertXMLGregToDate(documentEmissao.getDataEmissao()));
		}
		// versaoProposta.setNumeroSorteTituloCapitalizacao(documentEmissao.getNumeroSorteTituloCapitalizacao());

		if (documentEmissao.getDataInicioVigencia() != null) {

			versaoProposta.setDataInicioVigencia(EmissaoConvertTypes.convertXMLGregToDate(documentEmissao
				.getDataInicioVigencia()));
		}
		versaoProposta.setDataFimVigencia(EmissaoConvertTypes.convertXMLGregToDate(documentEmissao.getDataFimVigencia()));

		versaoProposta.setDataMelhorDataPrimeiraParcela(EmissaoConvertTypes.convertXMLGregToDate(documentEmissao
			.getDataMelhorDataPrimeiraParcela()));

		if ((documentEmissao.getDiasVenciamento() != null) && AssertUtil.isNotNullAndEmpty(documentEmissao.getDiasVenciamento()
			.getDiaVencimento())) {

			List<VencimentoFaturaTransporteVersaoProposta> listDiasVencimentoVersaoProposta =
				convertListVencFatTranspVrsPrpToEntity(documentEmissao.getDiasVenciamento(), documentEmissao
					.getNumeroProposta(), documentEmissao.getNumeroVersaoProposta());
			versaoProposta.setVencimentoFaturaTransportVersaoProposta(listDiasVencimentoVersaoProposta);
		}
		if (documentEmissao.getCodigoFaixaResgatePonto() != null
				&& !documentEmissao.getCodigoFaixaResgatePonto().isEmpty()) {
			
			List<SolicitacaoResgatePontoCartaoCredito> listSolicitacaoResgatePonto = 
					new ArrayList<SolicitacaoResgatePontoCartaoCredito>();
			SolicitacaoResgatePontoCartaoCredito solicitacaoResgatePontoCartaoCredito =
					new SolicitacaoResgatePontoCartaoCredito();
			solicitacaoResgatePontoCartaoCredito.setCodigoFaixaResgatePonto(
					documentEmissao.getCodigoFaixaResgatePonto());
			listSolicitacaoResgatePonto.add(solicitacaoResgatePontoCartaoCredito);
			versaoProposta.setSolicitacaoResgatePonto(listSolicitacaoResgatePonto);
		}
		return versaoProposta;
	}

	/**
	 * Convert list venc fat transp vrs prp to entity.
	 *
	 * @param diasVencimento
	 *            the dias vencimento
	 * @param numeroProposta
	 *            the numero proposta
	 * @param numeroVersaoProposta
	 *            the numero versao proposta
	 * @return the list
	 */
	public List<VencimentoFaturaTransporteVersaoProposta> convertListVencFatTranspVrsPrpToEntity(
		final DiasVencimento diasVencimento, final Long numeroProposta, final Long numeroVersaoProposta) {

		List<VencimentoFaturaTransporteVersaoProposta> listEntity = new ArrayList<>();

		if ((diasVencimento != null) && AssertUtil.isNotNullAndEmpty(diasVencimento.getDiaVencimento())) {

			for (DiaVencimento diaVencimentoType : diasVencimento.getDiaVencimento()) {

				VencimentoFaturaTransporteVersaoProposta entity = convertVencFatTransporteVrsPrpToEntity(diaVencimentoType);

				if ((entity != null) && (entity.getEntityPK() != null) && 
						AssertUtil.isNotNull(numeroProposta) && 
						AssertUtil.isNotNull(numeroVersaoProposta) ) {
					entity.getEntityPK().setNumeroProposta(numeroProposta);
					entity.getEntityPK().setNumeroVersaoProposta(numeroVersaoProposta);

				}
				
				if(AssertUtil.isNotNullAndEmpty(entity)){
					listEntity.add(entity);
				}
			}
		}
		return listEntity;
	}

	/**
	 * Convert venc fat transporte vrs prp to entity.
	 *
	 * @param diaVencimento
	 *            the dia vencimento
	 * @return the vencimento fatura transporte versao proposta
	 */
	public VencimentoFaturaTransporteVersaoProposta convertVencFatTransporteVrsPrpToEntity(
		final DiaVencimento diaVencimento) {

		VencimentoFaturaTransporteVersaoProposta vencimentoFaturaTransporteVrsProposta =
			new VencimentoFaturaTransporteVersaoProposta();

		if (diaVencimento.getCodigoDiaVencimento() != null) {

			VencimentoFaturaTransporteVersaoPropostaPK primK = new VencimentoFaturaTransporteVersaoPropostaPK();
			primK.setCodigoDiaVencimentoFaturaTransporte(ConvertTypes.convertBigIntToLong(diaVencimento
				.getCodigoDiaVencimento()));

			vencimentoFaturaTransporteVrsProposta.setEntityPK(primK);
		}
		return vencimentoFaturaTransporteVrsProposta;
	}

	/**
	 * Convert to Entity.
	 *
	 * @param formaPagamentoEBO
	 *            parameter
	 * @return FormaPagamento.
	 */
	public FormaPagamento convertFormaPagamentoToEntity(final FormaPagamentoEBO formaPagamentoEBO) {

		final FormaPagamento formaPagamentoEntity = new FormaPagamento();

		formaPagamentoEntity.setCodigoFormaPagamento(EmissaoConvertTypes.convertLongToInt(formaPagamentoEBO
			.getCodigoFormaPagamento()));
		formaPagamentoEntity.setCodigoMeioPagamentoDemaisParcela(EmissaoConvertTypes.convertBigIntToInt(formaPagamentoEBO
			.getCodigoMeioPagamentoDemaisParcela()));
		formaPagamentoEntity.setCodigoMeioPagamentoPrimeiraParcela(EmissaoConvertTypes.convertBigIntToInt(formaPagamentoEBO
			.getCodigoMeioPagamentoPrimeiraParcela()));
		formaPagamentoEntity.setFlagAtivo(formaPagamentoEBO.getFlagAtivo());
		formaPagamentoEntity.setNomeFormaPagamento(formaPagamentoEBO.getNomeFormaPagamento());
		formaPagamentoEntity.setNomeResumidoFormaPagamento(formaPagamentoEBO.getNomeResumidoFormaPagamento());
		formaPagamentoEntity.setQuantidadeParcela(EmissaoConvertTypes.convertBigIntToInt(formaPagamentoEBO
			.getQuantidadeParcela()));
		formaPagamentoEntity.setTextoComentario(formaPagamentoEBO.getTextoComentario());

		return formaPagamentoEntity;
	}

	/**
	 * Convert to Type.
	 *
	 * @param proposta
	 *            parameter
	 * @return DocumentoEmissaoEBO.
	 */
	@Override
	public DocumentoEmissaoEBO convertToType(final Proposta proposta) {

		DocumentoEmissaoEBO convertedDocumentoEmissao = null;

		if (proposta != null) {
			convertedDocumentoEmissao = new DocumentoEmissaoEBO();

			final List<VersaoProposta> versaoPropostas = proposta.getVersaoPropostas();

			if (CollectionUtils.hasContents(versaoPropostas)) {

				for (final VersaoProposta selected : versaoPropostas) {

					convertedDocumentoEmissao = convertToType(selected, null);
				}
			}
			if (proposta.getNumeroProposta() != null) {

				propostaTypeConverterExt.convertProposta(proposta, convertedDocumentoEmissao);
			}
		}
		return convertedDocumentoEmissao;
	}

	/**
	 * Convert List of VersaoProposta to type.
	 *
	 * @param proposta
	 *            parameter
	 * @param versaoPropostaList
	 *            parameter
	 * @return List<DocumentoEmissaoEBO>
	 */
	@Override
	public List<DocumentoEmissaoEBO> convertVersaoPropostaToType(final Proposta proposta,
		final List<VersaoProposta> versaoPropostaList) {

		final List<DocumentoEmissaoEBO> documentoEmissaoEBOList = new ArrayList<>(versaoPropostaList.size());

		for (final VersaoProposta versaoProposta : versaoPropostaList) {

			final DocumentoEmissaoEBO documentoEmissaoEBO = convertToType(versaoProposta, null);

			propostaTypeConverterExt.convertProposta(proposta, documentoEmissaoEBO);

			documentoEmissaoEBOList.add(documentoEmissaoEBO);
		}

		return documentoEmissaoEBOList;
	}

	/**
	 * Convert List of VersaoProposta to type.
	 *
	 * @param versaoPropostaList
	 *            parameter
	 * @return List<DocumentoEmissaoEBO>
	 */
	@Override
	public List<DocumentoEmissaoEBO> convertVersaoPropostaToType(final List<VersaoProposta> versaoPropostaList) {

		final List<DocumentoEmissaoEBO> documentoEmissaoEBOList = new ArrayList<>(versaoPropostaList.size());

		for (final VersaoProposta versaoProposta : versaoPropostaList) {

			documentoEmissaoEBOList.add(convertToType(versaoProposta, null));
		}
		return documentoEmissaoEBOList;
	}

	/**
	 * Convert VersaoProposta to type.
	 *
	 * @param versaoProposta
	 *            parameter
	 * @param documentoEmissao
	 *            parameter
	 * @return DocumentoEmissaoEBO
	 */
	@SuppressWarnings("PMD.ExcessiveMethodLength")
	@Override
	public DocumentoEmissaoEBO convertToType(final VersaoProposta versaoProposta,
		final DocumentoEmissaoEBO documentoEmissao) {
		DocumentoEmissaoEBO documentoEmissaoEBO = null;
		if (documentoEmissao == null) {
			documentoEmissaoEBO = new DocumentoEmissaoEBO();
		} else {
			documentoEmissaoEBO = documentoEmissao;
		}
		documentoEmissaoEBO.setFlagSolicitacaoCartaoCredito(versaoProposta.getFlagSolicitacaoCartaoCredito());
		documentoEmissaoEBO.setNumeroSequenciaRegistroTituloCapitalizacao(versaoProposta
			.getNumeroSequenciaRegistroTituloCapitalizacao());
		if (versaoProposta.getIdentificador() != null) {
			documentoEmissaoEBO.setCodigoTipoDestinario(versaoProposta.getCodigoTipoDestinario());//
			if ((documentoEmissaoEBO.getNumeroApolice() == null) && (versaoProposta.getNumeroApolice() != null)) {
				documentoEmissaoEBO.setNumeroApolice(versaoProposta.getNumeroApolice());
			}
			propostaTypeConverterExt.convertVersaoProposta(documentoEmissaoEBO, versaoProposta);
			if (CollectionUtils.hasContents(versaoProposta.getPendenciaVersaoPropostas())) {
				final ListaPendenciasEBO pendencias = propostaTypeConverterExt.convertPendencias(versaoProposta
					.getPendenciaVersaoPropostas());
				documentoEmissaoEBO.setPendencias(pendencias);
			}
			if (CollectionUtils.hasContents(versaoProposta.getStatusVersaoPropostas())) {
				final List<StatusVersaoProposta> statusVersaoPropostas = versaoProposta.getStatusVersaoPropostas();
				if (CollectionUtils.hasContents(statusVersaoPropostas) && (statusVersaoPropostas.get(0) != null) &&
					(statusVersaoPropostas.get(0).getIdentificador() != null)) {
					for (final StatusVersaoProposta statusVersaoProposta : statusVersaoPropostas) {
						if (statusVersaoProposta.getDataFimStatusProposta() == null) {
							documentoEmissaoEBO.setCodigoStatusProposta(EmissaoConvertTypes.convertIntToBigInt(
								statusVersaoProposta.getIdentificador().getCodigoStatusProposta()));
							documentoEmissaoEBO.setDataInicioStatusProposta(EmissaoConvertTypes.convertDateToXMLGreg(
								statusVersaoProposta.getDataInicioStatusProposta()));
							documentoEmissaoEBO.setDataFimStatusProposta(EmissaoConvertTypes.convertDateToXMLGreg(
								statusVersaoProposta.getDataFimStatusProposta()));
						}
					}
					if (documentoEmissaoEBO.getCodigoStatusProposta() == null) {
						final StatusVersaoProposta statusVersaoProposta = statusVersaoPropostas.get(0);
						documentoEmissaoEBO.setCodigoStatusProposta(EmissaoConvertTypes.convertIntToBigInt(
							statusVersaoProposta.getIdentificador().getCodigoStatusProposta()));
						documentoEmissaoEBO.setDataInicioStatusProposta(EmissaoConvertTypes.convertDateToXMLGreg(
							statusVersaoProposta.getDataInicioStatusProposta()));
						documentoEmissaoEBO.setDataFimStatusProposta(EmissaoConvertTypes.convertDateToXMLGreg(
							statusVersaoProposta.getDataFimStatusProposta()));
					}
				}
			}
			contConvertDocumentoEmissao(versaoProposta, documentoEmissaoEBO);
		}
		if (versaoProposta.getCodigoPrazoAverbacao() != null) {
			documentoEmissaoEBO.setCodigoPrazoAverbacao(BigInteger.valueOf(versaoProposta.getCodigoPrazoAverbacao()));
		}
		if ((versaoProposta.getFrequenciaFatoramento() != null) && (versaoProposta.getFrequenciaFatoramento()
			.getCodigoFrequenciaFaturamento() != null)) {
			documentoEmissaoEBO.setCodigoFrequenciaFaturamento(BigInteger.valueOf(versaoProposta.getFrequenciaFatoramento()
				.getCodigoFrequenciaFaturamento()));
		}
		if (AssertUtil.isNotNullAndEmpty(versaoProposta.getFlagCobrancaJuro())) {
			documentoEmissaoEBO.setFlagCobrancaJuro(versaoProposta.getFlagCobrancaJuro());
		} else {
			documentoEmissaoEBO.setFlagCobrancaJuro("S");
		}
		if (AssertUtil.isNotNullAndEmpty(versaoProposta.getVencimentoFaturaTransportVersaoProposta())) {
			DiasVencimento diasVencimento = new DiasVencimento();
			diasVencimento.getDiaVencimento().addAll(propostaTypeConverterExt.convertListDiaVencimentoToType(versaoProposta
				.getVencimentoFaturaTransportVersaoProposta()));
			documentoEmissaoEBO.setDiasVenciamento(diasVencimento);
		}
		if (versaoProposta.getVersaoOrcamento() != null) {
			if (versaoProposta.getVersaoOrcamento().getTipoPessoaProponete() != null) {
				documentoEmissaoEBO.setCodigoTipoPessoaProponente(BigInteger.valueOf(versaoProposta.getVersaoOrcamento()
					.getTipoPessoaProponete().getCodigoTipoPessoa()));
			}
			if (versaoProposta.getVersaoOrcamento().getPrazoAverbacao() != null) {
				documentoEmissaoEBO.setCodigoPrazoAverbacaoAdendo(BigInteger.valueOf(versaoProposta.getVersaoOrcamento()
					.getPrazoAverbacao().getCodigoPrazoAverbacao()));
			}
			if (versaoProposta.getVersaoOrcamento().getValorPremioMinimo() != null) {
				documentoEmissaoEBO.setValorPremioMinimo(versaoProposta.getVersaoOrcamento().getValorPremioMinimo());
			}
			if (versaoProposta.getVersaoOrcamento().getValorPremioDepositoInicial() != null) {
				documentoEmissaoEBO.setValorPremioDepositoInicial(versaoProposta.getVersaoOrcamento()
					.getValorPremioDepositoInicial());
			}
			if (versaoProposta.getVersaoOrcamento().getFlagCobrancaPremioDepIniAdendo() != null) {
				documentoEmissaoEBO.setFlagCobrancaPremioDeposito(versaoProposta.getVersaoOrcamento()
					.getFlagCobrancaPremioDepIniAdendo());
			}
			if (versaoProposta.getVersaoOrcamento().getValorAjustePremioMinimo() != null) {
				documentoEmissaoEBO.setValorAjustePremioMinimo(versaoProposta.getVersaoOrcamento()
					.getValorAjustePremioMinimo());
			}
			if (versaoProposta.getVersaoOrcamento().getFlagEndossoRetroativo() != null) {
				documentoEmissaoEBO.setFlagEndossoRetroativo(versaoProposta.getVersaoOrcamento().getFlagEndossoRetroativo());
			}
			if (versaoProposta.getVersaoOrcamento().getFlagPossuiAverbacao() != null) {
				documentoEmissaoEBO.setFlagPossuiAverbacao(versaoProposta.getVersaoOrcamento().getFlagPossuiAverbacao());
			}
			if (versaoProposta.getVersaoOrcamento().getFlagPossuiEmbarcador() != null) {
				documentoEmissaoEBO.setFlagPossuiEmbarcador(versaoProposta.getVersaoOrcamento().getFlagPossuiEmbarcador());
			}
			if (versaoProposta.getVersaoOrcamento().getNumeroApoliceAssociado() != null) {
				documentoEmissaoEBO.setNumeroApoliceAssociado(versaoProposta.getVersaoOrcamento()
					.getNumeroApoliceAssociado());
			}
			if ((versaoProposta.getVersaoOrcamento() != null) && (versaoProposta.getVersaoOrcamento()
				.getNumeroVersaoOrcamentoAssociado() != null)) {
				documentoEmissaoEBO.setNumeroVersaoOrcamentoAssociado(BigInteger.valueOf(versaoProposta.getVersaoOrcamento()
					.getNumeroVersaoOrcamentoAssociado()));
			}
			if ((versaoProposta.getVersaoOrcamento() != null) && (versaoProposta.getVersaoOrcamento()
				.getNumeroOrcamentoAssociado() != null)) {
				documentoEmissaoEBO.setNumeroOrcamentoAssociado(BigInteger.valueOf(versaoProposta.getVersaoOrcamento()
					.getNumeroOrcamentoAssociado()));
			}
		}
		final AuditoriaEBO auditoriaType = new AuditoriaEBO();
		auditoriaType.setDataUltimaAlteracao(ConvertTypes.convertDateToXMLGreg(versaoProposta.getDataUltimaAlteracao()));
		auditoriaType.setCodigoTipoUsuarioUltimaAlteracao(versaoProposta.getCodigoTipoUsuarioUltimaAlteracao());
		auditoriaType.setCodigoEmpresaUsuarioUltimaAlteracao(versaoProposta.getCodigoEmpresaUsuarioUltimaAlteracao());
		auditoriaType.setCodigoMatriculaUsuarioUltimaAlteracao(versaoProposta.getCodigoMatriculaUsuarioUltimaAlteracao());
		documentoEmissaoEBO.setAuditoria(auditoriaType);
		return documentoEmissaoEBO;
	}

	/**
	 * Continue convert of DocumentoEmissao.
	 *
	 * @param versaoProposta
	 *            parameter
	 * @param documentoEmissaoEBO
	 *            parameter
	 */
	@SuppressWarnings({ "checkstyle:cyclomaticcomplexity", "PMD.CyclomaticComplexity", "pmd:ConfusingTernary" })
	private void contConvertDocumentoEmissao(final VersaoProposta versaoProposta,
		final DocumentoEmissaoEBO documentoEmissaoEBO) {

		if (CollectionUtils.hasContents(versaoProposta.getItemVersaoPropostas())) {
			if (documentoEmissaoEBO.getItensDocumentoEmissao() == null) {
				documentoEmissaoEBO.setItensDocumentoEmissao(propostaTypeConverterExt.convertItemVersaoProposta(
					versaoProposta.getItemVersaoPropostas()));
			} else {
				for (final ItemVersaoProposta entityClass : versaoProposta.getItemVersaoPropostas()) {
					for (final ItemDocumentoEmissaoEBO typeClass : documentoEmissaoEBO.getItensDocumentoEmissao()
						.getItemDocumentoEmissao()) {
						final Integer numeroItem = EmissaoConvertTypes.convertBigIntToInt(typeClass
							.getNumeroItemVersaoOrcamento());
						if (entityClass.getIdentificador().getNumeroItemVersaoProposta().equals(numeroItem)) {
							typeClass.setNumeroProposta(entityClass.getIdentificador().getNumeroProposta());
							typeClass.setNumeroVersaoProposta(entityClass.getIdentificador().getNumeroVersaoProposta());
							typeClass.setNumeroItemVersaoProposta(EmissaoConvertTypes.convertIntToBigInt(entityClass
								.getIdentificador().getNumeroItemVersaoProposta()));
							typeClass.setNumeroVersaoOrcamento(typeClass.getNumeroVersaoOrcamento());
							if (CollectionUtils.hasContents(entityClass.getCriticaItemVersaoPropostas())) {
								final ListaCriticasItensEBO listaCriticasItens = propostaTypeConverterExt
									.convertToCriticasItem(entityClass.getCriticaItemVersaoPropostas());
								typeClass.setCriticasItem(listaCriticasItens);
							}
							if (CollectionUtils.hasContents(entityClass.getListaItemVersaoPropostas())) {
								final ListaItensEBO listaItens = propostaTypeConverterExt.convertToListaItens(entityClass
									.getListaItemVersaoPropostas());
								typeClass.setListaItens(listaItens);
							}
							if (CollectionUtils.hasContents(entityClass.getCoberturaItemVersaoPropostas())) {
								final ListaCoberturaItemEBO listaCobItm = propostaTypeConverterExt
									.convertCoberturaItemVersaoPropostas(entityClass.getCoberturaItemVersaoPropostas());
								final CoberturasItemEBO cobItmType = new CoberturasItemEBO();
								cobItmType.setListaCoberturasItem(listaCobItm);
								if (typeClass.getCoberturasItem() == null) {
									typeClass.setCoberturasItem(cobItmType);
								} else {
									final List<BigInteger> listIdCoberturas = new ArrayList<>();
									for (final CoberturaItemDocumentoEBO cobertura : typeClass.getCoberturasItem()
										.getListaCoberturasItem().getCoberturaItemDocumento()) {
										listIdCoberturas.add(cobertura.getCodigoCobertura());
									}
									for (final CoberturaItemDocumentoEBO cobertura : listaCobItm
										.getCoberturaItemDocumento()) {
										if (!listIdCoberturas.contains(cobertura.getCodigoCobertura())) {
											typeClass.getCoberturasItem().getListaCoberturasItem()
												.getCoberturaItemDocumento().addAll(listaCobItm.getCoberturaItemDocumento());
										} else {
											for (final CoberturaItemDocumentoEBO coberturaItemEBO : typeClass
												.getCoberturasItem().getListaCoberturasItem().getCoberturaItemDocumento()) {
												if (coberturaItemEBO.getCodigoCobertura().equals(cobertura
													.getCodigoCobertura())) {
													if ((cobertura.getBeneficiarios() != null) && (cobertura.getBeneficiarios()
														.getBeneficiario() != null) && (cobertura.getBeneficiarios()
															.getBeneficiario().size() > 0) && ((coberturaItemEBO
																.getBeneficiarios() == null) || (coberturaItemEBO
																	.getBeneficiarios().getBeneficiario() == null) ||
																(coberturaItemEBO.getBeneficiarios().getBeneficiario()
																	.size() == 0))) {
														coberturaItemEBO.setBeneficiarios(cobertura.getBeneficiarios());
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		if (CollectionUtils.hasContents(versaoProposta.getCorretorVersaoPropostas())) {
			final ListaCorretoresEBO listarCorretor = propostaTypeConverterExt.convertCorretorToType(versaoProposta
				.getCorretorVersaoPropostas());
			documentoEmissaoEBO.setCorretores(listarCorretor);
		}
		if (CollectionUtils.hasContents(versaoProposta.getIntervenienteVersaoPropostas())) {
			final ListaIntervenientesEBO listaIntervenientes = propostaTypeConverterExt
				.convertIntervenienteVersaoPropostaToType(versaoProposta.getIntervenienteVersaoPropostas());
			documentoEmissaoEBO.setIntervenientes(listaIntervenientes);
		}
		if (CollectionUtils.hasContents(versaoProposta.getPagadorVersaoPropostas())) {
			documentoEmissaoEBO.setPagadores(propostaTypeConverterExt.convertPagadores(versaoProposta
				.getPagadorVersaoPropostas()));
		}
		if (CollectionUtils.hasContents(versaoProposta.getCriticaVersaoPropostas())) {
			documentoEmissaoEBO.setCriticas(convertCritica(versaoProposta.getCriticaVersaoPropostas()));
		}
		if (CollectionUtils.hasContents(versaoProposta.getAnaliseVersaoPropostas())) {
			final ListaAnalisesEBO listaAnalisesEBO = propostaTypeConverterExt.convertAnalise(versaoProposta
				.getAnaliseVersaoPropostas());
			documentoEmissaoEBO.setAnalises(listaAnalisesEBO);
		}
		if (CollectionUtils.hasContents(versaoProposta.getStatusVersaoPropostas())) {
			final List<StatusVersaoProposta> statusVerProposta = versaoProposta.getStatusVersaoPropostas();
			if (CollectionUtils.hasContents(statusVerProposta)) {
				for (final StatusVersaoProposta statusVersaoProposta : statusVerProposta) {
					if ((statusVersaoProposta != null) && (statusVersaoProposta.getDataFimStatusProposta() == null)) {
						documentoEmissaoEBO.setCodigoStatusProposta(BigInteger.valueOf(statusVersaoProposta
							.getIdentificador().getCodigoStatusProposta()));
						documentoEmissaoEBO.setDataFimStatusProposta(EmissaoConvertTypes.convertDateToXMLGreg(
							statusVersaoProposta.getDataFimStatusProposta()));
						documentoEmissaoEBO.setDataInicioStatusProposta(EmissaoConvertTypes.convertDateToXMLGreg(
							statusVersaoProposta.getDataInicioStatusProposta()));
					}
				}
			}
			if (documentoEmissaoEBO.getCodigoStatusProposta() == null) {
				final StatusVersaoProposta statusProposta = versaoProposta.getStatusVersaoPropostas().get(ZERO);
				if (statusProposta != null) {
					documentoEmissaoEBO.setCodigoStatusProposta(BigInteger.valueOf(statusProposta.getIdentificador()
						.getCodigoStatusProposta()));
					documentoEmissaoEBO.setDataFimStatusProposta(EmissaoConvertTypes.convertDateToXMLGreg(statusProposta
						.getDataFimStatusProposta()));
					documentoEmissaoEBO.setDataInicioStatusProposta(EmissaoConvertTypes.convertDateToXMLGreg(statusProposta
						.getDataInicioStatusProposta()));
				}
			}
		}
	}

	/**
	 * Convert Critica.
	 *
	 * @param criticaVersaoPropostas
	 *            - The criticaVersaoPropostas to convert
	 * @return entityClasses - the entity class List form.
	 */
	@Override
	public ListaCriticasEBO convertCritica(final List<CriticaSeguroVersaoProposta> criticaVersaoPropostas) {

		final ListaCriticasEBO criticaVersaoPropostaType = new ListaCriticasEBO();

		for (final CriticaSeguroVersaoProposta selected : criticaVersaoPropostas) {

			final CriticaEBO criticaEBO = convertCritica(selected);
			criticaVersaoPropostaType.getCritica().add(criticaEBO);
		}
		return criticaVersaoPropostaType;
	}

	/**
	 * Convert Critica.
	 *
	 * @param selected
	 *            parameter
	 * @return CriticaEBO
	 */
	@Override
	public CriticaEBO convertCritica(final CriticaSeguroVersaoProposta selected) {

		final CriticaSeguro critica = selected.getCritica();
		final CriticaEBO criticaType = new CriticaEBO();

		criticaType.setDataCritica(EmissaoConvertTypes.convertDateToXMLGreg(selected.getDataCritica()));
		if (selected.getIdentificador() != null) {
			criticaType.setCodigoCritica(EmissaoConvertTypes.convertIntToBigInt(selected.getIdentificador()
				.getCodigoCritica()));
		}
		if (selected.getTextoRetornoCritica() != null) {
			criticaType.setTextoRetornoCritica(selected.getTextoRetornoCritica());
		}

		if (critica != null) {

			criticaType.setNomeCritica(critica.getNomeCritica());
			criticaType.setNomeResumidoCritica(critica.getNomeResumidoCritica());

			if (critica.getTipoCritica() != null) {

				criticaType.setCodigoTipoCritica(EmissaoConvertTypes.convertIntToBigInt(critica.getTipoCritica()
					.getCodigoTipoCritica()));
			}
			criticaType.setTextoCritica(critica.getTextoCritica());

			if (critica.getGrupoAcesso() != null) {
				criticaType.setCodigoGrupoAcesso(EmissaoConvertTypes.convertIntToBigInt(critica.getGrupoAcesso()
					.getCodigoGrupoAcesso()));
			}
			criticaType.setFlagAtivo(critica.getFlagAtivo());

			criticaType.setTextoComentario(critica.getTextoComentario());

			final DevolutivaEBO devolutivaType = propostaTypeConverterExt.convertDevolutiva(critica.getDevolutiva());

			final ListaDevolutivaEBO listaDevolutivaType = new ListaDevolutivaEBO();
			listaDevolutivaType.getDevolutiva().add(devolutivaType);
			criticaType.setListaDevolutiva(listaDevolutivaType);

			criticaType.setFlagJustificativaLiberacaoObrigatorio(critica.getFlagJustificativaLiberacaoObrigatorio());
		}
		if (CollectionUtils.hasContents(selected.getStatusCriticaVersaoPropostas())) {
			final StatusCriticaSeguroVersaoProposta statusCriticaVerProp = selected.getStatusCriticaVersaoPropostas().get(
				ZERO);

			criticaType.setCodigoStatusCritica(EmissaoConvertTypes.convertIntToBigInt(statusCriticaVerProp.getIdentificador()
				.getCodigoStatusCritica()));
		}
		return criticaType;
	}

	/**
	 * Convert Devolutiva.
	 *
	 * @param devolutiva
	 *            parameter
	 * @return DevolutivaEBO
	 */
	private DevolutivaEBO convertDevolutiva(final Devolutiva devolutiva) {

		final DevolutivaEBO devolutivaType = new DevolutivaEBO();

		devolutivaType.setCodigoDevolutiva(EmissaoConvertTypes.convertIntToBigInt(devolutiva.getCodigoDevolutiva()));

		devolutivaType.setNomeDevolutiva(devolutiva.getNomeDevolutiva());
		devolutivaType.setNomeResumidoDevolutiva(devolutiva.getNomeResumidoDevolutiva());

		if (null != devolutiva.getTipoDevolutiva()) {
			devolutivaType.setCodigoTipoDevolutiva(EmissaoConvertTypes.convertIntToBigInt(devolutiva.getTipoDevolutiva()
				.getCodigoTipoDevolutiva()));
		}
		if (devolutiva.getModeloCarta() != null) {
			devolutivaType.setCodigoModeloCarta(EmissaoConvertTypes.convertIntToBigInt(devolutiva.getModeloCarta()
				.getCodigoModeloCarta()));
		}
		devolutivaType.setFlagAtivo(devolutiva.getFlagAtivo());
		devolutivaType.setTextoComentario(devolutiva.getTextoComentario());

		return devolutivaType;
	}

	/**
	 * Convert Pendencias.
	 *
	 * @param pendenciaVersaoPropostas
	 *            - The pendenciaVersaoPropostas to convert
	 * @return entityClasses - the entity class List form.
	 */
	public ListaPendenciasEBO convertPendencias(final List<PendenciaVersaoProposta> pendenciaVersaoPropostas) {

		final ListaPendenciasEBO pendenciaVersaoPropostaType = new ListaPendenciasEBO();

		for (final PendenciaVersaoProposta selected : pendenciaVersaoPropostas) {

			final PendenciaEBO pendenciaType = new PendenciaEBO();

			if (selected.getPendencia() != null) {
				pendenciaType.setCodigoPendencia(EmissaoConvertTypes.convertIntToBigInt(selected.getPendencia()
					.getCodigoPendencia()));
			}
			pendenciaType.setNumeroSequenciaPendencia(EmissaoConvertTypes.convertIntToBigInt(selected.getIdentificador()
				.getNumeroSequenciaPendencia()));

			if (selected.getStatusPendencia() != null) {
				pendenciaType.setCodigoStatusPendencia(EmissaoConvertTypes.convertIntToBigInt(selected.getStatusPendencia()
					.getCodigoStatusPendencia()));
			}
			if (selected.getDevolutiva() != null) {
				pendenciaType.setCodigoDevolutiva(EmissaoConvertTypes.convertIntToBigInt(selected.getDevolutiva()
					.getCodigoDevolutiva()));
			}
			pendenciaType.setCodigoCorretor(selected.getCodigoCorretor());
			pendenciaType.setTextoPendencia(selected.getTextoPendencia());

			if (selected.getDataRegistroAbertura() != null) {
				pendenciaType.setDataRegistroAbertura(EmissaoConvertTypes.convertDateToXMLGreg(selected
					.getDataRegistroAbertura()));
			}
			final List<RespostaPendenciaVersaoProposta> respostaPendencias = selected.getRespostaPendenciaVersaoPropostas();

			final ListaRespostaPendenciaEBO respostaPendenciaVesaoPropostaType = new ListaRespostaPendenciaEBO();

			if (respostaPendencias != null) {
				convertListOfRespostaPendenciaVersaoProposta(respostaPendencias, respostaPendenciaVesaoPropostaType);
			}
			pendenciaType.setListaRespostasPendencia(respostaPendenciaVesaoPropostaType);
			pendenciaVersaoPropostaType.getPendencia().add(pendenciaType);
		}

		return pendenciaVersaoPropostaType;
	}

	/**
	 * Convert RespostaPendenciaVersaoProposta to
	 * RespostaPendenciaVersaoProposta.
	 *
	 * @param respostaPendencias
	 *            parameter
	 * @param respostaPendenciaVesaoPropostaType
	 *            parameter
	 */
	private void convertListOfRespostaPendenciaVersaoProposta(final List<RespostaPendenciaVersaoProposta> respostaPendencias,
		final ListaRespostaPendenciaEBO respostaPendenciaVesaoPropostaType) {

		if (respostaPendencias != null) {
			for (final RespostaPendenciaVersaoProposta selectedRespostaPendencia : respostaPendencias) {

				final RespostaPendenciaEBO respostaPendenciaType = new RespostaPendenciaEBO();

				respostaPendenciaType.setNumeroSequenciaRespostaPendencia(EmissaoConvertTypes.convertIntToBigInt(
					selectedRespostaPendencia.getIdentificador().getNumeroSequenciaRespostaPendencia()));

				if (selectedRespostaPendencia.getDataResposta() != null) {
					respostaPendenciaType.setDataResposta(EmissaoConvertTypes.convertDateToXMLGreg(selectedRespostaPendencia
						.getDataResposta()));
				}
				respostaPendenciaType.setTextoRespostaPendencia(selectedRespostaPendencia.getTextoRespostaPendencia());

				respostaPendenciaType.setFlagPossuiAnexo(selectedRespostaPendencia.getFlagPossuiAnexo());

				respostaPendenciaType.setCodigoIdentificacaoDocumento(selectedRespostaPendencia
					.getCodigoIdentificacaoDocumento());

				final AuditoriaEBO auditoria = new AuditoriaEBO();

				auditoria.setCodigoEmpresaUsuarioUltimaAlteracao(selectedRespostaPendencia
					.getCodigoEmpresaUsuarioUltimaAlteracao());

				auditoria.setCodigoMatriculaUsuarioUltimaAlteracao(selectedRespostaPendencia
					.getCodigoEmpresaUsuarioUltimaAlteracao());

				auditoria.setCodigoTipoUsuarioUltimaAlteracao(selectedRespostaPendencia
					.getCodigoTipoUsuarioUltimaAlteracao());

				auditoria.setDataUltimaAlteracao(EmissaoConvertTypes.convertDateToXMLGreg(selectedRespostaPendencia
					.getDataUltimaAlteracao()));

				respostaPendenciaType.setAuditoria(auditoria);

				respostaPendenciaVesaoPropostaType.getRespostaPendencia().add(respostaPendenciaType);
			}
		}
	}

	/**
	 * Method used to convert VersaoProposta to Type.
	 *
	 * @param convertedDocumentoEmissao
	 *            - The convertedDocumentoEmissao to convert
	 * @param selected
	 *            - The VersaoProposta object.
	 */
	private void convertVersaoProposta(final DocumentoEmissaoEBO convertedDocumentoEmissao, final VersaoProposta selected) {

		if ((selected.getIdentificador() != null) && (selected.getIdentificador().getNumeroVersaoProposta() != null)) {
			convertedDocumentoEmissao.setNumeroVersaoProposta(selected.getIdentificador().getNumeroVersaoProposta());
			convertedDocumentoEmissao.setNumeroProposta(selected.getIdentificador().getNumeroProposta());
		}

		if (selected.getProposta() != null) {
			propostaTypeConverterExt.convertProposta(selected.getProposta(), convertedDocumentoEmissao);
		}
		convertVersaoPropostaFields(convertedDocumentoEmissao, selected);

		// if (selected.getNumeroSorteTituloCapitalizacao() != null) {
		// convertedDocumentoEmissao.setNumeroSorteTituloCapitalizacao(selected.getNumeroSorteTituloCapitalizacao()
		// .longValue());
		// }

		final EnderecoEBO enderecoType = new EnderecoEBO();

		if (selected.getCodigoEnderecoCorrespondencia() != null) {

			enderecoType.setCodigoEndereco(selected.getCodigoEnderecoCorrespondencia());
			convertedDocumentoEmissao.setEnderecoCorrespondencia(enderecoType);
		}
		// Missing attributes from DocumentoEmissaoEBO
		// flagRenovacaoAutomatico
		// codigoTipoOrganizacao

		convertedDocumentoEmissao.setFlagEndossoAlteracaoDadoCadastralSegurado(selected
			.getFlagEndossoAlteracaoDadoCadastralSegurado());
		convertedDocumentoEmissao.setNomeProcessoSistemaGerenciamentoProcesso(selected
			.getNomeProcessoSistemaGerenciamentoProcesso());

		if ((selected.getAnaliseVersaoPropostas() != null) && !selected.getAnaliseVersaoPropostas().isEmpty()) {
			convertedDocumentoEmissao.setAnalises(convertAnalise(selected.getAnaliseVersaoPropostas())); // FIX
		}
		if (selected.getVersaoOrcamento() != null) {
			final Orcamento orcamento = selected.getVersaoOrcamento().getOrcamento();
			List<VersaoOrcamento> listaVersaoOrcamento = new ArrayList<>();
			listaVersaoOrcamento.add(selected.getVersaoOrcamento());
			orcamento.setVersaoOrcamentos(listaVersaoOrcamento);
			iOrcamentoSOAPConverter.convertToType(orcamento, convertedDocumentoEmissao);
			iOrcamentoSOAPConverter.convertVersaoOrcamentoToType(selected.getVersaoOrcamento(), convertedDocumentoEmissao, Boolean.FALSE);
		}
		// Moved for Locking functionality Functional Design Update
		convertedDocumentoEmissao.setFlagBloqueio(selected.getFlagBloqueio());
		convertedDocumentoEmissao.setDataBloqueio(EmissaoConvertTypes.convertDateToXMLGreg(selected.getDataBloqueio()));
		convertedDocumentoEmissao.setCodigoTipoUsuarioBloqueio(selected.getCodigoTipoUsuarioBloqueio());
		convertedDocumentoEmissao.setCodigoEmpresaUsuarioBloqueio(selected.getCodigoEmpresaUsuarioBloqueio());
		convertedDocumentoEmissao.setCodigoMatriculaUsuarioBloqueio(selected.getCodigoMatriculaUsuarioBloqueio());

		// FIX 5382 Campo não existe no ebo 99.48.27
		convertedDocumentoEmissao.setDataProtocoloImpressao(EmissaoConvertTypes.convertDateToXMLGreg(selected
			.getDataProtocolo()));

		/*
		 * DocumentoEmissaoEBO only needs the PK of VersaoOrcamento to be
		 * converted. NOTE: Removed 20160819
		 */
		if (selected.getVersaoOrcamento() != null) {
			convertedDocumentoEmissao.setNumeroOrcamento(selected.getVersaoOrcamento().getIdentificador()
				.getNumeroOrcamento());
			convertedDocumentoEmissao.setNumeroVersaoOrcamento(selected.getVersaoOrcamento().getIdentificador()
				.getNumeroVersaoOrcamento());
			if (!(selected.getVersaoOrcamento().getOrcamento() == null)) {
				convertedDocumentoEmissao.setCodigoOferta(selected.getVersaoOrcamento().getOrcamento().getCodigoOferta());
				convertedDocumentoEmissao.setNumeroVersaoOferta(selected.getVersaoOrcamento().getOrcamento()
					.getNumeroVersaoOferta());
				convertedDocumentoEmissao.setNumeroSequenciaVersaoOferta(BigInteger.valueOf(selected.getVersaoOrcamento()
					.getOrcamento().getNumeroSequenciaVersaoOferta()));
				convertedDocumentoEmissao.setCodigoRamo(BigInteger.valueOf(selected.getVersaoOrcamento().getOrcamento()
					.getCodigoRamo()));
				convertedDocumentoEmissao.setCodigoEmpresa(BigInteger.valueOf(selected.getVersaoOrcamento().getOrcamento()
					.getCodigoEmpresa()));
				convertedDocumentoEmissao.setCodigoModalidade(BigInteger.valueOf(selected.getVersaoOrcamento().getOrcamento()
					.getCodigoModalidade()));
				convertedDocumentoEmissao.setCodigoGrupoComercial(EmissaoConvertTypes.convertIntToBigInt(selected
					.getVersaoOrcamento().getOrcamento().getCodigoGrupoComercial()));
			}
			if (selected.getVersaoOrcamento().getOnus() != null) {
				convertedDocumentoEmissao.setCodigoOnus(EmissaoConvertTypes.convertIntToBigInt(selected.getVersaoOrcamento()
					.getOnus().getCodigoOnus()));
			}

			if ((selected.getAnaliseVersaoPropostas() != null) && !selected.getAnaliseVersaoPropostas().isEmpty()) {
				convertAnalise(selected.getAnaliseVersaoPropostas());
				convertedDocumentoEmissao.setAnalises(convertAnalise(selected.getAnaliseVersaoPropostas())); // FIX
																												// //
																												// 5286
			}
		}
	}

	/**
	 * Convert VersaoProposta fields.
	 *
	 * @param convertedDocumentoEmissao
	 *            parameter
	 * @param selected
	 *            parameter
	 */
	private void convertVersaoPropostaFields(final DocumentoEmissaoEBO convertedDocumentoEmissao,
		final VersaoProposta selected) {

		if ((selected.getFormaPagamento() != null) && (selected.getFormaPagamento().getCodigoFormaPagamento() != null)) {

			convertedDocumentoEmissao.setCodigoFormaPagamento(EmissaoConvertTypes.convertIntToLong(selected
				.getFormaPagamento().getCodigoFormaPagamento()));
		}
		convertedDocumentoEmissao.setDataProtocolo(EmissaoConvertTypes.convertDateToXMLGreg(selected.getDataProtocolo()));
		convertedDocumentoEmissao.setDataEmissao(EmissaoConvertTypes.convertDateToXMLGreg(selected.getDataEmissao()));
		convertedDocumentoEmissao.setNumeroPropostaAutomovel(selected.getNumeroPropostaAutomovel());
		convertedDocumentoEmissao.setFlagPossuiCorretorSecundario(selected.getFlagPossuiCorretorSecundario());
		convertedDocumentoEmissao.setFlagPossuiBeneficiario(selected.getFlagPossuiBeneficiario());
		convertedDocumentoEmissao.setFlagPossuiSinistro(selected.getFlagPossuiSinistro());
		// convertedDocumentoEmissao.setFlagPrimeiraCompraCartaoEmpresa(selected.getFlagPrimeiraCompraCartaoEmpresa());
		convertedDocumentoEmissao.setFlagEnvioEmailCorretor(selected.getFlagEnvioEmailCorretor());
		if(selected.getFlagEnvioEmailImobiliaria() == "S" && selected.getFlagEnvioEmailCorretor() == "S") {
			convertedDocumentoEmissao.setFlagEnvioEmailCorretor("T");
		}
		else if(selected.getFlagEnvioEmailImobiliaria() == "S" && selected.getFlagEnvioEmailCorretor() == "N") {
			convertedDocumentoEmissao.setFlagEnvioEmailCorretor("I");
		}
		convertedDocumentoEmissao.setFlagPossuiTituloCapitalizacao(selected.getFlagPossuiTituloCapitalizacao());
		convertedDocumentoEmissao.setDataInicioVigencia(EmissaoConvertTypes.convertDateToXMLGreg(selected
			.getDataInicioVigencia()));
		convertedDocumentoEmissao.setDataFimVigencia(EmissaoConvertTypes.convertDateToXMLGreg(selected
			.getDataFimVigencia()));
		convertedDocumentoEmissao.setDataMelhorDataPrimeiraParcela(EmissaoConvertTypes.convertDateToXMLGreg(selected
			.getDataMelhorDataPrimeiraParcela()));

		// Impressao emissao - convert dados de versaoOrcamento 12/05/2016
		// danilo.da.silva
		if (selected.getVersaoOrcamento() != null) {
			iOrcamentoSOAPConverter.convertVersaoOrcamentoToType(selected.getVersaoOrcamento(), convertedDocumentoEmissao, Boolean.FALSE);
		}
	}

	/**
	 * Convert Corretor to Type.
	 *
	 * @param numeroProposta
	 *            parameter
	 * @param numeroVersaoProposta
	 *            parameter
	 * @param corretorVersaoProposta
	 *            parameter
	 * @return DocumentoEmissaoEBO
	 */
	public DocumentoEmissaoEBO convertCorretorToType(final Long numeroProposta, final Long numeroVersaoProposta,
		final List<CorretorVersaoProposta> corretorVersaoProposta) {

		final ListaCorretoresEBO listaCorretoresType = propostaTypeConverterExt.convertCorretorToType(
			corretorVersaoProposta);

		final DocumentoEmissaoEBO newDocumentoEmissao = new DocumentoEmissaoEBO();

		if (CollectionUtils.hasContents(listaCorretoresType.getCorretor())) {
			newDocumentoEmissao.setNumeroProposta(numeroProposta);
			newDocumentoEmissao.setNumeroVersaoProposta(numeroVersaoProposta);
			newDocumentoEmissao.setCorretores(listaCorretoresType);
		}
		return newDocumentoEmissao;
	}

	/**
	 * Convert Pagador to Type.
	 *
	 * @param numeroProposta
	 *            parameter
	 * @param numeroVersaoProposta
	 *            parameter
	 * @param pagadorVersaoProposta
	 *            parameter
	 * @return DocumentoEmissaoEBO
	 */
	public DocumentoEmissaoEBO convertPagadorToType(final Long numeroProposta, final Long numeroVersaoProposta,
		final List<PagadorVersaoProposta> pagadorVersaoProposta) {
		final ListaPagadoresEBO listaPagadoresType = new ListaPagadoresEBO();
		for (final PagadorVersaoProposta selected : pagadorVersaoProposta) {
			listaPagadoresType.getPagador().add(convertPagadorToType(selected));
		}
		final DocumentoEmissaoEBO newDocumentoEmissao = new DocumentoEmissaoEBO();
		newDocumentoEmissao.setNumeroProposta(numeroProposta);
		newDocumentoEmissao.setNumeroVersaoProposta(numeroVersaoProposta);
		newDocumentoEmissao.setPagadores(listaPagadoresType);
		return newDocumentoEmissao;
	}

	/**
	 * Convert Pagador to Type.
	 *
	 * @param pagadorVersaoProposta
	 *            parameter
	 * @return PagadorEBO
	 */
	public PagadorEBO convertPagadorToType(final PagadorVersaoProposta pagadorVersaoProposta) {
		final PagadorEBO pagador = new PagadorEBO();
		if ((pagadorVersaoProposta != null) && (pagadorVersaoProposta.getIdentificador() != null) && (pagadorVersaoProposta
			.getIdentificador().getCodigoPessoa() != null)) {
			final PessoaEBO pessoaEBO = new PessoaEBO();
			pessoaEBO.setCodigoPessoa(pagadorVersaoProposta.getIdentificador().getCodigoPessoa());
			pagador.setDadosPessoaPagador(pessoaEBO);
			final EnderecoEBO enderecoEBO = new EnderecoEBO();
			enderecoEBO.setCodigoEndereco(pagadorVersaoProposta.getCodigoEnderecoCobranca());
			pagador.setEnderecoCobranca(enderecoEBO);
			final ListaPagadorParcelaEBO listarPagador = propostaTypeConverterExt.convertPagadoresParcela(
				pagadorVersaoProposta.getPagadorParcelaVersaoPropostas());

			pagador.setPagadoresParcela(listarPagador);
		}
		return pagador;
	}

	/**
	 * Method used to convert AnaliseVersaoProposta to Type.
	 *
	 * @param analiseVersaoPropostas
	 *            - The analiseVersaoPropostas to convert
	 * @return listaAnalisesType - The entity class List form.
	 */
	public ListaAnalisesEBO convertAnalise(final List<AnaliseVersaoProposta> analiseVersaoPropostas) {

		final ListaAnalisesEBO listaAnalisesType = new ListaAnalisesEBO();
		for (final AnaliseVersaoProposta selected : analiseVersaoPropostas) {
			final AnaliseEBO analiseType = new AnaliseEBO();
			analiseType.setNumeroSequenciaAnalise(EmissaoConvertTypes.convertIntToBigInt(selected.getId()
				.getNumeroSequenciaAnalise()));
			final StatusParecer statusParecer = selected.getStatusParecer();
			if (statusParecer != null) {
				analiseType.setCodigoStatusParecer(EmissaoConvertTypes.convertIntToBigInt(statusParecer
					.getCodigoStatusParecer()));
			}
			final TipoParecer tipoParecer = selected.getTipoParecer();
			if (tipoParecer != null) {
				analiseType.setCodigoTipoParecer(EmissaoConvertTypes.convertIntToBigInt(tipoParecer.getCodigoTipoParecer()));
			}
			analiseType.setTextoAnalise(selected.getTextoAnalise());
			analiseType.setCodigoEmpresaUsuarioUltimaAlteracao(selected.getCodigoEmpresaUsuarioUltimaAlteracao());
			analiseType.setCodigoMatriculaUsuarioUltimaAlteracao(selected.getCodigoMatriculaUsuarioUltimaAlteracao());
			analiseType.setCodigoTipoUsuarioUltimaAlteracao(selected.getCodigoTipoUsuarioUltimaAlteracao());
			try {
				setDataUltimaAlteracaoInFormatXmlGregorian(selected, analiseType);
			} catch (DatatypeConfigurationException e) {
				LOGGER.info(e.getMessage());
			}
			listaAnalisesType.getAnalise().add(analiseType);
		}
		return listaAnalisesType;
	}

	/**
	 * Sets the data ultima alteracao in format xml gregorian.
	 *
	 * @param analiseVersaoProposta
	 *            the analise versao proposta
	 * @param analiseEBO
	 *            the analise EBO
	 * @throws DatatypeConfigurationException
	 *             the datatype configuration exception
	 */
	private void setDataUltimaAlteracaoInFormatXmlGregorian(final AnaliseVersaoProposta analiseVersaoProposta,
		final AnaliseEBO analiseEBO) throws DatatypeConfigurationException {
		GregorianCalendar gregorianCalendar = new GregorianCalendar();
		gregorianCalendar.setTime(analiseVersaoProposta.getDataUltimaAlteracao());
		XMLGregorianCalendar calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
		analiseEBO.setDataUltimaAlteracao(calendar);
	}

	/**
	 * A method used to convert a list of Proposta entity to a list of Proposta
	 * type.
	 *
	 * @param entityClasses
	 *            object of List<{@link Proposta}>
	 * @return List<{@link DocumentoEmissaoEBO}>
	 */
	@Override
	public List<DocumentoEmissaoEBO> convertToType(final List<Proposta> entityClasses) {

		final List<DocumentoEmissaoEBO> typeClassList = new ArrayList<>();

		if (CollectionUtils.hasContents(entityClasses)) {

			for (final Proposta entityClass : entityClasses) {
				final DocumentoEmissaoEBO typeClass = convertToType(entityClass);
				typeClassList.add(typeClass);
			}
		}
		return typeClassList;
	}

	/**
	 * A method used to convert a list of Proposta type to a list of Proposta
	 * entity.
	 *
	 * @param typeClasses
	 *            the type classes
	 * @return List<{@link Proposta}>
	 */
	@Override
	public List<Proposta> convertToEntity(final List<DocumentoEmissaoEBO> typeClasses) {

		final List<Proposta> entityClassList = new ArrayList<>();

		if (CollectionUtils.hasContents(typeClasses)) {

			for (final DocumentoEmissaoEBO typeClass : typeClasses) {
				final Proposta entityClass = convertToEntity(typeClass);
				entityClassList.add(entityClass);
			}
		}
		return entityClassList;
	}

	/**
	 * Convert versao orcamento.
	 *
	 * @param documentoEmissaoEbo
	 *            the documento emissao ebo
	 * @return the long
	 */
	public Long convertVersaoOrcamento(final DocumentoEmissaoEBO documentoEmissaoEbo) {
		Long numeroVersaoProposta = 0L;

		if ((documentoEmissaoEbo != null) && (documentoEmissaoEbo.getNumeroVersaoProposta() != null)) {
			numeroVersaoProposta = documentoEmissaoEbo.getNumeroVersaoProposta();
		}
		return numeroVersaoProposta;
	}
}
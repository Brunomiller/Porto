(function() {
    'use strict';

    angular
        .module('porto.re.emissaocadastro.operacoes')
        .controller('OrcamentoPropostaController', OrcamentoPropostaController);

    OrcamentoPropostaController.$inject = ['PageInfo', 'Pages', 'TipoDocumento', 'OrcamentoPropostaFactory', 'DominiosService',
        'Dominios', 'UsuarioService', 'OrcamentoPropostaService', 'PessoaService', 'FaixaRendaService', 'blockUI',
        'TipoDocumentoPessoaService', 'PessoaFactory', 'PessoaEBODataFactory', 'EnderecoEBODataFactory', 'CartoesService',
        'Constants', '$state', '$stateParams', '$modal', '$filter', '$scope', '$q', 'SelectedOpts', 'OrcamentoService', 'OrcamentoFormFactory', 'ParceiroNegocioService',
        'FaixaCapitalService', 'LogradourosService', 'Documentos', 'DocumentoEmissaoService', 'MoedaService', 'OperacaoService', '$rootScope', 'OrcamentoUtilityFactory',
        'OrcamentoPropostaValidator', 'CanonicoService', 'CanonicoFactory', 'CorretoresService', 'cepFilter', 'MotivoAusenciaService', 'MotivoAusenciaCnpjCpfDataFactory',
        '$location', '$anchorScroll', 'OnusService', 'ParametroConfigService', 'CadastroProfissionalService', 'FaixaResgateOrcamentoService'
    ];

    /**
     * @ngdoc controller
     * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
     * @requires PageInfo
     * @requires Pages
     * @requires TipoDocumento
     * @requires OrcamentoPropostaFactory
     * @requires DominiosService
     * @requires Dominios
     * @requires UsuarioService
     * @requires OrcamentoPropostaService
     * @requires PessoaService
     * @requires FaixaRendaService
     * @requires TipoDocumentoPessoaService
     * @requires PessoaFactory
     * @requires Constants
     * @requires $state
     * @requires $stateParams
     * @requires $stateParams
     * @requires $modal
     * @requires $filter
     * @requires $scope
     * @requires SelectedOpts
     * @requires OrcamentoService
     * @requires OrcamentoFormFactory
     * @requires ParceiroNegocioService
     * @requires FaixaCapitalService
     * @requires LogradourosService
     * @requires Documentos
     * @requires DocumentoEmissaoService
     * @requires MoedaService
     * @requires OperacaoService
     * @requires $rootScope
     * @requires OrcamentoUtilityFactory
     * @requires OrcamentoPropostaValidator
     * @requires CanonicoService
     * @requires CanonicoFactory
     * @requires CorretoresService
     * @requires MotivoAusenciaService
     * @requires MotivoAusenciaCnpjCpfDataFactory
     * @description
     *
     * Main controller to handle OrcamentoProposta functionalities.
     **/
    function OrcamentoPropostaController(PageInfo, Pages, TipoDocumento, OrcamentoPropostaFactory, DominiosService,
        Dominios, UsuarioService, OrcamentoPropostaService, PessoaService, FaixaRendaService, blockUI,
        TipoDocumentoPessoaService, PessoaFactory, PessoaEBODataFactory, EnderecoEBODataFactory, CartoesService, Constants, $state, $stateParams, $modal, $filter, $scope,
        $q, SelectedOpts, OrcamentoService, OrcamentoFormFactory, ParceiroNegocioService, FaixaCapitalService, LogradourosService,
        Documentos, DocumentoEmissaoService, MoedaService, OperacaoService, $rootScope, OrcamentoUtilityFactory, OrcamentoPropostaValidator,
        CanonicoService, CanonicoFactory, CorretoresService, cepFilter, MotivoAusenciaService, MotivoAusenciaCnpjCpfDataFactory, $location, $anchorScroll, OnusService, ParametroConfigService, CadastroProfissionalService, FaixaResgateOrcamentoService) {

        var vm = this;
        vm.pageinfo = SelectedOpts;

        $scope.orcamentoCtrl.isFloppyDisabled = false;

        vm.stateUrl = "operacoes.orcamento.main.proposta";
        vm.activeState = "proposta";
        vm.validationCpf = validationCpf;
        var codigoEmpresa = null;
        var nomeDoServico = 'PROPOSTA';
        var orcamentoQuestionarioList = [];
        var coberturaOfertaList = [];
        var codigoMeioPagamentoPrimeiraParcela = null;
        vm.getDefaultDadosSegurado = OrcamentoPropostaFactory.defaultDadosSegurado();

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#questionario
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold all the selected `Questionario` data from the database
         **/
        vm.questaoList = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#descontos
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold all the selected `Desconto` data from the database
         **/
        vm.descontos = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#clausulas
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold all the selected `Clausula` data from the database
         **/
        vm.clausulas = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#criticas
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold all the selected `Criticas` data from the database
         **/
        vm.criticas = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#corretagem
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold all the selected `Co-Corretagem` data from the database
         **/
        vm.corretagem = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#dadosSegurado
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold all the selected `DadosSegurado` data from the database
         **/
        vm.dadosSeguro = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#endereco
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold all the default `Endereco` values
         **/
        vm.endereco = OrcamentoPropostaFactory.defaultEndereco();

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#showCorretagem
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Flag for showing corretagem
         **/
        vm.showCorretagem = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#disableEnderecoCobrancaCadastros
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Flag for disabling Endereco Cobranca Cadastros
         **/
        vm.disableEnderecoCobrancaCadastros = true;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#disableEnderecoCorrespondenciaCadastros
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Flag for disabling Endereco Correspondencia Cadastros
         **/
        vm.disableEnderecoCorrespondenciaCadastros = true;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#enderecoCobranca
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the default endereco Cobranca values
         **/
        vm.enderecoCobranca = OrcamentoPropostaFactory.defaultEnderecoCobranca();

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#enderecoCorrespondencia
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the default endereco Correspondencia values
         **/
        vm.enderecoCorrespondencia = OrcamentoPropostaFactory.defaultEnderecoCorrespondencia();

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#tipoIntervenienteDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the tipo Tipo Interveniente Dropdown values
         **/
        vm.tipoIntervenienteDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#tipoEnderecoDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the tipo Endereco Dropdown values
         **/
        vm.tipoEnderecoDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#pagamentoFormaDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the pagamento Forma Dropdown values
         **/
        vm.pagamentoFormaDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#pagamentoQuantidadeParcelaDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the pagamento Quantidade Parcela Data Dropdown values
         **/
        vm.pagamentoQuantidadeParcelaDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#tipoDocumentoDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the tipo Documento Dropdown values
         **/
        vm.tipoDocumentoDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#faixaDeRendaDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the Faixa de Renda Dropdown values
         **/
        vm.faixaDeRendaDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#tipoClassificacaoDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the Tipo Classificacao values
         **/
        vm.tipoClassificacaoDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#pessoaExpostaDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the Pessoa Exposta Dropdown values
         **/
        vm.pessoaExpostaDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#paisResidenteDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the Pais Residente Dropdown values
         **/
        vm.paisResidenteDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#sexoDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the Pais Sexo Dropdown values
         **/
        vm.sexoDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#atividadeDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the Atividade Dropdown values
         **/
        vm.atividadeDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#profissaoDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the Profissão Dropdown values
         **/
        vm.profissaoDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#classeProfissionalDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the classe Profissional Dropdown values
         **/
        vm.classeProfissionalDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#grauRelacionamentoDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the grau Relacionamento Dropdown values
         **/
        vm.grauRelacionamentoDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#classeTipoDocDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the classe Tipo Documento Dropdown values
         **/
        vm.classeTipoDocDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#pagamentoCalcularParcela
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold all the default `Pagamento Calcular Parcela` values
         **/
        vm.pagamentoCalcularParcela = OrcamentoPropostaFactory.defaultCalcularParcela();

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#pagamentoBandeiraDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the pagamento Bandeira Dropdown values
         **/
        vm.pagamentoBandeiraDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#pagamentoMaisUmPagador
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the pagamento Mais Um Pagador values
         **/
        vm.pagamentoMaisUmPagador = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isNao
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the value is Nao
         **/
        vm.isNao = true;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#showPagamentoDaParcelaGrid
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if Pagamento Da Parcela Grid should be shown.
         **/
        vm.showPagamentoDaParcelaGrid = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isRelacionamentoProximo
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the value of Pessoa exposta politicamente? in Dados Do Segurado is Relacionamento Próximo
         **/
        vm.isRelacionamentoProximo = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isDadosDeContatoRelacionamentoProximo
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the value of Pessoa exposta politicamente? in Dados De Contato is Relacionamento Próximo
         **/
        vm.isDadosDeContatoRelacionamentoProximo = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isPagamentoBtnDisabled
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Enables and disables the pagamento button.
         **/
        vm.isPagamentoBtnDisabled = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isCorretorFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the Corretagem form is submitted
         **/
        vm.isCorretorFormSubmitted = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#tipoPessoaDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the tipo Pessoa Dropdown values
         **/
        vm.tipoPessoaDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#formaPagamentoDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Forma Pagamento Dropdown values
         **/
        vm.formaPagamentoDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isPagamentoFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the Pagamento form is submitted
         **/
        vm.isPagamentoFormSubmitted = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isAdcPagamentoFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the ADC Pagamento form is submitted
         **/
        vm.isAdcPagamentoFormSubmitted = true;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isDemaisPagamentoFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the Demais Pagamento form is submitted
         **/
        vm.isDemaisPagamentoFormSubmitted = true;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isCartaoFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the Cartao form is submitted
         **/
        vm.isCartaoFormSubmitted = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isEmissaoEnderecoFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the Emissao Endereco form is submitted
         **/
        vm.isEmissaoEnderecoFormSubmitted = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isEnderecoCorrespondenciaFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the Endereco Correspondencia form is submitted
         **/
        vm.isEnderecoCorrespondenciaFormSubmitted = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isBeneficiarioFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the Beneficiario form is submitted
         **/
        vm.isBeneficiarioFormSubmitted = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isDadosFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the Dados form is submitted
         **/
        vm.isDadosFormSubmitted = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isDadosEnderecoFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the Dados Endereco form is submitted
         **/
        vm.isDadosEnderecoFormSubmitted = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isControlladorFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the Controllador form is submitted
         **/
        vm.isControlladorFormSubmitted = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isDadosEnderecoJuridicaFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the Dados Endereco Juridica form is submitted
         **/
        vm.isDadosEnderecoJuridicaFormSubmitted = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isDadosContatoFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the Dados Contato form is submitted
         **/
        vm.isDadosContatoFormSubmitted = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isCosseguradoFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the Cossegurado form is submitted
         **/
        vm.isCosseguradoFormSubmitted = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isDadosContatoJuridicaFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the Dados Contato Juridica form is submitted
         **/
        vm.isDadosContatoJuridicaFormSubmitted = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#tipoSeguroDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the Tipo Seguro Dropdown values
         **/
        vm.tipoSeguroDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#tipoEndossoDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the Tipo Endosso Dropdown values
         **/
        vm.tipoEndossoDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#tipoOrigemRenovacaoDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the Tipo Origem Renovacao Dropdown values
         **/
        vm.tipoOrigemRenovacaoDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#onusDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the Onus Dropdown values
         **/
        vm.onusDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#canalDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the Canal Dropdown values
         **/
        vm.canalDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#moedaDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the Moeda Dropdown values
         **/
        vm.moedaDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#tipoCalculoDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the Tipo Calculo Dropdown values
         **/
        vm.tipoCalculoDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#codigoOperacaoDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the codigo Operacao Dropdown values
         **/
        vm.codigoOperacaoDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#pagamentoProfissaoDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the pagamento Profissao Dropdown values
         **/
        vm.pagamentoProfissaoDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#pagamentoTipoIdentificacaoDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the pagamento Tipo Identificacao Dropdown values
         **/
        vm.pagamentoTipoIdentificacaoDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#pagamentoGrauParentescoDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the pagamento Grau Parentesco Dropdown values
         **/
        vm.pagamentoGrauParentescoDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#pagamentoTipoLogradouroDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the pagamento Tipo Logradouro Dropdown values
         **/
        vm.pagamentoTipoLogradouroDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#pagamentoTipoEmailDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the pagamento Tipo Email Dropdownn values
         **/
        vm.pagamentoTipoEmailDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#pagamentoTipoTelefoneDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the pagamento Tipo Telefone Dropdown values
         **/
        vm.pagamentoTipoTelefoneDropdown = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#tipoBemDropdown
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the Tipo Bem Dropdown values
         **/
        vm.tipoBemDropdown = []; //temporary

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#statusParcelas
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * This will hold the Status Parcela values
         **/
        vm.statusParcelas = [];

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#dataValidadeOpened
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if data Validade date picker is opened.
         **/
        vm.dataValidadeOpened = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isFisica
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if selected tipo Pessoa is Fisica
         **/
        vm.isFisica = true;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isFisicaModal
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if selected tipo Pessoa in modal is Fisica
         **/
        vm.isFisicaModal = true;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isFisicaContatoCoseg
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if selected tipo Pessoa in cossegurado is Fisica
         **/
        vm.isFisicaContatoCoseg = true;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isTelefone
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if selected tipo Contato is Telefone
         **/
        vm.isTelefone = null;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isFisicaBeneficiario
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if selected tipo Pessoa in Beneficiario is Fisica - initiated null
         **/
        vm.isFisicaBeneficiario = null;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isEspecificosFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if Quantidade bens, valor total do bens, nome and valor do bem are valid.
         **/
        vm.isEspecificosFormSubmitted = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isEspecificosFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if Quantidade bens, valor total do bens, nome and valor do bem are valid.
         **/
        vm.isBeneficiarioCPFCNPJFormSubmitted = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isEspecificosFormSubmitted
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if the person is politically exposed
         **/
        vm.isPoliticamenteExposta = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#dataEmissaoOpened
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * * Checks if data Emissao date picker is opened.
         **/
        vm.dataEmissaoOpened = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#dateOptions
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Stores the Global options format for the date.
         **/
        vm.dateOptions = {
            formatYear: Constants.DATE_YEAR_FORMAT,
            startingDay: 1
        };

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#cossegurado
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Stores the data on the cossegurado menu.
         **/
        vm.cossegurado = [];

        vm.isInvalid = isInvalid;
        vm.isInvalidLicitacao = isInvalidLicitacao;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#nomeFormaPagamento
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Stores the name of the selected Forma Pagamento.
         **/
        vm.nomeFormaPagamento = null;

        vm.quantidadeParcela = null;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#controladores
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Stores the data on the cossegurado menu.
         **/
        vm.controlador = [];

        vm.alerts = [];
        vm.flagHideTipoClassificacaoPessoa = true;

        /**Cartões**/
        vm.openModalSolicitacaoCartaoCredito = openModalSolicitacaoCartaoCredito;
        vm.openModalResgatePontos = openModalResgatePontos;
        vm.diasVencimento = [];
        vm.bancosConveniados = [];
        vm.cartoesPortoValidos = [];
        vm.tipoVinculoIntervenienteOptions = [];
        /**END CARTÕES**/

        vm.isADC = false;
        vm.isCartao = false;
        vm.isDemais = false;
        vm.isBoleto = false;

        vm.dataMelhorDataPrimeiraParcela = null;
        vm.recusada = false;
        vm.protocolada = false;
        vm.propostaInativa = false;

        /**
         * @ngdoc property
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#format
         * @propertyOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Stores the date format for the date picker.
         **/
        vm.format = Constants.DATE_FORMAT;

        vm.envioEmailCorretorDropdown = [];
        vm.envioEmailCorretorImobiliariaDropdown = [];
        vm.destEnFisSegViaDocumentoDropdown = [];
        vm.contatoPessoaExpostaDropDown = [];

        //Endereco dropdowns
        //Selecione o Endereço de Cobrança
        vm.enderecoDeCobrancaDropdown = [];

        //Selecione o Endereço de Correspondência
        vm.enderecoDeCorrespondenciaDropdown = [];

        vm.motivoAusenciaCpfOptions = [];
        vm.motivoAusenciaCnpjOptions = [];

        // Set as active page
        PageInfo.activePage = Pages.ORCAMENTO_PROPOSTA;
        //for side menu navigation
        PageInfo.activeUrl = 'operacoes.orcamento.main.proposta';
        //to control li active class
        vm.selectedIndex = SelectedOpts.activeObjetoIndex;
        //to control ul collapse class
        vm.selectedSubIndex = SelectedOpts.activeObjetoSubIndex;

        //methods exposed by the controller
        vm.salvarCorretagem = salvarCorretagem;

        vm.populateEnderecoEmpresarial = populateEnderecoEmpresarial;
        vm.populateEnderecoCobranca = populateEnderecoCobranca;
        vm.populateEnderecoCorrespondencia = populateEnderecoCorrespondencia;
        vm.displayNovoEndereco = displayNovoEndereco;
        vm.calcularParcela = calcularParcela;
        vm.salvarDocComplementares = salvarDocComplementares;
        vm.salvarDadosDoEndereco = salvarDadosDoEndereco;
        vm.solicitarCartao = solicitarCartao;
        vm.salvarDadosDoEnderecoJuridica = salvarDadosDoEnderecoJuridica;
        vm.salvarDadosDeContato = salvarDadosDeContato;
        vm.salvarDadosDeContatoJuridica = salvarDadosDeContatoJuridica;
        vm.checkDadosSeguradoMandatoryField = checkDadosSeguradoMandatoryField;
        vm.openDatePicker = openDatePicker;
        vm.changeTipoPessoa = changeTipoPessoa;
        vm.changeTipoPessoaModal = changeTipoPessoaModal;
        vm.changeContatoCosegTipoPessoa = changeContatoCosegTipoPessoa;
        vm.changeTipoContato = changeTipoContato;
        vm.changeTipoPessoaBene = changeTipoPessoaBene;
        vm.changeFisicaPessoaExposta = changeFisicaPessoaExposta;
        vm.changeDadosDeContatoPessoaExposta = changeDadosDeContatoPessoaExposta;
        vm.tipoEnderecoOptions = [];
        vm.salvarCobranca = salvarCobranca;
        vm.salvarCadastros = salvarCadastros;
        vm.changeEnderecoCobrancaContent = changeEnderecoCobrancaContent;
        vm.changeEnderecoCorrespondenciaContent = changeEnderecoCorrespondenciaContent;
        vm.openPagadorParcelaModal = openPagadorParcelaModal;
        vm.changePessoaExposta = changePessoaExposta;
        vm.getOferta = getOferta;
        vm.getOfertaDetails = getOfertaDetails;
        vm.showClausulaModal = showClausulaModal;
        vm.setBandeira = setBandeira;
        vm.listarClasseProfissionalProposta = listarClasseProfissionalProposta;

        //Exposed Corretagem Functions
        vm.populateCorretagem = populateCorretagem;
        vm.removeCorretagem = removeCorretagem;
        vm.changePercentualParticipacao = changePercentualParticipacao;
        vm.changeCodigoCorretor = changeCodigoCorretor;

        //Exposed Cossegurado Functions
        vm.populateCossegurado = populateCossegurado;
        vm.salvarCossegurado = salvarCossegurado;
        vm.changePossuiCossegurado = changePossuiCossegurado;
        vm.validacaoTrocaModalidadeProposta = validacaoTrocaModalidadeProposta;

        vm.changeValueExposicao = changeValueExposicao;
        vm.checkDropDownContatoPessoaExposta = checkDropDownContatoPessoaExposta;

        //Exposed Controlador Functions
        vm.populateControladores = populateControladores;
        vm.salvarControllador = salvarControllador;
        vm.openIntervenienteModal = openIntervenienteModal;
        vm.removeInterveniente = removeInterveniente;
        // vm.emitirProposta = emitirProposta;
        // vm.recusarProposta = recusarProposta;

        vm.saveEnderecoCobranca = saveEnderecoCobranca;
        vm.saveEnderecoCorrespondencia = saveEnderecoCorrespondencia;

        //date validation
        vm.dateValidation = dateValidation;
        vm.maskDate = maskDate;
        vm.clearWhenNotValidDate = clearWhenNotValidDate;
        vm.formatDate = formatDate;

        vm.maskCPF = maskCPF;
        vm.maskCPFwithinOneObject = maskCPFwithinOneObject;
        vm.maskCPFwithinTwoObject = maskCPFwithinTwoObject;
        vm.maskCPFwithinFourObject = maskCPFwithinFourObject;
        vm.maskCPFwithinFiveObject = maskCPFwithinFiveObject;
        vm.maskCNPJ = maskCNPJ;
        vm.maskCNPJwithinOneObject = maskCNPJwithinOneObject;
        vm.maskCNPJwithinTwoObject = maskCNPJwithinTwoObject;
        vm.maskCNPJwithinFourObject = maskCNPJwithinFourObject;
        vm.maskCNPJwithinFiveObject = maskCNPJwithinFiveObject;

        vm.isTxtPessoaExpostaCPFEmpty = false;
        vm.isNomePessoaExpostoEmpty = false;
        vm.isCodigoTipoVinculoEmpty = false;

        // Orcamento screen object from Orcamento screen
        vm.orcamento = OrcamentoFormFactory.getDefaultOrcamento();

        //pessoa methods
        vm.savePessoa = savePessoa;
        vm.setValuesToNull = setValuesToNull;
        vm.setToContatoPessoaSeguroForm = setToContatoPessoaSeguroForm;
        vm.setToDocumentoPessoaSeguroForm = setToDocumentoPessoaSeguroForm;
        vm.buscarCep = buscarCep;
        vm.setNumerico = setNumerico;
        vm.validarEndereco = validarEndereco;

        vm.setCorresNumerico = setCorresNumerico;

        //local risco methods
        vm.saveLocalRiscoCobrancaToProposta = saveLocalRiscoCobrancaToProposta;
        vm.saveLocalRiscoCorrespondenciaToProposta = saveLocalRiscoCorrespondenciaToProposta;
        vm.localRiscoList = [];

        vm.contatoPessoaSeguro = {};
        vm.documentoPessoaSeguro = {};
        vm.enderecoPessoaSeguro = {
            flagSemNumero: 'N'
        };
        vm.vinculoPessoaSeguro = {};
        vm.enderecoPessoaSeguroCorres = {
            flagSemNumero: 'N'
        };
        vm.isEnderecoCorresFormSubmitted = false;
        vm.isDropDownContatoPessoaExpostaEmpty = false;

        vm.logradouro = '';

        vm.selectedProdutoComercialName = null;
        vm.selectedOfertaName = null;
        vm.selectedParceiroNegocioName = null;

        vm.format = Constants.DATE_FORMAT;

        var itensListasValores = [];
        var corretorError = '';

        vm.tipoLogradouroOptions = [];

        //Start Beneficiario

        /* SM 761 - Parametrizador Tipo Bem */
        // vm.getCoberturasOfItemOrcamento = getCoberturasOfItemOrcamento;
        /* FIM - SM 761 - Parametrizador Tipo Bem */

        vm.addComponente = addComponente;
        vm.removeComponente = removeComponente;
        vm.objetoSeguradoDropdown = [];
        vm.beneficiarioCoberturas = [];
        vm.beneficiarioCoberturasCompletas = [];
        vm.getBeneficiario = getBeneficiario;
        vm.salvarBeneficiario = salvarBeneficiario;
        vm.deleteBeneficiario = deleteBeneficiario;
        vm.getBeneficiarioList = getBeneficiarioList;
        vm.isBeneficiarioInvalid = isBeneficiarioInvalid;
        vm.isEspecificaoInvalid = isEspecificaoInvalid;
        vm.isBeneficiarioCpfCnpjInvalid = isBeneficiarioCpfCnpjInvalid;
        vm.updateValorTotalDosBens = updateValorTotalDosBens;
        vm.updateValorTotalDosBensWithCheckedCobertura = updateValorTotalDosBensWithCheckedCobertura;
        //End Beneficiario
        vm.disableDocumento = disableDocumento;
        vm.isInvalidDate = isInvalidDate;

        vm.checkEmptyMandatoryField = checkEmptyMandatoryField;
        vm.openCosseguradoDeleteConfirmModal = openCosseguradoDeleteConfirmModal;

        vm.isNullEmptyOrUndefined = isNullEmptyOrUndefined;

        vm.replaceWithNumbers = replaceWithNumbers;

        vm.flagPermissaoMultiploSegurado = false;

        //Resgate de pontos
        vm.flagResgatePontos = false;


        // Validation for Pessoa Juridica
        vm.clearCodigoTipoLicitacao = clearCodigoTipoLicitacao;
        vm.flagLicitacaoStatus = flagLicitacaoStatus;
        vm.clearNumeroProcessoLicitacao = clearNumeroProcessoLicitacao;

        vm.populateQuantidadeParcela = populateQuantidadeParcela;
        vm.changeFormaPagamento = changeFormaPagamento;
        vm.changeQuantidadeParcela = changeQuantidadeParcela;

        vm.checkAndValidateNotAllContato = checkAndValidateNotAllContato;
        vm.checkAndValidateAllContato = checkAndValidateAllContato;
        // vm.convertPessoaForCreate = convertPessoaForCreate;
        vm.loadEnderecoCobranca = loadEnderecoCobranca;
        vm.loadEnderecoCorrespondencia = loadEnderecoCorrespondencia;
        vm.loadInformacoesFormaPagamento = loadInformacoesFormaPagamento;
        vm.getPessoa = getPessoa;

        vm.openModalAtividade = openModalAtividade;

        vm.validateContatoInput = validateContatoInput;

        //cartoes
        vm.buscarCartaoCredito = buscarCartaoCredito;
        vm.incluirCartaoCredito = incluirCartaoCredito;

        vm.validateCodigoTipoClassificacaoPessoa = validateCodigoTipoClassificacaoPessoa;

        // INICO - SM159
        vm.getByCpfCnpj = getByCpfCnpj;

        vm.criaPessoa = false;
        vm.atualizaPessoa = false;
        // FIM - SM159

        vm.cartaoPortoSolicitado = false;
        vm.faixaResgateList = [];

        activate();

        function disableDocumento() {
            if (vm.proposta.dadosPessoaSegurado &&
                vm.proposta.dadosPessoaSegurado.pessoaFisica &&
                vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoNacionalidade == 2) {
                // NOTE RNR
                vm.isEstrangeiro = true;
                vm.documentoPessoaSeguro.codigoTipoDocumentoPessoa = 5;
            } else {
                vm.documentoPessoaSeguro.codigoTipoDocumentoPessoa = null;
                vm.isEstrangeiro = false;
            }
        }


        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#activate
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called when the `Controller` is instantiated.
         *
         */
        function activate() {

            /*
             * Retrieve the selected proposta from the previous state
             */
            vm.proposta = SelectedOpts.proposta;

            var pessoaTipo = null;
            if (vm.proposta.dadosPessoaSegurado) {
                pessoaTipo = vm.proposta.dadosPessoaSegurado.codigoTipoPessoa;
            }
            vm.CPFCNPJ = 'CPF';
            // NOTE Fix for 706
            if (pessoaTipo == Constants.CODIGO_TIPO_PESSOA.FISICA) { // == 1
                vm.CPFCNPJ = 'CPF';
            } else if (pessoaTipo == Constants.CODIGO_TIPO_PESSOA.JURIDICA) { // == 2
                vm.CPFCNPJ = 'CNPJ';
            }
            if (vm.proposta.dataProtocolo) {
                vm.protocolada = true;
            }
            if (vm.proposta.codigoStatusProposta === Constants.STATUS_VERSAO_PROP_INATIVA) {
                vm.propostaInativa = true;
            }
            if (angular.isDefined(vm.proposta.numeroProposta)) {
                vm.proposta.codigoFormaPagamento = null;
                vm.proposta.quantidadeParcela = null;
                //this field is always set to N
                vm.proposta.flagPrimeiraCompraCartaoEmpresa = 'N';
                vm.nomeFormaPagamento = null;
                vm.quantidadeParcela = null;

                /*
                 * Codigo Empresa Value; Will be used for Populating dropdowns
                 */
                codigoEmpresa = vm.proposta.codigoEmpresa;

                /*
                 * Loads all the Dominios in the Proposta Form Screen
                 */
                getDominioService();

                getMotivoAusenciaCpfCnpj();

                getOfertaDetails();

                getParceiroNegocioDetails(vm.proposta.codigoParceiroNegocio, vm.proposta.numeroVersaoParceiroNegocio);

                getDadosCartao();


                /*
                 * Load values for Dados De Seguro Read-Only fields
                 */
                vm.dadosSeguro = OrcamentoPropostaFactory.convertDadosDoSeguro(vm.proposta.orcamento);
                if (SelectedOpts.selectedCorretor) {
                    vm.dadosSeguro.nomeCorretor = SelectedOpts.selectedCorretor.nomeSusepCorretor;
                }
                // CorretoresService.getCorretorById(vm.dadosSeguro.susepCorretor)
                //     .then(
                //         function(response) {
                //             if (response.data !== null) {
                //                 var listaCorretores = response.data.listaCorretores;
                //                 vm.dadosSeguro.nomeCorretor = listaCorretores.corretor[0].nome;
                //             }
                //     });
                $scope.$on('trocaModalidade', function(event) {
                    validacaoTrocaModalidadeProposta();
                });

                //populateLocalRiscoOptions();

                populateQuestionario();
                getQuestionarioList();
                //populateDescontos();
                populateClausulas();

                populateDadosSeguro();
                populateCriticas();
                //populateEndereco();

                populateCossegurado();
                populateControladores();

                populateCorretagem();

                //populuateFormaPagamentoDropdown();

                getPagamentoCalcularParcela();
                vm.pagamentoFormaDropdown = OrcamentoPropostaFactory.convertPagamentoForma(vm.proposta.formasPagamento.formaPagamento);

                // NOTE Decrepted
                populateDados();

                populateBeneficiario(true);

                //getOferta();

                /*
                 * Assign the submission object.
                 * Automatically updates object thru pass-by-reference saving
                 */
                PageInfo.submissionObject = vm.proposta;

                SelectedOpts.isEditPropostaMode = true;

                if (vm.proposta.codigoStatusProposta == 8) {
                    vm.recusada = true;
                } else if (SelectedOpts.proposta.codigoStatusProposta == 6) {
                    var _params = {
                        "filtroNomeResumidoParametroSistema": Constants.EMISSAO_SEM_BOLETO,
                        "skip": 0,
                        "top": 1
                    };
                    ParametroConfigService.getParametrosConfiguracoesLista(_params).success(function(data) {
                        if (data && data.length > 0) {
                            $scope.orcamentoCtrl.parametroConfiguracao = data[0];
                            if ($scope.orcamentoCtrl.parametroConfiguracao && $scope.orcamentoCtrl.parametroConfiguracao.textoConteudoParametro === 'S') {
                                $scope.orcamentoCtrl.isEmitada = false;
                            }
                        }
                    });
                }

                //GET date of Birth from Orcamento else retain pessoa date of birth
                if (vm.proposta.orcamento.dataNascimentoPessoaSegurado) {
                    if (vm.proposta.dadosPessoaSegurado && vm.proposta.dadosPessoaSegurado.pessoaFisica) {
                        if (!vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento) {
                            vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento = vm.proposta.orcamento.dataNascimentoPessoaSegurado;
                        }
                        if (vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento &&
                            angular.isDate(vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento)) {
                            vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento = $filter('date')(vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento, 'dd/MM/yyyy');
                        }
                    }
                } else if (vm.proposta.orcamento.dataNascimentoPessoaProponente) {
                    if (vm.proposta.dadosPessoaSegurado && vm.proposta.dadosPessoaSegurado.pessoaFisica) {
                        if (!vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento) {
                            vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento = vm.proposta.orcamento.dataNascimentoPessoaProponente;
                        }
                        if (vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento &&
                            angular.isDate(vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento)) {
                            vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento = $filter('date')(vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento, 'dd/MM/yyyy');
                        }
                    }
                }

                if (!vm.proposta.enderecoCobranca.flagEnderecoCobranca) {
                    vm.proposta.enderecoCobranca.flagEnderecoCobranca = 2;
                }

                if (!vm.proposta.enderecoCorrespondencia.flagEnderecoCorrespondencia) {
                    vm.proposta.enderecoCorrespondencia.flagEnderecoCorrespondencia = 2;
                }

                listarClasseProfissionalProposta();
                changeFisicaPessoaExposta();

                loadFaixasResgate();
            }
            // SM 1084
            OrcamentoUtilityFactory.recarregarCoCorretores($scope, vm.proposta, populateCorretagem);
        }

        function chunk(arr, size) {
            // Break it up.
            var tempArray = new Array();
            for (var i = 0, j = arr.length; i < j; i += size) {
                tempArray.push(arr.slice(i, i + size));
                // do whatever
            }
            return tempArray;
        }

        function loadFaixasResgate() {
            var params = {
                'numeroOrcamento': vm.proposta.numeroOrcamento,
                'numeroVersaoOrcamento': vm.proposta.numeroVersaoOrcamento
            };

            FaixaResgateOrcamentoService.getFaixaResgateList(params)
                .then(function(result) {
                    if (result.data) {
                        vm.faixaResgateList = chunk(result.data.faixaResgatePonto, 5);
                    }
                    habilitarFinalizacaoProposta();
                }, function(error) {
                    habilitarFinalizacaoProposta();
                });
        }

        function habilitarFinalizacaoProposta() {
            if (vm.proposta.codigoStatusProposta == 1 && vm.proposta.numeroVersaoProposta > 1 &&
                (!vm.proposta.flagBloqueioEdicaoCorretor || vm.proposta.flagBloqueioEdicaoCorretor == 'N') &&
                !checkEmptyMandatoryField()) {
                $scope.orcamentoCtrl.savedProposta = true;
            }
        }

        /* SM 761 - Parametrizador Tipo Bem */

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#getOferta
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to get oferta
         *
         **/
        function getOferta(codigoTipoBem, isNotFromHtml, isCarregar) {
            var orcamento = vm.proposta.orcamento;

            if (!codigoTipoBem || isCarregar) {
                vm.beneficiarioCoberturasAux = [];
                CanonicoService.buscarOferta(orcamento.codigoOferta, orcamento.numeroVersaoOferta, orcamento.numeroSequenciaVersaoOferta).then(
                    function(response) {
                        if (response.data && response.data.oferta && response.data.oferta.coberturas && response.data.oferta.coberturas.coberturaOferta) {
                            var oferta = CanonicoFactory.convertOferta(response.data);
                            var beneficiarioCoberturas = OrcamentoPropostaFactory.constructBeneficiarioCoberturaList(oferta.coberturas, coberturaOfertaList);
                            var ofertaCoberturas = oferta.coberturas;
                            if (isNotFromHtml) {
                                beneficiarioCoberturas = OrcamentoPropostaFactory.constructBeneficiarioCoberturaListChecked(beneficiarioCoberturas, vm.beneficiario.coberturas);
                            }

                            var itemSelecionado = vm.proposta.orcamento.itemDocumentoEmissaoEBO.filter(function(item) {
                                return item.numeroItemVersaoOrcamento == vm.beneficiario.numeroItemVersaoProposta;
                            });

                            if (itemSelecionado && itemSelecionado.length > 0) {
                                itemSelecionado = itemSelecionado[0].coberturasItem.listaCoberturasItem.coberturaItemDocumento;

                                var coberturaAux = beneficiarioCoberturas.filter(function(aux) {
                                    var listaContratada = itemSelecionado.filter(function(item) {
                                        if (item.codigoCobertura === aux.codigoCobertura) {
                                            aux.valorLimiteMaximoIndenizacao = item.valorLimiteMaximoIndenizacao;
                                        }
                                        return item.codigoCobertura === aux.codigoCobertura;
                                    });

                                    return listaContratada.length > 0;
                                });

                                vm.beneficiarioCoberturasAux = coberturaAux.filter(function(cobertura) {
                                    if (cobertura.listaTipoBemBeneficiario && cobertura.listaTipoBemBeneficiario.tipoBemBeneficiario) {
                                        var listaTipoBem = cobertura.listaTipoBemBeneficiario.tipoBemBeneficiario.filter(function(tipo) {
                                            return angular.isDefined(tipo.codigoTipoBem);
                                        });

                                        return listaTipoBem.length > 0;
                                    } else {
                                        return false;
                                    }
                                });

                                vm.beneficiarioCoberturasCompletas = ofertaCoberturas.filter(function(item) {
                                    return vm.beneficiarioCoberturas.filter(function(beneficiario) {
                                        return beneficiario.codigoCobertura === item.codigoCobertura;
                                    });
                                });

                                // if (vm.beneficiarioCoberturasCompletas.length > 0) {
                                //     cobertura.nomeCobertura = vm.beneficiarioCoberturasCompletas[0].nomeCobertura;
                                // }

                                if (vm.beneficiarioCoberturasAux && vm.beneficiarioCoberturasAux.length > 0) {
                                    var listaAux = [];

                                    angular.forEach(vm.beneficiarioCoberturasAux, function(itemCobertura) {
                                        if (itemCobertura.listaTipoBemBeneficiario && itemCobertura.listaTipoBemBeneficiario.tipoBemBeneficiario) {
                                            itemCobertura.listaTipoBemBeneficiario.tipoBemBeneficiario.forEach(function(tipo) {
                                                listaAux.push({
                                                    codigoTipoBem: tipo.codigoTipoBem
                                                });
                                            });
                                        }
                                    });

                                    if (listaAux && listaAux.length > 0) {
                                        var listaTipo = [];
                                        angular.forEach(listaAux, function(item) {
                                            if (listaTipo.length == 0) {
                                                listaTipo = vm.tipoBemDropdown.filter(function(tipobem) {
                                                    return tipobem.codigo == item.codigoTipoBem;
                                                });
                                            } else {
                                                var aux = listaTipo.filter(function(tipobem) {
                                                    return tipobem.codigo == item.codigoTipoBem;
                                                });
                                                if (!aux || !aux.length) {
                                                    listaTipo.push(vm.tipoBemDropdown.filter(function(tipobem) {
                                                        return tipobem.codigo == item.codigoTipoBem;
                                                    })[0]);
                                                }
                                            }
                                        });
                                        vm.tipoBemDropdown = listaTipo;

                                        vm.enableTipoBem = true;
                                    } else {
                                        vm.enableTipoBem = true;
                                    }

                                    if (isCarregar) {
                                        vm.beneficiarioCoberturas = vm.beneficiarioCoberturasAux.filter(function(cobertura) {
                                            if (cobertura.listaTipoBemBeneficiario && cobertura.listaTipoBemBeneficiario.tipoBemBeneficiario) {
                                                var listaTipoBem = cobertura.listaTipoBemBeneficiario.tipoBemBeneficiario.filter(function(tipo) {
                                                    return tipo.codigoTipoBem === codigoTipoBem;
                                                });

                                                return listaTipoBem.length > 0;
                                            } else {
                                                return false;
                                            }
                                        });
                                    }

                                } else {
                                    vm.tipoBemDropdown = [];
                                }
                            }
                        }
                    },
                    function(error) {
                        displayError(error);
                    }
                );
            } else if (vm.beneficiarioCoberturasAux && vm.beneficiarioCoberturasAux.length > 0) {

                vm.beneficiarioCoberturas = vm.beneficiarioCoberturasAux.filter(function(cobertura) {
                    if (cobertura.listaTipoBemBeneficiario && cobertura.listaTipoBemBeneficiario.tipoBemBeneficiario) {
                        var listaTipoBem = cobertura.listaTipoBemBeneficiario.tipoBemBeneficiario.filter(function(tipo) {
                            return tipo.codigoTipoBem === codigoTipoBem;
                        });

                        return listaTipoBem.length > 0;
                    } else {
                        return false;
                    }
                });
            }
        }
        /* FIM - SM 761 - Parametrizador Tipo Bem */

        function getDadosCartao() {
            if (vm.proposta.cartoes &&
                vm.proposta.cartoes.codigoIdentificacaoCartao) {

                buscarCartaoCredito(vm.proposta.cartoes.codigoIdentificacaoCartao);

            } else if (vm.proposta.pagadores &&
                vm.proposta.pagadores.pagador &&
                vm.proposta.pagadores.pagador.length > 0) {

                if (vm.proposta.pagadores.pagador[0].pagadoresParcela &&
                    vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela &&
                    vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela.length > 0) {

                    vm.proposta.cartoes = {
                        "codigoIdentificacaoCartao": vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoIdentificacaoCartao
                    };

                    if (vm.proposta.cartoes.codigoIdentificacaoCartao) {
                        buscarCartaoCredito(vm.proposta.cartoes.codigoIdentificacaoCartao);
                    } else {
                        vm.proposta.cartoes = {};
                    }
                }

            } else {
                vm.proposta.cartoes = {};
            }
        }

        function populateDadosPessoaSeguroNome() {

            if (vm.proposta.dadosPessoaSegurado &&
                vm.proposta.dadosPessoaSegurado.documentos &&
                angular.isArray(vm.proposta.dadosPessoaSegurado.documentos) &&
                vm.proposta.dadosPessoaSegurado.documentos.length > 0) {
                vm.proposta.dadosPessoaSegurado.documentos =
                    PessoaFactory.convertDocumentoPessoaSeguros(vm.proposta.dadosPessoaSegurado.documentos,
                        vm.tipoDocumentoPessoaOptions, vm.unidadeFederacaoOptions);
            } else {
                vm.proposta.dadosPessoaSegurado.documentos = [];
            }

            if (vm.proposta.dadosPessoaSegurado &&
                vm.proposta.dadosPessoaSegurado.contatos &&
                angular.isArray(vm.proposta.dadosPessoaSegurado.contatos) &&
                vm.proposta.dadosPessoaSegurado.contatos.length > 0) {
                vm.proposta.dadosPessoaSegurado.contatos =
                    PessoaFactory.convertContatoPessoaSeguros(vm.proposta.dadosPessoaSegurado.contatos,
                        vm.tipoContatoOptions);
            } else {
                vm.proposta.dadosPessoaSegurado.contatos = [];
            }

            if (vm.proposta.dadosPessoaSegurado &&
                vm.proposta.dadosPessoaSegurado.enderecosPessoa &&
                angular.isArray(vm.proposta.dadosPessoaSegurado.enderecosPessoa) &&
                vm.proposta.dadosPessoaSegurado.enderecosPessoa.length > 0) {
                vm.proposta.dadosPessoaSegurado.enderecosPessoa =
                    PessoaFactory.convertEnderecoPessoaSeguros(vm.proposta.dadosPessoaSegurado.enderecosPessoa,
                        vm.tipoEnderecoOptions, vm.tipoLogradouroOptions);
            } else {
                vm.proposta.dadosPessoaSegurado.enderecosPessoa = [];
            }

            if (vm.proposta.codigoTipoClassificacaoPessoa ||
                vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoOcupacao) {
                validateCodigoTipoClassificacaoPessoa();
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#populateLocalRiscoOptions
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method to populate the Local Risco Dropdown.
         *
         **/
        /*function populateLocalRiscoOptions() {

            var numeroOrcamento = vm.proposta.orcamento.numeroOrcamento;
            var numeroVersaoOrcamento = vm.proposta.orcamento.numeroVersaoOrcamento;

            OrcamentoService.getItemOrcamentoList(0, 0, null, numeroOrcamento, numeroVersaoOrcamento).then(function(response) {
                var localRiscoObject = OrcamentoPropostaFactory.constructLocalRiscoList(response.data.itemDocumentoEmissao, vm.tipoLogradouroOptions);
                vm.localRiscoMap = localRiscoObject.localRiscoMap;
                vm.localRiscoList = localRiscoObject.localRiscoList;
            }, function(error) {
                displayError(error);
                vm.localRiscoMap = {};
                vm.localRiscoList = [];
            });
        }*/

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#getDominioService
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method to get all values for Dominio.
         *
         **/
        function getDominioService() {
            /*jshint sub:true*/
            blockUI.start();
            DominiosService.getDominio(Dominios['TIPO_PESSOA'].codigo,
                Dominios['TIPO_PESSOA'].cache, codigoEmpresa).then(

                function(tipoPessoa) {
                    vm.tipoPessoaOptions = OrcamentoFormFactory.constructDominiosList(tipoPessoa);
                    blockUI.stop();
                },
                function(error) {
                    displayError(error);
                    blockUI.stop();
                });

            blockUI.start();
            DominiosService.getDominio(Dominios['ESTADO_CIVIL'].codigo,
                Dominios['ESTADO_CIVIL'].cache, codigoEmpresa).then(

                function(estadoCivil) {
                    vm.estadoCivilOptions = OrcamentoFormFactory.constructDominiosList(estadoCivil);
                    blockUI.stop();
                },
                function(error) {
                    displayError(error);
                    blockUI.stop();
                });

            blockUI.start();
            DominiosService.getDominio(Dominios['TIPO_ENDERECO'].codigo,
                Dominios['TIPO_ENDERECO'].cache, codigoEmpresa).then(

                function(tipoEndereco) {
                    vm.tipoEnderecoOptions = OrcamentoPropostaFactory.convertDominioList(tipoEndereco);
                    blockUI.stop();
                },
                function(error) {
                    displayError(error);
                    blockUI.stop();
                });

            blockUI.start();
            DominiosService.getDominio(Dominios['BANCO'].codigo,
                Dominios['BANCO'].cache, codigoEmpresa).then(

                function(banco) {
                    vm.bancoOptions = OrcamentoPropostaFactory.convertBanco(banco);
                    blockUI.stop();
                },
                function(error) {
                    displayError(error);
                    blockUI.stop();
                });
            blockUI.start();
            DominiosService.getDominio(Dominios['OCUPACAO'].codigo, Dominios['OCUPACAO'].cache)
                .then(

                    function(profissao) {
                        vm.pagamentoProfissaoDropdown = OrcamentoPropostaFactory.convertProfissao(profissao);
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });

            blockUI.start();
            DominiosService.getDominio(Dominios['SEXO_PESSOA'].codigo, Dominios['SEXO_PESSOA'].cache)
                .then(

                    function(sexos) {
                        vm.sexoOptions = OrcamentoPropostaFactory.convertSexo(sexos);
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['TIPO_LOGRADOURO'].codigo, Dominios['TIPO_LOGRADOURO'].cache)
                .then(

                    function(tipoLograduoro) {
                        vm.tipoLogradouroOptions = OrcamentoFormFactory.constructDominiosList(tipoLograduoro);
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['ATIVIDADE_ECONOMICA'].codigo, Dominios['ATIVIDADE_ECONOMICA'].cache)
                .then(

                    function(response) {
                        vm.atividadeEconomicaOptions = OrcamentoFormFactory.constructDominiosList(response);

                        if (vm.proposta.dadosPessoaSegurado.pessoaJuridica) {
                            var objetoAtividadeEconomica = vm.atividadeEconomicaOptions.filter(function(item) {
                                return item.codigoValorDominio == vm.proposta.dadosPessoaSegurado.pessoaJuridica.codigoAtividadeEconomica;
                            })[0];

                            vm.proposta.dadosPessoaSegurado.pessoaJuridica.nomeAtividadeEconomica = objetoAtividadeEconomica ? objetoAtividadeEconomica.nomeDominio : "";
                            blockUI.stop();
                        }
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['NACIONALIDADE'].codigo, Dominios['NACIONALIDADE'].cache)
                .then(

                    function(response) {
                        vm.nacionalidadeOptions = OrcamentoFormFactory.constructDominiosList(response);

                        //SM 599
                        angular.forEach(vm.nacionalidadeOptions, function(nacionalidade) {

                            if (nacionalidade.nomeDominio.indexOf("BRASILEIRO") > -1) {
                                if (!vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoNacionalidade ||
                                    vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoNacionalidade === '') {
                                    vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoNacionalidade = nacionalidade.codigoValorDominio;
                                }
                            }
                        });
                        blockUI.stop();
                        //FIM SM 599

                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });

            blockUI.start();
            DominiosService.getDominio(Dominios['TIPO_EXPOSICAO_PESSOA'].codigo, Dominios['TIPO_EXPOSICAO_PESSOA'].cache)
                .then(

                    function(response) {
                        vm.tipoExposicaoPessoa = OrcamentoFormFactory.constructDominiosList(response);
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });

            blockUI.start();      
            DominiosService.getDominio(Dominios['TIPO_VINCULO'].codigo, Dominios['TIPO_VINCULO'].cache)
                .then(

                    function(response) {
                        vm.tipoVinculoOptions = OrcamentoFormFactory.constructDominiosList(response);
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['TIPO_VINCULO_INTERVENIENTE'].codigo, Dominios['TIPO_VINCULO_INTERVENIENTE'].cache)
                .then(

                    function(response) {
                        vm.tipoVinculoIntervenienteOptions = OrcamentoFormFactory.constructDominiosList(response);
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['TIPO_EXPOSICAO_PESSOA'].codigo, Dominios['TIPO_EXPOSICAO_PESSOA'].cache)
                .then(

                    function(response) {
                        vm.tipoExposicaoPessoa = OrcamentoFormFactory.constructDominiosList(response);
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });

            blockUI.start();
            DominiosService.getDominio(Dominios['PAIS'].codigo, Dominios['PAIS'].cache)
                .then(

                    function(response) {
                        vm.paisResidenteOptions = OrcamentoFormFactory.constructDominiosList(response);

                        //SM 599
                        angular.forEach(vm.paisResidenteOptions, function(pais) {

                            if (pais.nomeDominio.indexOf("BRASIL") > -1) {
                                if (!vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoPais ||
                                    vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoPais === '') {
                                    vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoPais = pais.codigoValorDominio;
                                }
                            }
                        });
                        blockUI.stop();
                        //FIM SM 599
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['UNIDADE_FEDERACAO'].codigo,
                    Dominios['UNIDADE_FEDERACAO'].cache)
                .then(

                    function(response) {
                        vm.unidadeFederacaoOptions = response;
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['TIPO_CONTATO'].codigo,
                    Dominios['TIPO_CONTATO'].cache)
                .then(

                    function(response) {
                        vm.tipoContatoOptions = OrcamentoFormFactory.constructDominiosList(response);
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['ORIGEM_RENOVACAO'].codigo,
                    Dominios['ORIGEM_RENOVACAO'].cache, codigoEmpresa)
                .then(function(response) {
                        vm.origemRenovacaos = OrcamentoFormFactory.constructDominiosList(response);
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['NATUREZA_JURIDICA'].codigo,
                    Dominios['NATUREZA_JURIDICA'].cache)
                .then(

                    function(response) {
                        vm.naturezaJuridicaOptions = OrcamentoFormFactory.constructDominiosList(response);
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['ORIGEM_RENOVACAO'].codigo,
                    Dominios['ORIGEM_RENOVACAO'].cache, codigoEmpresa)
                .then(function(response) {
                        vm.origemRenovacaos = OrcamentoFormFactory.constructDominiosList(response);
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['TIPO_LICITACAO'].codigo,
                    Dominios['TIPO_LICITACAO'].cache, codigoEmpresa)
                .then(function(response) {
                        vm.tipoLicitacaoList = OrcamentoFormFactory.constructDominiosList(response);
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            var selectFaixaRenda = 'codigoFaixaRenda,nomeFaixaRenda,nomeAbreviadoFaixaCapital';
            blockUI.start();
            FaixaRendaService.getFaixaRendas(0, selectFaixaRenda, null, null, null).then(

                function(response) {
                    vm.faixaRendaOptions = OrcamentoPropostaFactory.convertFaixaRendaList(response.data);
                    blockUI.stop();
                },
                function(error) {
                    displayError(error);
                    blockUI.stop();
                });
            var selectFaixaCapital = 'codigoFaixaCapital,nomeFaixaCapital,nomeAbreviadoFaixaCapital';
            blockUI.start();
            FaixaCapitalService.getFaixaCapitals(0, selectFaixaCapital, null, null, null).then(

                function(response) {
                    vm.faixaCapitalOptions = PessoaFactory.convertFaixaCapitalList(response.data);
                    blockUI.stop();
                },
                function(error) {
                    displayError(error);
                    blockUI.stop();
                });
            blockUI.start();
            DominiosService.getDominio(Dominios['TIPO_INTERVENIENTE'].codigo,
                    Dominios['TIPO_INTERVENIENTE'].cache, codigoEmpresa)
                .then(function(response) {
                        //Filter interveniente
                        vm.tipoIntervenienteDropdown = OrcamentoPropostaFactory.convertTipoInterveniente(response);
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            var selectTipoDocumento = "codigoTipoDocumentoPessoa,nomeTipoDocumentoPessoa,nomeAbreviadoTipoDocumentoPessoa,codigoTipoPessoa";
            blockUI.start();
            TipoDocumentoPessoaService.getTipoDocumentoPessoas(0, null, null, null, null, selectTipoDocumento).then(

                function(response) {
                    vm.tipoDocumentoPessoaOptions = PessoaFactory.convertTipoDocumentoPessoaList(response.data);
                    populateDadosPessoaSeguroNome();
                    blockUI.stop();
                },

                function(error) {
                    displayError(error);
                    blockUI.stop();
                });
            blockUI.start();
            DominiosService.getDominio(Dominios['TIPO_PESSOA'].codigo, Dominios['TIPO_PESSOA'].cache)
                .then(function(response) {
                        vm.tipoPessoaDropdown = response;
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['STATUS_PARCELA'].codigo,
                    Dominios['STATUS_PARCELA'].cache, codigoEmpresa)
                .then(function(response) {
                        vm.statusParcelas = response;
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['BANDEIRA_CARTAO'].codigo,
                    Dominios['BANDEIRA_CARTAO'].cache, codigoEmpresa)
                .then(function(response) {
                        vm.pagamentoBandeiraDropdown = response;
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });

        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#setToDocumentoPessoaSeguroForm
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * This method will set the selected dados de contato row in the form
         *
         * @params {Integer} index The selected row to be updated.
         *
         **/
        function setToDocumentoPessoaSeguroForm(index) {

            vm.documentoPessoaSeguro = PessoaFactory.setToDocumentoPessoaSeguroForm(vm.proposta.dadosPessoaSegurado.documentos[index], vm.unidadeFederacaoOptions);
            vm.documentoPessoaSeguro.codigoUnidadeFederacao = parseInt(vm.documentoPessoaSeguro.codigoUnidadeFederacao);
        }

        //---------------------------------------------QUESTIONARIO-----------------------------------------------//

        function getQuestionarioList() {
            blockUI.start();
            CanonicoService.listarQuestionariosProdutoComercialOferta(0, 0,
                    vm.proposta.codigoEmpresa,
                    vm.proposta.codigoRamo,
                    vm.proposta.codigoModalidade,
                    vm.proposta.codigoGrupoComercial,
                    vm.proposta.numeroVersaoProdutoComercial,
                    vm.proposta.numeroSequenciaVersaoProdutoComercial,
                    Constants.CODIGO_TIPO_QUESTIONARIO.PRODUTO_COMERCIAL,
                    vm.proposta.orcamento.codigoOferta,
                    vm.proposta.orcamento.numeroVersaoOferta,
                    vm.proposta.orcamento.numeroSequenciaVersaoOferta)
                .then(

                    function(response) {
                        var produtoQuestionarioList = CanonicoFactory.convertQuestionarioList(response.data);

                        if (vm.proposta.orcamento.respostaQuestionario && vm.proposta.orcamento.respostaQuestionario.length > 0) {
                            angular.forEach(vm.proposta.orcamento.respostaQuestionario, function(item) {
                                var questionario = $filter('filter')(produtoQuestionarioList, {
                                    codigoQuestionario: item.codigoQuestionario
                                }, true)[0];
                                if (questionario && angular.isObject(questionario)) {
                                    orcamentoQuestionarioList.push(questionario);
                                }
                            });
                            populateQuestionario();
                        }
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
        }

        function getQuestionario(codigoQuestionario) {
            var questionario = $filter('filter')(orcamentoQuestionarioList, {
                codigoQuestionario: codigoQuestionario
            }, true)[0];

            return questionario;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#populateQuestionario
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to populate questionarion form
         *
         **/
        function populateQuestionario() {
            var ctr = 0;

            angular.forEach(vm.proposta.orcamento.respostaQuestionario, function(respostaQuestionario) {
                var questionario = getQuestionario(respostaQuestionario.codigoQuestionario);
                if (angular.isObject(questionario)) {
                    angular.forEach(questionario.questoes, function(questaoQuestionario) {
                        if (questaoQuestionario.codigoQuestao === respostaQuestionario.codigoQuestao) {
                            var questaoObject = OrcamentoPropostaFactory.convertQuestionario(questaoQuestionario, respostaQuestionario);

                            switch (questaoObject.codigoTipoQuestao) {
                                case Constants.CODIGO_TIPO_QUESTAO.LISTA_DE_VALORES:
                                    getItensListaValoresOptions(questaoObject);
                                    break;
                                case Constants.CODIGO_TIPO_QUESTAO.MULTIPLA_ESCOLHA:
                                    getItensListaValoresOptions(questaoObject);
                                    break;
                                case Constants.CODIGO_TIPO_QUESTAO.RELACAO_DE_ITENS:
                                    blockUI.start();
                                    CanonicoService.buscarListaItens(questaoObject.codigoListaItem).then(function(response) {
                                        var listaItem = CanonicoFactory.convertListaItemQuestao(response.data);
                                        questaoObject.listaItem = OrcamentoFormFactory.constructRelacaoListaItem(listaItem);

                                        angular.forEach(questaoObject.listaItem.componentesListaItemQuestaoTypes, function(item) {
                                            if (item.codigoTipoQuestao ===
                                                Constants.CODIGO_TIPO_QUESTAO.LISTA_DE_VALORES) {
                                                getItensListaValoresOptions(item);
                                            }
                                        });
                                        blockUI.stop();
                                    },
                                    function(error) {
                                        displayError(error);
                                        blockUI.stop();
                                    });
                                    break;
                                case Constants.CODIGO_TIPO_QUESTAO.PERIODO:
                                    var periodo = OrcamentoFormFactory.constructQuestaoPeriodo(questaoObject, 1);
                                    questaoObject.periodo.push(periodo);
                                    periodo = OrcamentoFormFactory.constructQuestaoPeriodo(questaoObject, 2);
                                    questaoObject.periodo.push(periodo);
                                    break;
                                default:
                                    break;
                            }

                            vm.questaoList.push(questaoObject);
                            vm.questaoList = $filter('orderBy')(vm.questaoList, ['codigoQuestionario', 'numeroOrdemExibicao']);

                            var relacaoQuestaoList = $filter('filter')(vm.questaoList, {
                                codigoTipoQuestao: Constants.CODIGO_TIPO_QUESTAO.RELACAO_DE_ITENS
                            }, true);

                            ctr++;
                            // TODO - codigo bugfix --> if (ctr === vm.proposta.orcamento.respostasQuestionario.respostaQuestionario.length) {
                            if (ctr === vm.proposta.orcamento.respostaQuestionario.length) {
                                angular.forEach(relacaoQuestaoList, function(relacaoQuestao) {
                                    setRelacaoTable(relacaoQuestao);
                                });
                            }
                        }
                    });
                }
            });
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#getItensListaValoresOptions
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Private method to get the ListaValores options to display in dropdown
         * for LISTA_DE_VALORES type of Questao.
         *
         * @param {Object} item The ComponenteListaItem or Questao with type of LISTA_DE_VALORES
         * to set values of ItensListaValores dropdown options.
         **/
        function getItensListaValoresOptions(item) {
            var options = $filter('filter')(itensListasValores, {
                codigoListaValor: item.codigoListaValor
            }, true)[0];
            if (angular.isUndefined(options)) {
                // Get the ListaValor options for specific codigoListaValor
                // and store to local variable if not yet saved.
                blockUI.start();
                CanonicoService.buscarListaValores(item.codigoListaValor)
                    .then(

                        function(response) {
                            options = CanonicoFactory.convertListaValorQuestao(response.data);
                            options = OrcamentoFormFactory.constructListaValor(options);
                            item.listaValor = {};
                            item.listaValor.codigoListaValor = item.codigoListaValor;
                            item.listaValor.itensListasValores = options;
                            blockUI.stop();
                        },
                        function(error) {
                            displayError(error);
                            blockUI.stop();
                        });
            } else {
                // Fetch the saved data.
                item.listaValor = options;
            }
        }

        function setRelacaoTable(questaoDetail) {
            CanonicoService.buscarListaItens(questaoDetail.codigoListaItem).then(function(response) {
                var listaItem = CanonicoFactory.convertListaItemQuestao(response.data);
                questaoDetail.listaItem = OrcamentoFormFactory.constructRelacaoListaItem(listaItem);

                if (questaoDetail.listaItem.componentesListaItemQuestaoTypes.length === 0) {
                    return;
                }
                angular.forEach(questaoDetail.listaItem.componentesListaItemQuestaoTypes, function(item) {
                    if (item.codigoTipoQuestao ===
                        Constants.CODIGO_TIPO_QUESTAO.LISTA_DE_VALORES) {
                        getItensListaValoresOptions(item);
                    }
                });

                var respostaListaQuestionario = questaoDetail.respostaListaQuestionario;
                if (respostaListaQuestionario.length > 0) {
                    respostaListaQuestionario = $filter('orderBy')(
                        respostaListaQuestionario, 'codigoItem');
                    var rowCount = respostaListaQuestionario[
                        respostaListaQuestionario.length - 1].codigoItem;

                    for (var i = 1; i <= rowCount; i++) {
                        var listaComponenteColumn = [];
                        angular.forEach(questaoDetail.listaItem.componentesListaItemQuestaoTypes, function(item) {
                            var defaultRespostaListaQuestionario = OrcamentoFormFactory.getDefaultRespostaListaQuestionario(item);
                            var respostaListaQuestionarioItem =
                                $filter('filter')(questaoDetail.respostaListaQuestionario, {
                                    codigoItem: i,
                                    codigoComponenteListaItem: item.codigoComponenteListaItem
                                }, true)[0];
                            if (angular.isObject(respostaListaQuestionarioItem)) {
                                defaultRespostaListaQuestionario.textoResposta = respostaListaQuestionarioItem.textoResposta;
                                defaultRespostaListaQuestionario.dataResposta = respostaListaQuestionarioItem.dataResposta;
                            }
                            defaultRespostaListaQuestionario.codigoListaItem = questaoDetail.codigoListaItem;
                            defaultRespostaListaQuestionario.codigoItem = i;

                            OrcamentoFormFactory.setRespostaQuestionario(defaultRespostaListaQuestionario, false);

                            listaComponenteColumn.push(defaultRespostaListaQuestionario);
                        });
                        questaoDetail.respostaListaRow.push(listaComponenteColumn);
                    }
                }
            });
        }

        //-------------------------------------------END QUESTIONARIO---------------------------------------------//

        //----------------------------------------------DESCONTOS-------------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#populateDescontos
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to populate Descontos form
         *
         **/
        // function populateDescontos() {
        //     var orcamento = vm.proposta.orcamento;

        //     CanonicoService.buscarOferta(orcamento.codigoOferta, orcamento.numeroVersaoOferta,
        //             orcamento.numeroSequenciaVersaoOferta, $filter('date')(new Date(), Constants.DATE_FORMAT_BACKEND))
        //         .then(
        //             function(response) {
        //                 var oferta = CanonicoFactory.convertOferta(response.data);
        //                 var descontoOfertaList = oferta.descontosAgravos;
        //                 coberturaOfertaList = oferta.coberturas;

        //                 angular.forEach(vm.proposta.orcamento.descontoAgravo, function(descontoAgravoOrcamento) {
        //                     var filteredDesconto = $filter('filter')(descontoOfertaList, {
        //                         codigoDescontoAgravo: descontoAgravoOrcamento.codigoDescontoAgravo
        //                     }, true)[0];
        //                     if (angular.isObject(filteredDesconto)) {
        //                         var data = {};
        //                         data = OrcamentoPropostaFactory.convertDesconto(filteredDesconto, descontoAgravoOrcamento);
        //                         vm.descontos.push(data);
        //                     }
        //                 });
        //             },

        //             function(error) {
        //                 displayError(error);
        //             });
        // }
        //--------------------------------------------END DESCONTOS-----------------------------------------------//

        //----------------------------------------CLÁUSULAS PARTICULARES------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#populateClausulas
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to populate Clausulas form
         *
         **/
        function populateClausulas() {
            if (vm.proposta.orcamento.clausula) {
                angular.forEach(vm.proposta.orcamento.clausula, function(clausulaOrcamento) {
                    blockUI.start();
                    CanonicoService.buscarClausula(
                            codigoEmpresa, clausulaOrcamento.codigoClausula, null,
                            $filter('date')(new Date(), Constants.DATE_FORMAT_BACKEND))
                        .then(

                            function(response) {
                                var data = CanonicoFactory.convertClausula(response.data.clausula[0]);
                                data = OrcamentoPropostaFactory.convertClausulas(data, clausulaOrcamento);
                                vm.clausulas.push(data);
                                blockUI.stop();
                            },

                            function(error) {
                                blockUI.stop();
                            });
                });
            }
        }

        //--------------------------------------END CLÁUSULAS PARTICULARES----------------------------------------//

        //--------------------------------------ENDERECO----------------------------------------------------------//


        function populateEndereco() {
            var mockdata = "mockdataList";

            vm.enderecoDeCobrancaDropdown = OrcamentoPropostaFactory.convertEnderecoDeCobrancaDropdown(mockdata);
            vm.enderecoDeCorrespondenciaDropdown = OrcamentoPropostaFactory.convertEnderecoDeCorrespondenciaDropdown(mockdata);

            if (vm.proposta.pagadores && vm.proposta.pagadores.pagador && vm.proposta.pagadores.pagador.length > 0) {
                for (var i = 0; vm.proposta.pagadores.pagador.length > i; i++) {
                    var item = vm.proposta.pagadores.pagador[i];
                    if (item.dadosPessoaPagador &&
                        item.dadosPessoaPagador.codigoPessoa) {
                        if (vm.proposta.dadosPessoaSegurado && vm.proposta.dadosPessoaSegurado.codigoPessoa) {

                            if (item.enderecoCobranca && item.enderecoCobranca.codigoEndereco) {
                                vm.proposta.enderecoCobranca.flagEnderecoCobranca = getFlagEnderecoCobranca(item.enderecoCobranca.codigoEndereco);
                                if (vm.proposta.enderecoCobranca.flagEnderecoCobranca == 1) {
                                    vm.proposta.enderecoCobranca.codigoEndereco = item.enderecoCobranca.codigoEndereco;
                                }
                                vm.proposta.enderecoCobranca.enderecosCadastrado = item.enderecoCobranca.codigoEndereco;
                                break;
                            }
                        }
                    }
                }
            }

            if (vm.proposta.enderecoCorrespondencia && vm.proposta.enderecoCorrespondencia.codigoEndereco) {
                vm.proposta.enderecoCorrespondencia.flagEnderecoCorrespondencia = getFlagEnderecoCorrespondencia(vm.proposta.enderecoCorrespondencia.codigoEndereco);
                vm.proposta.enderecoCorrespondencia.enderecosCadastrado = vm.proposta.enderecoCorrespondencia.codigoEndereco;

                if (vm.proposta.codigoCanal == 2) {
                    if (!vm.proposta.enderecoCobranca || (!vm.proposta.enderecoCobranca.codigoEndereco && !vm.proposta.enderecoCobranca.enderecosCadastrado)) {
                        vm.proposta.enderecoCobranca.codigoEndereco = vm.proposta.enderecoCorrespondencia.codigoEndereco;
                        vm.proposta.enderecoCobranca.enderecosCadastrado = vm.proposta.enderecoCorrespondencia.codigoEndereco;
                    }
                }
            }

            if (vm.proposta.enderecoCobranca && vm.proposta.enderecoCobranca.codigoEndereco) {
                vm.proposta.enderecoCobranca.flagEnderecoCobranca = getFlagEnderecoCobranca(vm.proposta.enderecoCobranca.codigoEndereco);
                vm.proposta.enderecoCobranca.enderecosCadastrado = vm.proposta.enderecoCobranca.codigoEndereco;

                if (vm.proposta.codigoCanal == 2) {
                    if (!vm.proposta.enderecoCorrespondencia || (!vm.proposta.enderecoCorrespondencia.codigoEndereco && !vm.proposta.enderecoCorrespondencia.enderecosCadastrado)) {
                        vm.proposta.enderecoCorrespondencia.codigoEndereco = vm.proposta.enderecoCobranca.codigoEndereco;
                        vm.proposta.enderecoCorrespondencia.enderecosCadastrado = vm.proposta.enderecoCobranca.codigoEndereco;
                    }
                }
            }
        }

        function getFlagEnderecoCobranca(codigoEndereco) {
            if (vm.localRiscoList) {

                vm.endereco.enderecoCobranca.enderecosCadastradoList =
                    OrcamentoPropostaFactory.convertEnderecosCadastradoList(vm.proposta.dadosPessoaSegurado.enderecosPessoa);

                var localRiscoDropDown = [];

                angular.forEach(vm.localRiscoList, function(localRisco) {
                    var localRiscoChild = carregarDadosChilde(localRisco);
                    var address = OrcamentoPropostaFactory.getLocalRiscoDropDown(localRiscoChild, vm.tipoLogradouroOptions);
                    localRiscoDropDown.push(address);
                });
                vm.endereco.enderecoCobranca.localDeRiscoList = localRiscoDropDown;

                angular.forEach(vm.localRiscoList, function(localRisco) {
                    var existeEndereco = vm.proposta.dadosPessoaSegurado.enderecosPessoa.filter(function(item) {
                        return item.codigoEndereco == codigoEndereco;
                    }).shift();
                    if (existeEndereco && localRisco && existeEndereco.numeroCep) {
                        var existeEnderecoCEP = parseInt(existeEndereco.numeroCep.replace(/[^0-9]/g, ''));
                        if (existeEndereco.codigoLogradouro == localRisco.codigoLogradouro && existeEnderecoCEP == localRisco.numeroCep) {
                            vm.proposta.enderecoCobranca.localDeRisco = localRisco.codigoLocalRisco;
                        }
                    }
                });
   
                if (!vm.proposta.enderecoCobranca.localDeRisco) {
                    vm.endereco.enderecoCobranca.enderecosCadastradoList =
                        OrcamentoPropostaFactory.convertEnderecosCadastradoList(vm.proposta.dadosPessoaSegurado.enderecosPessoa);
                    return 2;
                }
                return 1;
            } else {
                vm.endereco.enderecoCobranca.enderecosCadastradoList =
                    OrcamentoPropostaFactory.convertEnderecosCadastradoList(vm.proposta.dadosPessoaSegurado.enderecosPessoa);
                return 2;
            }
        }

        function getFlagEnderecoCorrespondencia(codigoEndereco) {
            if (vm.localRiscoList) {

                vm.endereco.enderecoCorrespondencia.enderecosCadastradoList =
                    OrcamentoPropostaFactory.convertEnderecosCadastradoList(vm.proposta.dadosPessoaSegurado.enderecosPessoa);

                var localRiscoDropDown = [];

                angular.forEach(vm.localRiscoList, function(localRisco) {
                    var address = OrcamentoPropostaFactory.getLocalRiscoDropDown(localRisco, vm.tipoLogradouroOptions);
                    localRiscoDropDown.push(address);
                });
                vm.endereco.enderecoCorrespondencia.localDeRiscoList = localRiscoDropDown;

                angular.forEach(vm.localRiscoList, function(localRisco) {
                    var existeEndereco = vm.proposta.dadosPessoaSegurado.enderecosPessoa.filter(function(item) {
                        return item.codigoEndereco == codigoEndereco;
                    }).shift();
                    if (existeEndereco && localRisco && existeEndereco.numeroCep) {
                        var existeEnderecoCEP = parseInt(existeEndereco.numeroCep.replace(/[^0-9]/g, ''));
                        if (existeEndereco.codigoLogradouro == localRisco.codigoLogradouro && existeEnderecoCEP == localRisco.numeroCep) {
                            vm.proposta.enderecoCorrespondencia.localDeRisco = localRisco.codigoLocalRisco;
                        }
                    }
                });
   
                if (!vm.proposta.enderecoCorrespondencia.localDeRisco) {
                    vm.endereco.enderecoCorrespondencia.enderecosCadastradoList =
                        OrcamentoPropostaFactory.convertEnderecosCadastradoList(vm.proposta.dadosPessoaSegurado.enderecosPessoa);
                    return 2;
                }
                return 1;
            } else {
                vm.endereco.enderecoCorrespondencia.enderecosCadastradoList =
                    OrcamentoPropostaFactory.convertEnderecosCadastradoList(vm.proposta.dadosPessoaSegurado.enderecosPessoa);
                return 2;
            }
        }



        //--------------------------------------END CLÁUSULAS PARTICULARES----------------------------------------//

        //------------------------------------------------CRITICAS-----------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#populateCriticas
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to populate Criticas form
         *
         **/
        function populateCriticas() {
            var data = [];
            vm.criticas = OrcamentoPropostaFactory.convertCriticas(data);
        }

        //---------------------------------------------END CRITICAS----------------------------------------------//

        //----------------------------------------------CO CORRETAGEM--------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#salvarCorretagem
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to add new row to Corretagem table
         *
         **/
        function salvarCorretagem() {

            var lastIndex = vm.corretagem.corretores.length - 1;

            if ((vm.corretagem.corretores[lastIndex].codigoSucursal === null ||
                    vm.corretagem.corretores[lastIndex].codigoSucursal === '') &&
                (vm.corretagem.corretores[lastIndex].percentualParticipacao === null ||
                    vm.corretagem.corretores[lastIndex].percentualParticipacao === '') &&
                (vm.corretagem.corretores[lastIndex].codigoCorretor === null ||
                    vm.corretagem.corretores[lastIndex].codigoCorretor === '') &&
                (lastIndex !== 0 && lastIndex !== 1)) {

                vm.corretagem.corretores.splice(lastIndex, 1);
                lastIndex = vm.corretagem.corretores.length - 1;
            }

            if (checkCorretorMandatoryField()) {
                displayPreconditionError(corretorError);
            } else {

                var numeroProposta = vm.proposta.numeroProposta;
                var numeroVersaoProposta = vm.proposta.numeroVersaoProposta;

                var corretorVersaoProposta = OrcamentoPropostaFactory.convertBackCorretorVersaoProposta(
                    numeroProposta, numeroVersaoProposta, vm.corretagem);

                if (vm.corretagemIsUpdate) {

                    if (vm.corretagem.corretores[lastIndex].codigoSucursal === null &&
                        vm.corretagem.corretores[lastIndex].percentualParticipacao === null) {
                        corretorVersaoProposta.documentoEmissao.corretores.corretor.splice(lastIndex, 1);
                    }

                    var codigoCorretor;
                    if (corretorVersaoProposta.documentoEmissao.corretores.corretor.length > 1) {
                        codigoCorretor = corretorVersaoProposta.documentoEmissao.corretores.corretor[0].codigoCorretor;
                    }

                    if (corretorVersaoProposta.documentoEmissao.corretores.corretor[0].percentualParticipacao > 0) {

                        var param = {
                            "numeroVersaoProposta": numeroVersaoProposta,
                            "numeroProposta": numeroProposta,
                            "codigoEmpresa": vm.pageinfo.orcamento.codigoEmpresa,
                            "documentoEmissao": corretorVersaoProposta.documentoEmissao
                        }
                        updateCorretagem(numeroProposta, numeroVersaoProposta, codigoCorretor, param, true);

                    } else {
                        displayPreconditionError(Constants.MSG_ERROR_PERCENTUAL_PARTICIPACAO);
                    }

                } else {

                    if (vm.corretagem.corretores[lastIndex].codigoSucursal === null &&
                        vm.corretagem.corretores[lastIndex].percentualParticipacao === null) {
                        corretorVersaoProposta.documentoEmissao.corretores.corretor.splice(lastIndex, 1);
                    }
                    if (corretorVersaoProposta.documentoEmissao.corretores.corretor[0].percentualParticipacao > 0) {
                        OrcamentoPropostaService.createCorretagem(numeroProposta, numeroVersaoProposta, corretorVersaoProposta)
                            .then(

                                function(response) {
                                    vm.isCorretorFormSubmitted = false;
                                    $rootScope.$broadcast(Constants.SUCCESSO, Constants.MSG_SUCCESS_SAVE);
                                    populateCorretagem();
                                },
                                function(error) {
                                    displayError(error);
                                });
                    }
                }
            }
        }

        function updateCorretagem(numeroProposta, numeroVersaoProposta, codigoCorretor, corretorVersaoProposta, notRemoved) {
            OrcamentoPropostaService.updateCorretagem(numeroProposta, numeroVersaoProposta, codigoCorretor, corretorVersaoProposta)
                .then(

                    function(response) {
                        vm.isCorretorFormSubmitted = false;
                        if (notRemoved) {
                            $rootScope.$broadcast(Constants.SUCCESSO, Constants.MSG_SUCCESS_SAVE);
                        } else {
                            $rootScope.$broadcast(Constants.SUCCESSO, Constants.MSG_SUCCESS_REMOVE);
                        }
                        populateCorretagem();
                    },
                    function(error) {
                        displayError(error);
                    });
        }

        function checkCorretorMandatoryField(corretorVersaoProposta) {
            vm.isCorretorFormSubmitted = true;
            var hasError = false;
            var duplicateCorretor = false;
            var inValidPercentual = false;
            var codigoCorretorHolder = [];
            var percentualTotal = 0;

            var percentualNomes = [];
            var corretoresNomes = [];

            if (angular.isObject(vm.corretagem)) {
                if (angular.isArray(vm.corretagem.corretores)) {
                    var lastIndex = vm.corretagem.corretores.length - 1;
                    angular.forEach(vm.corretagem.corretores, function(corretor, index) {

                        var susep = "isCodigoSuscepCorretagem" + index;
                        var percentual = "isPercentualParticipacao" + index;

                        vm[percentual] = false;
                        vm[susep] = false;

                        if ((corretor.codigoCorretor === '' || corretor.codigoCorretor === null) &&
                            (!angular.isNumber(corretor.percentualParticipacao)) && (index === 0 || index === 1)) {
                            vm[susep] = true;
                            vm[percentual] = true;
                            hasError = true;
                            return false;
                        }
                        if ((corretor.codigoCorretor !== '' && corretor.codigoCorretor !== null) &&
                            (!angular.isNumber(corretor.percentualParticipacao))) {
                            vm[percentual] = true;
                            hasError = true;
                            return false;
                        } else if ((corretor.codigoCorretor === '' || corretor.codigoCorretor === null) &&
                            (angular.isNumber(corretor.percentualParticipacao))) {
                            vm[susep] = true;
                            hasError = true;
                            return false;
                        }

                        if (angular.isNumber(corretor.percentualParticipacao)) {
                            if (index === 0 && (corretor.percentualParticipacao <= 0 || corretor.percentualParticipacao > 100)) {
                                inValidPercentual = true;
                                percentualNomes.push(percentual);
                            } else if (index !== 0 && (corretor.percentualParticipacao <= 0 || corretor.percentualParticipacao >= 100)) {
                                inValidPercentual = true;
                                percentualNomes.push(percentual);
                                //vm[percentual] = true;
                            } else {
                                percentualTotal = percentualTotal + corretor.percentualParticipacao;
                            }
                        }

                        var filteredCorretor = null;

                        filteredCorretor = $filter('filter')(codigoCorretorHolder, corretor.codigoCorretor);

                        if (filteredCorretor.length === 0) {
                            codigoCorretorHolder.push(corretor.codigoCorretor);
                        } else {
                            //vm[susep] = true;
                            corretoresNomes.push(susep);
                            duplicateCorretor = true;
                        }
                    });
                }
            }

            if (!inValidPercentual) {
                if (percentualTotal !== 100) {
                    inValidPercentual = true;
                }
            }

            if (hasError) {
                corretorError = Constants.MSG_ERROR_SAVE;
            } else if (duplicateCorretor) {
                angular.forEach(corretoresNomes, function(nome) {
                    vm[nome] = true;
                });
                corretorError = Constants.MSG_ERROR_EXISTING_BENEFICIARIO;
            } else if (inValidPercentual) {
                angular.forEach(percentualNomes, function(nome) {
                    vm[nome] = true;
                });
                corretorError = Constants.MSG_ERROR_PERCENTUAL_PARTICIPACAO;
            }

            return hasError || inValidPercentual || duplicateCorretor;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#removeCorretagem
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to remove row from Corretagem table
         *
         **/
        function removeCorretagem(index) {

            if (!vm.flagPermissaoMultiploSegurado) {
                return;
            }

            var corretor = vm.corretagem.corretores[index];
            if (angular.isDefined(corretor.codigoCorretor) &&
                corretor.codigoCorretor !== null &&
                corretor.codigoCorretor.trim() !== "" &&
                corretor.flagPrincipal !== "S") {
                var numeroProposta = vm.proposta.numeroProposta;
                var numeroVersaoProposta = vm.proposta.numeroVersaoProposta;

                var lastIndex = vm.corretagem.corretores.length - 1;

                if (lastIndex > 1 &&
                    ((vm.corretagem.corretores[lastIndex].codigoCorretor !== '' ||
                            vm.corretagem.corretores[lastIndex].codigoCorretor !== null) &&
                        (vm.corretagem.corretores[lastIndex].percentualParticipacao !== '' ||
                            vm.corretagem.corretores[lastIndex].percentualParticipacao !== null))) {

                    //remove selected corretagem
                    OrcamentoPropostaService.deleteCorretagem(numeroProposta, numeroVersaoProposta, corretor.codigoCorretor)
                        .then(

                            function(response) {

                                //get updated list of corretor
                                populateCorretagem();
                                var sum = 0;
                                var indexOfPrincipal = 0;
                                vm.corretagem.corretores.splice((vm.corretagem.corretores.length - 1), 1);
                                vm.corretagem.corretores.splice(index, 1);
                                var indexOfPrincipal = 0;
                                var sum = 0;
                                var len = vm.corretagem.corretores.length;

                                var corretagem = vm.corretagem.corretores;
                                for (var i = 0; i < len; i++) {
                                    if (corretagem[i].flagPrincipal !== 'S') {
                                        sum += corretagem[i].percentualParticipacao;
                                    } else {
                                        indexOfPrincipal = i;
                                    }
                                }
                                //set calculated principal percentual
                                var principalParticipacao = 100 - sum;
                                corretagem[indexOfPrincipal].percentualParticipacao = principalParticipacao;

                                var corretorVersaoProposta = OrcamentoPropostaFactory.convertBackCorretorVersaoProposta(
                                    numeroProposta, numeroVersaoProposta, vm.corretagem);
                                updateCorretagem(numeroProposta, numeroVersaoProposta, corretagem[0].codigoCorretor, corretorVersaoProposta, false);

                                angular.forEach(vm.corretagem.corretores, function(corretor, index) {
                                    var percentualVar = "isPercentualParticipacao" + index;
                                    vm[percentualVar] = false;
                                });
                            },
                            function(error) {
                                displayError(error);
                            });
                } else {
                    displayPreconditionError(Constants.MSG_ERROR_PERCENTUAL_PARTICIPACAO);
                }

            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#populateCorretagem
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to populate Corretagem form
         *
         **/
        function populateCorretagem() {

            var numeroProposta = vm.proposta.numeroProposta;
            var numeroVersaoProposta = vm.proposta.numeroVersaoProposta;
            var skip = 0;
            var top = 0;
            var codigoCorretorMain = null;

            if (vm.dadosSeguro.susepCorretor) {
                codigoCorretorMain = vm.dadosSeguro.susepCorretor;
                //SM 531/533
                blockUI.start();
                CorretoresService.getCorretorById(codigoCorretorMain)
                    .then(
                        function(response) {
                            if (angular.isObject(response.data)) {
                                vm.selectedCorretorDetails = response.data;
                                if (vm.selectedCorretorDetails && vm.selectedCorretorDetails.tipoBloqueios) {
                                    vm.bloqueioCorretor = vm.selectedCorretorDetails.tipoBloqueios.tipoBloqueio
                                    changeCorretorForBlock(vm.bloqueioCorretor);
                                }

                            }
                            blockUI.stop();
                        },
                        function(error) {
                            blockUI.stop();
                        });
            } else {
                codigoCorretorMain = "1";
            }

            vm.corretagemIsUpdate = false;

            blockUI.start();
            OrcamentoPropostaService.getCorretagemList(skip, top, numeroProposta, numeroVersaoProposta, codigoEmpresa)
                .then(

                    function(response) {
                        if (response.data && response.data.documentoEmissao) {
                            searchCorretores(response.data.documentoEmissao, codigoCorretorMain);
                        }
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#changePercentualParticipacao
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to validate the percentual value
         *
         **/
        function changePercentualParticipacao(index, percentual) {
            var percentualAcumulado = null;
            var percentualVar = "isPercentualParticipacao" + index;
            var susep = "isCodigoSuscepCorretagem" + index;
            var codigoCorretorHasError = false;

            var lastIndex = vm.corretagem.corretores.length - 1;
            if (lastIndex === 0 || lastIndex === 1) {
                lastIndex = 3;
            }

            if (percentual !== "" && percentual !== null) {
                var tempHolder = percentual.replace(/(?!^-)[^0-9]/g, '');
                if (tempHolder === "") {
                    vm.corretagem.corretores[index].percentualParticipacao = null;
                    percentual = null;
                } else {
                    var toSet = tempHolder;
                    if (tempHolder !== "-") {
                        toSet = parseInt(tempHolder);
                    }

                    vm.corretagem.corretores[index].percentualParticipacao = toSet;
                    percentual = toSet;
                }
            }

            if (vm.corretagem.corretores[index].codigoCorretor === '' || vm.corretagem.corretores[index].codigoCorretor === null) {
                codigoCorretorHasError = true;
            }

            var percentualHolder = percentual;
            var errorPercentual = false;

            if (percentual === '' || percentual === '-' || percentual === null) {
                percentualHolder = 0;
                errorPercentual = true;
            }

            // if(angular.isNumber(percentual)){
            percentualAcumulado = vm.corretagem.corretores[0].percentualParticipacao - percentualHolder;

            vm.corretagem.corretores[index].percentualParticipacao = percentual;
            var sum = 0;
            for (var i = 1; i < vm.corretagem.corretores.length; i++) {
                if (vm.corretagem.corretores[i].percentualParticipacao !== '-' && vm.corretagem.corretores[i].percentualParticipacao !== '') {
                    sum += vm.corretagem.corretores[i].percentualParticipacao;
                }
            }
            //set calculated principal percentual
            var principalParticipacao = 100 - sum;
            vm.corretagem.corretores[0].percentualParticipacao = principalParticipacao;

            if (principalParticipacao > 0 || principalParticipacao <= 100) {
                vm.isPercentualParticipacao0 = false;
            }

            if ((codigoCorretorHasError && errorPercentual) && index === lastIndex) {
                vm[percentualVar] = false;
                vm[susep] = false;
            } else if ((codigoCorretorHasError && errorPercentual) && index !== lastIndex) {
                vm[percentualVar] = true;
                vm[susep] = true;
            } else if (codigoCorretorHasError && !errorPercentual) {
                vm[percentualVar] = false;
                vm[susep] = true;
            } else if (!codigoCorretorHasError && errorPercentual) {
                vm[percentualVar] = true;
                vm[susep] = false;
            } else if (!codigoCorretorHasError && !errorPercentual) {
                vm[percentualVar] = false;
                vm[susep] = false;
            }
        }

        function replaceWithNumbers(value, objectName, fieldName) {

            if (!value) {
                return;
            }

            vm[objectName][fieldName] = value.replace(/(?!^-)[^0-9]/g, '');
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#changeCodigoCorretor
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to get the nome corretor based on codigo corretor
         *
         **/
        function changeCodigoCorretor(index, codigoCorretor) {
            var listaCorretores = null;

            if (angular.isDefined(codigoCorretor) && codigoCorretor !== null && codigoCorretor !== '') {
                CorretoresService.getCorretorById(codigoCorretor)
                    .then(

                        function(response) {
                            if (response.data && response.data.listaCorretores) {
                                listaCorretores = response.data.listaCorretores;
                                vm.corretagem.corretores[index].codigoCorretor = response.data.susepPorto;
                                vm.corretagem.corretores[index].nomeCorretor = listaCorretores.corretor[0].nome;
                                vm.corretagem.corretores[index].codigoSucursal = response.data.codigoSucursal;
                                vm.corretagemIsUpdate = true;
                            } else {
                                vm.corretagem.corretores[index].codigoCorretor = '';
                                vm.corretagem.corretores[index].nomeCorretor = '';
                                vm.corretagem.corretores[index].codigoSucursal = '';
                            }
                        });
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#searchCorretores
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method to search list of Corretor by name of Corretor.
         *
         **/
        function searchCorretores(documentoEmissao, codigoCorretorMain) {
            vm.corretoresList = [];
            vm.corretagem = OrcamentoPropostaFactory.convertCorretagem(documentoEmissao, codigoCorretorMain);
            if (vm.corretagem.corretores.length >= 2) {
                vm.corretagemIsUpdate = true;
            }
            vm.corretagem.corretores.push(OrcamentoPropostaFactory.defaultCorretagem());

            angular.forEach(vm.corretagem.corretores, function(item, index) {
                if (angular.isDefined(item.codigoCorretor) && item.codigoCorretor !== null) {
                    CorretoresService.getCorretorById(item.codigoCorretor)
                        .then(

                            function(response) {
                                if (response.data) {
                                    var listaCorretores = response.data.listaCorretores;
                                    vm.corretagem.corretores[index].nomeCorretor = listaCorretores.corretor[0].nome;
                                }
                            });
                }
            });
        }

        //------------------------------------------END OF CO CORRETAGEM-----------------------------------------//

        //-----------------------------------------------ENDERECO------------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#populateEnderecoEmpresarial
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to populate Endereco Empresarial fields in Endereco form
         *
         **/
        function populateEnderecoEmpresarial(state) {
            var data = [];
            vm.endereco.enderecoEmpresarial.localDeRiscoList = OrcamentoPropostaFactory.convertLocalDeRiscoList(data);
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#populateEnderecoCobranca
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to populate Endereco Cobranca fields in Endereco form
         *
         **/
        function populateEnderecoCobranca(state) {
            var data = [];
            if (state === "sim") {
                var localRiscoDropDown = [];

                angular.forEach(vm.localRiscoList, function(localRisco) {
                    var localRiscoChild = carregarDadosChilde(localRisco);
                    var address = OrcamentoPropostaFactory.getLocalRiscoDropDown(localRiscoChild, vm.tipoLogradouroOptions);
                    localRiscoDropDown.push(address);
                });

                vm.endereco.enderecoCobranca.localDeRiscoList = localRiscoDropDown;
            } else {
                vm.endereco.enderecoCobranca.enderecosCadastradoList =
                    OrcamentoPropostaFactory.convertEnderecosCadastradoList(vm.proposta.dadosPessoaSegurado.enderecosPessoa);
            }
        }

        function carregarDadosChilde(localRisco) {
            var nomeUnidadeFederativa = "";
            var nomePais = "";

            angular.forEach(vm.unidadeFederacaoOptions, function(unidadeFederacao) {
                if (unidadeFederacao.codigoValorDominio == localRisco.codigoUnidadeFederacao) {
                    nomeUnidadeFederativa = unidadeFederacao.nomeDominio;
                    return;
                }
            });

            angular.forEach(vm.paisResidenteOptions, function(pais) {
                if (pais.codigoValorDominio == localRisco.codigoPais) {
                    nomePais = pais.nomeDominio;
                    return;
                }
            });

            localRisco.nomeUnidadeFederacao = nomeUnidadeFederativa;
            localRisco.nomePais = nomePais;
            return localRisco;
        }


        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#populateEnderecoCorrespondencia
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to populate Endereco Correspondencia fields in Endereco form
         *
         **/
        function populateEnderecoCorrespondencia(state) {
            var data = [];
            if (state === "sim") {
                var localRiscoDropDown = [];

                angular.forEach(vm.localRiscoList, function(localRisco) {
                    var address = OrcamentoPropostaFactory.getLocalRiscoDropDown(localRisco, vm.tipoLogradouroOptions);
                    localRiscoDropDown.push(address);
                });

                vm.endereco.enderecoCorrespondencia.localDeRiscoList = localRiscoDropDown;
            } else {
                vm.endereco.enderecoCobranca.enderecosCadastradoList =
                    OrcamentoPropostaFactory.convertEnderecosCadastradoList(vm.proposta.dadosPessoaSegurado.enderecosPessoa);
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#displayNovoEndereco
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to display Novo Endereco
         *
         **/
        function displayNovoEndereco(type) {
            var data = [];
            if (type === 'cobranca') {
                if (vm.endereco.enderecoCobranca.enderecosCadastrado === 1) {
                    vm.disableEnderecoCobrancaCadastros = false;
                    vm.enderecoCobranca = OrcamentoPropostaFactory.defaultEnderecoCobranca();
                } else {
                    vm.disableEnderecoCobrancaCadastros = true;
                    vm.enderecoCobranca = OrcamentoPropostaFactory.convertEnderecoCobranca(data);
                }
            } else {
                if (vm.endereco.enderecoCorrespondencia.enderecosCadastrado === 1) {
                    vm.disableEnderecoCorrespondenciaCadastros = false;
                    vm.enderecoCorrespondencia = OrcamentoPropostaFactory.defaultEnderecoCorrespondencia();
                } else {
                    vm.disableEnderecoCorrespondenciaCadastros = true;
                    vm.enderecoCorrespondencia = OrcamentoPropostaFactory.convertEnderecoCorrespondencia(data);
                }
            }
            /*jshint sub:true*/
            DominiosService.getDominio(Dominios['TIPO_ENDERECO'].codigo, Dominios['TIPO_ENDERECO'].cache)
                .then(function(response) {
                        vm.tipoEnderecoDropdown = response;
                    },
                    function(error) {
                        displayError(error);
                    });
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#salvarCobranca
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon clicking salvar button in Cobranca under endereco field
         *
         **/
        function salvarCobranca() {
            vm.isEmissaoEnderecoFormSubmitted = true;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#salvarCadastros
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon clicking salvar button in Cadastros under endereco field
         *
         **/
        function salvarCadastros() {
            vm.isEnderecoCorrespondenciaFormSubmitted = true;
        }

        //--------------------------------------------END OF ENDERECO--------------------------------------------//

        //---------------------------------------------INTERVENIENTE---------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#openPagadorParcelaModal
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Instantiate modal and get all versions
         *
         **/
        function openIntervenienteModal(codigoInterveniente, screenID, codigoTipoInterveniente, codigoPossuiControlador) {

            var modalInstance = $modal.open({
                animation: true,
                size: 'lg',
                backdrop: 'static',
                keyboard: false,
                templateUrl: 'proposta.cosseguradomodal.html',
                controllerAs: 'modalPropostaCtrl',
                controller: ['$modalInstance', function($modalInstance) {

                    var mod = this;

                    //Exposed variables
                    if (screenID === undefined) {
                        mod.isCosseguradoControlador = 2;
                    } else {
                        mod.isCosseguradoControlador = 1;
                    }
                    mod.alerts = [];
                    mod.cossegurado = {};
                    mod.numeroProposta = vm.proposta.numeroProposta;
                    mod.numeroVersaoProposta = vm.proposta.numeroVersaoProposta;
                    mod.codigoEmpresa = vm.proposta.codigoEmpresa;;
                    mod.skip = 0;
                    mod.top = 0;
                    mod.isFisica = false;
                    mod.isJuridica = false;
                    mod.tipoPessoaOptions = vm.tipoPessoaOptions;
                    mod.tipoVinculoOptions = vm.tipoVinculoOptions;
                    mod.isCosseguradoFormSubmitted = false;
                    mod.codigoTipoInterveniente = codigoTipoInterveniente;
                    mod.codigoInterveniente = codigoInterveniente;

                    //Exposed Methods
                    mod.maskCPFwithinOneObject = maskCPFwithinOneObject;
                    mod.maskCNPJwithinOneObject = maskCNPJwithinOneObject;
                    mod.maskCPFwithinTwoObject = maskCPFwithinTwoObject;
                    mod.maskCNPJwithinTwoObject = maskCNPJwithinTwoObject;
                    mod.changeTipoPessoa = changeTipoPessoa;
                    mod.closeModalAlert = closeModalAlert;
                    mod.isNullOrEmpty = isNullOrEmpty;


                    //Get Interveniente by selected ID
                    getInterveniente(mod.numeroProposta, mod.numeroVersaoProposta, mod.codigoInterveniente, mod.codigoEmpresa);

                    function getInterveniente(numeroProposta, numeroVersaoProposta, codigoInterveniente, codigoEmpresa) {
                        OrcamentoPropostaService.getInterveniente(numeroProposta, numeroVersaoProposta, codigoInterveniente, codigoEmpresa)
                            .then(

                                function(response) {
                                    if (response.data && response.data.documentoEmissao) {
                                        mod.cossegurado = OrcamentoPropostaFactory.convertModInterveniente(response.data.documentoEmissao);
                                        if (mod.cossegurado.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA) {
                                            mod.isFisica = true;
                                            mod.isJuridica = false;
                                        } else if (mod.cossegurado.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.JURIDICA) {
                                            mod.isFisica = false;
                                            mod.isJuridica = true;
                                        }
                                        if (mod.cossegurado && mod.cossegurado.flagPessoaExposta == 'S') {
                                            if (codigoPossuiControlador && codigoPossuiControlador == 1 &&
                                                mod.cossegurado.codigoTipoExposicaoPessoa == 1) {
                                                mod.cossegurado.pessoaExpostaPoliticamente.numeroCnpjCpfPessoaExposto = "";
                                                mod.cossegurado.pessoaExpostaPoliticamente.nomePessoaExposto = "";
                                                mod.cossegurado.pessoaExpostaPoliticamente.codigoTipoVinculo = "";
                                            }
                                        }
                                    }
                                },
                                function(error) {
                                    if (error.status === Constants.HTTP_FORBIDDEN) {
                                        addModalAlert(Constants.ERROR_TYPE, Constants.MSG_ERROR_FORBIDDEN);
                                    } else {
                                        var errorMessage = getErrorMessage(error);
                                        addModalAlert(Constants.ERROR_TYPE, errorMessage);
                                    }
                                });
                    }

                    function getIntervenienteList(numeroProposta, numeroVersaoProposta, codigoEmpresa) {
                        OrcamentoPropostaService.getIntervenienteList(skip, top, numeroProposta, numeroVersaoProposta, codigoEmpresa)
                            .then(

                                function(response) {
                                    if (response.data && response.data.documentoEmissao) {
                                        vm.cossegurado = OrcamentoPropostaFactory.convertIntervenienteList(response.data.documentoEmissao);
                                    }
                                },
                                function(error) {
                                    if (error.status === Constants.HTTP_FORBIDDEN) {
                                        addModalAlert(Constants.ERROR_TYPE, Constants.MSG_ERROR_FORBIDDEN);
                                    } else {
                                        var errorMessage = getErrorMessage(error);
                                        addModalAlert(Constants.ERROR_TYPE, errorMessage);
                                    }
                                });
                    }

                    mod.fechar = function() {
                        $modalInstance.dismiss('fechar');
                        if (screenID === 1) {
                            vm.populateCossegurado();
                        } else if (screenID === 2) {
                            vm.populateControladores();
                        }
                    };

                    mod.salvar = function() {
                        var hasError = checkMandatoryFields();
                        mod.alerts = [];

                        if (hasError) {
                            addModalAlert(Constants.ERROR_TYPE, Constants.MSG_ERROR_SAVE);
                        } else {
                            salvarInterveniente();
                        }
                    };

                    function salvarInterveniente() {
                        var interveniente = angular.copy(mod.cossegurado);
                        if (mod.cossegurado && mod.cossegurado.flagPessoaExposta == 'S') {
                            if (codigoPossuiControlador && codigoPossuiControlador == 1 &&
                                mod.cossegurado.pessoaExpostaPoliticamente.codigoTipoPessoaExposto == 1) {
                                mod.cossegurado.pessoaExpostaPoliticamente.numeroCnpjCpfPessoaExposto = "";
                                mod.cossegurado.pessoaExpostaPoliticamente.nomePessoaExposto = "";
                                mod.cossegurado.pessoaExpostaPoliticamente.codigoTipoVinculo = "";
                            }
                        }
                        var toBeUpdated = OrcamentoPropostaFactory.convertBackIntervenienteVersaoProposta(
                            mod.codigoTipoInterveniente, mod.numeroProposta, mod.numeroVersaoProposta, interveniente, true);

                        OrcamentoPropostaService.updateInterveniente(mod.numeroProposta, mod.numeroVersaoProposta, mod.codigoInterveniente, toBeUpdated)
                            .then(

                                function(response) {
                                    $rootScope.$broadcast(Constants.SUCCESSO, Constants.MSG_SUCCESS_SAVE);
                                    mod.fechar();
                                },
                                function(error) {
                                    if (error.status === Constants.HTTP_FORBIDDEN) {
                                        addModalAlert(Constants.ERROR_TYPE, Constants.MSG_ERROR_FORBIDDEN);
                                    } else {
                                        var errorMessage = error.data.mensagens[2].mensagem;
                                        addModalAlert(Constants.ERROR_TYPE, errorMessage);
                                    }
                                }
                            );

                        if (screenID === 1) {
                            vm.populateCossegurado();
                        } else if (screenID === 2) {
                            vm.populateControladores();
                        }

                    }

                    function checkMandatoryFields() {
                        var hasError = mod.cosseguradoForm.$invalid;

                        if (hasError && mod.cossegurado.codigoMotivoAusenciaCnpjCpf === 3 &&
                            (mod.cosseguradoForm.numeroCnpjCpf.$viewValue ||
                                mod.cosseguradoForm.numeroCnpjCpf.$viewValue === "") &&
                            mod.cosseguradoForm.txtNomeInterveniente.$viewValue) {
                            hasError = false;
                        }

                        var expostaHasError = false;

                        if (Constants.CODIGO_TIPO_PESSOA.FISICA === mod.cossegurado.codigoTipoPessoa) {
                            if (isNullOrEmpty(mod.cossegurado.flagPessoaExposta)) {
                                expostaHasError = false;
                            } else {
                                if (mod.cossegurado.flagPessoaExposta === 'S') {
                                    if (codigoPossuiControlador && codigoPossuiControlador == 1) {
                                        if (isNullOrEmpty(mod.cossegurado.pessoaExpostaPoliticamente.numeroCnpjCpfPessoaExposto) &&
                                            isNullOrEmpty(mod.cossegurado.pessoaExpostaPoliticamente.nomePessoaExposto) &&
                                            isNullOrEmpty(mod.cossegurado.pessoaExpostaPoliticamente.codigoTipoVinculo)) {
                                            expostaHasError = false;
                                            var vinculo = vm.tipoVinculoOptions.filter(function(itemVinculo) {
                                                return itemVinculo.nomeDominio == "OUTROS";
                                            });
                                            mod.cossegurado.codigoTipoExposicaoPessoa = 1;
                                            mod.cossegurado.pessoaExpostaPoliticamente.flagVinculoPessoaExpostaPoliticamente = 1;
                                            mod.cossegurado.pessoaExpostaPoliticamente.numeroCnpjCpfPessoaExposto = mod.cossegurado.numeroCnpjCpf;
                                            mod.cossegurado.pessoaExpostaPoliticamente.nomePessoaExposto = mod.cossegurado.nomeInterveniente;

                                            if (vinculo && vinculo.length > 0) {
                                                mod.cossegurado.pessoaExpostaPoliticamente.codigoTipoVinculo = vinculo[0].codigoValorDominio;
                                            } else {
                                                mod.cossegurado.pessoaExpostaPoliticamente.codigoTipoVinculo = 6;
                                            }
                                        } else {
                                            expostaHasError = false;
                                            mod.cossegurado.codigoTipoExposicaoPessoa = 3;
                                            mod.cossegurado.pessoaExpostaPoliticamente.flagVinculoPessoaExpostaPoliticamente = 3;
                                        }
                                    } else {
                                        expostaHasError = (isNullOrEmpty(mod.cossegurado.pessoaExpostaPoliticamente.numeroCnpjCpfPessoaExposto) ||
                                            isNullOrEmpty(mod.cossegurado.pessoaExpostaPoliticamente.nomePessoaExposto) ||
                                            isNullOrEmpty(mod.cossegurado.pessoaExpostaPoliticamente.codigoTipoVinculo));
                                    }
                                }
                            }
                        }

                        mod.isCosseguradoFormSubmitted = true;

                        return hasError || expostaHasError;
                    }

                    function isNullOrEmpty(item) {

                        var hasError = false;
                        if (angular.isUndefined(item) || item === '' || item === null) {
                            hasError = true;
                        }
                        return hasError;
                    }

                    mod.open = function($event) {
                        $event.preventDefault();
                        $event.stopPropagation();
                    };

                    function changeTipoPessoa() {
                        if (Constants.CODIGO_TIPO_PESSOA.FISICA === mod.cossegurado.codigoTipoPessoa) {
                            mod.isFisica = true;
                            mod.isJuridica = false;
                            clearFields();
                        } else if (Constants.CODIGO_TIPO_PESSOA.JURIDICA === mod.cossegurado.codigoTipoPessoa) {
                            mod.isJuridica = true;
                            mod.isFisica = false;
                            clearFields();
                        } else {
                            mod.isFisica = false;
                            mod.isJuridica = false;
                            clearFields();
                        }
                    }

                    function clearFields() {
                        mod.cossegurado.numeroCnpjCpf = null;
                        mod.cossegurado.nomeInterveniente = null;
                        mod.cossegurado.flagPessoaExposta = 'N';
                        mod.cossegurado.pessoaExpostaPoliticamente.codigoExposicaoInterveniente = null;
                        mod.cossegurado.pessoaExpostaPoliticamente.codigoPessoaExposto = null;
                        mod.cossegurado.pessoaExpostaPoliticamente.codigoTipoPessoaExposto = null;
                        mod.cossegurado.pessoaExpostaPoliticamente.codigoTipoVinculo = null;
                        mod.cossegurado.pessoaExpostaPoliticamente.flagPessoaExposta = null;
                        mod.cossegurado.pessoaExpostaPoliticamente.nomePessoaExposto = null;
                        mod.cossegurado.pessoaExpostaPoliticamente.numeroCnpjCpfPessoaExposto = null;
                    }

                    function maskCPFwithinOneObject(firstObjectName, secondObjectName, e) {
                        mod[firstObjectName][secondObjectName] = maskCPF(mod[firstObjectName][secondObjectName], e);
                    }

                    function maskCNPJwithinOneObject(firstObjectName, secondObjectName, e) {
                        mod[firstObjectName][secondObjectName] = maskCNPJ(mod[firstObjectName][secondObjectName], e);
                    }

                    function maskCPFwithinTwoObject(firstObjectName, secondObjectName, thirdObjectName, e) {
                        mod[firstObjectName][secondObjectName][thirdObjectName] = maskCPF(mod[firstObjectName][secondObjectName][thirdObjectName], e);
                    }

                    function maskCNPJwithinTwoObject(firstObjectName, secondObjectName, thirdObjectName, e) {
                        mod[firstObjectName][secondObjectName][thirdObjectName] = maskCNPJ(mod[firstObjectName][secondObjectName][thirdObjectName], e);
                    }

                    function addModalAlert(type, message) {
                        mod.alerts.push({
                            type: type,
                            msg: message
                        });
                    }

                    function closeModalAlert(index) {
                        mod.alerts.splice(index, 1);
                    }

                    function getErrorMessage(error) {
                        var errorMessage = '';

                        if (angular.isDefined(error.data) && angular.isObject(error.data)) {
                            if (angular.isDefined(error.data.mensagens) &&
                                angular.isArray(error.data.mensagens)) {
                                errorMessage = error.data.mensagens[0].mensagem;
                            } else if (angular.isDefined(error.data.errorMessage)) {
                                errorMessage = error.data.errorMessage;
                            }
                        } else {
                            errorMessage = error.statusText;
                        }

                        return errorMessage;
                    }

                }]
            });
        }

        //--------------------------------------------END OF INTERVENIENTE---------------------------------------//


        //-----------------------------------------------PAGAMENTO-----------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#populuateFormaPagamentoDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method to Populate the List of FormaPagamento and sort it in preparation for the Quantidade Parcela Dropdown.
         **/
        function populuateFormaPagamentoDropdown() {
            if (vm.proposta.formasPagamento && vm.proposta.formasPagamento.formaPagamento &&
                vm.proposta.formasPagamento.formaPagamento.length > 0) {
                vm.formaPagamentoDropdown = OrcamentoPropostaFactory.filterFormaPagamento(vm.proposta.formasPagamento.formaPagamento);
            }
        }


        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#getPagamentoCalcularParcela
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method to get existing pagamentoParcela already associated to the Proposal.
         *
         **/
        function getPagamentoCalcularParcela() {

            var numeroProposta = vm.proposta.numeroProposta;
            var numeroVersaoProposta = vm.proposta.numeroVersaoProposta;
            vm.proposta.cartoes = {};
            vm.pagamentoCalcularParcela = {};

            blockUI.start();
            OrcamentoPropostaService.getPagadorParcelaVersaoProposta(
                    numeroProposta, numeroVersaoProposta)
                .then(

                    function(response) {
                        if (response.data && response.data.length > 0) {

                            getFormaPagamentoFromList(response.data[0].codigoFormaPagamento);
                            getPessoaList(response.data);

                            vm.quantidadeParcela = response.data[0].quantidadeParcela;

                            if (angular.isUndefined(vm.controlador.controladores) || vm.controlador.controladores.length <= 0) {
                                vm.getDefaultDadosSegurado.controladores.flagPossuiControlador = 2;
                            } else {
                                vm.getDefaultDadosSegurado.controladores.flagPossuiControlador = 3;
                            }

                            if (vm.nomeFormaPagamento && (vm.nomeFormaPagamento.indexOf("97") == -1 && vm.nomeFormaPagamento.indexOf("62") == -1)) {
                                vm.proposta.cartoes = null;
                            }
                            if (vm.nomeFormaPagamento && (vm.nomeFormaPagamento.indexOf("97") == 0) && !vm.proposta.solicitacaoCartaoCredito) {
                                if(vm.proposta.cartoes) {
                                    if(vm.proposta.cartoes.bandeira) {
                                        vm.pagamentoBandeiraDropdownTempholder = $filter('filter')(vm.pagamentoBandeiraDropdownTempholder, {
                                            "codigoValorDominio": vm.proposta.cartoes.bandeira
                                        });
                                    }
                                }
                            }
                        } else {
                            vm.pagamentoCalcularParcela = {};
                            vm.proposta.codigoFormaPagamento = null;
                            vm.proposta.quantidadeParcela = null;
                            vm.nomeFormaPagamento = null;
                            vm.quantidadeParcela = null;
                            if (vm.controlador.controladores && vm.controlador.controladores.length <= 0) {
                                vm.getDefaultDadosSegurado.controladores.flagPossuiControlador = 1;
                            }
                        }

                        if (SelectedOpts.proposta && SelectedOpts.proposta.pagador &&
                            SelectedOpts.proposta.pagador.length > 0 &&
                            SelectedOpts.proposta.pagador[0].pagadorParcela &&
                            SelectedOpts.proposta.pagador[0].pagadorParcela.length > 0) {

                            if (vm.nomeFormaPagamento.indexOf("97") != -1 || vm.nomeFormaPagamento.indexOf("62") != -1) {
                                if (vm.proposta.cartoes && !vm.proposta.cartoes.bandeira) {
                                    if (SelectedOpts.proposta.pagador[0].pagadorParcela[0].codigoBandeiraCartao) {
                                        vm.proposta.cartoes.bandeira = SelectedOpts.proposta.pagador[0].pagadorParcela[0].codigoBandeiraCartao;
                                        vm.proposta.cartoes.codigoTipoCartao = vm.proposta.cartoes.bandeira;
                                    } else if (SelectedOpts.proposta.pagador[0].pagadorParcela[0].codigoTipoCartao) {
                                        vm.proposta.cartoes.bandeira = SelectedOpts.proposta.pagador[0].pagadorParcela[0].codigoTipoCartao;
                                        vm.proposta.cartoes.codigoTipoCartao = vm.proposta.cartoes.bandeira;
                                    }

                                    // if (vm.nomeFormaPagamento.indexOf("97") != -1) {
                                    //     vm.proposta.cartoes.codigoTipoCartao = 1;
                                    // } else if (vm.nomeFormaPagamento.indexOf("62") != -1) {
                                    //     vm.proposta.cartoes.codigoTipoCartao = 2;
                                    // }
                                }
                            } else {
                                vm.proposta.cartoes = null;
                            }
                        }
                        blockUI.stop();
                    },

                    function(error) {
                        vm.getDefaultDadosSegurado.controladores.flagPossuiControlador = 1;
                        vm.pagamentoCalcularParcela = {};
                        vm.proposta.codigoFormaPagamento = null;
                        vm.proposta.quantidadeParcela = null;
                        vm.nomeFormaPagamento = null;
                        vm.quantidadeParcela = null;
                        displayError(error);
                        blockUI.stop();
                    });
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#getFormaPagamentoFromList
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method to get the selected formaPagamento and prepare the pagamentoQuantidadeParcelaDropdown.
         *
         **/
        function getFormaPagamentoFromList(codigoFormaPagamento) {

            var formaPagamento = $filter('filter')(vm.proposta.formasPagamento.formaPagamento, {
                codigoFormaPagamento: codigoFormaPagamento
            }, true)[0];

            if (formaPagamento) {
                vm.nomeFormaPagamento = formaPagamento.nomeFormaPagamento;
                vm.quantidadeParcela = formaPagamento.quantidadeParcela;
                $scope.orcamentoCtrl.nomeFormaPagamento = vm.nomeFormaPagamento;

                populateQuantidadeParcela(false);

                vm.proposta.codigoFormaPagamento = formaPagamento.codigoFormaPagamento;
                vm.proposta.quantidadeParcela = formaPagamento.quantidadeParcela;
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#populateQuantidadeParcela
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method to get the populate the pagamentoQuantidadeParcelaDropdown based on the codigoFormaPagamento Selected.
         *
         **/
        function populateQuantidadeParcela(isAlteracao) {
            if (isAlteracao) {
                vm.proposta.codigoIdentificacaoCartao = null;
                vm.proposta.cartoes = {};
                vm.proposta.quantidadeParcela = null;
                vm.quantidadeParcela = null;
                vm.proposta.pagadores = {
                    pagador: []
                };

                SelectedOpts.proposta.codigoIdentificacaoCartao = null;
                SelectedOpts.proposta.cartoes = {};
                SelectedOpts.proposta.quantidadeParcela = null;
                SelectedOpts.quantidadeParcela = null;
                SelectedOpts.proposta.pagadores = {
                    pagador: []
                };
                $scope.orcamentoCtrl.nomeFormaPagamento = vm.nomeFormaPagamento;
            }
            SelectedOpts.nomeFormaPagamento = vm.nomeFormaPagamento;
            SelectedOpts.quantidadeParcela = vm.quantidadeParcela;

            vm.showPagamentoDaParcelaGrid = false;
            hideAndShowPagamentoFields();

            vm.pagamentoQuantidadeParcelaDropdown = OrcamentoPropostaFactory.filterQuantidadeParcela(vm.proposta.formasPagamento.formaPagamento, vm.nomeFormaPagamento);
            if ($scope.orcamentoCtrl.isElaborar) {
                $scope.orcamentoCtrl.isElaborar = false;
                calcularParcela(true);
            }
        }

        function changeFormaPagamento() {

            if (vm.proposta.formasPagamento && vm.proposta.formasPagamento.formaPagamento) {
                var formaPagamentoAnterior = vm.proposta.formasPagamento.formaPagamento.filter(
                    function(forma) {
                        return forma.codigoFormaPagamento == vm.proposta.codigoFormaPagamento;
                    }
                ).shift();

                if (formaPagamentoAnterior) {
                    vm.nomeFormaPagamentoAnterior = formaPagamentoAnterior.nomeResumidoFormaPagamento;
                }
            }

            if (vm.nomeFormaPagamento) {
                if (vm.nomeFormaPagamento.substr(0, 2) === '97') {
                    if (vm.proposta.dadosPessoaSegurado && vm.proposta.dadosPessoaSegurado.numeroCnpjCpf) {
                        consultaCartoesPortoValidos(vm.proposta.dadosPessoaSegurado.numeroCnpjCpf.replace(/[^0-9]/g, ""), true);
                    }
                } else {
                    vm.pagamentoBandeiraDropdownTempholder = angular.copy(vm.pagamentoBandeiraDropdown);
                }
            }
            populateQuantidadeParcela(true);
        }

        function changeQuantidadeParcela() {

            if (vm.pagamentoCalcularParcela && vm.pagamentoCalcularParcela.nomeFormaPagamento == vm.nomeFormaPagamento) {
                vm.nomeFormaPagamentoAnterior = vm.nomeFormaPagamento;
            }

            calcularParcela(true);
        }


        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#getPessoaList
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method to get List of Pessoa to populate nome part on parcela grid.
         *
         **/
        function getPessoaList(proposta) {

            var codigos = [];

            angular.forEach(proposta, function(toget) {
                var notFound = true;
                angular.forEach(codigos, function(codigo) {
                    if (toget.codigoPessoa === codigo) {
                        notFound = false;
                        return false;
                    }
                });
                if (notFound) {
                    codigos.push(toget.codigoPessoa);
                }
                // Replaces the credit card number and validity to encrypted values.
                if (vm.proposta.cartoes && angular.isDefined(toget.codigoIdentificacaoCartao) && toget.codigoIdentificacaoCartao !== null) {
                    vm.proposta.cartoes.codigoIdentificacaoCartao = parseInt(toget.codigoIdentificacaoCartao);
                    // vm.proposta.cartoes.numeroCartao = toget.codigoIdentificacaoCartao;
                    vm.proposta.cartoes.mesValidadeCartao = '**';
                    vm.proposta.cartoes.anoValidadeCartao = '****';

                    if (vm.proposta.pagadores && vm.proposta.pagadores.pagador &&
                        vm.proposta.pagadores.pagador.length > 0 &&
                        vm.proposta.pagadores.pagador[0].pagadoresParcela &&
                        vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela &&
                        vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela.length > 0 &&
                        vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0]) {
                        if (vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoBandeiraCartao) {
                            vm.proposta.cartoes.bandeira = vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoBandeiraCartao;
                        } else if (vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoTipoCartao) {
                            vm.proposta.cartoes.bandeira = vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoTipoCartao;
                        }
                    }
                }
            });
            var topValue = 0;

            if (angular.isArray(codigos) && codigos.length > 0) {
                topValue = codigos.length;
            }

            PessoaService.getPessoaPorId(0, topValue, codigos)
                .then(

                    function(responsePessoa) {
                        vm.pessoas = OrcamentoPropostaFactory.convertPessoa(responsePessoa.data.listaPessoas.pessoa);

                        vm.pagamentoCalcularParcela =
                            OrcamentoPropostaFactory.convertPagadorParcelaVersaoProposta(proposta, vm.pessoas, vm.statusParcelas, vm.nomeFormaPagamento);
                        vm.showPagamentoDaParcelaGrid = true;

                        angular.forEach(vm.pagamentoCalcularParcela.grid, function(parcelaValue, parcelaKey) {
                            if (!parcelaValue.numeroParcelaVersao) {
                                parcelaValue.numeroParcelaVersao = parcelaKey;
                                for (var i = parcelaKey + 1; i < vm.pagamentoCalcularParcela.grid.length; i++) {
                                    if (parcelaValue.numeroParcela == vm.pagamentoCalcularParcela.grid[i].numeroParcela) {
                                        vm.pagamentoCalcularParcela.grid[i].numeroParcelaVersao = i;
                                    }
                                }
                            }
                        });
                        // Updates the currently created pagador parcelas
                        if (vm.proposta.cartoes) {
                            if (vm.proposta.cartoes.bandeira) {
                                vm.proposta.cartoes.codigoTipoCartao = vm.proposta.cartoes.bandeira;
                            } else {
                                if (vm.proposta.cartoes.codigoTipoCartao) {
                                    vm.proposta.cartoes.bandeira = vm.proposta.cartoes.codigoTipoCartao;
                                } else if (vm.proposta.pagadores && vm.proposta.pagadores.pagador &&
                                    vm.proposta.pagadores.pagador.length > 0 &&
                                    vm.proposta.pagadores.pagador[0].pagadoresParcela &&
                                    vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela &&
                                    vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela.length > 0 &&
                                    vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0]) {
                                    if (vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoBandeiraCartao) {
                                        vm.proposta.cartoes.bandeira = vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoBandeiraCartao;
                                    } else if (vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoTipoCartao) {
                                        vm.proposta.cartoes.bandeira = vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoTipoCartao;
                                    } else if(vm.proposta.codigoBandeiraCartao) {
                                        vm.proposta.cartoes.bandeira = vm.proposta.codigoBandeiraCartao;
                                    }
                                    vm.proposta.cartoes.codigoTipoCartao = vm.proposta.cartoes.bandeira;
                                }
                            }
                            // if (vm.nomeFormaPagamento == "97-CARTAO PORTO SEGURO") {
                            //     vm.proposta.cartoes.codigoTipoCartao = 1;
                            // } else if (vm.nomeFormaPagamento == "62-CARTAO DE CREDITO (TODAS PARC.EM CARTAO)") {
                            //     vm.proposta.cartoes.codigoTipoCartao = 2;
                            // }
                        }
                        var pagadorVersaoPropostas = OrcamentoPropostaFactory.convertGridPagadores(
                            vm.pagamentoCalcularParcela.grid, vm.pessoas, vm.proposta.cartoes);

                        var codigoEnderecoCobranca;
                        if (vm.proposta.pagadores && vm.proposta.pagadores.pagador && vm.proposta.pagadores.pagador.length > 0 &&
                            vm.proposta.pagadores.pagador[0].enderecoCobranca) {
                            codigoEnderecoCobranca = vm.proposta.pagadores.pagador[0].enderecoCobranca.codigoEndereco;
                        }
                        vm.proposta.pagadores.pagador = [];

                        if (pagadorVersaoPropostas) {
                            angular.forEach(pagadorVersaoPropostas, function(pagadorVersao) {
                                if (codigoEnderecoCobranca) {
                                    pagadorVersao.dadosPessoaPagadorParcela.codigoEndereco = codigoEnderecoCobranca;
                                } else if (vm.proposta.enderecoCobranca && vm.proposta.enderecoCobranca.codigoEndereco) {
                                    pagadorVersao.dadosPessoaPagadorParcela.codigoEndereco = vm.proposta.enderecoCobranca.codigoEndereco;
                                } else if (vm.proposta.enderecoCobranca && vm.proposta.enderecoCobranca.enderecosCadastrado) {
                                    pagadorVersao.dadosPessoaPagadorParcela.codigoEndereco = vm.proposta.enderecoCobranca.enderecosCadastrado;
                                }

                                var hasPagador = false;
                                angular.forEach(vm.proposta.pagadores.pagador, function(pag, index) {
                                    if (pag.dadosPessoaPagador &&
                                        pag.dadosPessoaPagador.codigoPessoa == pagadorVersao.dadosPessoaPagadorParcela.codigoPessoa) {
                                        vm.proposta.pagadores.pagador[index].pagadoresParcela.pagadorParcela.push(pagadorVersao);
                                        hasPagador = true;
                                    }
                                });
                                if (!hasPagador) {
                                    var pagadorObj = {
                                        dadosPessoaPagador: {
                                            codigoPessoa: pagadorVersao.dadosPessoaPagadorParcela.codigoPessoa
                                        },
                                        enderecoCobranca: {
                                            codigoEndereco: pagadorVersao.dadosPessoaPagadorParcela.codigoEndereco
                                        },
                                        pagadoresParcela: {
                                            pagadorParcela: [pagadorVersao]
                                        }
                                    };

                                    vm.proposta.pagadores.pagador.push(pagadorObj);
                                }
                            });
                        }

                        calcularParcela(false);
                        
                        if(vm.nomeFormaPagamento.indexOf("97") === 0 && vm.proposta.cartoes.bandeira) {
                            vm.pagamentoBandeiraDropdownTempholder = vm.pagamentoBandeiraDropdown.filter(function(itemCartao) {
                                return itemCartao.codigoValorDominio === vm.proposta.cartoes.bandeira;
                            });
                        }
                    },
                    function(error) {
                        displayError(error);
                    });
        }


        function incluirCartaoCredito(numeroCartao) {

            var params = {
                codigoOrigem: 1,
                numeroCartao: numeroCartao
            };

            if (vm.proposta.cartoes.anoValidadeCartao === '****') {
                vm.proposta.cartoes.anoValidadeCartao = "";
            }

            if (vm.proposta.cartoes.mesValidadeCartao === '**') {
                vm.proposta.cartoes.mesValidadeCartao = "";
            }

            var rangeNum = ['484635', '412177', '415274', '415275', '446690', '553659', '536380', '532930', '536537'];
            var BIN = numeroCartao ? numeroCartao.substr(0, 6) : null;
            if (BIN && rangeNum.indexOf(BIN) != -1) {
                vm.proposta.cartoes.codigoIdentificacaoCartao = null;
            } else {
                OrcamentoPropostaService.incluirDadosCartoesDeCredito(params).then(

                    function(response) {
                        if (angular.isObject(response.data)) {
                            vm.proposta.cartoes.codigoIdentificacaoCartao = response.data.codigoIdentificacaoCartaoCredito;
                        }
                    },
                    function(error) {
                        vm.proposta.cartoes.codigoIdentificacaoCartao = null;
                        displayError(error);
                    });
            }
        }

        function buscarCartaoCredito(codigoIdentificacaoCartao) {

            if (codigoIdentificacaoCartao) {
                var params = {
                    codigoOrigem: 1,
                    codigoIdentificacaoCartaoCredito: codigoIdentificacaoCartao
                };
                blockUI.start();
                OrcamentoPropostaService.consultarDadosCartaoDeCredito(params).then(
                    function(response) {
                        if (response.data) {
                            vm.proposta.cartoes = vm.proposta.cartoes ? vm.proposta.cartoes : {};
                            vm.proposta.cartoes.numeroCartao = response.data.numeroCartao;
                            vm.proposta.cartoes.codigoIdentificacaoCartao = response.data.codigoIdentificacaoCartaoCredito;

                            SelectedOpts.proposta.cartoes = SelectedOpts.proposta.cartoes ? SelectedOpts.proposta.cartoes : {};
                            SelectedOpts.proposta.cartoes.numeroCartao = vm.proposta.cartoes.numeroCartao;
                            SelectedOpts.proposta.cartoes.codigoIdentificacaoCartao = vm.proposta.cartoes.codigoIdentificacaoCartao;
                        }
                        blockUI.stop();
                    },
                    function(error) {
                        displayPreconditionError(Constants.MSG_ERROR_NOT_FOUND_CARD_CREDIT);
                        blockUI.stop();
                    });
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#calcularParcela
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon clicking calcular parcela
         *
         **/
        function calcularParcela(toCreate, codigoBandeira) {

            vm.isPagamentoFormSubmitted = true;

            if (OrcamentoUtilityFactory.isNullOrEmpty(vm.nomeFormaPagamento) ||
                OrcamentoUtilityFactory.isNullOrEmpty(vm.quantidadeParcela)) {
                if (!vm.proposta.dataMelhorDataPrimeiraParcela) {
                    vm.proposta.dataMelhorDataPrimeiraParcela = '';
                }
                vm.showPagamentoDaParcelaGrid = false;
            } else if (!OrcamentoUtilityFactory.isNullOrEmpty(vm.nomeFormaPagamento) &&
                !OrcamentoUtilityFactory.isNullOrEmpty(vm.quantidadeParcela)) {

                if (toCreate) {
                    calculatePagadorParcelaVersaoProposta(codigoBandeira);
                }

                hideAndShowPagamentoFields();
            } else {
                if (!vm.proposta.dataMelhorDataPrimeiraParcela) {
                    vm.proposta.dataMelhorDataPrimeiraParcela = '';
                }
                vm.showPagamentoDaParcelaGrid = false;
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#calculatePagadorParcelaVersaoProposta
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method to get List of Pessoa to populate nome part on parcela grid.
         *
         **/
        function calculatePagadorParcelaVersaoProposta(codigoBandeira) {

            vm.proposta.pagador = [];
            if (!OrcamentoUtilityFactory.isNullOrEmpty(vm.quantidadeParcela)) {

                var selectedFormaPagamento = getDetailsOfSelectedFormaPagamento();

                vm.codigoFormaPagamento = angular.copy(vm.proposta.codigoFormaPagamento);
                vm.pagamentoCalcularParcela.codigoFormaPagamento = selectedFormaPagamento.codigoFormaPagamento;
                vm.pagamentoCalcularParcela.quantidadeParcela = selectedFormaPagamento.quantidadeParcela;

                var pagadorParcelaVersaoProposta = OrcamentoPropostaFactory.convertBackPagadorParcelaVersaoProposta(
                    vm.proposta.numeroProposta, vm.proposta.numeroVersaoProposta, vm.proposta.dadosPessoaSegurado.codigoPessoa, vm.pagamentoCalcularParcela,
                    vm.proposta.dataMelhorDataPrimeiraParcela);

                OrcamentoPropostaService.createPagadorParcelaVersaoProposta(
                        vm.proposta.numeroProposta, vm.proposta.numeroVersaoProposta, pagadorParcelaVersaoProposta)
                    .then(

                        function(response) {
                            vm.proposta.codigoFormaPagamento = selectedFormaPagamento.codigoFormaPagamento;
                            vm.proposta.quantidadeParcela = selectedFormaPagamento.quantidadeParcela;
                            getPessoaListPagadores(response.data, codigoBandeira);
                        },
                        function(error) {
                            displayError(error);
                        });
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#getDetailsOfSelectedFormaPagamento
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Get the value of Selected Forma Pagamento.
         *
         **/
        function getDetailsOfSelectedFormaPagamento() {
            var selectedFormaPagamento = null;
            angular.forEach(vm.pagamentoQuantidadeParcelaDropdown, function(currentItem) {
                if (currentItem.quantidadeParcela === vm.quantidadeParcela &&
                    currentItem.nomeFormaPagamento === vm.nomeFormaPagamento) {
                    selectedFormaPagamento = currentItem;
                }
            });
            return selectedFormaPagamento;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#hideAndShowPagamentoFields
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * To Show or Hide Fields of Pagamento Panel.
         *
         **/
        function hideAndShowPagamentoFields() {
            var selectedFormaPagamento = $filter('filter')(vm.proposta.formasPagamento.formaPagamento, {
                nomeFormaPagamento: vm.nomeFormaPagamento
            }, true)[0];
            if (!vm.nomeFormaPagamento) {
                vm.isADC = false;
                vm.isCartao = false;
                vm.isDemais = false;
                vm.isBoleto = false;
                vm.isPagamentoBtnDisabled = false;
            } else if (selectedFormaPagamento) {
                vm.pagamentoCalcularParcela.flagPrimeiraCompraCartaoEmpresa = "N";
                if (((selectedFormaPagamento.codigoMeioPagamentoPrimeiraParcela && selectedFormaPagamento.codigoMeioPagamentoDemaisParcela) !== 8) &&
                    ((selectedFormaPagamento.codigoMeioPagamentoPrimeiraParcela && selectedFormaPagamento.codigoMeioPagamentoDemaisParcela) !== 9)) {
                    if (selectedFormaPagamento.codigoMeioPagamentoPrimeiraParcela === 2) {
                        vm.isADC = true;
                        vm.isCartao = false;
                        vm.isDemais = false;
                        vm.isBoleto = false;
                        vm.isPagamentoBtnDisabled = false;
                    } else if (selectedFormaPagamento.codigoMeioPagamentoPrimeiraParcela === 6) {
                        vm.isADC = false;
                        vm.isCartao = true;
                        vm.isDemais = false;
                        vm.isBoleto = false;
                        vm.isPagamentoBtnDisabled = false;

                        vm.proposta.cartoes.cpf = vm.proposta.dadosPessoaSegurado.numeroCnpjCpf;
                        vm.proposta.cartoes.nome = vm.proposta.dadosPessoaSegurado.nomePessoa;
                    } else if (selectedFormaPagamento.codigoMeioPagamentoPrimeiraParcela === 7) {
                        vm.isADC = false;
                        vm.isCartao = false;
                        vm.isDemais = true;
                        vm.isBoleto = false;
                        vm.isPagamentoBtnDisabled = false;
                    } else if (selectedFormaPagamento.codigoMeioPagamentoDemaisParcela === 1 ||
                        selectedFormaPagamento.codigoMeioPagamentoDemaisParcela === 4 ||
                        selectedFormaPagamento.codigoMeioPagamentoDemaisParcela === 5 ||
                        selectedFormaPagamento.codigoMeioPagamentoDemaisParcela === 3) {
                        vm.isADC = false;
                        vm.isCartao = false;
                        vm.isDemais = false;
                        vm.isBoleto = true;
                        vm.isPagamentoBtnDisabled = false;
                    }
                    codigoMeioPagamentoPrimeiraParcela = selectedFormaPagamento.codigoMeioPagamentoPrimeiraParcela;
                    //calcularParcela(true);
                }
            }
        }

        function getPessoaListPagadores(propostaArr, codigoBandeira) {
            var codigos = [];
            if (angular.isArray(propostaArr)) {
                codigos = propostaArr.map(function(proposta) {
                    return proposta.codigoPessoa;
                });
            }

            angular.forEach(propostaArr, function(toget) {
                if (vm.nomeFormaPagamento == vm.nomeFormaPagamentoAnterior || !vm.nomeFormaPagamentoAnterior) {
                    // Replaces the credit card number and validity to encrypted values.
                    if (vm.proposta.cartoes && angular.isDefined(toget.codigoIdentificacaoCartao) && toget.codigoIdentificacaoCartao !== null) {
                        vm.proposta.cartoes.codigoIdentificacaoCartao = parseInt(toget.codigoIdentificacaoCartao);
                        // vm.proposta.cartoes.numeroCartao = toget.codigoIdentificacaoCartao;
                        vm.proposta.cartoes.mesValidadeCartao = '**';
                        vm.proposta.cartoes.anoValidadeCartao = '****';

                        if (vm.proposta.pagadores && vm.proposta.pagadores.pagador &&
                            vm.proposta.pagadores.pagador.length > 0 &&
                            vm.proposta.pagadores.pagador[0].pagadoresParcela &&
                            vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela &&
                            vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela.length > 0 &&
                            vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0]) {
                            if (codigoBandeira) {
                                vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela.map(function(itemPagador) {
                                    itemPagador.codigoBandeiraCartao = codigoBandeira;
                                });
                            }
                            vm.proposta.cartoes.bandeira = vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoBandeiraCartao;
                        }
                    }
                } else {
                    toget.codigoBanco = null;
                    toget.codigoBandeira = null;
                    toget.numeroAgenciaBancaria = null;
                    toget.numeroContaBancaria = null;
                    toget.digitoContaBancaria = null;
                    toget.codigoIdentificacaoCartao = null;
                }
            });

            PessoaService.getPessoaPorId(0, codigos.length, codigos)
                .then(

                    function(responsePessoa) {
                        vm.pessoas = OrcamentoPropostaFactory.convertPessoa(responsePessoa.data.listaPessoas.pessoa);

                        vm.pagamentoCalcularParcela =
                            OrcamentoPropostaFactory.convertPagadorParcelaVersaoProposta(propostaArr, vm.pessoas, vm.statusParcelas, vm.nomeFormaPagamento);

                        angular.forEach(vm.pagamentoCalcularParcela.grid, function(parcelaValue, parcelaKey) {
                            if (!parcelaValue.numeroParcelaVersao) {
                                parcelaValue.numeroParcelaVersao = parcelaKey;
                                for (var i = parcelaKey + 1; i < vm.pagamentoCalcularParcela.grid.length; i++) {
                                    if (parcelaValue.numeroParcela == vm.pagamentoCalcularParcela.grid[i].numeroParcela) {
                                        vm.pagamentoCalcularParcela.grid[i].numeroParcelaVersao = i;
                                    }
                                }
                            }
                        });
                        vm.showPagamentoDaParcelaGrid = true;
                        // Updates the currently created pagador parcelas
                        if (vm.proposta.cartoes) {
                            if (vm.proposta.cartoes.bandeira) {
                                vm.proposta.cartoes.codigoTipoCartao = vm.proposta.cartoes.bandeira;
                            } else {
                                if (vm.proposta.cartoes.codigoTipoCartao) {
                                    vm.proposta.cartoes.bandeira = vm.proposta.cartoes.codigoTipoCartao;
                                } else if (vm.proposta.pagadores && vm.proposta.pagadores.pagador &&
                                    vm.proposta.pagadores.pagador.length > 0 &&
                                    vm.proposta.pagadores.pagador[0].pagadoresParcela &&
                                    vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela &&
                                    vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela.length > 0 &&
                                    vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0]) {
                                    if (vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoBandeiraCartao) {
                                        vm.proposta.cartoes.bandeira = vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoBandeiraCartao;
                                    } else if (vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoTipoCartao) {
                                        vm.proposta.cartoes.bandeira = vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoTipoCartao;
                                    }
                                    vm.proposta.cartoes.codigoTipoCartao = vm.proposta.cartoes.bandeira;
                                }
                            }
                            // if (vm.nomeFormaPagamento == "97-CARTAO PORTO SEGURO") {
                            //     vm.proposta.cartoes.codigoTipoCartao = 1;
                            // } else if (vm.nomeFormaPagamento == "62-CARTAO DE CREDITO (TODAS PARC.EM CARTAO)") {
                            //     vm.proposta.cartoes.codigoTipoCartao = 2;
                            // }
                        }
                        var pagadorVersaoPropostas = OrcamentoPropostaFactory.convertGridPagadores(vm.pagamentoCalcularParcela.grid, vm.pessoas, vm.proposta.cartoes);

                        var codigoEnderecoCobranca;
                        if (vm.proposta.pagadores && vm.proposta.pagadores.pagador && vm.proposta.pagadores.pagador.length > 0 &&
                            vm.proposta.pagadores.pagador[0].enderecoCobranca) {
                            codigoEnderecoCobranca = vm.proposta.pagadores.pagador[0].enderecoCobranca.codigoEndereco;
                        }

                        vm.proposta.pagadores.pagador = [];

                        if (pagadorVersaoPropostas) {
                            angular.forEach(pagadorVersaoPropostas, function(pagadorVersao) {
                                if (codigoEnderecoCobranca) {
                                    pagadorVersao.dadosPessoaPagadorParcela.codigoEndereco = codigoEnderecoCobranca;
                                } else if (vm.proposta.enderecoCobranca && vm.proposta.enderecoCobranca.codigoEndereco) {
                                    pagadorVersao.dadosPessoaPagadorParcela.codigoEndereco = vm.proposta.enderecoCobranca.codigoEndereco;
                                } else if (vm.proposta.enderecoCobranca && vm.proposta.enderecoCobranca.enderecosCadastrado) {
                                    pagadorVersao.dadosPessoaPagadorParcela.codigoEndereco = vm.proposta.enderecoCobranca.enderecosCadastrado;
                                }
                                var hasPagador = false;
                                angular.forEach(vm.proposta.pagadores.pagador, function(pag, index) {
                                    if (pag.dadosPessoaPagador && pag.dadosPessoaPagador.codigoPessoa ==
                                        pagadorVersao.dadosPessoaPagadorParcela.codigoPessoa) {
                                        vm.proposta.pagadores.pagador[index].pagadoresParcela.pagadorParcela.push(pagadorVersao);
                                        hasPagador = true;
                                    }
                                });
                                if (!hasPagador) {
                                    var pagadorObj = {
                                        dadosPessoaPagador: {
                                            codigoPessoa: pagadorVersao.dadosPessoaPagadorParcela.codigoPessoa
                                        },
                                        enderecoCobranca: {
                                            codigoEndereco: pagadorVersao.dadosPessoaPagadorParcela.codigoEndereco
                                        },
                                        pagadoresParcela: {
                                            pagadorParcela: [pagadorVersao]
                                        }
                                    };

                                    vm.proposta.pagadores.pagador.push(pagadorObj);
                                }
                            });
                        }

                        if (vm.nomeFormaPagamento && vm.nomeFormaPagamento.indexOf("52") == -1 &&
                            vm.nomeFormaPagamento.indexOf("97") == -1 && vm.nomeFormaPagamento.indexOf("62") == -1) {
                            if (vm.proposta.enderecoCobranca && (vm.proposta.enderecoCobranca.enderecosCadastrado || vm.proposta.enderecoCobranca.codigoEndereco)) {

                                var documentoEmissao = OrcamentoPropostaFactory.convertProposta(PageInfo.submissionObject);
                                var propostaForUpdate = {};
                                propostaForUpdate.documentoEmissao = documentoEmissao;
                                propostaForUpdate.documentoEmissao.codigoFormaPagamento = PageInfo.submissionObject.codigoFormaPagamento;

                                OrcamentoPropostaService.updateProposta(propostaForUpdate).then(
                                    function(response) {
                                        if (response && response.data &&
                                            response.data.documentoEmissao &&
                                            response.data.documentoEmissao.numeroVersaoProposta) {
                                            // Updates the version of proposta if the response version is greater than current.
                                            var updatedversion = response.data.documentoEmissao.numeroVersaoProposta;
                                            if (updatedversion > vm.proposta.numeroVersaoProposta) {
                                                vm.proposta.numeroVersaoProposta = updatedversion;
                                                vm.proposta.dataProtocolo = null;
                                                if ($scope.orcamentoCtrl.proposta) {
                                                    $scope.orcamentoCtrl.proposta.numeroVersaoProposta = updatedversion;
                                                    $scope.orcamentoCtrl.proposta.dataProtocolo = null;
                                                }
                                                $scope.orcamentoCtrl.tabVersion = updatedversion;
                                                PageInfo.submissionObject.numeroVersaoProposta = updatedversion;
                                                PageInfo.submissionObject.dataProtocolo = null;
                                                SelectedOpts.proposta.numeroVersaoProposta = updatedversion;
                                                SelectedOpts.proposta.dataProtocolo = null;
                                            }
                                        }

                                        SelectedOpts.isSavePressed = false;
                                        getPagamentoCalcularParcela();
                                    },
                                    function(error) {
                                        displayError(error);
                                    });
                            }
                        }

                        calcularParcela(false);
                    },
                    function(error) {
                        displayError(error);
                    });
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#openPagadorParcelaModal
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Instantiate modal and get all versions
         *
         **/
        function openPagadorParcelaModal(numeroParcela, isEmitir, savedProposta, editorFlag, item) {
            if (!vm.flagFilterBanco) {
                if (vm.pagamentoCalcularParcela.grid && vm.pagamentoCalcularParcela.grid.length > 0) {
                    var possuiBancoAtivo = false;
                    var bancosAtivos = [];
                    vm.bancoOptions.map(function(itemBanco) {
                        possuiBancoAtivo = false;
                        vm.pagamentoCalcularParcela.grid.map(function(itemPagador) {
                            if (itemPagador.codigoBanco && itemBanco.flagAtivo === 'N') {
                                if (itemBanco.codigoBanco === itemPagador.codigoBanco) {
                                    possuiBancoAtivo = true;
                                }
                            } else if (itemBanco.flagAtivo === 'S') {
                                possuiBancoAtivo = true;
                            }
                        });
                        if (possuiBancoAtivo) {
                            bancosAtivos.push(itemBanco);
                        }
                    });
                }
                vm.bancoOptions = bancosAtivos;
                vm.flagFilterBanco = true;
            }

            var modalInstance = $modal.open({
                animation: true,
                size: 'lg',
                backdrop: 'static',
                keyboard: false,
                templateUrl: 'proposta.pagadorparcelamodal.html',
                controllerAs: 'modalPropostaCtrl',
                controller: ['$modalInstance', function($modalInstance) {

                    var mod = this;
                    var index = index;
                    mod.parcela = [];
                    mod.parcela.codigoTipoPessoa = '';
                    mod.isFisica = false;
                    mod.isJuridica = false;
                    mod.tipoPessoaDropdown = vm.tipoPessoaOptions;
                    mod.isAdcPagamentoFormSubmitted = false;
                    mod.pagadorVersaoProposta = [];
                    mod.pessoaSeguro = {};
                    mod.alerts = [];
                    mod.index = null;

                    mod.isEmitir = isEmitir;
                    mod.savedProposta = savedProposta;
                    mod.editorFlag = editorFlag;

                    mod.changeTipoPessoa = changeTipoPessoa;
                    changeTipoPessoa();

                    //SM 816
                    mod.checkTipoPgto = false;

                    if (vm.nomeFormaPagamento.indexOf('ADC') < 0) {
                        mod.checkTipoPgto = true;
                    }

                    mod.maskCPFwithinOneObject = maskCPFwithinOneObject;
                    mod.maskCNPJwithinOneObject = maskCNPJwithinOneObject;

                    mod.bancoOptions = vm.bancoOptions;

                    mod.activate = function() {
                        angular.forEach(vm.pagamentoCalcularParcela.grid, function(parcela, index) {
                            if (item.numeroParcela === parcela.numeroParcela &&
                                item.codigoPessoa === parcela.codigoPessoa) {
                                mod.parcela = angular.copy(vm.pagamentoCalcularParcela.grid[index]);
                                mod.index = index;
                            }
                        });
                    };

                    mod.closeAlert = function(index) {
                        mod.alerts.splice(index, 1);
                    };

                    mod.fechar = function() {
                        $modalInstance.dismiss('fechar');
                    };

                    mod.checkParcelaModalMandatory = function() {
                        var hasError = mod.parcelaForm.$invalid;
                        mod.isEmptyCpf = false;
                        mod.isEmptyCnpj = false;

                        if (Constants.CODIGO_TIPO_PESSOA.FISICA === mod.parcela.codigoTipoPessoa) {
                            if (!mod.parcela.cpf) {
                                mod.isEmptyCpf = true;
                                hasError = true;
                            }
                        }

                        if (Constants.CODIGO_TIPO_PESSOA.JURIDICA === mod.parcelaForm.cnpj.$invalid) {
                            if (!mod.parcela.cnpj) {
                                mod.isEmptyCnpj = true;
                                hasError = true;
                            }
                        }

                        mod.isAdcPagamentoFormSubmitted = true;

                        return hasError;
                    };

                    mod.salvar = function() {
                        if (vm.proposta.codigoRamo === 1101 && vm.proposta.codigoFormaPagamento === 35001) {
                            var dadosPagadorParcelaAgro = mod.parcela;
                        }

                        if (mod.checkParcelaModalMandatory()) {
                            mod.addAlert(Constants.ERROR_TYPE, Constants.MSG_ERROR_SAVE);
                        } else if (!OrcamentoPropostaValidator.validateProposta(vm.proposta, true) && !(vm.proposta.codigoRamo === 1101 && vm.proposta.codigoFormaPagamento === 35001)) {
                            vm.pagamentoCalcularParcela.grid[mod.index] = angular.copy(mod.parcela);
                            vm.isFormSubmitted = true;
                            SelectedOpts.isSavePressed = true;
                            $modalInstance.close('confirmado');
                            displayPreconditionError(Constants.MSG_ERROR_SAVE);
                        } else if (!OrcamentoPropostaValidator.validateProposta(vm.proposta, true, null, null, null, dadosPagadorParcelaAgro) && (vm.proposta.codigoRamo === 1101 && vm.proposta.codigoFormaPagamento === 35001)) {
                            vm.pagamentoCalcularParcela.grid[mod.index] = angular.copy(mod.parcela);
                            vm.isFormSubmitted = true;
                            SelectedOpts.isSavePressed = true;
                            $modalInstance.close('confirmado');
                            displayPreconditionError(Constants.MSG_ERROR_SAVE);
                        } else {

                            var numeroCnpjCpf;
                            var pessoa = {};

                            if (mod.parcela.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA) {
                                numeroCnpjCpf = OrcamentoPropostaFactory.removeFormat(mod.parcela.cpf);
                            } else {
                                numeroCnpjCpf = OrcamentoPropostaFactory.removeFormat(mod.parcela.cnpj);
                            }

                            if (numeroCnpjCpf === OrcamentoPropostaFactory.removeFormat(vm.proposta.dadosPessoaSegurado.numeroCnpjCpf)) {

                                if (mod.parcela.nomePessoa !== vm.proposta.dadosPessoaSegurado.nomePessoa) {
                                    vm.proposta.dadosPessoaSegurado.nomePessoa = mod.parcela.nomePessoa;
                                    var pessoaToUpdate = OrcamentoPropostaFactory.createPessoaToUpdate(vm.proposta.dadosPessoaSegurado);
                                    PessoaService.updatePessoa(pessoaToUpdate);
                                }
                                mod.createPagadorVersao(vm.proposta.dadosPessoaSegurado, vm.proposta.dadosPessoaSegurado.codigoPessoa);

                            } else {
                                //Prepare to create new Pessoa
                                var converted = {};
                                converted.pessoa = OrcamentoPropostaFactory.convertPessoaForCreate(mod.parcela);

                                /*Method to check numeroCpfCnpj and return Pessoa or create Pessoa*/
                                PessoaService.createPessoa(converted.pessoa)
                                    .then(

                                        function(response) {
                                            var pessoaItems = [];
                                            if (response.data.listaPessoas) {
                                                pessoaItems.push(response.data.listaPessoas.pessoa);
                                                pessoa = PessoaFactory.convertPessoaSeguro(pessoaItems,
                                                    vm.tipoDocumentoPessoaOptions,
                                                    vm.tipoEnderecoOptions,
                                                    vm.tipoContatoOptions,
                                                    vm.tipoLogradouroOptions,
                                                    vm.unidadeFederacaoOptions);
                                            } else {
                                                pessoaItems.push(response.data.pessoa);
                                                pessoa = PessoaFactory.convertPessoaSeguro(pessoaItems,
                                                    vm.tipoDocumentoPessoaOptions,
                                                    vm.tipoEnderecoOptions,
                                                    vm.tipoContatoOptions,
                                                    vm.tipoLogradouroOptions,
                                                    vm.unidadeFederacaoOptions);
                                            }

                                            mod.createPagadorVersao(pessoa, mod.parcela.codigoPessoa);
                                        },
                                        function(error) {
                                            mod.addPessoaAlert(error);
                                        });
                            }
                        }
                    };

                    function getPagadorIndex(codigoPessoa) {
                        var pagadorIndex;
                        var pagador = vm.proposta.pagadores.pagador;
                        var codigosPagadores = pagador.map(function(item) {
                            return item.dadosPessoaPagador.codigoPessoa;
                        });
                        return codigosPagadores.indexOf(codigoPessoa);
                    }

                    mod.createPagadorVersao = function(createdPessoa, codigoPessoaAnterior) {
                        vm.pessoasGrid = [];
                        var pagadorVersaoPropostas =
                            OrcamentoPropostaFactory.convertBackPagadorParcelaVersaoPropostaForUpdate(
                                vm.pagamentoCalcularParcela.grid, mod.parcela, numeroParcela, createdPessoa, vm.proposta.dadosPessoaSegurado, null, vm.pessoasGrid);
                        if (pagadorVersaoPropostas) {
                            vm.proposta.pagadores.pagador = OrcamentoPropostaFactory.ajustaPagadorParcela(pagadorVersaoPropostas, vm.proposta.enderecoCobranca);
                            vm.pagamentoCalcularParcela = OrcamentoPropostaFactory.ajustaGrid(pagadorVersaoPropostas, vm.pagamentoCalcularParcela, vm.pessoasGrid, vm.statusParcelas);
                        }

                        var documentoEmissao = OrcamentoPropostaFactory.convertProposta(PageInfo.submissionObject);
                        var propostaForUpdate = {};
                        propostaForUpdate.documentoEmissao = documentoEmissao;
                        propostaForUpdate.documentoEmissao.codigoFormaPagamento = PageInfo.submissionObject.codigoFormaPagamento;

                        OrcamentoPropostaService.updateProposta(propostaForUpdate).then(

                            function(response) {
                                if (response &&
                                    response.data &&
                                    response.data.documentoEmissao &&
                                    response.data.documentoEmissao.numeroVersaoProposta) {
                                    // Updates the version of proposta if the response version is greater than current.
                                    var updatedversion = response.data.documentoEmissao.numeroVersaoProposta;
                                    if (updatedversion > vm.proposta.numeroVersaoProposta) {
                                        vm.proposta.numeroVersaoProposta = updatedversion;
                                        vm.proposta.dataProtocolo = null;
                                        if ($scope.orcamentoCtrl.proposta) {
                                            $scope.orcamentoCtrl.proposta.numeroVersaoProposta = updatedversion;
                                            $scope.orcamentoCtrl.proposta.dataProtocolo = null;
                                        }
                                        $scope.orcamentoCtrl.tabVersion = updatedversion;
                                        PageInfo.submissionObject.numeroVersaoProposta = updatedversion;
                                        PageInfo.submissionObject.dataProtocolo = null;
                                        SelectedOpts.proposta.numeroVersaoProposta = updatedversion;
                                        SelectedOpts.proposta.dataProtocolo = null;
                                    }
                                }

                                $modalInstance.close('confirmado');
                                vm.isFormSubmitted = false;
                                SelectedOpts.isSavePressed = false;
                                getPagamentoCalcularParcela();
                            },
                            function(error) {
                                displayError(error);
                                $modalInstance.close('confirmado');
                            });
                    };

                    mod.addAlert = function(type, message, trid) {
                        mod.alerts = [];
                        mod.alerts.push({
                            type: type,
                            msg: message,
                            trid: trid
                        });
                    };

                    mod.addPessoaAlert = function(error) {
                        mod.alerts = [];
                        switch (error.status) {
                            case Constants.HTTP_FORBIDDEN:
                                var errorMessage = Constants.MSG_ERROR_FORBIDDEN + ' ' +
                                    nomeDoServico + '.' + error.config.method;
                                mod.alerts.push({
                                    type: Constants.ERROR_TYPE,
                                    msg: errorMessage
                                });
                                break;
                            case Constants.HTTP_CONFLICT:
                                mod.alerts.push({
                                    type: Constants.ERROR_TYPE,
                                    msg: error.data.mensagens[0].mensagem
                                });
                                break;
                            case Constants.HTTP_PREREQUISITE:
                                mod.alerts.push({
                                    type: Constants.ERROR_TYPE,
                                    msg: error.data.mensagens[0].mensagem
                                });
                                break;
                            case Constants.HTTP_BAD_REQUEST:
                                mod.alerts.push({
                                    type: Constants.ERROR_TYPE,
                                    msg: error.data.mensagens[0].mensagem
                                });
                                break;
                            default:
                                if (angular.isDefined(error.data)) {
                                    var mensagens = error.data.mensagens;

                                    if (angular.isDefined(mensagens) && angular.isDefined(mensagens[2]) &&
                                        angular.isDefined(mensagens[2].mensagem)) {
                                        if (Constants.MSG_ERROR_NOT_FOUND !== mensagens[2].mensagem) {
                                            mod.alerts.push({
                                                type: Constants.ERROR_TYPE,
                                                msg: error.data.mensagens[2].mensagem
                                            });
                                        }
                                    }
                                }
                                break;
                        }
                    };

                    function checkMandatoryFields() {
                        var hasError;

                        var formAttributesValidation = {
                            banco: mod.parcelaForm.banco.$invalid,
                            agencia: mod.parcelaForm.agencia.$invalid,
                            contaCorrente: mod.parcelaForm.contaCorrente.$invalid,
                            tipoPessoa: mod.parcelaForm.tipoPessoa.$invalid,
                            nome: mod.parcelaForm.nome.$invalid
                        };

                        angular.forEach(formAttributesValidation, function(value, key) {
                            if (value) {
                                hasError = true;
                            }
                        });

                        return hasError;
                    }

                    mod.open = function($event) {
                        $event.preventDefault();
                        $event.stopPropagation();
                    };

                    function changeTipoPessoa() {
                        if (Constants.CODIGO_TIPO_PESSOA.FISICA === mod.parcela.codigoTipoPessoa) {
                            mod.isFisica = true;
                            mod.isJuridica = false;
                            mod.parcela.cnpj = null;
                            mod.parcela.nomePessoa = null;
                        } else if (Constants.CODIGO_TIPO_PESSOA.JURIDICA === mod.parcela.codigoTipoPessoa) {
                            mod.isJuridica = true;
                            mod.isFisica = false;
                            mod.parcela.cpf = null;
                            mod.parcela.nomePessoa = null;
                        } else {
                            mod.isFisica = false;
                            mod.isJuridica = false;
                        }
                    }

                    function maskCPFwithinOneObject(firstObjectName, secondObjectName, e) {
                        mod[firstObjectName][secondObjectName] = maskCPF(mod[firstObjectName][secondObjectName], e);
                    }

                    function maskCNPJwithinOneObject(firstObjectName, secondObjectName, e) {
                        mod[firstObjectName][secondObjectName] = maskCNPJ(mod[firstObjectName][secondObjectName], e);
                    }

                    mod.activate();

                }]
            });
        }

        //--------------------------------------------END OF PAGAMENTO-------------------------------------------//

        //------------------------------------------DADOS DO SEGURO--------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#populateDadosSeguro
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to populate Dadoown = OrcamentoPropostaFactory.convertFlagEnvioEmailCorretorDropdown();
        	/*jshint sub:true*/
        function populateDadosSeguro() {
            vm.envioEmailCorretorDropdown = OrcamentoPropostaFactory.convertFlagEnvioEmailCorretorDropdown();
            vm.envioEmailCorretorImobiliariaDropdown = OrcamentoPropostaFactory.convertFlagEnvioEmailCorretorImobiliariaDropdown();
            
            blockUI.start();
            DominiosService.getDominio(Dominios['TIPO_DESTINARIO'].codigo, Dominios['TIPO_DESTINARIO'].cache)
                .then(function(response) {
                	var responseFiltered = response;
                		if(vm.proposta.codigoOferta != "1028" && vm.proposta.codigoOferta != "1029") {
                			var responseFiltered = $filter('filter')(response, {"codigoValorDominio": "!5"});
                		}
                        vm.destEnFisSegViaDocumentoDropdown = responseFiltered;
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['TIPO_SEGURO'].codigo, Dominios['TIPO_SEGURO'].cache)
                .then(function(response) {
                        vm.tipoSeguroDropdown = response;
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['TIPO_ENDOSSO'].codigo, Dominios['TIPO_ENDOSSO'].cache)
                .then(function(response) {
                        vm.tipoEndossoDropdown = response;
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['ORIGEM_RENOVACAO'].codigo, Dominios['ORIGEM_RENOVACAO'].cache)
                .then(function(response) {
                        vm.tipoOrigemRenovacaoDropdown = response;
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });

            OnusService.getOnusList('', '', "S", 0, 200).then(function(response) {
                vm.onusDropdown = $filter('orderBy')(response.data.onus, ['nomeOnus']);
            });
            blockUI.start();
            DominiosService.getDominio(Dominios['CANAL'].codigo, Dominios['CANAL'].cache)
                .then(function(response) {
                        vm.canalDropdown = response;
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            MoedaService.getActiveMoedasByEmpresa(codigoEmpresa)
                .then(function(response) {
                        vm.moedaDropdown = $filter('orderBy')(response.data, ['nomeMoeda']);
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['TIPO_CALCULO'].codigo, Dominios['TIPO_CALCULO'].cache)
                .then(function(response) {
                        vm.tipoCalculoDropdown = response;
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            blockUI.start();
            DominiosService.getDominio(Dominios['TIPO_CLASSIFICACAO_PESSOA'].codigo, Dominios['TIPO_CLASSIFICACAO_PESSOA'].cache)
                .then(function(response) {
                        vm.tipoClassificacaoDropdown = response;
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
            var dataInicioVigencia = $filter('date')(new Date(), 'yyyy/MM/dd');
            var codigoOferta = vm.proposta.orcamento.codigoOferta;
            blockUI.start();
            OperacaoService.getOperacaoList(0, codigoEmpresa, codigoOferta, dataInicioVigencia)
                .then(function(response) {
                        vm.codigoOperacaoDropdown = $filter('orderBy')(response.data, ['codigoOperacao']);
                        blockUI.stop();
                    },

                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });

            //vm.dadosSegurado = OrcamentoPropostaFactory.convertDadosDoSeguro();
        }

        //--------------------------------------END OF DADOS DO SEGURADO-----------------------------------------//

        //-------------------------------------------DADOS DO SEGURADO----------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#populateDados
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to populate fields under Dados do Segurado
         *
         **/
        function populateDados() {

            // PLEASE CHECK SOME OF THE DROPDOWNS HERE SINCE SOME
            // OF THESE DOMINIO SERVICES WERE ALREADY
            // LOADED UPON ACTIVATE. PLEASE REUSE THEM.

            vm.dados = OrcamentoPropostaFactory.convertDados();
            vm.tipoDocumentoDropdown = OrcamentoPropostaFactory.convertTipoDocumento();
            vm.faixaDeRendaDropdown = OrcamentoPropostaFactory.convertFaixaDeRenda();
            //vm.tipoClassificacaoDropdown = OrcamentoPropostaFactory.convertTipoClassificacao();
            vm.profissaoDropdown = OrcamentoPropostaFactory.convertProfissao();
            vm.pessoaExpostaDropdown = OrcamentoPropostaFactory.convertPessoaExposta();
            vm.paisResidenteDropdown = OrcamentoPropostaFactory.convertPaisResidente();
            vm.sexoDropdown = OrcamentoPropostaFactory.convertSexo();
            vm.atividadeDropdown = OrcamentoPropostaFactory.convertAtividade();
            vm.classeProfissionalDropdown = OrcamentoPropostaFactory.convertClasseProfissional();
            // vm.grauRelacionamentoDropdown = OrcamentoPropostaFactory.convertGrauRelacionamento();
            vm.classeTipoDocDropdown = OrcamentoPropostaFactory.convertClasseTipoDoc();
            vm.enderecoTipoLogradouroDropdown = OrcamentoPropostaFactory.convertEnderecoTipoLogradouro();
            vm.tipoContatoDropdown = OrcamentoPropostaFactory.convertTipoContato();
            vm.tipoContatoList = OrcamentoPropostaFactory.convertTipoContatoList(vm.dados, vm.tipoContatoDropdown);
            vm.possuiControladorDropdown = OrcamentoPropostaFactory.convertPossuiControlador();
            vm.tipoVinculoDropdown = OrcamentoPropostaFactory.convertTipoVinculo();
            vm.getDefaultDadosSegurado = OrcamentoPropostaFactory.defaultDadosSegurado();
            vm.contatoPessoaExpostaDropDown = OrcamentoPropostaFactory.convertContatoPessoaExpostaDropDown();
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#changeFisicaPessoaExposta
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon change in Pessoa Exposta dropdown. This method controls the visibility of some fields depending
         * on the value of flagVinculoPessoaExpostaPoliticamente.
         *
         **/
        function changeFisicaPessoaExposta() {
            if (vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoTipoExposicaoPessoa == 3) {
                vm.isRelacionamentoProximo = true;
            } else {
                vm.isRelacionamentoProximo = false;

                // SM 1082 - Alterar regra de preenchimento dos campos de pessoa em proposta
                if (vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoTipoExposicaoPessoa == Constants.CODIGO_PESSOA_POLITICAMENTE_EXPOSTA) {
                    vm.isPoliticamenteExposta = true;
                } else {
                    vm.isPoliticamenteExposta = false;
                }
                // end
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#changeDadosDeContatoPessoaExposta
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon change in Pessoa Exposta dropdown. This method controls the visibility of some fields depending
         * on the value of flagVinculoPessoaExpostaPoliticamente.
         *
         **/
        function changeDadosDeContatoPessoaExposta() {
            if (3 === vm.getDefaultDadosSegurado.controladores.pessoaExpostaPoliticamente.flagVinculoPessoaExpostaPoliticamente) {
                vm.isDadosDeContatoRelacionamentoProximo = true;
            } else {
                vm.isDadosDeContatoRelacionamentoProximo = false;
            }
        }

        function changePossuiCossegurado() {
            if (vm.getDefaultDadosSegurado.cossegurado.flagPossuiCossegurado == "N") {
                vm.flagPermissaoMultiploSegurado = false;
                vm.getDefaultDadosSegurado.cossegurado.codigoTipoPessoa = null;
                vm.getDefaultDadosSegurado.cossegurado.numeroCnpjCpf = null;
                vm.getDefaultDadosSegurado.cossegurado.nomePessoa = null;
                vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.flagPessoaExposta = 2;
                vm.cossegurado.cossegurados = [];
                changePessoaExposta();
            }
        }

        function changePossuiCossegurado_() { // TODO - rever esse metodo duplicado
            if (vm.getDefaultDadosSegurado.cossegurado.flagPossuiCossegurado == "N") {
                vm.flagPermissaoMultiploSegurado = false;
                vm.getDefaultDadosSegurado.cossegurado.codigoTipoPessoa = null;
                vm.getDefaultDadosSegurado.cossegurado.numeroCnpjCpf = null;
                vm.getDefaultDadosSegurado.cossegurado.nomeInterveniente = null;
                vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.flagPessoaExposta = 2;
                vm.isCosseguradoFormSubmitted = false;
            }
        }

        //validação troca de modalidade na proposta- aplicação da regra de negocio GR.RN.034
        function validacaoTrocaModalidadeProposta() {
            //validação conssegurado
            if (vm.getDefaultDadosSegurado.cossegurado.flagPossuiCossegurado == "S") {
                vm.getDefaultDadosSegurado.cossegurado.flagPossuiCossegurado = "N";
                vm.cossegurado.cossegurados = [];
                vm.getDefaultDadosSegurado.cossegurado.codigoTipoPessoa = null;
                vm.getDefaultDadosSegurado.cossegurado.numeroCnpjCpf = null;
                vm.getDefaultDadosSegurado.cossegurado.nomePessoa = null;
                vm.getDefaultDadosSegurado.editorFlag = true;

            }
            //validação forma de pagamento
            vm.pagamentoCalcularParcela = [];
            vm.proposta.codigoFormaPagamento = null;
            vm.proposta.codigoFormaPagamentoTempHolder = null;
            vm.proposta.quantidadeParcela = null;
        }

        //fim validação troca de modalidade

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#changeTipoPessoa
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon change in Tipo Pessoa dropdown. This method controls the visibility of some fields depending
         * on the value of isFisica.
         *
         **/
        function changeTipoPessoa() {
            if (vm.dados.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA) {
                vm.isFisica = true;
            } else if (vm.dados.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.JURIDICA) {
                vm.isFisica = false;
            }
        }



        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#changeTipoPessoa
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon change in Tipo Pessoa dropdown. This method controls the visibility of some fields depending
         * on the value of isFisica.
         *
         **/
        function changePessoaExposta() {
            if (vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.flagPessoaExposta === 1 ||
                vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.flagPessoaExposta === 2 ||
                vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.flagPessoaExposta === 3) {
                vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.numeroCnpjCpfPessoaExposto = null;
                vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.nomePessoaExposto = null;
                vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.grauRelacionamento = null;
                vm.isDropDownContatoPessoaExpostaEmpty = false;
            } else {
                vm.isDropDownContatoPessoaExpostaEmpty = true;
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#changeTipoPessoaModal
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon change in Tipo Pessoa dropdown inside the modal.
         * This method controls the visibility of some fields depending on the value of isFisicaModal.
         *
         **/
        function changeTipoPessoaModal() {
            if (vm.cossegurado.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA) {
                vm.isFisicaModal = true;
            } else if (vm.cossegurado.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.JURIDICA) {
                vm.isFisicaModal = false;
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#changeContatoCosegTipoPessoa
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon change in contato Coseg Tipo Pessoa.
         *
         **/
        function changeContatoCosegTipoPessoa() {
            if (vm.getDefaultDadosSegurado.cossegurado.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA) {
                vm.getDefaultDadosSegurado.cossegurado.numeroCnpjCpf = null;
                vm.isFisicaContatoCoseg = true;
            } else if (vm.getDefaultDadosSegurado.cossegurado.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.JURIDICA) {
                vm.getDefaultDadosSegurado.cossegurado.numeroCnpjCpf = null;
                vm.isFisicaContatoCoseg = false;
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#changeTipoContato
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon change in Tipo Contato
         *
         **/
        function changeTipoContato() {
            if (vm.getDefaultDadosSegurado.contatos.codigoTipoContato === 1 ||
                vm.getDefaultDadosSegurado.contatos.codigoTipoContato === 2) {
                vm.isTelefone = true;
            } else {
                vm.isTelefone = false;
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#openDatePicker
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to open/close the date picker
         *
         **/
        function openDatePicker($event, datepicker) {
            $event.preventDefault();
            $event.stopPropagation();

            vm.dataEmissaoOpened = datepicker === Constants.DATE_EMISSAO;
            vm.dataValidadeOpened = datepicker === Constants.DATE_VALIDADE;
            vm.dadosDataNascimento = datepicker === Constants.DATE_NASCIMENTO;
            vm.dataregistroaberturaOpen = datepicker === Constants.DATE_REGISTROABERTURA;
        }

        //------- SAVE FUNCTIONS IN DADOS DO SEGURADO-----------
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#salvarDocComplementares
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon clicking salvar of Doc Complementares
         *
         **/
        function salvarDocComplementares() {
            checkDadosSeguradoMandatoryField(); //(Doc Complementares) --includes temporary checking for mandatory fields in Dados do segurado
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#salvarDadosDoEndereco
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon clicking salvar of Dados do Endereco
         *
         **/
        function salvarDadosDoEndereco() {
            checkDadosEnderecoMandatoryField();
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#salvarControllador
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon clicking salvar of Dados do Endereco
         *
         **/
        function salvarControllador() {

            if (checkControlladorMandatoryField()) {
                displayPreconditionError(Constants.MSG_ERROR_SAVE);
                return;
            }

            if (vm.getDefaultDadosSegurado.controladores.numeroCnpjCpf) {
                if (!(vm.getDefaultDadosSegurado.controladores.numeroCnpjCpf === "")) {
                    vm.getDefaultDadosSegurado.controladores.codigoMotivoAusenciaCnpjCpf = "";
                }
            }

            var numeroProposta = vm.proposta.numeroProposta;
            var numeroVersaoProposta = vm.proposta.numeroVersaoProposta;
            var codigoTipoInterveniente = vm.getDefaultDadosSegurado.controladores.codigoTipoInterveniente;
            var intervenienteVersaoProposta = OrcamentoPropostaFactory.convertBackIntervenienteVersaoProposta(
                codigoTipoInterveniente, numeroProposta, numeroVersaoProposta, vm.getDefaultDadosSegurado.controladores, false);
            OrcamentoPropostaService.createInterveniente(
                    numeroProposta, numeroVersaoProposta, intervenienteVersaoProposta)
                .then(

                    function(response) {
                        $rootScope.$broadcast(Constants.SUCCESSO, Constants.MSG_SUCCESS_SAVE);
                        setDefaultValueControlador();
                        vm.isControlladorFormSubmitted = false;
                        populateControladores();
                    },
                    function(error) {
                        displayError(error);
                    });
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#solicitarCartao
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon clicking salvar of Dados do Endereco
         *
         **/
        function solicitarCartao() {
            checkCartaoMandatoryField();
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#salvarDadosDoEnderecoJuridica
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon clicking salvar of Dados Do Endereco Juridica
         *
         **/
        function salvarDadosDoEnderecoJuridica() {
            checkDadosEnderecoJuridicaMandatoryField();
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#salvarDadosDeContato
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon clicking salvar of Dados De Contato
         *
         **/
        function salvarDadosDeContato() {
            checkDadosContatoMandatoryField();
            // checkCosseguradoMandatoryField(); //temporary checking for mandatory in Cossegurado
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#salvarDadosDeContatoJuridica
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon clicking salvar of Dados De Contato Juridica
         *
         **/
        function salvarDadosDeContatoJuridica() {
            checkDadosContatoJuridicaMandatoryField();
        }

        //-----end of SAVE functions--------------

        //------CHECK MANDATORY FIELDS in DADOS DO SEGURADO FORM --------------
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#checkDadosSeguradoMandatoryField
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to check mandatory field in Dados Segurado
         *
         **/
        function checkDadosSeguradoMandatoryField() {
            vm.isDadosFormSubmitted = true;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#checkDadosEnderecoMandatoryField
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to check mandatory field in Endereco
         *
         **/
        function checkDadosEnderecoMandatoryField() {
            vm.isDadosEnderecoFormSubmitted = true;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#checkControlladorMandatoryField
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to check mandatory field in Controllador
         *
         **/
        function checkControlladorMandatoryField() {
            vm.isControlladorFormSubmitted = true;
            var numeroError = false;
            var hasError = vm.controladorJuridicaForm.$invalid;
            var expostaHasError = false;
            var noExpostaSelection = false;
            var razoError = false;

            if (vm.getDefaultDadosSegurado.controladores.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA &&
                vm.getDefaultDadosSegurado.controladores.pessoaExpostaPoliticamente.flagVinculoPessoaExpostaPoliticamente === 3) {

                expostaHasError = (isNullEmptyOrUndefined(vm.controladorJuridicaForm.controladoresNumeroCpf.$viewValue) ||
                    isNullEmptyOrUndefined(vm.controladorJuridicaForm.pessoaExpostaNomePessoaVinculo.$viewValue) ||
                    isNullEmptyOrUndefined(vm.controladorJuridicaForm.pessoaExpostaGrauRelacionamentoOptions.$viewValue));
            }

            if (vm.getDefaultDadosSegurado.controladores.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA) {
                if (vm.getDefaultDadosSegurado.controladores.codigoMotivoAusenciaCnpjCpf != 3) {
                    numeroError = isNullEmptyOrUndefined(vm.controladorJuridicaForm.pessoaFisicaNumeroCnpjCpf.$viewValue);
                }
                noExpostaSelection = isNullEmptyOrUndefined(vm.getDefaultDadosSegurado.controladores.pessoaExpostaPoliticamente.flagVinculoPessoaExpostaPoliticamente);

            } else if (vm.getDefaultDadosSegurado.controladores.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.JURIDICA) {
                if (vm.getDefaultDadosSegurado.controladores.codigoMotivoAusenciaCnpjCpf != 3) {
                    numeroError = isNullEmptyOrUndefined(vm.controladorJuridicaForm.pessoaJuridicaNumeroCnpjCpf.$viewValue);
                }
                razoError = isNullEmptyOrUndefined(vm.controladorJuridicaForm.pessoaJuridicaRazaoSocial.$viewValue);

            }

            return hasError || expostaHasError || noExpostaSelection || numeroError || razoError;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#checkCartaoMandatoryField
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to check mandatory field in Controllador
         *
         **/
        function checkCartaoMandatoryField() {
            vm.isCartaoFormSubmitted = true;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#checkDadosEnderecoJuridicaMandatoryField
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to check mandatory field in Dados Endereco Juridica
         *
         **/
        function checkDadosEnderecoJuridicaMandatoryField() {
            vm.isDadosEnderecoJuridicaFormSubmitted = true;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#checkDadosContatoMandatoryField
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to check mandatory field in Dados Contato
         *
         **/
        function checkDadosContatoMandatoryField() {
            vm.isDadosContatoFormSubmitted = true;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#checkCosseguradoMandatoryField
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to check mandatory field in Contato Juridica
         *
         **/
        function checkDadosContatoJuridicaMandatoryField() {
            vm.isDadosContatoJuridicaFormSubmitted = true;
        }

        //-------------end-------------------------------------

        //-------------COSSEGURADO-------------

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#populateCossegurado
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to populate Cossegurado form
         *
         **/
        function populateCossegurado() {
            var numeroProposta = vm.proposta.numeroProposta;
            var numeroVersaoProposta = vm.proposta.numeroVersaoProposta;
            var skip = 0;
            var top = 0;

            blockUI.start();
            OrcamentoPropostaService.getIntervenienteList(
                    skip, top, numeroProposta, numeroVersaoProposta, codigoEmpresa)
                .then(

                    function(response) {
                        if (response.data && response.data.documentoEmissao) {
                            vm.cossegurado = OrcamentoPropostaFactory.convertIntervenienteList(response.data.documentoEmissao);
                            if (angular.isDefined(vm.cossegurado.cossegurados) && vm.cossegurado.cossegurados.length <= 0) {
                                vm.getDefaultDadosSegurado.cossegurado.flagPossuiCossegurado = 'N';
                            } else {
                                vm.getDefaultDadosSegurado.cossegurado.flagPossuiCossegurado = 'S';
                            }
                        } else {
                            vm.getDefaultDadosSegurado.cossegurado.flagPossuiCossegurado = 'N';
                            addAlert(Constants.INFO_TYPE, Constants.MSG_ERROR_NOT_FOUND);
                        }
                        blockUI.stop();
                    },
                    function(error) {
                        vm.getDefaultDadosSegurado.cossegurado.flagPossuiCossegurado = 'N';
                        displayError(error);
                        blockUI.stop();
                    });

        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#populateCossegurado
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to populate Cossegurado form
         *
         **/
        function populateControladores() {

            var numeroProposta = vm.proposta.numeroProposta;
            var numeroVersaoProposta = vm.proposta.numeroVersaoProposta;
            var skip = 0;
            var top = 0;

            blockUI.start();
            OrcamentoPropostaService.getIntervenienteList(
                    skip, top, numeroProposta, numeroVersaoProposta, codigoEmpresa)
                .then(

                    function(response) {
                        if (response.data && response.data.documentoEmissao) {
                            vm.controlador = OrcamentoPropostaFactory.convertIntervenienteList(response.data.documentoEmissao);
                            if ((vm.pagamentoCalcularParcela && vm.pagamentoCalcularParcela.length > 0) &&
                                (vm.controlador.controladores && vm.controlador.controladores.length > 0)) {
                                vm.getDefaultDadosSegurado.controladores.flagPossuiControlador = 3;
                            } else if (vm.pagamentoCalcularParcela && vm.pagamentoCalcularParcela.length > 0 && vm.controlador.controladores && vm.controlador.controladores.length <= 0) {
                                vm.getDefaultDadosSegurado.controladores.flagPossuiControlador = 2;
                            } else {
                                vm.getDefaultDadosSegurado.controladores.flagPossuiControlador = 1;
                            }
                        } else {
                            vm.getDefaultDadosSegurado.controladores.flagPossuiControlador = 2;
                        }
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    });
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#setDefaultValueControlador
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Clear setDefaultValueControlador.
         *
         **/
        function setDefaultValueControlador() {
            vm.getDefaultDadosSegurado.controladores.codigoMotivoAusenciaCnpjCpf = null;
            vm.getDefaultDadosSegurado.controladores.codigoTipoInterveniente = null;
            vm.getDefaultDadosSegurado.controladores.codigoTipoPessoa = null;
            vm.getDefaultDadosSegurado.controladores.flagPossuiControlador = null;
            vm.getDefaultDadosSegurado.controladores.nomeInterveniente = null;
            vm.getDefaultDadosSegurado.controladores.nomePessoa = null;
            vm.getDefaultDadosSegurado.controladores.numeroCnpjCpf = null;
            vm.getDefaultDadosSegurado.controladores.flagAtivo = 'S';
            vm.getDefaultDadosSegurado.controladores.pessoaExpostaPoliticamente.flagPessoaExposta = null;
            vm.getDefaultDadosSegurado.controladores.pessoaExpostaPoliticamente.numeroCnpjCpfPessoaExposto = null;
            vm.getDefaultDadosSegurado.controladores.pessoaExpostaPoliticamente.nomePessoaExposto = null;
            vm.getDefaultDadosSegurado.controladores.pessoaExpostaPoliticamente.flagAtivo = 'S';
            vm.getDefaultDadosSegurado.controladores.pessoaExpostaPoliticamente.codigoTipoVinculo = null;
            vm.getDefaultDadosSegurado.controladores.pessoaExpostaPoliticamente.flagVinculoPessoaExpostaPoliticamente = null;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#removeInterveniente
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Delete a specific cossegurado or controlador in grid list.
         *
         **/
        function removeInterveniente(codigoInterveniente, screenID) {
            openCosseguradoDeleteConfirmModal(codigoInterveniente, screenID);
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#salvarCossegurado
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * save method of cossegurado fields.
         *
         **/
        function salvarCossegurado() {

            var hasError = checkCosseguradoMandatoryField();
            if (hasError) {
                displayPreconditionError(Constants.MSG_ERROR_SAVE);
                return;
            }
            var numeroProposta = vm.proposta.numeroProposta;
            var numeroVersaoProposta = vm.proposta.numeroVersaoProposta;
            var codigoTipoInterveniente = Constants.CODIGO_TIPO_INTERVENIENTE.COSSEGURADO;
            vm.getDefaultDadosSegurado.cossegurado.numeroCnpjCpf = vm.getDefaultDadosSegurado.cossegurado.numeroCnpjCpf.replace(/[\/.-]/g, "");
            var intervenienteVersaoProposta = OrcamentoPropostaFactory.convertBackIntervenienteVersaoProposta(codigoTipoInterveniente, numeroProposta, numeroVersaoProposta, vm.getDefaultDadosSegurado.cossegurado, false);
            OrcamentoPropostaService.createInterveniente(
                    numeroProposta, numeroVersaoProposta, intervenienteVersaoProposta)
                .then(

                    function(response) {

                        // INICO - SM159
                        if (vm.criaPessoa) {

                            var pessoa = {};
                            pessoa.pessoa = {
                                "codigoPessoa": null,
                                "codigoTipoPessoa": vm.getDefaultDadosSegurado.cossegurado.codigoTipoPessoa,
                                "numeroCnpjCpf": vm.getDefaultDadosSegurado.cossegurado.numeroCnpjCpf,
                                "nomePessoa": vm.getDefaultDadosSegurado.cossegurado.nomeInterveniente,
                                "nomeResumidoPessoa": vm.getDefaultDadosSegurado.cossegurado.nomeInterveniente,
                                "flagAtivo": "S",
                                "pessoaFisica": {
                                    "codigoEstadoCivil": null,
                                    "codigoFaixaRenda": null,
                                    "codigoNacionalidade": null,
                                    "codigoOcupacao": null,
                                    "codigoSexoPessoa": null,
                                    "codigoTipoExposicaoPessoa": null,
                                    "dataNascimento": null,
                                    "codigoPais": null
                                },
                                "pessoaJuridica": {
                                    "codigoAtividadeEconomica": null,
                                    "codigoFaixaReceitaOperacionalAno": null,
                                    "codigoFaixaPatrimonioLiquido": null,
                                    "codigoNaturezaJuridica": null,
                                    "flagCongenere": null,
                                    "codigoSusepCongenere": null,
                                    "dataRegistroAbertura": null
                                }
                            };

                            if (vm.getDefaultDadosSegurado.cossegurado.codigoTipoPessoa == 1) {
                                pessoa.pessoa.pessoaFisica.codigoTipoExposicaoPessoa = vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.flagVinculoPessoaExpostaPoliticamente;
                            }

                            PessoaService.createPessoa(pessoa)
                                .then(

                                    function(response) {},
                                    function(error) {});
                        }

                        if (vm.atualizaPessoa) {

                            vm.pessoaPorId.pessoa.nomePessoa = vm.getDefaultDadosSegurado.cossegurado.nomeInterveniente;

                            if (vm.getDefaultDadosSegurado.cossegurado.codigoTipoPessoa == 1) {

                                if (vm.pessoaPorId.pessoa.pessoaFisica == undefined) {
                                    var pessoaFisica = {
                                        "codigoEstadoCivil": null,
                                        "codigoFaixaRenda": null,
                                        "codigoNacionalidade": null,
                                        "codigoOcupacao": null,
                                        "codigoSexoPessoa": null,
                                        "codigoTipoExposicaoPessoa": null,
                                        "dataNascimento": null,
                                        "codigoPais": null
                                    };

                                    vm.pessoaPorId.pessoa.pessoaFisica = pessoaFisica;
                                }

                                vm.pessoaPorId.pessoa.pessoaFisica.codigoTipoExposicaoPessoa = vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.flagVinculoPessoaExpostaPoliticamente;
                            }

                            PessoaService.updatePessoa(vm.pessoaPorId)
                                .then(

                                    function(response) {},
                                    function(error) {
                                        console.log("Erro ao atualizar pessoa.");
                                    });
                        }
                        // FIM - SM159

                        $rootScope.$broadcast(Constants.SUCCESSO, Constants.MSG_SUCCESS_SAVE);
                        vm.isCosseguradoFormSubmitted = false;
                        setDefaultValueCossegurado();
                        populateCossegurado();
                    },
                    function(error) {
                        displayError(error);
                    });
        }

        function setDefaultValueCossegurado() {
            vm.getDefaultDadosSegurado.cossegurado.codigoTipoPessoa = null;
            vm.getDefaultDadosSegurado.cossegurado.numeroCnpjCpf = null;
            vm.getDefaultDadosSegurado.cossegurado.nomePessoa = null;
            vm.getDefaultDadosSegurado.cossegurado.nomeInterveniente = null;
            vm.getDefaultDadosSegurado.cossegurado.flagPossuiCossegurado = 'N';
            vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.flagVinculoPessoaExpostaPoliticamente = null;
            vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.numeroCnpjCpfPessoaExposto = null;
            vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.nomePessoaExposto = null;
            vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.codigoTipoVinculo = null;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#checkCosseguradoMandatoryField
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to check mandatory field in Cossegurado
         *
         **/
        function checkCosseguradoMandatoryField() {

            var hasError = vm.cosseguradoForm.$invalid;
            var exposicaoHasError = false;
            var contatoPessoaExpostaError = false;

            if (vm.getDefaultDadosSegurado.cossegurado.codigoTipoPessoa === 2) {
                contatoPessoaExpostaError = false;
            } else {
                contatoPessoaExpostaError = checkDropDownContatoPessoaExposta();
            }

            if (vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.flagVinculoPessoaExpostaPoliticamente === 3) {
                exposicaoHasError = checkMandatoryFieldForExposicao();
            }

            vm.isCosseguradoFormSubmitted = true;

            return hasError || exposicaoHasError || contatoPessoaExpostaError;
        }

        //------------COSSEGURADO END------------

        function checkDropDownContatoPessoaExposta() {
            return isNullEmptyOrUndefined(vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.flagVinculoPessoaExpostaPoliticamente);

        }

        function checkMandatoryFieldForExposicao() {
            var hasError = (isNullEmptyOrUndefined(vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.numeroCnpjCpfPessoaExposto) ||
                isNullEmptyOrUndefined(vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.nomePessoaExposto) ||
                isNullEmptyOrUndefined(vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.codigoTipoVinculo));

            return hasError;
        }

        function changeValueExposicao() {
            checkMandatoryFieldForExposicao();
        }


        //----------------- START BENEFICIARIO ----------------------
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#getBeneficiarioList
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to get Beneficiario List
         *
         **/
        function getBeneficiarioList() {
            blockUI.start();
            OrcamentoPropostaService.getBeneficiarioList(0, 0, vm.proposta.numeroProposta, vm.proposta.numeroVersaoProposta)
                .then(

                    function success(response) {
                        if (response) {
                            //convertBeneficiarios
                            vm.beneficiario.flagBeneficiario = vm.proposta.flagPossuiBeneficiario;
                            if (vm.tipoBemDropdown.length === 0) {
                                /*jshint sub:true*/
                                vm.enableTipoBem = false;
                                DominiosService.getDominio(Dominios['TIPO_BEM'].codigo,
                                        Dominios['TIPO_BEM'].cache, codigoEmpresa)
                                    .then(function(tipoBemResponse) {
                                            vm.tipoBemDropdown = OrcamentoPropostaFactory.convertTipoBemDropdown(tipoBemResponse);
                                            constructBeneficiarioList(response.data);
                                        },
                                        function(error) {
                                            displayError(error);
                                        });
                            }
                            if (response.data) {
                                constructBeneficiarioList(response.data);
                            } else {
                                vm.beneficiarioList = [];
                            }
                        } else {
                            constructBeneficiarioList(response.data);
                        }
                        blockUI.stop();
                    },
                    function error(error) {
                        vm.beneficiarioList = [];
                        displayError(error);
                        blockUI.stop();
                    });
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#constructBeneficiarioList
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *

         * Construct Beneficiario List.
         *
         **/
        function constructBeneficiarioList(responseData) {
            if (responseData) {
                vm.beneficiarioList = OrcamentoPropostaFactory.constructBeneficiarioList(responseData.itemDocumentoEmissao, vm.tipoBemDropdown, vm.tipoPessoaOptions);
                constructDadosPessoaForBeneficiario();
            } else {
                vm.beneficiarioList = [];
                addAlert(Constants.INFO_TYPE, Constants.MSG_ERROR_NOT_FOUND);
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#constructDadosPessoaForBeneficiario
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Constructs the dados Pessoa details for Beneficiario.
         *
         **/
        function constructDadosPessoaForBeneficiario() {
            if (angular.isArray(vm.beneficiarioList) && vm.beneficiarioList !== null) {
                angular.forEach(vm.beneficiarioList, function(beneficiario, index) {
                    PessoaService.getPessoaPorId(0, 1, beneficiario.codigoPessoa)
                        .then(

                            function(response) {
                                var pessoaList = response.data.listaPessoas;
                                if (angular.isObject(pessoaList) && pessoaList !== null &&
                                    angular.isArray(pessoaList.pessoa) && pessoaList.pessoa !== null) {
                                    var pessoaSeguro = pessoaList.pessoa[0];

                                    vm.beneficiarioList[index].nomePessoa = pessoaSeguro.nomePessoa;
                                    vm.beneficiarioList[index].codigoTipoPessoa = pessoaSeguro.codigoTipoPessoa;
                                    vm.beneficiarioList[index].nomePessoa = pessoaSeguro.nomePessoa;
                                    vm.beneficiarioList[index].numeroCnpjCpf = pessoaSeguro.numeroCnpjCpf;

                                    if (angular.isArray(vm.tipoPessoaOptions) && vm.tipoPessoaOptions.length > 0) {
                                        var tipoPessoa = $filter('filter')(vm.tipoPessoaOptions, {
                                            codigoValorDominio: vm.beneficiarioList[index].codigoTipoPessoa
                                        }, true)[0];
                                        if (angular.isObject(tipoPessoa)) {
                                            vm.beneficiarioList[index].nomeTipoPessoa = tipoPessoa.nomeDominio;
                                        }
                                    }

                                    if (vm.beneficiarioList[index].codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA) {
                                        vm.beneficiarioList[index].numeroCnpjCpf = OrcamentoUtilityFactory.convertCpf(pad(vm.beneficiarioList[index].numeroCnpjCpf, 11));
                                    } else if (vm.beneficiarioList[index].codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.JURIDICA) {
                                        vm.beneficiarioList[index].numeroCnpjCpf = OrcamentoUtilityFactory.convertCnpj(pad(vm.beneficiarioList[index].numeroCnpjCpf, 14));
                                    }
                                }
                            });
                });
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#populateBeneficiario
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *

         * Method called to populate Beneficiario form
         *
         **/
        function populateBeneficiario(isInit) {

            vm.beneficiario = OrcamentoPropostaFactory.defaultBeneficiario();
            getBeneficiarioList();
            createObjetoSeguroDropdown(isInit);

            vm.beneficiarioCoberturas = [];
            vm.isFisicaBeneficiario = null;
        }

        function createObjetoSeguroDropdown(isInit) {
            OrcamentoService.getItemOrcamentoList(0, 0, 0, vm.proposta.numeroOrcamento, vm.proposta.numeroVersaoOrcamento, vm.proposta.codigoCanal)
                .then(

                    function(responseOrcamento) {
                        if (responseOrcamento.data && responseOrcamento.data.itemDocumentoEmissao) {
                            var initialObjetoSeguroDropdown = OrcamentoPropostaFactory.initializeObjetoSeguradoDropdown(
                                responseOrcamento.data.itemDocumentoEmissao);
                            vm.objetoSeguradoDropdown = OrcamentoPropostaFactory.constructObjetoSegurado(initialObjetoSeguroDropdown);
                            var localRiscoObject = OrcamentoPropostaFactory.constructLocalRiscoList(responseOrcamento.data.itemDocumentoEmissao, vm.tipoLogradouroOptions);
                            vm.localRiscoMap = localRiscoObject.localRiscoMap;
                            vm.localRiscoList = localRiscoObject.localRiscoList;
                        }
                        if (isInit) {
                            populateEndereco();
                        }
                    },
                    function(error) {
                        displayError(error);
                        vm.localRiscoMap = {};
                        vm.localRiscoList = [];
                    });

        }

        /* SM 761 - Parametrizador Tipo Bem */
        // function getCoberturasOfItemOrcamento(numeroItemVersao, isNotFromHtml) {
        //     OrcamentoService.getItemOrcamento(vm.proposta.numeroOrcamento, vm.proposta.numeroVersaoOrcamento, numeroItemVersao).then(
        //         function(response) {
        //             if (response.data && response.data.itemDocumentoEmissao &&
        //                 response.data.itemDocumentoEmissao.coberturasItem.listaCoberturasItem) {
        //                 vm.beneficiarioCoberturas = OrcamentoPropostaFactory.constructBeneficiarioCoberturaList(
        //                     response.data.itemDocumentoEmissao.coberturasItem.listaCoberturasItem.coberturaItemDocumento,
        //                     coberturaOfertaList);
        //                 if (isNotFromHtml) {
        //                     vm.beneficiarioCoberturas = OrcamentoPropostaFactory.constructBeneficiarioCoberturaListChecked(
        //                         vm.beneficiarioCoberturas, vm.beneficiario.coberturas);
        //                 }
        //             }
        //         },
        //         function(error) {
        //             displayError(error);
        //         }
        //     );
        // }
        /* FIM - SM 761 - Parametrizador Tipo Bem */

        function addComponente() {

            vm.isEspecificosFormSubmitted = true;
            if (vm.beneficiario.nomeDoBem && vm.beneficiario.valorDoBem) {

                var componente = {
                    nomeDoBem: vm.beneficiario.nomeDoBem,
                    valorDoBem: vm.beneficiario.valorDoBem
                };
                vm.beneficiario.componentes.push(componente);
                vm.beneficiario.quantidadeBens = vm.beneficiario.componentes.length;

                var valorTotalBens = OrcamentoUtilityFactory.convertBackDecimal(vm.beneficiario.valorTotalBens);
                var valorDoBem = OrcamentoUtilityFactory.convertBackDecimal(vm.beneficiario.valorDoBem);

                var total = parseFloat(valorTotalBens) + parseFloat(valorDoBem);

                vm.beneficiario.valorTotalBens = OrcamentoUtilityFactory.convertDecimal(total);
                vm.beneficiario.nomeDoBem = null;
                vm.beneficiario.valorDoBem = null;
                vm.isEspecificosFormSubmitted = false;

                vm.updateValorTotalDosBensWithCheckedCobertura();
            }
        }

        function removeComponente(index) {

            vm.beneficiario.componentes.splice(index, 1);

            var valorTotalBens = 0;

            angular.forEach(vm.beneficiario.componentes, function(item) {
                valorTotalBens = parseFloat(valorTotalBens) +
                    parseFloat(OrcamentoUtilityFactory.convertBackDecimal(item.valorDoBem));
            });

            var total = parseFloat(valorTotalBens);
            vm.beneficiario.valorTotalBens = OrcamentoUtilityFactory.convertDecimal(total);
            vm.updateValorTotalDosBensWithCheckedCobertura();
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#changeTipoPessoaBene
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon change in Tipo Pessoa Bene
         *
         **/
        function changeTipoPessoaBene() {
            if (vm.beneficiario.codigoTipoPessoa === 1) {
                vm.isFisicaBeneficiario = true;
            } else {
                vm.isFisicaBeneficiario = false;
            }

            vm.beneficiario.numeroCnpjCpf = "";
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#salvarBeneficiario
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called upon clicking salvar in Beneficiario
         *
         **/
        function salvarBeneficiario() {

            // NOTE Refactor for ALM 897
            // TODO Ongoing progress for resolve ALM 897
            var hasError = checkBeneficiarioMandatoryField();
            if (hasError) {
                displayPreconditionError(Constants.MSG_ERROR_SAVE);
                return;
            }

            if (vm.beneficiario.codigoTipoBem !== Constants.CODIGO_TIPO_BEM.BENS_ESPECIFICOS) {
                vm.beneficiario.componentes = [];
            }
            var updateBeneficiario = function(toPersistBeneficiario) {
                OrcamentoPropostaService.updateBeneficiario(vm.proposta.numeroProposta, vm.proposta.numeroVersaoProposta, vm.beneficiario.codigoBeneficiario, toPersistBeneficiario).then(function(response) {
                        $rootScope.$broadcast(Constants.SUCCESSO, Constants.MSG_SUCCESS_SAVE);
                        vm.isBeneficiarioFormSubmitted = false;
                        populateBeneficiario();
                        vm.beneficiario.isEditMode = false;
                        $scope.orcamentoCtrl.saveProposta(); // atualizar proposta
                    },
                    function(error) {
                        displayError(error);
                    }
                );
            };
            var createBeneficiario = function(toPersistBeneficiario) {
                OrcamentoPropostaService.createBeneficiario(vm.proposta.numeroProposta, vm.proposta.numeroVersaoProposta, toPersistBeneficiario).then(function(response) {
                        $rootScope.$broadcast(Constants.SUCCESSO, Constants.MSG_SUCCESS_SAVE);
                        vm.isBeneficiarioFormSubmitted = false;
                        populateBeneficiario();
                        $scope.orcamentoCtrl.saveProposta(); // atualizar proposta
                    },
                    function(error) {
                        displayError(error);
                    }
                );
            };
            var businessBeneficiario = function(codigoBeneficiario) {

                if (angular.isDefined(codigoBeneficiario)) {
                    vm.beneficiario.codigoPessoa = codigoBeneficiario;
                }
                if (vm.beneficiario.numeroItemVersaoProposta) {
                    vm.beneficiario.numeroItemVersaoOrcamento = vm.beneficiario.numeroItemVersaoProposta;
                }

                var toPersistBeneficiario = OrcamentoPropostaFactory.createBeneficiarioRequest(vm.proposta.numeroProposta, vm.proposta.numeroVersaoProposta, vm.proposta.numeroOrcamento, vm.proposta.numeroVersaoOrcamento, vm.beneficiario, vm.beneficiarioCoberturas);

                if (vm.beneficiario.codigoBeneficiario === null) {
                    vm.beneficiario.isEditMode = false;
                    createBeneficiario(toPersistBeneficiario);
                } else {
                    var beneficiario = $filter('filter')(vm.beneficiarioList, {
                        codigoBeneficiario: vm.beneficiario.codigoBeneficiario
                    });

                    if (!vm.beneficiarioCoberturas.codigoBeneficiario && beneficiario && beneficiario.length > 0) {
                        vm.beneficiario.codigoBeneficiario = beneficiario[0].codigoBeneficiario;
                        toPersistBeneficiario.itemDocumentoEmissao.codigoBeneficiario = beneficiario[0].codigoBeneficiario;

                        angular.forEach(toPersistBeneficiario.itemDocumentoEmissao.coberturasItem.listaCoberturasItem.coberturaItemDocumento,
                            function(value, index) {
                                if (value.beneficiarios.beneficiario && !value.beneficiarios.beneficiario[0].dadosPessoa.codigoPessoa) {
                                    value.beneficiarios.beneficiario.dadosPessoa.codigoPessoa = beneficiario[0].codigoPessoa;
                                    value.beneficiarios.beneficiario.codigoBeneficiario = beneficiario[0].codigoBeneficiario;
                                }
                            });
                    }
                    updateBeneficiario(toPersistBeneficiario);
                }
            };

            PessoaService.getByCpfcnpj(vm.beneficiario.codigoTipoPessoa, vm.beneficiario.numeroCnpjCpf).then(

                function sucess(response) {
                    if (angular.isObject(response.data.listaPessoas)) {
                        businessBeneficiario(response.data.listaPessoas.pessoa[0].codigoPessoa);
                    } else {
                        var nomeBeneficiario = vm.beneficiario.nomeBeneficiario;
                        if (vm.beneficiario.coberturas && vm.beneficiario.coberturas[0].beneficiarios[0].dadosPessoa.nomePessoa) {
                            nomeBeneficiario = vm.beneficiario.coberturas[0].beneficiarios[0].dadosPessoa.nomePessoa;
                        }
                        var pessoa = {};
                        pessoa.pessoa = {
                            "codigoPessoa": vm.beneficiario.codigoPessoa,
                            "codigoTipoPessoa": vm.beneficiario.codigoTipoPessoa,
                            "numeroCnpjCpf": OrcamentoUtilityFactory.convertBackCpfCnpj(vm.beneficiario.numeroCnpjCpf),
                            "nomePessoa": nomeBeneficiario,
                            "nomeResumidoPessoa": nomeBeneficiario,
                            "flagAtivo": "S"
                        };
                        PessoaService.createPessoa(pessoa).then(
                            function(response) {
                                businessBeneficiario(response.data.pessoa.codigoPessoa);
                            },
                            function(error) {
                                console.log("Erro ao salvar Pessoa.");
                            });
                    }
                },
                function error(response) {
                    businessBeneficiario();
                }
            );
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#checkBeneficiarioMandatoryField
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method called to check mandatory field in Beneficiario
         *
         **/
        function checkBeneficiarioMandatoryField() {

            var hasError = vm.beneficiarioForm.$invalid;
            vm.isBeneficiarioFormSubmitted = true;
            vm.isBeneficiarioCPFCNPJFormSubmitted = true;
            vm.isEspecificosFormSubmitted = false;

            if (!hasError) {
                if (vm.beneficiario.codigoTipoBem === Constants.CODIGO_TIPO_BEM.BENS_ESPECIFICOS) {
                    hasError = isInvalidBeneficiario(vm.beneficiario.quantidadeBens) ||
                        isInvalidBeneficiario(vm.beneficiario.valorTotalBens);

                    if (!hasError) {
                        if (vm.beneficiario.componentes.length === 0) {
                            hasError = true;
                        }
                    }
                } else {
                    hasError = isInvalidBeneficiario(vm.beneficiario.valorTipoBem);
                }

                if (!hasError) {

                    var numeroCnpjCpf = vm.beneficiario.numeroCnpjCpf;

                    if (numeroCnpjCpf === undefined || numeroCnpjCpf === null || numeroCnpjCpf.trim() === "") {
                        hasError = true;
                    }

                }

                if (!hasError) {
                    if (vm.beneficiarioCoberturas.length > 0) {
                        hasError = true;
                        for (var i = 0; vm.beneficiarioCoberturas.length > i; i++) {
                            if (vm.beneficiarioCoberturas[i].isChecked === true) {
                                hasError = false;
                                break;
                            }
                        }
                    }
                }
            }

            return hasError;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isInvalidBeneficiario
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Checks if the value of the attribute is invalid.
         *
         * @param {Object} model The attribute to check if is invalid.
         * @returns {Boolean} Returns if invalid or not.
         **/
        function isInvalidBeneficiario(model) {
            return (angular.isUndefined(model) || model === null || model === '');
        }

        function isBeneficiarioInvalid(model) {
            return vm.isBeneficiarioFormSubmitted && isInvalidBeneficiario(model);
        }

        function isEspecificaoInvalid(model) {
            return vm.isEspecificosFormSubmitted && isInvalidBeneficiario(model);
        }

        function isBeneficiarioCpfCnpjInvalid(model) {
            return vm.isBeneficiarioCPFCNPJFormSubmitted && isInvalidBeneficiario(model);
        }

        function updateValorTotalDosBens(index, value) {

            var beneficiarioCobertura = vm.beneficiarioCoberturas[index];
            var valorTotalDosBens = "";

            if (beneficiarioCobertura.isChecked === true) {
                var codigoTipoBem = vm.beneficiario.codigoTipoBem;

                if (codigoTipoBem !== undefined && codigoTipoBem !== null) {

                    if (codigoTipoBem == Constants.CODIGO_TIPO_BEM.BENS_ESPECIFICOS) {
                        valorTotalDosBens = updateValorTotalBens(value);
                    } else {
                        valorTotalDosBens = updateValorTipoBem(value);
                    }
                }
            }

            vm.beneficiarioCoberturas[index].valorTotalDosBens = valorTotalDosBens;
        }

        function updateValorTotalDosBensWithCheckedCobertura(value) {

            if (vm.beneficiarioCoberturas.length > 0) {
                for (var i = 0; vm.beneficiarioCoberturas.length > i; i++) {
                    if (vm.beneficiarioCoberturas[i].isChecked === true) {
                        vm.updateValorTotalDosBens(i, value);
                    }
                }
            }
        }

        function updateValorTotalBens(value) {
            var valorTotalDosBens = "";
            var valorTotalBens = 0;

            if (value === undefined || value === null) {
                valorTotalBens = vm.beneficiario.valorTotalBens;
            } else {
                valorTotalBens = value;
            }

            if (valorTotalBens !== undefined && valorTotalBens !== null) {
                valorTotalDosBens = valorTotalBens;
            }

            return valorTotalDosBens;
        }

        function updateValorTipoBem(value) {
            var valorTotalDosBens = "";
            var valorTipoBem = 0;

            if (value === undefined || value === null) {
                valorTipoBem = vm.beneficiario.valorTipoBem;
            } else {
                valorTipoBem = value;
            }

            if (valorTipoBem !== undefined && valorTipoBem !== null) {
                valorTotalDosBens = valorTipoBem;
            }

            return valorTotalDosBens;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#getBeneficiario
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Retrieves specific Beneficiario.
         *
         * @param {Number} numeroItemVersaoProposta parameter.
         * @returns {Number} codigoBeneficiario parameter.
         **/
        function getBeneficiario(numeroItemVersaoProposta, codigoBeneficiario) {
            vm.beneficiario.numeroItemVersaoProposta = numeroItemVersaoProposta;
            OrcamentoPropostaService.getBeneficiario(vm.proposta.numeroProposta, vm.proposta.numeroVersaoProposta, null, codigoBeneficiario, null)
                .then(

                    function(response) {

                        var itemDocumentoEmissao = response.data.itemDocumentoEmissao;
                        // Retrieve the associated Pessoa Seguro Object.
                        var codigoPessoa = null;

                        if (angular.isObject(itemDocumentoEmissao.coberturasItem) &&
                            angular.isObject(itemDocumentoEmissao.coberturasItem.listaCoberturasItem) &&
                            angular.isArray(itemDocumentoEmissao.coberturasItem.listaCoberturasItem.coberturaItemDocumento) &&
                            itemDocumentoEmissao.coberturasItem.listaCoberturasItem.coberturaItemDocumento !== null) {

                            var coberturaItems = itemDocumentoEmissao.coberturasItem.listaCoberturasItem.coberturaItemDocumento;

                            if (angular.isObject(coberturaItems[0].beneficiarios) && angular.isArray(coberturaItems[0].beneficiarios.beneficiario) &&
                                coberturaItems[0].beneficiarios.beneficiario[0] !== null &&
                                angular.isObject(coberturaItems[0].beneficiarios.beneficiario[0].dadosPessoa) &&
                                coberturaItems[0].beneficiarios.beneficiario[0].dadosPessoa !== null) {

                                codigoPessoa = coberturaItems[0].beneficiarios.beneficiario[0].dadosPessoa.codigoPessoa;

                            }
                        }

                        if (codigoPessoa !== null) {
                            PessoaService.getPessoaPorId(0, 1, codigoPessoa).then(
                                function(response) {
                                    var pessoaList = response.data.listaPessoas;

                                    if (angular.isObject(pessoaList) && pessoaList !== null && angular.isArray(pessoaList.pessoa) && pessoaList.pessoa !== null) {
                                        var pessoaSeguro = pessoaList.pessoa[0];

                                        vm.beneficiario = OrcamentoPropostaFactory.convertBeneficiario(itemDocumentoEmissao, codigoBeneficiario, vm.tipoBemDropdown, pessoaSeguro);

                                        vm.isFisicaBeneficiario = vm.beneficiario.isFisicaBeneficiario;

                                        /* SM 761 - Parametrizador Tipo Bem */
                                        // getCoberturasOfItemOrcamento(vm.beneficiario.numeroItemVersaoProposta, true);
                                        getOferta(vm.beneficiario.codigoTipoBem, true, true);
                                        /* FIM - SM 761 - Parametrizador Tipo Bem */

                                        /*vm.beneficiario.coberturas = vm.beneficiarioCoberturas;*/
                                        vm.beneficiario.isEditMode = true;
                                    }
                                }
                            );
                        }
                    }
                );
        }

        function deleteBeneficiario(codigoBeneficiario, numeroItemVersaoProposta) {
            openDeleteConfirmModal(codigoBeneficiario, numeroItemVersaoProposta);
            $scope.$broadcast(Constants.OPEN_MODAL_CONFIRM, {
                title: 'Confirma a exclusão?'
            });
        }

        function openDeleteConfirmModal(codigoBeneficiario, numeroItemVersaoProposta) {
            vm.foo = {};
            vm.foo.codigoBeneficiario = codigoBeneficiario;
            vm.foo.numeroItemVersaoProposta = numeroItemVersaoProposta;
            // Listener function to trigger update from modal directive.

            $scope.$on(Constants.CLOSE_MODAL_CONFIRM, checkDeleteBeneficiario);
        }

        function checkDeleteBeneficiario(event, status) {
            if (vm.proposta.numeroVersaoProposta && vm.foo.codigoBeneficiario) {
                if (status === Constants.CONFIRM) {
                    OrcamentoPropostaService.deleteBeneficiario(vm.proposta.numeroProposta, vm.proposta.numeroVersaoProposta, vm.foo.codigoBeneficiario, 0, 0, vm.foo.numeroItemVersaoProposta)
                        .then(

                            function(response) {
                                if (response.status === 200) {
                                    getBeneficiarioList();
                                }
                            },
                            function(error) {
                                displayError(error);
                            });
                }
            }
        }

        //----------------- END BENEFICIARIO ----------------------

        function changeEnderecoCobrancaContent() {
            $scope.orcamentoCtrl.savedProposta = false;
            if (vm.proposta.enderecoCobranca.flagEnderecoCobranca === 1) {
                populateEnderecoCobranca('sim');
                vm.proposta.enderecoCobranca.enderecosCadastrado = null;
            } else if (vm.proposta.enderecoCobranca.flagEnderecoCobranca === 2) {
                populateEnderecoCobranca('pessoa');
                vm.proposta.enderecoCobranca.localDeRisco = null;
            } else if (vm.proposta.enderecoCobranca.flagEnderecoCobranca === 3) {
                displayNovoEndereco('cobranca');
                vm.proposta.enderecoCobranca.localDeRisco = null;
                vm.proposta.enderecoCobranca.enderecosCadastrado = null;
            }
        }

        function changeEnderecoCorrespondenciaContent() {
            $scope.orcamentoCtrl.savedProposta = false;
            if (vm.proposta.enderecoCorrespondencia.flagEnderecoCorrespondencia === 1) {
                populateEnderecoCorrespondencia('sim');
                vm.proposta.enderecoCorrespondencia.enderecosCadastrado = null;
            } else if (vm.proposta.enderecoCorrespondencia.flagEnderecoCorrespondencia === 2) {
                populateEnderecoCorrespondencia('pessoa');
                vm.proposta.enderecoCorrespondencia.localDeRisco = null;
            } else if (vm.proposta.enderecoCorrespondencia.flagEnderecoCorrespondencia === 3) {
                displayNovoEndereco('correspondencia');
                vm.proposta.enderecoCorrespondencia.enderecosCadastrado = null;
                vm.proposta.enderecoCorrespondencia.localDeRisco = null;
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#dateValidation
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method for validating date fields, data inicio should always be less than data Fim
         *
         * startDateComponentName - the start date component name specified in the html template.
         * endDateComponentName - the end date component name specified in the html template.
         * mainObjectName - the object name that contains the object(model) of startdate and enddate.
         * startDateObjectName - the startdate model name as string.
         * endDateObjectName - the enddate model name as string.
         * status - value should be 'start' or 'end'
         **/
        function dateValidation(formName, startDateComponentName, endDateComponentName, mainObjectName, startDateObjectName, endDateObjectName, status) {

            var startDateString = vm[formName][startDateComponentName].$viewValue;
            var endDateString = vm[formName][endDateComponentName].$viewValue;

            if (isValidDate(startDateString) && isValidDate(endDateString) && startDateString.length === 10 && endDateString.length === 10) {

                //Swap day and month position and convert to day. why? because javascript only accept date format (mm/dd/yyyy)
                var startDateObj = new Date(startDateString.substring(3, 5) + '/' + startDateString.substring(0, 2) + '/' + startDateString.substring(6, 10));
                var endDateObj = new Date(endDateString.substring(3, 5) + '/' + endDateString.substring(0, 2) + '/' + endDateString.substring(6, 10));

                if (startDateObj > endDateObj && status === "start") {
                    displayPreconditionError(Constants.MSG_ERROR_DATAINICIO);
                    vm[mainObjectName][startDateObjectName] = "";
                } else if (startDateObj > endDateObj && status === "end") {
                    displayPreconditionError(Constants.MSG_ERROR_DATAINICIO);
                    vm[mainObjectName][endDateObjectName] = "";
                }
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#maskDate
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * This method masks the given input.
         *
         *e - the event object that contains the keypress code.
         *formName - the name of the form that contains the start and end date component.
         *dateComponentName - the input component name as string to get viewValue.
         *mainObjectName - the object that contains the date
         *dateObjectName - the date object(model)
         *
         **/
        function maskDate(e, formName, dateComponentName, mainObjectName, dateObjectName) {

            var key = e.which || e.keyCode || 0;

            if (key === 8 || key === 9) {
                return true;
            }

            var dateAsText = vm[formName][dateComponentName].$viewValue;
            if (!dateAsText) {
                dateAsText = '';
            }

            if (key > 47 && key < 58) {
                var charInput = String.fromCharCode(e.keyCode);

                if (angular.isDefined(charInput) && charInput !== null && charInput !== '') {
                    var parsedNum = parseInt(charInput);

                    if (dateAsText.length === 0) {
                        if (!(parsedNum >= 0 && parsedNum <= 3)) {
                            e.preventDefault();
                            return;
                        }
                    }

                    if (dateAsText.length === 1) {

                        if (dateAsText.charAt(0) === '3') {
                            if (parsedNum !== 0 && parsedNum !== 1) {
                                e.preventDefault();
                                return;
                            }
                        }

                        if (dateAsText.charAt(0) === '0' && parsedNum === 0) {
                            e.preventDefault();
                            return;
                        }

                    }

                    if (dateAsText.length === 2) {
                        if (parsedNum !== 0 && parsedNum !== 1) {
                            e.preventDefault();
                            return;
                        } else {
                            if (angular.isString(mainObjectName) && mainObjectName.indexOf('.') > -1) {
                                var objectNames = mainObjectName.split('.');
                                var object = vm;
                                angular.forEach(objectNames, function(item) {
                                    object = object[item];
                                });
                                object[dateObjectName] = dateAsText + '/';
                            } else {
                                vm[mainObjectName][dateObjectName] = dateAsText + '/';
                            }
                        }
                    }

                    if (dateAsText.length === 3) {
                        if (parsedNum !== 0 && parsedNum !== 1) {
                            e.preventDefault();
                            return;
                        }
                    }

                    if (dateAsText.length === 4) {
                        var day = dateAsText.substring(0, 2);
                        var month = dateAsText.charAt(3) + charInput;

                        if (day === "31") {
                            if (!(month === "01" || month === "03" || month === "05" || month === "07" || month === "08" || month === "10" || month === "12")) {
                                e.preventDefault();
                                return;
                            }
                        }
                        if (dateAsText.charAt(3) === '1') {
                            if (parsedNum !== 0 && parsedNum !== 1 && parsedNum !== 2) {
                                e.preventDefault();
                                return;
                            }
                        }

                        if (dateAsText.charAt(3) === '0' && parsedNum === 0) {
                            e.preventDefault();
                            return;
                        }
                    }

                    if (dateAsText.length === 5) {
                        // TEMP FIX FOR USING THIS MASKING FUNCTION!!!!!
                        if (angular.isString(mainObjectName) && mainObjectName.indexOf('.') > -1) {
                            var objectNames = mainObjectName.split('.');
                            var object = vm;
                            angular.forEach(objectNames, function(item) {
                                object = object[item];
                            });
                            object[dateObjectName] = dateAsText + '/';
                        } else {
                            vm[mainObjectName][dateObjectName] = dateAsText + '/';
                        }
                    }

                    if (dateAsText.length === 9) {
                        var selectionStart = e.currentTarget.selectionStart;
                        var fullDate = dateAsText.slice(0, selectionStart) + charInput + dateAsText.slice(selectionStart, dateAsText.length);
                        var isValid = isValidDate(fullDate);

                        if (!isValid) {
                            e.preventDefault();
                            return;
                        }

                    }

                    if (dateAsText.length >= 10) {

                        if (!isValidDate(dateAsText)) {
                            if (angular.isString(mainObjectName) && mainObjectName.indexOf('.') > -1) {
                                var objectNames = mainObjectName.split('.');
                                var object = vm;
                                angular.forEach(objectNames, function(item) {
                                    object = object[item];
                                });
                                object[dateObjectName] = dateAsText + '/';
                            } else {
                                vm[mainObjectName][dateObjectName] = '';
                            }
                            e.preventDefault();
                            return;
                        }
                    }
                }
            } else {
                e.preventDefault();
                return;
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#clearWhenNotValidDate
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         *
         * This method clears input when not valid date.
         *
         *formName - the name of the form that contains the start and end date component.
         *dateComponentName - the input component name as string to get viewValue.
         *mainObjectName - the object that contains the date
         *dateObjectName - the date object(model)
         *
         **/
        function clearWhenNotValidDate(formName, dateComponentName, mainObjectName, dateObjectName) {

            var dateAsText = vm[formName][dateComponentName].$viewValue === undefined ? vm[formName][dateComponentName] : vm[formName][dateComponentName].$viewValue;

            dateAsText = $filter('date')(dateAsText, Constants.DATE_FORMAT);

            if (dateAsText === null || dateAsText === undefined || dateAsText === '') {
                dateAsText = '';
            }

            if (!isValidDate(dateAsText)) {
                vm[mainObjectName][dateObjectName] = '';
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#formatDate
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * This method format the given masked date.
         *
         *formName - the name of the form that contains the start and end date component.
         *dateComponentName - the input component name as string to get viewValue.
         *mainObjectName - the object that contains the date
         *dateObjectName - the date object(model)
         *
         **/
        function formatDate(formName, dateComponentName, mainObjectName, dateObjectName) {
            if (mainObjectName.indexOf('.') > -1) {
                var objectArray = mainObjectName.split('.');
                var object = vm;
                angular.forEach(objectArray, function(item) {
                    object = object[item];
                });
                if (angular.isDefined(object)) {
                    var dateAsText = vm[formName][dateComponentName].$viewValue;
                    if (angular.isDefined(dateAsText) && dateAsText.length === 10) {
                        var toDate = (dateAsText).split("/");
                        var toDateObject = new Date(toDate[2], toDate[1] - 1, toDate[0]);
                        object[dateObjectName] = toDateObject;
                    }
                }
            } else {
                if (vm[formName][dateComponentName] !== undefined) {
                    var dateAsText = vm[formName][dateComponentName].$viewValue;
                    if (dateAsText !== null) {
                        if (undefined !== dateAsText && dateAsText.length === 10) {
                            var toDate = (dateAsText).split("/");
                            var toDateObject = new Date(toDate[2], toDate[1] - 1, toDate[0]);
                            vm[mainObjectName][dateObjectName] = toDateObject;
                        }
                    }
                }
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isValidDate
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         *Method for checking if the string date passed is a valid date.
         *The method for it to work. should be passed by a string date with dd/MM/yyyy as format.
         *
         **/
        function isValidDate(s) {

            if (s === null || undefined) {
                return false;
            }

            // format D(D)/M(M)/(YY)YY
            var dateFormat = /^\d{1,4}[\.|\/|-]\d{1,2}[\.|\/|-]\d{1,4}$/;

            if (dateFormat.test(s)) {
                // remove any leading zeros from date values
                s = s.replace(/0*(\d*)/gi, "$1");
                var dateArray = s.split(/[\.|\/|-]/);

                // correct month value
                dateArray[1] = dateArray[1] - 1;

                // correct year value
                if (dateArray[2].length < 4) {
                    // correct year value
                    dateArray[2] = (parseInt(dateArray[2]) < 50) ? 2000 + parseInt(dateArray[2]) : 1900 + parseInt(dateArray[2]);
                }

                var testDate = new Date(dateArray[2], dateArray[1], dateArray[0]);
                if (testDate.getDate() != dateArray[0] || testDate.getMonth() != dateArray[1] || testDate.getFullYear() != dateArray[2]) {
                    return false;
                } else {
                    return true;
                }
            } else {
                return false;
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#maskCPFwithinOneObject
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Masks the input value for CPF on keypress within one object.
         *
         * @param {Object} firstObjectName parameter
         * @param {Object} secondObjectName parameter
         * @param {Object} $event Event triggered.
         **/
        function maskCPFwithinOneObject(firstObjectName, secondObjectName, e) {
            if (firstObjectName == 'beneficiario' && secondObjectName == 'numeroCnpjCpf') {
                vm[firstObjectName][secondObjectName] = maskCPF(vm[firstObjectName][secondObjectName], e);
            } else {
                vm[firstObjectName][secondObjectName] = maskCPF(vm[firstObjectName][secondObjectName], e);
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#maskCPFwithinOneObject
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Masks the input value for CPF on keypress within two objects.
         *
         * @param {Object} firstObjectName parameter
         * @param {Object} secondObjectName parameter
         * @param {Object} thirdObjectName parameter
         * @param {Object} $event Event triggered.
         **/
        function maskCPFwithinTwoObject(firstObjectName, secondObjectName, thirdObjectName, e) {
            vm[firstObjectName][secondObjectName][thirdObjectName] = maskCPF(vm[firstObjectName][secondObjectName][thirdObjectName], e);
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#maskCPFwithinOneObject
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Masks the input value for CPF on keypress within four objects.
         *
         * @param {Object} firstObjectName parameter
         * @param {Object} secondObjectName parameter
         * @param {Object} thirdObjectName parameter
         * @param {Object} fourthObjectName parameter
         * @param {Object} fifthObjectName parameter
         * @param {Object} $event Event triggered.
         **/
        function maskCPFwithinFourObject(firstObjectName, secondObjectName, thirdObjectName, fourthObjectName, fifthObjectName, e) {
            vm[firstObjectName][secondObjectName][thirdObjectName][fourthObjectName][fifthObjectName] = maskCPF(vm[firstObjectName][secondObjectName][thirdObjectName][fourthObjectName][fifthObjectName], e);
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#maskCPFwithinOneObject
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Masks the input value for CPF on keypress within four objects.
         *
         * @param {Object} firstObjectName parameter
         * @param {Object} secondObjectName parameter
         * @param {Object} thirdObjectName parameter
         * @param {Object} fourthObjectName parameter
         * @param {Object} $event Event triggered.
         **/
        function maskCPFwithinFiveObject(firstObjectName, secondObjectName, thirdObjectName, fourthObjectName, e) {
            vm[firstObjectName][secondObjectName][thirdObjectName][fourthObjectName] = maskCPF(vm[firstObjectName][secondObjectName][thirdObjectName][fourthObjectName], e);
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#maskCNPJwithinOneObject
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Masks the input value for CNPJ on keypress within one object.
         *
         * @param {Object} firstObjectName parameter
         * @param {Object} secondObjectName parameter
         * @param {Object} $event Event triggered.
         **/
        function maskCNPJwithinOneObject(firstObjectName, secondObjectName, e) {
            vm[firstObjectName][secondObjectName] = maskCNPJ(vm[firstObjectName][secondObjectName], e);
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#maskCNPJwithinOneObject
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Masks the input value for CPF on keypress within two objects.
         *
         * @param {Object} firstObjectName parameter
         * @param {Object} secondObjectName parameter
         * @param {Object} thirdObjectName parameter
         * @param {Object} $event Event triggered.
         **/
        function maskCNPJwithinTwoObject(firstObjectName, secondObjectName, thirdObjectName, e) {
            vm[firstObjectName][secondObjectName][thirdObjectName] = maskCNPJ(vm[firstObjectName][secondObjectName][thirdObjectName], e);
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#maskCNPJwithinOneObject
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Masks the input value for CNPJ on keypress within four objects.
         *
         * @param {Object} firstObjectName parameter
         * @param {Object} secondObjectName parameter
         * @param {Object} thirdObjectName parameter
         * @param {Object} fourthObjectName parameter
         * @param {Object} fifthObjectName parameter
         * @param {Object} $event Event triggered.
         **/
        function maskCNPJwithinFourObject(firstObjectName, secondObjectName, thirdObjectName, fourthObjectName, fifthObjectName, e) {
            vm[firstObjectName][secondObjectName][thirdObjectName][fourthObjectName][fifthObjectName] = maskCNPJ(vm[firstObjectName][secondObjectName][thirdObjectName][fourthObjectName][fifthObjectName], e);
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#maskCNPJwithinFiveObject
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Masks the input value for CNPJ on keypress within four objects.
         *
         * @param {Object} firstObjectName parameter
         * @param {Object} secondObjectName parameter
         * @param {Object} thirdObjectName parameter
         * @param {Object} fourthObjectName parameter
         * @param {Object} $event Event triggered.
         **/
        function maskCNPJwithinFiveObject(firstObjectName, secondObjectName, thirdObjectName, fourthObjectName, e) {
            vm[firstObjectName][secondObjectName][thirdObjectName][fourthObjectName] = maskCPF(vm[firstObjectName][secondObjectName][thirdObjectName][fourthObjectName], e);
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#maskCPF
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Masks the input value for CPF on keypress.
         *
         * @param {Object} mainObjectName parameter
         * @param {Object} $event Event triggered.
         **/
        function maskCPF(mainObjectName, e) {
            var key = e.which || e.keyCode || 0;

            if ((key == 8) || (key > 47 && key < 58)) {

                if (undefined !== mainObjectName && null !== mainObjectName) {
                    if (mainObjectName.length == 3) {
                        mainObjectName = mainObjectName + '.';
                    }

                    if (mainObjectName.length == 7) {
                        mainObjectName = mainObjectName + '.';
                    }

                    if (mainObjectName.length == 11) {
                        mainObjectName = mainObjectName + '-';
                    }

                    if (mainObjectName.length >= 14 && (key != 8)) {
                        e.preventDefault();
                    }
                }
            } else {
                e.preventDefault();
            }

            return mainObjectName;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#maskCNPJ
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Masks the input value for CNPJ on keypress.
         *
         * @param {Object} mainObjectName parameter
         * @param {Object} $event Event triggered.
         **/
        function maskCNPJ(mainObjectName, e) {
            var key = e.which || e.keyCode || 0;

            if ((key == 8) || (key > 47 && key < 58)) {
                if (undefined !== mainObjectName && null !== mainObjectName) {
                    if (mainObjectName.length == 2) {
                        mainObjectName = mainObjectName + '.';
                    }

                    if (mainObjectName.length == 6) {
                        mainObjectName = mainObjectName + '.';
                    }

                    if (mainObjectName.length == 10) {
                        mainObjectName = mainObjectName + '/';
                    }

                    if (mainObjectName.length == 15) {
                        mainObjectName = mainObjectName + '-';
                    }

                    if (mainObjectName.length >= 18 && (key != 8)) {
                        e.preventDefault();
                    }
                }
            } else {
                e.preventDefault();
            }

            return mainObjectName;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#addAlert
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Adds an alert to be shown on screen.
         *
         * @param {String} type The type of alert to show (`success`, `warning`, `error`).
         * @param {String} message The alert message.
         * @param {String} conflictNames Array.
         **/
        function addAlert(type, message, conflictNames, trid) {
            vm.alerts.push({
                type: type,
                msg: message,
                conflictNames: conflictNames,
                trid: trid
            });
        }


        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#saveEnderecoCobranca
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * This method will call save and associate
         *
         * @param {String} section Determines the current section.
         * @params {String} form Pessoa section form name.
         *
         **/
        function saveEnderecoCobranca() {
            $scope.orcamentoCtrl.savedProposta = false;
            if (vm.proposta.enderecoCobranca.flagEnderecoCobranca === 1) {
                savePessoa('enderecoPessoaSeguroCobranca');
            } else if (vm.proposta.enderecoCobranca.flagEnderecoCobranca === 2) {
                var codigoPessoa = vm.proposta.dadosPessoaSegurado.codigoPessoa;
                var codigoEndereco = getLatestEndereco();

                var propostaPagador = {};
                propostaPagador.numeroProposta = vm.proposta.numeroProposta;
                propostaPagador.numeroVersaoProposta = vm.proposta.numeroVersaoProposta;
                propostaPagador.pagadores = {
                    pagador: [{
                        dadosPessoaPagador: {
                            codigoPessoa: codigoPessoa
                        },
                        enderecoCobranca: {
                            codigoEndereco: codigoEndereco
                        }
                    }]
                };

                vm.proposta.enderecoCobranca.codigoEndereco = vm.proposta.enderecoCobranca.enderecosCadastrado;

                OrcamentoPropostaService.associarEnderecoCobranca(vm.proposta.numeroProposta,
                    vm.proposta.numeroVersaoProposta, 1, codigoPessoa, propostaPagador).then(function(response) {
                    if (response.data && response.data.documentoEmissao &&
                        response.data.documentoEmissao.pagadores &&
                        response.data.documentoEmissao.pagadores.pagador) {
                        atualizarEnderecoCobrancaPagador();
                    }
                }, function(error) {
                    displayError(error);
                });
            }
        }

        function atualizarEnderecoCobrancaPagador() {
            if (vm.proposta.enderecoCobranca && vm.proposta.enderecoCobranca.codigoEndereco) {
                if (vm.proposta.pagadores && vm.proposta.pagadores.pagador &&
                    vm.proposta.pagadores.pagador.length > 0) {
                    angular.forEach(vm.proposta.pagadores.pagador, function(pagador) {
                        pagador.enderecoCobranca = vm.proposta.enderecoCobranca;
                    });
                }
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#saveEnderecoCorrespondencia
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * This method will call save and associate
         *
         **/
        function saveEnderecoCorrespondencia() {
            $scope.orcamentoCtrl.savedProposta = false;
            if (vm.proposta.enderecoCorrespondencia.flagEnderecoCorrespondencia == 1) {
                savePessoa('enderecoPessoaSeguroCorrespondencia');
            } else if (vm.proposta.enderecoCorrespondencia.flagEnderecoCorrespondencia == 2) {
                vm.proposta.enderecoCorrespondencia.codigoEndereco = vm.proposta.enderecoCorrespondencia.enderecosCadastrado;
            }
        }

        //PESSOA METHODS

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#savePessoa
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * This method will call the createPessoa method from pessoa service
         *
         * @param {String} section Determines the current section.
         * @params {String} form Pessoa section form name.
         *
         **/
        function savePessoa(section) {

            vm.section = section;
            var hasError = false;
            var showSuccessMessage = true;

            if (vm.section === 'contatoPessoaSeguro') {
                hasError = checkContatoMandatoryField();
            }
            if (vm.section === 'documentoPessoaSeguro') {
                hasError = checkDocumentoMandatoryField();
            }
            if (vm.section === 'enderecoPessoaSeguro') {
                hasError = checkEnderecoMandatoryField();
            }
            if (vm.section === 'enderecoPessoaSeguroCorres') {
                hasError = checkEnderecoCorresMandatoryField();
            }
            if (vm.section === 'enderecoPessoaSeguroCobranca') {
                showSuccessMessage = false;
            }
            if (hasError) {
                displayPreconditionError(Constants.MSG_ERROR_SAVE);
                return;
            } else {
                updatePessoa(showSuccessMessage);
            }
        }

        function checkContatoMandatoryField() {
            var hasError = vm.dadosContatoForm.$invalid;
            var contatoHasError = false;

            vm.isDadosContatoFormSubmitted = true;

            if (parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 1 ||
                parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 5 ||
                parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 6 ||
                parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 7) {
                validateTextoContato();
                contatoHasError = vm.istextoContatoEmpty;
            } else {
                validateDDD();
                //  validateDDI();
                validateNumeroContato();

                contatoHasError = vm.isDDIEmpty || vm.isDDDEmpty || vm.isnumeroContatoEmpty;
            }

            return hasError || contatoHasError;
        }

        function checkDocumentoMandatoryField() {
            var hasError = vm.documentosComplementaresForm.$invalid;
            vm.isDocumentosComplementaresFormSubmitted = true;

            if (angular.isUndefined(vm.documentosComplementaresForm.$error.required) &&
                angular.isDefined(vm.documentosComplementaresForm.$error.date)) {
                hasError = checkIfHasInvalidDate(vm.documentosComplementaresForm.$error.date);
            }

            return hasError;
        }

        function checkIfHasInvalidDate(errorDateList) {
            var hasInvalidDate = false;
            var viewValue = '';

            angular.forEach(errorDateList, function(date) {
                switch (date) {
                    case 'dataemissaodocumento':
                        viewValue = vm.documentosComplementaresForm.dataemissaodocumento.$viewValue;
                        hasInvalidDate = checkIsInvalidDate(viewValue);
                        break;
                    case 'dataValidade':
                        viewValue = vm.documentosComplementaresForm.dataValidade.$viewValue;
                        hasInvalidDate = checkIsInvalidDate(viewValue);
                        break;
                    default:
                        break;
                }

                if (hasInvalidDate) {
                    return false;
                }
            });

            return hasInvalidDate;
        }

        function checkIsInvalidDate(dateString) {
            var isInvalid = false;

            if (angular.isString(dateString) && viewValue.length === 10) {
                var digitArray = dateString.split('/');
                if (digitArray.length === 3) {
                    var date = new Date(digitArray[0] + '/' + digitArray[1] + '/' + digitArray[2]);
                    if (isNaN(Date.parse(date))) {
                        isInvalid = true;
                    }
                } else {
                    isInvalid = true;
                }
            } else {
                isInvalid = true;
            }

            return isInvalid;
        }

        function checkEnderecoMandatoryField() {

            var hasError = vm.enderecoForm.$invalid;
            var hasErrorNumero = false;
            vm.isNumeroEmpty = false;
            if (vm.enderecoPessoaSeguro.flagSemNumero === 'N') {
                hasErrorNumero = checkSemNumero();
            }
            vm.isEnderecoFormSubmitted = true;

            return hasError || hasErrorNumero;
        }

        function checkEnderecoCorresMandatoryField() {

            var decimalPoint = '.';
            var latitudeString = '';
            var longitudeString = '';
            var latitudeIndex = -1;
            var longitudeIndex = -1;

            if (angular.isDefined(vm.enderecoForm2.latitude) && vm.enderecoForm2.latitude !== '') {
                latitudeString = vm.enderecoForm2.latitude.toString();
                latitudeIndex = latitudeString.indexOf(decimalPoint);
            }

            if (angular.isDefined(vm.enderecoForm2.longitude) && vm.enderecoForm2.longitude !== '') {
                longitudeString = vm.enderecoForm2.longitude.toString();
                longitudeIndex = longitudeString.indexOf(decimalPoint);
            }

            if (latitudeIndex > -1) {
                vm.enderecoForm2.latitude = Number(latitudeString.substring(0, latitudeIndex));
            }
            if (longitudeIndex > -1) {
                vm.enderecoForm2.longitude = Number(longitudeString.substring(0, longitudeIndex));
            }

            var hasError = vm.enderecoForm2.$invalid;
            var hasErrorNumero = false;
            vm.isEnderecoCorresFormSubmitted = false;
            if (vm.enderecoPessoaSeguroCorres.flagSemNumero === 'N') {
                hasErrorNumero = checkCorresSemNumero();
            }
            vm.isEnderecoCorresFormSubmitted = true;

            return hasError || hasErrorNumero;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#updatePessoa
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * This method will call the updatePessoa method from pessoa service
         *
         *
         **/
        function updatePessoa(showSuccessMessage) {

            var converted = {};
            converted = convertPessoaChildObject();

            //SM 599
            PessoaService.updatePessoa(converted).then(
                function(response) {
                    clearAlerts();
                    if (angular.isDefined(showSuccessMessage) && showSuccessMessage) {
                        $rootScope.$broadcast(Constants.SUCCESSO, Constants.MSG_SUCCESS_SAVE);
                    }
                    setValuesOnSuccess(response.data);
                    setTimeout(function() {
                        clearAlerts();
                    }, 3000);
                },
                function(error) {
                    displayError(error);
                }
            );
            //FIM SM 599
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#convertPessoaChildObject
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * This method will construct the main object model (pessoaSeguro) with the
         * data of the section to be updated or created.
         *
         **/
        function convertPessoaChildObject() {
            var pessoa = {};
            var dateToReturn = null;
            var dateToReturnEmissao = null;
            var dateToReturnValidade = null;

            if (vm.section === 'documentoPessoaSeguro') {

                if (null !== vm.documentoPessoaSeguro.dataEmissaoDocumento) {
                    dateToReturnEmissao = new Date(vm.documentoPessoaSeguro.dataEmissaoDocumento);
                }

                vm.documentoPessoaSeguro.dataEmissaoDocumento = dateToReturnEmissao;

                if (null !== vm.documentoPessoaSeguro.dataValidade && vm.documentoPessoaSeguro.dataValidade !== "") {
                    dateToReturnValidade = new Date(vm.documentoPessoaSeguro.dataValidade);
                }

                vm.documentoPessoaSeguro.dataValidade = dateToReturnValidade;

                pessoa = PessoaFactory.convertBackDocumentoPessoaSeguro(vm.documentoPessoaSeguro, vm.proposta.dadosPessoaSegurado);

            } else if (vm.section === 'contatoPessoaSeguro') {
                if (parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 1) {
                    vm.contatoPessoaSeguro.textoContato = vm.contatoPessoaSeguro.textoContatoEmail;
                } else if (parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 5 ||
                    parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 6 ||
                    parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 7) {
                    vm.contatoPessoaSeguro.textoContato = vm.contatoPessoaSeguro.textoContatoLink;
                }

                pessoa = PessoaFactory.convertBackContatoPessoaSeguro(vm.contatoPessoaSeguro, vm.proposta.dadosPessoaSegurado);

            } else if (vm.section === 'enderecoPessoaSeguro') {
                vm.enderecoPessoaSeguro.flagAtivo = 'S';
                vm.enderecoPessoaSeguro.flagPrincipal = 'N';
                vm.enderecoPessoaSeguro.codigoUnidadeFederacao = obterCodigoUnidadeFederacao(vm.enderecoPessoaSeguro.nomeUnidadeFederacao);

                pessoa = PessoaFactory.convertBackEnderecoPessoaSeguro(vm.enderecoPessoaSeguro, vm.proposta.dadosPessoaSegurado);
            } else if (vm.section === 'enderecoPessoaSeguroCorres') {
                vm.enderecoPessoaSeguroCorres.flagAtivo = 'S';
                vm.enderecoPessoaSeguroCorres.flagPrincipal = 'N';
                vm.enderecoPessoaSeguroCorres.codigoUnidadeFederacao = obterCodigoUnidadeFederacao(vm.enderecoPessoaSeguroCorres.nomeUnidadeFederacao);

                pessoa = PessoaFactory.convertBackEnderecoPessoaSeguro(vm.enderecoPessoaSeguroCorres, vm.proposta.dadosPessoaSegurado);
            } else if (vm.section === 'enderecoPessoaSeguroCobranca') {
                var localRiscoCobranca = vm.proposta.enderecoCobranca.localDeRisco;
                pessoa = PessoaFactory.convertBackEnderecoPessoaSeguro(vm.localRiscoMap[localRiscoCobranca], vm.proposta.dadosPessoaSegurado);
            } else if (vm.section === 'enderecoPessoaSeguroCorrespondencia') {
                var localRiscoCorrespondencia = vm.proposta.enderecoCorrespondencia.localDeRisco;
                pessoa = PessoaFactory.convertBackEnderecoPessoaSeguro(vm.localRiscoMap[localRiscoCorrespondencia], vm.proposta.dadosPessoaSegurado);
            } else {

                if (parseInt(vm.proposta.dadosPessoaSegurado.codigoTipoPessoa) === 1) {
                    if (vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento) {
                        dateToReturn = new Date(vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento);
                    }
                    vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento = dateToReturn;
                    pessoa = PessoaFactory.convertBackPessoaFisicaSeguro(vm.proposta.dadosPessoaSegurado, vm.vinculoPessoaSeguro);
                } else {
                    pessoa = PessoaFactory.convertBackPessoaJuridicaSeguro(vm.proposta.dadosPessoaSegurado);
                }
            }
            var converted = {};
            converted.pessoa = pessoa;

            return converted;
        }

        function obterCodigoUnidadeFederacao(nomeUnidadeFederacao) {
            if (nomeUnidadeFederacao) {
                var unidadeFederacao = vm.unidadeFederacaoOptions.filter(function(unidade) {
                    return unidade.nomeDominio == nomeUnidadeFederacao;
                }, true);
                if (unidadeFederacao && unidadeFederacao.length > 0) {
                    return unidadeFederacao[0].codigoValorDominio;
                }
                return 0;
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#getOfertaDetails
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Get oferta Details.
         *
         **/
        function getOfertaDetails() {
            var orcamento = vm.proposta.orcamento;
            var filteredOptions = [];

            blockUI.start();
            CanonicoService.listarProdutoComercais(0, 0, codigoEmpresa, $filter('date')(new Date(), Constants.DATE_FORMAT_BACKEND)).then(
                function(response) {
                    filteredOptions = CanonicoFactory.convertProdutoComercialList(response.data);

                    var produtoComercial = $filter('filter')(filteredOptions, {
                        "nomeProdutoComercial": orcamento.nomeProdutoComercial
                    }, true)[0];
                    if (produtoComercial && produtoComercial.nomeResumidoProdutoComercial) {
                        vm.selectedProdutoComercialName = produtoComercial.nomeResumidoProdutoComercial;
                        /** RTC 8604 **/
                        if (produtoComercial.codigoRamo === 739 && produtoComercial.codigoModalidade === 0 &&
                            produtoComercial.codigoGrupoComercial === 987 && produtoComercial.codigoEmpresa === 1) {
                            vm.flagHideTipoClassificacaoPessoa = false;
                        }
                        /** RTC 8604 **/

                        blockUI.start();
                        CanonicoService.listarOfertasPorProdutoComercial(produtoComercial.codigoEmpresa,
                            produtoComercial.codigoGrupoComercial, produtoComercial.codigoRamo,
                            produtoComercial.codigoModalidade,
                            produtoComercial.numeroVersaoProdutoComercial,
                            produtoComercial.numeroSequenciaVersaoProdutoComercial).then(

                            function(ofertas) {
                                filteredOptions = CanonicoFactory.convertOfertaList(ofertas.data);
                                var oferta = $filter('filter')(filteredOptions, {
                                    "nomeOferta": orcamento.nomeOferta
                                }, true)[0];

                                if (oferta && oferta.nomeResumidoOferta) {
                                    vm.selectedOfertaName = oferta.nomeResumidoOferta;
                                } else {
                                    vm.selectedOfertaName = orcamento.nomeOferta;
                                }
                                blockUI.stop();
                            },
                            function(error) {
                                displayError(error);
                                blockUI.stop();
                            });
                    } else {
                        vm.selectedOfertaName = orcamento.nomeOferta;
                        vm.selectedProdutoComercialName = orcamento.nomeProdutoComercial;
                    }
                    blockUI.stop();
                },
                function(error) {
                    displayError(error);
                    blockUI.stop();
                });
            blockUI.start();
            CanonicoService.buscarOferta(orcamento.codigoOferta, orcamento.numeroVersaoOferta, orcamento.numeroSequenciaVersaoOferta).then(
                function(ofertaResponse) {
                    var oferta = CanonicoFactory.convertOferta(ofertaResponse.data);
                    var descontoOfertaList = oferta.descontosAgravos;
                    coberturaOfertaList = oferta.coberturas;

                    angular.forEach(orcamento.descontoAgravo, function(descontoAgravoOrcamento) {
                        var filteredDesconto = $filter('filter')(descontoOfertaList, {
                            codigoDescontoAgravo: descontoAgravoOrcamento.codigoDescontoAgravo
                        }, true)[0];
                        if (angular.isObject(filteredDesconto)) {
                            var data = {};
                            data = OrcamentoPropostaFactory.convertDesconto(filteredDesconto, descontoAgravoOrcamento);
                            vm.descontos.push(data);
                        }
                    });

                    if (angular.isDefined(oferta.tiposFormularios) &&
                        angular.isDefined(oferta.tiposFormularios.tipoFormularioOferta)) {
                        PageInfo.listaTiposFomulario = oferta.tiposFormularios.tipoFormularioOferta;
                    }

                    if (angular.isDefined(oferta.flagPermissaoMultiploSegurado)) {
                        if (oferta.flagPermissaoMultiploSegurado === 'S') {
                            vm.flagPermissaoMultiploSegurado = true;
                        } else {
                            if (vm.getDefaultDadosSegurado &&
                                vm.getDefaultDadosSegurado.cossegurado) {
                                vm.getDefaultDadosSegurado.cossegurado.flagPossuiCossegurado = 'N';
                                vm.flagPermissaoMultiploSegurado = false;
                            }
                        }
                    }

                    var codigoFormularioList = oferta.tiposFormularios.filter(function(i) {
                        if (angular.isDefined($scope.orcamentoCtrl.documentos[$scope.orcamentoCtrl.activeTabIndex]) &&
                            angular.isDefined($scope.orcamentoCtrl.documentos[$scope.orcamentoCtrl.activeTabIndex].tabDetails) &&
                            i.codigoTipoImpressao == $scope.orcamentoCtrl.documentos[$scope.orcamentoCtrl.activeTabIndex].tabDetails.codigoTipoFormulario) {
                            return i.codigoFormulario;
                        }
                    });
                    //if (codigoFormularioList && codigoFormularioList.length > 0) {
                    //    $scope.orcamentoCtrl.isPrintDisabled = false;
                    //    $scope.orcamentoCtrl.orcamento.codigoFormulario = codigoFormularioList[0].codigoFormulario;
                    //} else {
                    //    $scope.orcamentoCtrl.isPrintDisabled = true;
                    //}

                    if (codigoFormularioList && codigoFormularioList.length > 0) {
                        $scope.orcamentoCtrl.orcamento.codigoFormulario = codigoFormularioList[0].codigoFormulario;
                        $scope.orcamentoCtrl.codigoFormulario = codigoFormularioList[0].codigoFormulario;
                    }

                    if (vm.proposta.codigoStatusProposta === 2 || vm.proposta.dataProtocolo) {
                        $scope.orcamentoCtrl.isPrintDisabled = false;
                    } else {
                        $scope.orcamentoCtrl.isPrintDisabled = true;
                    }
                    blockUI.stop();
                },
                function(error) {
                    displayError(error);
                    blockUI.stop();
                }
            );
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#getParceiroNegocioDetails
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Get Parceiro Negocio Details.
         *
         **/
        function getParceiroNegocioDetails(codigoParceiroNegocio, numeroVersaoParceiroNegocio) {
            // Get specific details only if there is.
            if (angular.isNumber(codigoParceiroNegocio) && !isNaN(codigoParceiroNegocio) &&
                angular.isNumber(numeroVersaoParceiroNegocio) && !isNaN(numeroVersaoParceiroNegocio)) {
                blockUI.start();
                ParceiroNegocioService.getParceiroNegocio(codigoParceiroNegocio, numeroVersaoParceiroNegocio).then(

                    function(response) {
                        vm.selectedParceiroNegocioName = response.data.nomeResumidoParceiroNegocio;
                        blockUI.stop();
                    },
                    function(error) {
                        displayError(error);
                        blockUI.stop();
                    }
                );
            }
        }


        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#setValuesToNull
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * This method will set the values of the optional elements in the screen to null
         * when the the element is not present on the screen.
         *
         **/
        function setValuesToNull(element) {
            vm.alerts = [];

            if (element === 'pessoaExpostaPolitacamente') {
                vm.proposta.dadosPessoaSegurado.vinculos[0].numeroCnpjCpfPessoaVinculo = null;
                vm.proposta.dadosPessoaSegurado.vinculos[0].nomePessoaVinculo = null;
                vm.proposta.dadosPessoaSegurado.vinculos[0].codigoTipoPessoaVinculo = null;
            } else if (element === 'tipoContato') {
                vm.alerts = [];
                vm.isDadosContatoFormSubmitted = false;
                vm.showContatoEmail = false;
                vm.showContatoNumber = false;
                vm.contatoPessoaSeguro.numeroDdi = null;
                vm.contatoPessoaSeguro.numeroDdd = null;
                vm.contatoPessoaSeguro.numeroContato = null;
                vm.contatoPessoaSeguro.textoContatoLink = null;
                vm.contatoPessoaSeguro.textoContatoEmail = null;
                if (parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 1 ||
                    parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 5 ||
                    parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 6 ||
                    parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 7) {
                    vm.showContatoEmail = true;
                } else if (vm.contatoPessoaSeguro.codigoTipoContato !== '') {
                    vm.showContatoNumber = true;
                }

            } else if (element === 'pessoaFisicaJuridica') {
                vm.proposta.dadosPessoaSegurado.numeroCnpjCpf = null;
                vm.proposta.dadosPessoaSegurado.flagAtivo = null;
                vm.proposta.dadosPessoaSegurado.nomePessoa = null;
                vm.proposta.dadosPessoaSegurado.nomeResumidoPessoa = null;
                if (parseInt(vm.proposta.dadosPessoaSegurado.codigoTipoPessoa) === 1) {
                    vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoEstadoCivil = null;
                    vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoFaixaRenda = null;
                    vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoNacionalidade = null;
                    vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoOcupacao = null;
                    vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoSexoPessoa = null;
                    vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoTipoExposicaoPessoa = null;
                    vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento = null;
                    vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoPais = null;
                    vm.isFisicaFormSubmitted = false;
                    vm.isJuridicaFormSubmitted = false;
                    vm.isJuridicaCnpjEmpty = false;
                    vm.isCodigoSeguradoraSusepEmpty = false;
                    vm.alerts = [];
                } else {
                    vm.proposta.dadosPessoaSegurado.pessoaJuridica.codigoAtividadeEconomica = null;
                    vm.proposta.dadosPessoaSegurado.pessoaJuridica.nomeAtividadeEconomica = "";
                    vm.proposta.dadosPessoaSegurado.pessoaJuridica.codigoFaixaReceitaOperacionalAno = null;
                    vm.proposta.dadosPessoaSegurado.pessoaJuridica.codigoFaixaPatrimonioLiquido = null;
                    vm.proposta.dadosPessoaSegurado.pessoaJuridica.codigoNaturezaJuridica = null;
                    vm.proposta.dadosPessoaSegurado.pessoaJuridica.flagCongenere = null;
                    vm.proposta.dadosPessoaSegurado.pessoaJuridica.codigoSusepCongenere = null;
                    vm.proposta.dadosPessoaSegurado.pessoaJuridica.dataRegistroAbertura = null;
                    vm.isFisicaFormSubmitted = false;
                    vm.isJuridicaFormSubmitted = false;
                    vm.isJuridicaCnpjEmpty = false;
                    vm.isCodigoSeguradoraSusepEmpty = false;
                    vm.alerts = [];
                }
            }
        }


        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#validateTextoContato
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Validate the TextoContato.
         *
         **/
        function validateTextoContato() {
            if (parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 1) {
                if (OrcamentoUtilityFactory.isNullOrEmpty(vm.contatoPessoaSeguro.textoContatoEmail)) {
                    vm.istextoContatoEmpty = true;
                } else {
                    vm.istextoContatoEmpty = false;
                }
            } else {
                if (OrcamentoUtilityFactory.isNullOrEmpty(vm.contatoPessoaSeguro.textoContatoLink)) {
                    vm.istextoContatoEmpty = true;
                } else {
                    vm.istextoContatoEmpty = false;
                }
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#displayError
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Private method that displays an error alert in the form.
         *
         * @param {String} message that will be displayed in the banner.
         **/
        function displayErrorModal(message) {
            vm.alerts = [];
            addAlert(Constants.ERROR_TYPE, message);
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#validateCodigoSeguradoraSusepInput
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Validate the CodigoSeguradoraSusep input.
         *
         **/
        function validateCodigoSeguradoraSusepInput() {
            var hasError = false;
            if (OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.dadosPessoaSegurado.pessoaJuridica.codigoSusepCongenere)) {
                hasError = true;
            } else {
                hasError = false;
            }
            return hasError;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#validateDDD
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Validate the DDD input.
         *
         **/
        function validateDDD() {
            if (OrcamentoUtilityFactory.isNullOrEmpty(vm.contatoPessoaSeguro.numeroDdd)) {
                vm.isDDDEmpty = true;
            } else {
                vm.isDDDEmpty = false;
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#validateDDI
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Validate the DDI input.
         *
         **/
        function validateDDI() {
            if (OrcamentoUtilityFactory.isNullOrEmpty(vm.contatoPessoaSeguro.numeroDdi)) {
                vm.isDDIEmpty = true;
            } else {
                vm.isDDIEmpty = false;
            }
        }

        function checkSemNumero() {
            var retorno = false;

            if (OrcamentoUtilityFactory.isNullOrEmpty(vm.enderecoPessoaSeguro.numeroLogradouro)) {
                vm.isNumeroEmpty = true;
            } else {
                vm.isNumeroEmpty = false;
            }
            return retorno;
        }

        function checkCorresSemNumero() {
            var retorno = false;

            if (OrcamentoUtilityFactory.isNullOrEmpty(vm.enderecoPessoaSeguroCorres.numeroLogradouro)) {
                vm.isNumeroCorresEmpty = true;
            } else {
                vm.isNumeroCorresEmpty = false;
            }
            return retorno;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#validateNumeroContato
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Validate the Numero Contato input.
         *
         **/
        function validateNumeroContato() {
            if (OrcamentoUtilityFactory.isNullOrEmpty(vm.contatoPessoaSeguro.numeroContato)) {
                vm.isnumeroContatoEmpty = true;
            } else {
                vm.isnumeroContatoEmpty = false;
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#clearCodigoSeguradoSusep
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Clear the CodigoSeguradoraSusep input.
         *
         **/
        function clearCodigoSeguradoSusep() {
            vm.proposta.dadosPessoaSegurado.pessoaJuridica.codigoSusepCongenere = null;
            vm.isCodigoSeguradoraSusepEmpty = false;
        }


        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#setValuesOnSuccess
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * This method will update the entries of tables of each section when
         * creating or updating record is successful.
         *
         **/
        function setValuesOnSuccess(data) {
            if (vm.section === 'fisica') {
                if (!vm.isEditMode) {
                    vm.isEditMode = true;
                }
                vm.proposta.dadosPessoaSegurado = PessoaFactory.setPessoaFisicaForm(vm.proposta.dadosPessoaSegurado, data);
                if (vm.proposta.dadosPessoaSegurado.vinculos.length > 0) {
                    vm.proposta.dadosPessoaSegurado.vinculos = PessoaFactory.setToVinculoPessoaSeguroForm(vm.proposta.dadosPessoaSegurado.vinculos[0]);
                } else {
                    vm.proposta.dadosPessoaSegurado.vinculos = PessoaFactory.getDefaultVinculoPessoaSeguro();
                }
                vm.showDocumentosComplementares = true;
                vm.showDadosEndereco = true;
                vm.showDadosContato = true;
            } else if (vm.section === 'juridica') {
                if (!vm.isEditMode) {
                    vm.isEditMode = true;
                }
                vm.showDocumentosComplementares = false;
                vm.proposta.dadosPessoaSegurado = PessoaFactory.setPessoaJuridicaForm(vm.proposta.dadosPessoaSegurado, data);
                vm.showDadosEndereco = true;
                vm.showDadosContato = true;
            } else if (vm.section === 'contatoPessoaSeguro') {
                PessoaFactory.getContatoPessoaSeguro(data.pessoa.contatos.contato);
                vm.proposta.dadosPessoaSegurado.contatos = PessoaFactory.convertContatoPessoaSeguros(data.pessoa.contatos.contato, vm.tipoContatoOptions);
                vm.contatoPessoaSeguro = PessoaFactory.getDefaultContatoPessoaSeguro();
                vm.contatoPessoaSeguro.textoContatoEmail = null;
                vm.contatoPessoaSeguro.textoContatoLink = null;
                vm.isDadosContatoFormSubmitted = false;
                vm.showContatoEmail = false;
                vm.showContatoNumber = false;
            } else if (vm.section === 'documentoPessoaSeguro') {
                vm.proposta.dadosPessoaSegurado.documentos = PessoaFactory.convertDocumentoPessoaSeguros(data.pessoa.documentos.documento, vm.tipoDocumentoPessoaOptions, vm.unidadeFederacaoOptions);
                vm.documentoPessoaSeguro = PessoaFactory.getDefaultDocumentoPessoaSeguro();
                vm.isDocumentosComplementaresFormSubmitted = false;
                vm.showDadosEndereco = true;
            } else if (vm.section === 'enderecoPessoaSeguro') {
                vm.proposta.dadosPessoaSegurado.enderecosPessoa = PessoaFactory.convertEnderecoPessoaSeguros(data.pessoa.enderecosPessoa, vm.tipoEnderecoOptions, vm.tipoLogradouroOptions);
                vm.isEnderecoFormSubmitted = false;
                //vm.enderecoPessoaSeguro = PessoaFactory.getDefaultEnderecoPessoaSeguro();
                vm.showDadosContato = true;
                vm.logradouro = null;
                saveLocalRiscoCobrancaToProposta();
            } else if (vm.section === 'enderecoPessoaSeguroCorres') {
                vm.proposta.dadosPessoaSegurado.enderecosPessoa = PessoaFactory.convertEnderecoPessoaSeguros(data.pessoa.enderecosPessoa, vm.tipoEnderecoOptions, vm.tipoLogradouroOptions);
                vm.isEnderecoCorresFormSubmitted = false;
                //vm.enderecoPessoaSeguroCorres = PessoaFactory.getDefaultEnderecoPessoaSeguro();
                vm.showDadosContato = true;
                vm.logradouro = null;
                saveLocalRiscoCorrespondenciaToProposta();
            } else if (vm.section === 'enderecoPessoaSeguroCobranca') {
                vm.proposta.dadosPessoaSegurado.enderecosPessoa = PessoaFactory.convertEnderecoPessoaSeguros(data.pessoa.enderecosPessoa, vm.tipoEnderecoOptions, vm.tipoLogradouroOptions);
                saveLocalRiscoCobrancaToProposta();
            } else if (vm.section === 'enderecoPessoaSeguroCorrespondencia') {
                vm.proposta.dadosPessoaSegurado.enderecosPessoa = PessoaFactory.convertEnderecoPessoaSeguros(data.pessoa.enderecosPessoa, vm.tipoEnderecoOptions, vm.tipoLogradouroOptions);
                saveLocalRiscoCorrespondenciaToProposta();
            }
        }


        function saveLocalRiscoCobrancaToProposta() {
            var codigoEnderecoCobranca = getLatestEndereco();
            var codigoPessoa = vm.proposta.dadosPessoaSegurado.codigoPessoa;
            var propostaPagador = {};

            propostaPagador.numeroProposta = vm.proposta.numeroProposta;
            propostaPagador.numeroVersaoProposta = vm.proposta.numeroVersaoProposta;
            propostaPagador.pagadores = {
                pagador: [{
                    dadosPessoaPagador: {
                        codigoPessoa: codigoPessoa
                    },
                    enderecoCobranca: {
                        codigoEndereco: codigoEnderecoCobranca
                    }
                }]
            };

            vm.proposta.enderecoCobranca.codigoEndereco = codigoEnderecoCobranca;

            OrcamentoPropostaService.associarEnderecoCobranca(vm.proposta.numeroProposta,
                vm.proposta.numeroVersaoProposta, codigoEmpresa, codigoPessoa, propostaPagador).then(
                function(response) {
                    if (response.data && response.data.documentoEmissao &&
                        response.data.documentoEmissao.pagadores &&
                        response.data.documentoEmissao.pagadores.pagador) {
                        atualizarEnderecoCobrancaPagador();
                    }
                },
                function(error) {
                    displayError(error);
                    var error = error.data;
                });

        }

        function saveLocalRiscoCorrespondenciaToProposta() {
            var codigoEnderecoCorrespondencia = getLatestEndereco();
            vm.proposta.enderecoCorrespondencia.codigoEndereco = codigoEnderecoCorrespondencia;
        }

        function getLatestEndereco() {
            var codigoEndereco = 0;

            if (vm.section === 'enderecoPessoaSeguro' || vm.section === 'enderecoPessoaSeguroCorres') {
                var numeroCep = (vm.section === 'enderecoPessoaSeguro' ? vm.enderecoPessoaSeguro.numeroCep : vm.enderecoPessoaSeguroCorres.numeroCep);
                var enderecosPessoa = $filter('orderBy')(vm.proposta.dadosPessoaSegurado.enderecosPessoa, ['codigoEndereco'], true);
                enderecosPessoa = $filter('filter')(enderecosPessoa, {
                    "numeroCep": PessoaFactory.formatCep(numeroCep)
                });
                if (enderecosPessoa.length > 0) {
                    return enderecosPessoa[0].codigoEndereco;
                }
            } else if (vm.proposta.enderecoCobranca.localDeRisco) {
                var item = vm.localRiscoList.filter(function(local) {
                    return local.codigoLocalRisco == vm.proposta.enderecoCobranca.localDeRisco;
                }).shift();

                if (!item) return vm.proposta.enderecoCobranca.localDeRisco;

                var enderecosPessoa = vm.proposta.dadosPessoaSegurado.enderecosPessoa.filter(
                    function (endereco) {
                        var validation = endereco.codigoLogradouro == item.codigoLogradouro 
                        && endereco.numeroLogradouro == item.numeroLogradouro
                        && endereco.nomeLogradouro == item.nomeLogradouro
                        && endereco.nomeEndereco.indexOf(item.nomeLogradouro + ', ' + item.numeroLogradouro + ', ' + item.nomeBairro) !== -1
                        return validation;
                    }
                ).shift();

                if (enderecosPessoa) codigoEndereco = enderecosPessoa.codigoEndereco;

            } else if (vm.proposta.enderecoCorrespondencia.localDeRisco) {

                var item = vm.localRiscoList.filter(function(local) {
                    return local.codigoLocalRisco == vm.proposta.enderecoCorrespondencia.localDeRisco;
                }).shift();
                
                if (!item) return vm.proposta.enderecoCorrespondencia.localDeRisco;

                var enderecosPessoa = vm.proposta.dadosPessoaSegurado.enderecosPessoa.filter(
                    function (endereco) {
                        var validation = endereco.codigoLogradouro == item.codigoLogradouro 
                        && endereco.numeroLogradouro == item.numeroLogradouro
                        && endereco.nomeLogradouro == item.nomeLogradouro
                        && endereco.nomeEndereco.indexOf(item.nomeLogradouro + ', ' + item.numeroLogradouro + ', ' + item.nomeBairro) !== -1
                        return validation;
                    }
                ).shift();
                
                if (enderecosPessoa) codigoEndereco = enderecosPessoa.codigoEndereco;
                
            } else {
                angular.forEach(vm.proposta.dadosPessoaSegurado.enderecosPessoa, function(endereco) {
                    if (endereco.codigoEndereco > codigoEndereco) {
                        codigoEndereco = endereco.codigoEndereco;
                    }
                });
            }
            return codigoEndereco;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#setDefaultValue
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * This method will set the default structure of each pessoa sections
         *
         **/
        function setDefaultValue() {

            vm.contatoPessoaSeguro = PessoaFactory.getDefaultContatoPessoaSeguro();
            vm.contatoPessoaSeguro.textoContatoLink = null;
            vm.contatoPessoaSeguro.textoContatoEmail = null;

            vm.documentoPessoaSeguro = PessoaFactory.getDefaultDocumentoPessoaSeguro();
            vm.enderecoPessoaSeguro = PessoaFactory.getDefaultEnderecoPessoaSeguro();
            vm.vinculoPessoaSeguro = PessoaFactory.getDefaultVinculoPessoaSeguro();

            vm.logradouro = null;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#buscarCep
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * This method will open the modal for pessoa component.
         *
         **/
        function buscarCep(state) {
            $modal.open({
                animation: true,
                size: 'lg',
                backdrop: 'static',
                keyboard: false,
                templateUrl: 'orcamento.logradouros.modal.html',
                controllerAs: 'modalLogradourosCtrl',
                controller: ['$modalInstance', function($modalInstance) {
                    var modal = this;
                    var selectedLogradouros = null;

                    modal.unidadeFederacaoOptions = vm.unidadeFederacaoOptions;
                    modal.tipoLogradouroOptions = vm.tipoLogradouroOptions;

                    modal.logradourosList = [];

                    modal.buscar = buscar;
                    modal.fechar = fechar;
                    modal.cancelar = cancelar;
                    modal.selectLogradouros = selectLogradouros;
                    modal.addAlert = addAlert;
                    modal.clearAlerts = clearAlerts;
                    modal.alerts = [];
                    modal.closeAlert = closeAlert;

                    function addAlert(type, message, trid) {
                        modal.alerts = [];
                        modal.alerts.push({
                            type: type,
                            msg: message,
                            trid: trid
                        });
                    }

                    function closeAlert(index) {
                        modal.alerts.splice(index, 1);
                    }

                    function clearAlerts() {
                        modal.alerts = [];
                    }

                    function fechar() {
                        // Check if there is selected item.
                        if (selectedLogradouros !== null) {
                            // var updatedLocalRisco = OrcamentoObjetoFactory.setLogradourosDetails(localRisco, selectedLogradouros);
                            // PageInfo.submissionObject.categoriasRisco[index].objetoRisco.localRisco = updatedLocalRisco;
                            if (state === 'cobranca') {
                                vm.enderecoPessoaSeguro =
                                    PessoaFactory.setEnderecoDetails(selectedLogradouros, vm.unidadeFederacaoOptions, vm.tipoLogradouroOptions);
                            } else {
                                vm.enderecoPessoaSeguroCorres =
                                    PessoaFactory.setEnderecoDetails(selectedLogradouros, vm.unidadeFederacaoOptions, vm.tipoLogradouroOptions);
                            }

                        }
                        $modalInstance.close(Constants.CONFIRM);
                    }

                    function cancelar() {
                        $modalInstance.dismiss(Constants.CANCEL);
                    }

                    function selectLogradouros(logradouros) {
                        selectedLogradouros = logradouros;
                    }

                    function buscar() {
                        modal.logradourosList = [];
                        LogradourosService.getLogradouroList(modal.filtroNomeLogradouro, modal.filtroCidade.toUpperCase(), modal.filtroCodigoUnidadeFederacao).then(

                            function(response) {
                                modal.clearAlerts();
                                if (response.data !== null) {
                                    modal.logradourosList = PessoaFactory.setEnderecoList(response.data, vm.unidadeFederacaoOptions, vm.tipoLogradouroOptions);
                                } else {
                                    modal.addAlert(Constants.INFO_TYPE, Constants.MSG_ERROR_NOT_FOUND);
                                }
                            }
                        );
                    }
                }]
            });
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#validarEndereco
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * This method will populate the endereco form details based from the values
         * retrieved in LogradourosService.
         *
         **/
        function validarEndereco(state) {
            var numeroCep = '';
            var logradouro = '';
            if (state === 'cobranca') {
                numeroCep = vm.enderecoPessoaSeguro.numeroCep;
                logradouro = vm.enderecoPessoaSeguro.nomeLogradouro;
            } else {
                if (state === 'novocartao') {
                    numeroCep = vm.cartoes.endereco.numeroCep;
                    logradouro = vm.cartoes.endereco.nomeLogradouro;
                } else {
                    numeroCep = vm.enderecoPessoaSeguroCorres.numeroCep;
                    logradouro = vm.enderecoPessoaSeguroCorres.nomeLogradouro;
                }
            }

            if (numeroCep || logradouro) {
                vm.alerts = [];
                numeroCep = numeroCep.replace(/[^0-9]/g, '');
                LogradourosService.getSpecificLogradouro(numeroCep).then(

                    function(response) {
                        if (response.data === null) {
                            carregarDadosDefaultEndereco(state);
                            $rootScope.$broadcast(Constants.HTTP_FOUND_RESULT_NULL);
                            return;
                        }
                        if (!response.data.ListadeLogradouros[0].codigoTipoLogradouro && !response.data.ListadeLogradouros[0].nomeLogradouro && !response.data.ListadeLogradouros[0].nomeBairro) {
                            response.data.ListadeLogradouros[0].numeroLatitude = 0;
                            response.data.ListadeLogradouros[0].numeroLongitude = 0;
                        }
                        if (state === 'cobranca') {
                            vm.enderecoPessoaSeguro = PessoaFactory.setEnderecoDetails(response.data.ListadeLogradouros[0], vm.unidadeFederacaoOptions, vm.tipoLogradouroOptions);
                        } else {
                            if (state === 'novocartao') {
                                vm.cartoes.endereco = PessoaFactory.setEnderecoDetails(response.data.ListadeLogradouros[0], vm.unidadeFederacaoOptions, vm.tipoLogradouroOptions);
                            } else {
                                vm.enderecoPessoaSeguroCorres = PessoaFactory.setEnderecoDetails(response.data.ListadeLogradouros[0], vm.unidadeFederacaoOptions, vm.tipoLogradouroOptions);
                            }
                        }
                    },
                    function(error) {
                        carregarDadosDefaultEndereco();
                        displayError(error);
                    }
                );
            }
        }

        function carregarDadosDefaultEndereco(state) {
            if (state === 'cobranca') {
                vm.enderecoPessoaSeguro.nomePais = 'BRASIL';
                vm.enderecoPessoaSeguro.codigoPais = 237;
                vm.enderecoPessoaSeguro.numeroLatitude = 0;
                vm.enderecoPessoaSeguro.numeroLongitude = 0;
            } else {
                vm.enderecoPessoaSeguroCorres.nomePais = 'BRASIL';
                vm.enderecoPessoaSeguroCorres.codigoPais = 237;
                vm.enderecoPessoaSeguroCorres.numeroLatitude = 0;
                vm.enderecoPessoaSeguroCorres.numeroLongitude = 0;
            }
        }

        function setNumerico() {
            if (vm.enderecoPessoaSeguro.flagSemNumero !== 'N') {
                vm.enderecoPessoaSeguro.numeroLogradouro = '';
                vm.isNumeroEmpty = false;
            }
        }

        function setCorresNumerico() {
            if (vm.enderecoPessoaSeguroCorres.flagSemNumero !== 'N') {
                vm.enderecoPessoaSeguroCorres.numeroLogradouro = '';
                vm.isNumeroCorresEmpty = false;
            }
        }

        //PESSOA END

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#setToContatoPessoaSeguroForm
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * This method will set the selected dados de contato row in the form
         *
         * @params {Integer} index The selected row to be updated.
         *
         **/
        function setToContatoPessoaSeguroForm(index) {
            var contatoItem = vm.proposta.dadosPessoaSegurado.contatos[index];

            vm.showContatoEmail = false;
            vm.showContatoNumber = false;

            if (contatoItem.codigoTipoContato === 1 ||
                contatoItem.codigoTipoContato === 5 ||
                contatoItem.codigoTipoContato === 6 ||
                contatoItem.codigoTipoContato === 7) {
                vm.showContatoEmail = true;
            } else if (contatoItem.codigoTipoContato !== '') {
                vm.showContatoNumber = true;
            }

            vm.contatoPessoaSeguro = PessoaFactory.setToContatoPessoaSeguroForm(contatoItem);
            if (vm.proposta.dadosPessoaSegurado.contatos.length <= 1) {
                vm.contatoWithPrincipal = false;
                vm.contatoPessoaSeguro.flagPrincipal = 'S';
            }

            if (parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 1 ||
                parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 5 ||
                parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 6 ||
                parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 7) {
                if (parseInt(vm.contatoPessoaSeguro.codigoTipoContato) === 1) {
                    vm.contatoPessoaSeguro.textoContatoEmail = vm.contatoPessoaSeguro.textoContato;
                } else {
                    vm.contatoPessoaSeguro.textoContatoLink = vm.contatoPessoaSeguro.textoContato;
                }
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#setToDocumentoPessoaSeguroForm
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * This method will set the selected dados de contato row in the form
         *
         * @params {Integer} index The selected row to be updated.
         *
         **/
        function setToDocumentoPessoaSeguroForm(index) {
            vm.documentoPessoaSeguro = PessoaFactory.setToDocumentoPessoaSeguroForm(vm.proposta.dadosPessoaSegurado.documentos[index], vm.unidadeFederacaoOptions);
            vm.documentoPessoaSeguro.codigoUnidadeFederacao = parseInt(vm.documentoPessoaSeguro.codigoUnidadeFederacao);
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#showClausulaModal
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Clausula modal button method.
         *
         * @param {Integer} codigoClausula - codigo of Selected Clausula.
         **/
        function showClausulaModal(textoClausula) {
            $modal.open({
                animation: true,
                size: 'lg',
                backdrop: 'static',
                keyboard: false,
                templateUrl: 'clausula.modal.html',
                controllerAs: 'modalCtrl',
                controller: ['$modalInstance', function($modalInstance) {

                    var modal = this;

                    modal.fechar = fechar;
                    modal.cancelar = cancelar;
                    modal.selectedClausula = {};

                    modal.selectedClausula.textoClausula = textoClausula;

                    function fechar() {
                        $modalInstance.close(Constants.CONFIRM);
                    }

                    function cancelar() {
                        $modalInstance.dismiss(Constants.CANCEL);
                    }
                }]
            });
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#displayPreconditionError
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Private method that displays an error alert in the form.
         *
         * @param {String} errorMessage The error message to be displayed.
         **/
        function displayPreconditionError(errorMessage) {
            $rootScope.$broadcast(Constants.ERRO_HTTP_PRECONDITION, errorMessage);
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#clearAlerts
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Private method that emits event to clear alerts.
         **/
        function clearAlerts() {
            $rootScope.$broadcast(Constants.CLEAR_ALERTS);
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#displayError
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Private method that displays an error alert in the form.
         *
         * @param {Object} error Object that contains the error status and the message to be displayed.
         **/
        function displayError(error) {

            if (error) {
                var checker = prepareInnerError(error);

                if (angular.isDefined(checker.status)) {
                    error = checker;
                }

                switch (error.status) {
                    case Constants.HTTP_FORBIDDEN:
                        var errorMessage = Constants.MSG_ERROR_FORBIDDEN + ' ' +
                            nomeDoServico + '.' + error.config.method;
                        $rootScope.$broadcast(Constants.ERRO_HTTP_NAO_AUTORIZADO,
                            errorMessage);
                        break;
                    case Constants.HTTP_GENERIC_ERROR:
                        if (!angular.isUndefined(error)) {
                            if (!angular.isUndefined(error.data)) {
                                if (!angular.isUndefined(error.data.mensagens[0])) {
                                    addAlert('danger', error.data.mensagens[0].mensagem);
                                    displayPreconditionError(error.data.mensagens[0].mensagem);
                                    break;
                                }
                            }
                        }
                    case Constants.HTTP_CONFLICT:
                        $rootScope.$broadcast(Constants.ERRO_HTTP_CONFLICT, {
                            message: error.data.mensagens[0].mensagem,
                            xtrid: error.headers("X-TRID") || ''
                        });
                        break;
                    case Constants.HTTP_PREREQUISITE:
                        displayPreconditionError(error.data.mensagens[0].mensagem);
                        break;
                    case Constants.HTTP_BAD_REQUEST:
                        $rootScope.$broadcast(Constants.ERRO_HTTP_BAD_REQUEST, error);
                        break;
                    default:
                        if (angular.isObject(error.data)) {
                            var mensagens = error.data.mensagens;

                            if (angular.isArray(mensagens) && angular.isObject(mensagens[2]) &&
                                angular.isString(mensagens[2].mensagem)) {
                                if (Constants.MSG_ERROR_NOT_FOUND !== mensagens[2].mensagem) {
                                    displayPreconditionError(mensagens[2].mensagem);
                                }
                            }
                        }
                        break;
                }
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#prepareInnerError
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Method to get Inner Error Message from Pessoa or other modules.
         **/
        function prepareInnerError(erro) {

            var error = {};
            var message = '';
            var codigo = '';

            if (angular.isObject(erro) && angular.isObject(erro.data)) {
                var additionalInfo = erro.data.additionalInfo;
                if (angular.isObject(additionalInfo) && angular.isObject(additionalInfo.portoSeguroFaultInfo) &&
                    angular.isObject(additionalInfo.portoSeguroFaultInfo.additionalInfo) &&
                    angular.isObject(additionalInfo.portoSeguroFaultInfo.additionalInfo.portoSeguroFaultInfo) &&
                    angular.isObject(additionalInfo.portoSeguroFaultInfo.additionalInfo.portoSeguroFaultInfo.mensagens)) {

                    message = erro.data.additionalInfo.portoSeguroFaultInfo.additionalInfo.portoSeguroFaultInfo.mensagens.mensagem;
                    codigo = erro.data.additionalInfo.portoSeguroFaultInfo.additionalInfo.portoSeguroFaultInfo.mensagens.codigo;

                    error.status = null;
                    error.status = parseInt(codigo);
                    error.config = {};
                    error.config.method = erro.config.method;
                    error.data = {};
                    error.data.mensagens = [];
                    error.data.mensagens.push({
                        mensagem: message,
                        codigo: parseInt(codigo)
                    });
                }
            }

            return error;
        }

        function checkEmptyMandatoryField() {
            var hasEmptyField = false;

            if (angular.isDefined(vm.proposta.numeroProposta)) {
                // DADOS DO SEGURADO
                hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.flagEnvioEmailCorretor);

                // DADOS DO SEGURADO
                if (vm.proposta.dadosPessoaSegurado.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.JURIDICA) {
                    if (OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.flagLicitacao)) {
                        hasEmptyField = true;
                    } else if (vm.proposta.flagLicitacao === 'S') {
                        hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.codigoTipoLicitacao) || hasEmptyField;

                        if (vm.proposta.codigoTipoLicitacao == Constants.TIPO_LICITACAO.COLETA) {
                            hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.numeroProcessoLicitacao) || hasEmptyField;
                        }
                    }
                    hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.dadosPessoaSegurado.pessoaJuridica.nomeAtividadeEconomica) || hasEmptyField;
                } else if (vm.proposta.dadosPessoaSegurado.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA) {
                    hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoEstadoCivil) || hasEmptyField;
                    hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.dadosPessoaSegurado.pessoaFisica.dataNascimento) || hasEmptyField;
                    hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoSexoPessoa) || hasEmptyField;
                    hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoNacionalidade) || hasEmptyField;
                    hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoPais) || hasEmptyField;
                    hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoTipoExposicaoPessoa) || hasEmptyField;

                    if (vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoTipoExposicaoPessoa === 3) {
                        if (vm.proposta.dadosPessoaSegurado.vinculos && vm.proposta.dadosPessoaSegurado.vinculos.length > 0) {
                            hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.dadosPessoaSegurado.vinculos[0].numeroCnpjCpfPessoaVinculo) || hasEmptyField;
                            hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.dadosPessoaSegurado.vinculos[0].nomePessoaVinculo) || hasEmptyField;
                            hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.dadosPessoaSegurado.vinculos[0].codigoTipoVinculo) || hasEmptyField;
                        } else {
                            vm.proposta.dadosPessoaSegurado.vinculos = [];
                            var vinculo = {
                                numeroCnpjCpfPessoaVinculo: null,
                                nomePessoaVinculo: null,
                                codigoTipoVinculo: null,
                                codigoTipoPessoaVinculo: null
                            };
                            vm.proposta.dadosPessoaSegurado.vinculos.push(vinculo);
                        }
                    }
                }

                // ENDEREÇO
                hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.enderecoCobranca.flagEnderecoCobranca) || hasEmptyField || !vm.proposta.enderecoCobranca;
                if (!hasEmptyField && vm.proposta.enderecoCobranca.flagEnderecoCobranca === 1) {
                    hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.enderecoCobranca.localDeRisco) || hasEmptyField;
                } else if (!hasEmptyField && vm.proposta.enderecoCobranca.flagEnderecoCobranca === 2) {
                    hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.enderecoCobranca.enderecosCadastrado) || hasEmptyField;
                }

                hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.enderecoCorrespondencia.flagEnderecoCorrespondencia) || hasEmptyField || !vm.proposta.enderecoCorrespondencia;
                if (!hasEmptyField && vm.proposta.enderecoCorrespondencia.flagEnderecoCobranca === 1) {
                    hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.enderecoCorrespondencia.localDeRisco) || hasEmptyField;
                } else if (!hasEmptyField && vm.proposta.enderecoCorrespondencia.flagEnderecoCobranca === 2) {
                    hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.enderecoCorrespondencia.enderecosCadastrado) || hasEmptyField;
                }

                // PAGAMENTO
                hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.nomeFormaPagamento) || hasEmptyField;
                hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.codigoFormaPagamento) || hasEmptyField;
                hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.quantidadeParcela) || hasEmptyField;

                if (codigoMeioPagamentoPrimeiraParcela === 2) {
                    angular.forEach(vm.pagamentoCalcularParcela.grid, function(parcela) {
                        if (parcela.flagOrgaoSubvencao) {
                            if (parcela.flagOrgaoSubvencao == 'N') {
                                hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(parcela.codigoBanco) || hasEmptyField;
                                hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(parcela.numeroAgenciaBancaria) || hasEmptyField;
                                hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(parcela.numeroContaBancaria) || hasEmptyField;
                                hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(parcela.digitoContaBancaria) || hasEmptyField;
                            }
                        } else {
                            hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(parcela.codigoBanco) || hasEmptyField;
                            hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(parcela.numeroAgenciaBancaria) || hasEmptyField;
                            hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(parcela.numeroContaBancaria) || hasEmptyField;
                            hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(parcela.digitoContaBancaria) || hasEmptyField;
                        }
                    });
                }

                if (codigoMeioPagamentoPrimeiraParcela === 6 || codigoMeioPagamentoPrimeiraParcela === 7) {
                    if (vm.nomeFormaPagamento && vm.nomeFormaPagamento.indexOf('97') < 0) {
                        hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.cartoes.numeroCartao) || hasEmptyField;
                        hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.cartoes.codigoIdentificacaoCartao) || hasEmptyField;
                        hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.cartoes.bandeira) || hasEmptyField;
                        hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.cartoes.mesValidadeCartao) || hasEmptyField;
                        hasEmptyField = OrcamentoUtilityFactory.isNullOrEmpty(vm.proposta.cartoes.anoValidadeCartao) || hasEmptyField;
                    }
                }

                if (hasEmptyField) {
                    SelectedOpts.propostaHasEmptyField = true;
                }
            }
            return hasEmptyField;
        }

        function openCosseguradoDeleteConfirmModal(codigoInterveniente, screenID) {
            function check(event, status) {
                if (status === Constants.CONFIRM) {
                    var numeroProposta = vm.proposta.numeroProposta;
                    var numeroVersaoProposta = vm.proposta.numeroVersaoProposta;
                    OrcamentoPropostaService.deleteInterveniente(numeroProposta, numeroVersaoProposta, codigoInterveniente, codigoEmpresa).then(

                        function(response) {
                            if (screenID === 1) {
                                vm.cossegurado = populateCossegurado();
                            } else if (screenID === 2) {
                                vm.controlador = populateControladores();
                            }
                        },
                        function(error) {
                            displayError(error);
                        }
                    );
                }
            }
            // Listener function to trigger update from modal directive.
            $scope.$on(Constants.CLOSE_MODAL_CONFIRM, check);
            $scope.$broadcast(Constants.OPEN_MODAL_CONFIRM, {
                title: 'Confirma a exclusão?'
            });

        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isNullEmptyOrUndefined
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * To check if parameter provided is valid.
         **/
        function isNullEmptyOrUndefined(item) {
            var hasError = false;
            if (angular.isUndefined(item) || item === '' || item === null) {
                hasError = true;
            }
            return hasError;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isInvalid
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * To check if parameter provided is valid and if Form is submitted.
         **/
        function isInvalid(model) {
            return (SelectedOpts.isSavePressed && (angular.isUndefined(model) || model === null || model === ''));
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isInvalidDate
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * To check if Date is Invalid and if form is submitted.
         **/
        function isInvalidDate(input) {
            var flag = false;

            if (angular.isDate(input)) {
                flag = (SelectedOpts.isSavePressed && ((angular.isUndefined(input)) || (!angular.isDate(input))));
            } else if (input && SelectedOpts.isSavePressed) {
                var split = input.split('/');
                var novadata = split[1] + "/" + split[0] + "/" + split[2];
                flag = (SelectedOpts.isSavePressed && !(/^\d{2}\/\d{2}\/\d{4}$/.test(input) && new Date(novadata).getTime()));
            }

            return flag;
        }
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#isInvalidLicitacao
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * To check if Licitacao fields are invalid and if form is submitted.
         **/
        function isInvalidLicitacao(model) {
            return vm.proposta.flagLicitacao === "S" && isInvalid(model);
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#clearCodigoTipoLicitacao
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Clears the codigoTipoLicitacao on change of flagLicitacao radio button to Não.
         **/
        function clearCodigoTipoLicitacao() {
            vm.proposta.codigoTipoLicitacao = null;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#flagLicitacaoStatus
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Clears codigoTipoLicitacao and numeroProcessoLicitacao on change of flagLicitacao radio button to Não.
         **/
        function flagLicitacaoStatus() {
            vm.proposta.codigoTipoLicitacao = null;
            vm.proposta.numeroProcessoLicitacao = null;
            vm.proposta.flagLicitacao = 'N';
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#clearNumeroProcessoLicitacao
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Clears codigoTipoLicitacao and numeroProcessoLicitacao on change of flagLicitacao radio button to Não.
         **/
        function clearNumeroProcessoLicitacao() {
            vm.proposta.numeroProcessoLicitacao = null;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#pad
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Add leading zeros to value when needed.
         *
         * @param {Long} value that needs to be formatted.
         * @param {Integer} expected size of string to be returned.
         * @returns {String} formatted string
         **/
        function pad(num, size) {
            var str = num + "";
            while (str.length < size) {
                str = "0" + str;
            }
            return str;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#checkAndValidateAllContato
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * validates .
         *
         **/
        function checkAndValidateAllContato() {
            return (vm.contatoPessoaSeguro.codigoTipoContato === 5 ||
                vm.contatoPessoaSeguro.codigoTipoContato === 6 ||
                vm.contatoPessoaSeguro.codigoTipoContato === 7);
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#validateContatoInput
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * Validates if contato isn't with invalid input selections.
         *
         **/
        function validateContatoInput() {
            if (vm.contatoPessoaSeguro.flagPrincipal === "S") {
                vm.contatoPessoaSeguro.flagAtivo = "S";
            }
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController#checkAndValidateNotAllContato
         * @methodOf porto.re.emissaocadastro.operacoes.controller:OrcamentoPropostaController
         * @description
         *
         * validates .
         *
         **/
        function checkAndValidateNotAllContato() {
            return (vm.contatoPessoaSeguro.codigoTipoContato !== 5 &&
                vm.contatoPessoaSeguro.codigoTipoContato !== 6 &&
                vm.contatoPessoaSeguro.codigoTipoContato !== 7);
        }
        // $scope.$watch(function() {
        // 	return vm.proposta.cartoes.cpf;
        // }, function() {
        // 	validationCpf(vm.proposta.cartoes.cpf);
        // });

        function validationCpf(cpf) {
            if (cpf) {
                cpf = angular.isString(cpf) ? cpf.replace(/[\.-]/g, "") : cpf;
                if (vercpf(cpf)) {
                    vm.cpfValidado = true;
                } else {
                    vm.cpfValidado = false;
                }
            } else {
                vm.cpfValidado = false;
            }
            PageInfo.cpfValidado = vm.cpfValidado;
        }

        function getPessoa() {
            if (vm.isCartao) {
                if (vm.proposta && vm.proposta.pagadores && vm.proposta.pagadores.pagador) {
                    if (vm.proposta.pagadores.pagador[0].pagadoresParcela) {
                        if (vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoBandeiraCartao) {
                            vm.proposta.cartoes.bandeira = vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoBandeiraCartao;
                        } else if (vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoTipoCartao) {
                            vm.proposta.cartoes.bandeira = vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela[0].codigoTipoCartao;
                        } else {
                            vm.proposta.cartoes.bandeira = null;
                        }
                    }
                    PessoaService.getPessoaPorId(0, 1, vm.proposta.pagadores.pagador[0].dadosPessoaPagador.codigoPessoa).then(function(response) {
                        vm.proposta.cartoes.cpf = vm.proposta.cartoes.cpf ? vm.proposta.cartoes.cpf : response.data.listaPessoas.pessoa[0].numeroCnpjCpf;
                        vm.proposta.cartoes.nome = vm.proposta.cartoes.nome ? vm.proposta.cartoes.nome : response.data.listaPessoas.pessoa[0].nomePessoa;
                        // vm.proposta.cartoes.cpf = cpfFormat(vm.proposta.cartoes.cpf);
                    });
                }
            }
        }

        function vercpf(cpf) {
            if (cpf !== undefined && cpf !== "") {
                var numeros, digitos, soma, i, resultado, digitos_iguais;
                digitos_iguais = 1;
                if (cpf.length < 11)
                    return false;
                for (i = 0; i < cpf.length - 1; i++)
                    if (cpf.charAt(i) != cpf.charAt(i + 1)) {
                        digitos_iguais = 0;
                        break;
                    }
                if (!digitos_iguais) {
                    numeros = cpf.substring(0, 9);
                    digitos = cpf.substring(9);
                    soma = 0;
                    for (i = 10; i > 1; i--)
                        soma += numeros.charAt(10 - i) * i;
                    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
                    if (resultado != digitos.charAt(0))
                        return false;
                    numeros = cpf.substring(0, 10);
                    soma = 0;
                    for (i = 11; i > 1; i--)
                        soma += numeros.charAt(11 - i) * i;
                    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
                    if (resultado != digitos.charAt(1))
                        return false;
                    return true;
                } else
                    return false;
            }
        }

        function validateCodigoTipoClassificacaoPessoa() {
            if (vm.proposta.dadosPessoaSegurado &&
                vm.proposta.dadosPessoaSegurado.pessoaFisica &&
                vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoOcupacao > 0) {
                vm.proposta.codigoTipoClassificacaoPessoa = Constants.CODIGO_TIPO_CLASSIFICACAO_PESSOA.PROFISSIONAL_LIBERAL;
            } else {
                vm.proposta.codigoTipoClassificacaoPessoa = Constants.CODIGO_TIPO_CLASSIFICACAO_PESSOA.PROPRIETARIO_IMOVEL;
            }
        }

        function _modalSolicitacaoCartaoCredito() {
            $modal.open({
                animation: true,
                size: 'lg',
                backdrop: 'static',
                keyboard: false,
                templateUrl: 'modules/operacoes/templates/modal.solicitarcartao.template.html',
                controllerAs: 'modalSolicitarCartaoCtrl',
                controller: 'ModalSolicitarCartaoController',
                resolve: {
                    cartoesPortoValidos: function() {
                        return vm.cartoesPortoValidos;
                    },
                    tipoPessoaDropdown: function() {
                        return vm.tipoPessoaOptions;
                    },
                    tipoDocumentoPessoaDropdown: function() {
                        return vm.tipoDocumentoPessoaOptions;
                    },
                    proposta: function() {
                        return vm.proposta;
                    },
                    tipoVinculo: function() {
                        return vm.tipoVinculoIntervenienteOptions;
                    },
                    estadoCivilOptions: function() {
                        return vm.estadoCivilOptions;
                    },
                    pagamentoProfissaoDropdown: function() {
                        return vm.pagamentoProfissaoDropdown;
                    },
                    unidadeFederacaoOptions: function() {
                        return vm.unidadeFederacaoOptions;
                    },
                    paisResidenteOptions: function() {
                        return vm.paisResidenteOptions;
                    },
                    nacionalidadeOptions: function() {
                        return vm.nacionalidadeOptions;
                    },
                    sexoOptions: function() {
                        return vm.sexoOptions;
                    },
                    tipoLogradouroOptions: function() {
                        return vm.tipoLogradouroOptions
                    }
                }
            }).result.then(function(data) {
                if (data && data.codigoBandeiraCartao) {
                    vm.pagamentoBandeiraDropdownTempholder = angular.copy(vm.pagamentoBandeiraDropdown);
                    vm.pagamentoBandeiraDropdownTempholder = $filter('filter')(vm.pagamentoBandeiraDropdownTempholder, {
                        "codigoValorDominio": data.codigoBandeiraCartao
                    });
                    if (vm.proposta.pagadores.pagador[0]) {
                        if (vm.proposta.pagadores.pagador[0].pagadoresParcela) {
                            if (vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela && vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela.length > 0) {
                                vm.proposta.pagadores.pagador[0].pagadoresParcela.pagadorParcela.map(function(itemPagador) {
                                    if (data.codigoBandeiraCartao) {
                                        itemPagador.codigoBandeiraCartao = data.codigoBandeiraCartao;
                                    }
                                });
                            }
                        }
                    }

                    vm.proposta.cartoes.bandeira = data.codigoBandeiraCartao;
                    vm.proposta.cartoes.codigoTipoCartao = vm.proposta.cartoes.bandeira;
                    //vm.proposta.cartoes.codigoTipoCartao = 1;
                    vm.proposta.cartoes.solicitacaoCartaoCredito = data;
                    var dataAtual = new Date();
                    vm.proposta.cartoes.dataPagamento = new Date(dataAtual.getFullYear(), dataAtual.getMonth() + 1, data.diaVencimentoCartao);
                    if (vm.nomeFormaPagamento.indexOf("97")) {
                        calcularParcela(true, data.codigoBandeiraCartao);
                    } else {
                        calcularParcela(true);
                    }

                    vm.cartaoPortoSolicitado = true;
                }
            });
        }

        function openModalSolicitacaoCartaoCredito() {
            _modalSolicitacaoCartaoCredito();
        }

        function openModalResgatePontos() {
            $modal.open({
                animation: true,
                size: 'lg',
                backdrop: 'static',
                keyboard: false,
                templateUrl: 'modules/operacoes/templates/modal.resgatepontos.template.html',
                controllerAs: 'modalResgatePontosCtrl',
                controller: 'ModalResgatePontosController',
                resolve: {
                    proposta: function() {
                        return vm.proposta;
                    },
                    faixaResgateList: function() {
                        return vm.faixaResgateList;
                    }
                }
            }).result.then(function(data) {
                vm.proposta.codigoFaixaResgatePonto = data.codigoFaixaResgate;
                PageInfo.submissionObject.codigoFaixaResgatePonto = data.codigoFaixaResgate;
            });
        }

        function loadEnderecoCobranca() {
            saveEnderecoCobranca();
        }

        function loadEnderecoCorrespondencia() {
            saveEnderecoCorrespondencia();
        }

        function loadInformacoesFormaPagamento() {
            populateQuantidadeParcela(true);
            vm.proposta.cartoes.cpf = vm.proposta.dadosPessoaSegurado.numeroCnpjCpf;
            vm.proposta.cartoes.nome = vm.proposta.dadosPessoaSegurado.nomePessoa;
            if (vm.isCartao) {
                consultaCartoesPortoValidos(vm.proposta.dadosPessoaSegurado.numeroCnpjCpf.replace(/[^0-9]/g, ""), true);
            }
        }

        function getMotivoAusenciaCpfCnpj() { //bugfix R2 - 5193

            vm.motivoAusenciaCpfOptions = [];
            vm.motivoAusenciaCnpjOptions = [];

            blockUI.start();
            MotivoAusenciaService.listarMotivosAusenciaCnpjCpf(0, 0, null, null, 'S').then(

                function(response) {
                    if (response.data) {
                        var listaMotivos = MotivoAusenciaCnpjCpfDataFactory.convertList(response.data);
                        if (listaMotivos && listaMotivos.length > 0) {
                            vm.motivoAusenciaCpfOptions = $filter('filter')(listaMotivos, {
                                codigoTipoPessoa: Constants.CODIGO_TIPO_PESSOA.FISICA
                            }, true);
                            vm.motivoAusenciaCnpjOptions = $filter('filter')(listaMotivos, {
                                codigoTipoPessoa: Constants.CODIGO_TIPO_PESSOA.JURIDICA
                            }, true);
                        }
                    }
                    blockUI.stop();
                },
                function(error) {
                    displayError(error);
                    vm.motivoAusenciaCpfOptions = [];
                    vm.motivoAusenciaCnpjOptions = [];
                    blockUI.stop();
                }
            );
        }

        function filterCartoesPortoValidos(cartoes) {
            return $filter('filter')(cartoes, {
                "flagCartaoValido": "S"
            });
        }

        function sortCartoesPortoValidos(bandeiras) {
            var retorno = -1;
            return bandeiras.sort(function(a, b) {
                angular.forEach(vm.cartoesPortoValidos, function(value) {
                    if ((value.codigoBandeira === a.codigoValorDominio) || (value.codigoBandeira === b.codigoValorDominio)) {
                        retorno = 1;
                    }
                });
                return retorno;
            });
        }

        function consultaCartoesPortoValidos(cpf, flag) {
            setBandeira(cpf, flag);
        }

        function setBandeira(cpf, flag) {
            var cpfSemMascara = OrcamentoPropostaFactory.removeFormat(cpf);

            vm.pagamentoBandeiraDropdownTempholder = [];

            CartoesService.consultarCartoesPortoValidos(cpfSemMascara).then(
                function(result) {
                    vm.pagamentoBandeiraDropdownTempholder = angular.copy(vm.pagamentoBandeiraDropdown);
                    vm.cartoesPortoValidos = angular.copy(filterCartoesPortoValidos(result.data.dadosCartao));
                    if (vm.cartoesPortoValidos && vm.cartoesPortoValidos.length > 0) {
                        if (vm.cartoesPortoValidos.length === 1) {
                            vm.pagamentoBandeiraDropdownTempholder = $filter('filter')(vm.pagamentoBandeiraDropdownTempholder, {
                                "codigoValorDominio": vm.cartoesPortoValidos[0].codigoBandeira
                            });

                            if (!vm.proposta.cartoes) {
                                vm.proposta.cartoes = {};
                            }

                            vm.proposta.cartoes.bandeira = vm.cartoesPortoValidos[0].codigoBandeiraCartao;

                            if (vm.nomeFormaPagamento == "97-CARTAO PORTO SEGURO" && vm.proposta.solicitacaoCartaoCredito) {

                                var codigoBandeira = vm.proposta.cartoes.bandeira ? vm.proposta.solicitacaoCartaoCredito.codigoBandeiraCartao : vm.proposta.cartoes.bandeira;
                                vm.pagamentoBandeiraDropdownTempholder = angular.copy(vm.pagamentoBandeiraDropdown);
                                vm.pagamentoBandeiraDropdownTempholder = $filter('filter')(vm.pagamentoBandeiraDropdownTempholder, {
                                    "codigoValorDominio": codigoBandeira
                                });

                                if (vm.proposta.cartoes.bandeira) {
                                    vm.proposta.cartoes.bandeira = codigoBandeira;
                                    vm.cartaoPortoSolicitado = true;
                                }
                            }
                        } else {
                            vm.pagamentoBandeiraDropdownTempholder = sortCartoesPortoValidos(vm.pagamentoBandeiraDropdownTempholder);
                        }
                    } else {
                        vm.pagamentoBandeiraDropdownTempholder = [];
                        if (vm.proposta.cartoes) {
                            vm.proposta.cartoes.bandeira = null;
                        }
                        $rootScope.$broadcast(Constants.ERRO_HTTP_PRECONDITION, 'Não possui um cartão válido para o CPF informado.');
                        //addAlert(Constants.ERROR_TYPE, 'Não possui um cartão válido para o CPF informado.');
                    }
                },
                function(error) {

                    vm.pagamentoBandeiraDropdownTempholder = [];
                    if (vm.proposta.cartoes) {
                        vm.proposta.cartoes.bandeira = null;
                    }
                    $rootScope.$broadcast(Constants.ERRO_HTTP_PRECONDITION, 'Não possui um cartão válido para o CPF informado.');
                    //addAlert(Constants.ERROR_TYPE, 'Não possui um cartão válido para o CPF informado.');

                    /*if (vm.nomeFormaPagamento == "97-CARTAO PORTO SEGURO" && vm.proposta.solicitacaoCartaoCredito) {

                        var codigoBandeira;
                        if (vm.proposta.codigoBandeiraCartao == vm.proposta.cartoes.bandeira) {
                            codigoBandeira = vm.proposta.cartoes.bandeira;
                        } else if (vm.proposta.codigoBandeiraCartao) {
                            codigoBandeira = vm.proposta.codigoBandeiraCartao;
                        } else {
                            codigoBandeira = vm.proposta.solicitacaoCartaoCredito.codigoBandeiraCartao
                        }

                        vm.pagamentoBandeiraDropdownTempholder = angular.copy(vm.pagamentoBandeiraDropdown);
                        vm.pagamentoBandeiraDropdownTempholder = $filter('filter')(vm.pagamentoBandeiraDropdownTempholder, {
                            "codigoValorDominio": codigoBandeira
                        });

                        if (vm.proposta.cartoes.bandeira != codigoBandeira) {
                            vm.proposta.cartoes.bandeira = codigoBandeira;
                        }

                        var dataAtual = new Date();
                        vm.proposta.cartoes.dataPagamento = new Date(dataAtual.getFullYear(), dataAtual.getMonth() + 1, vm.proposta.solicitacaoCartaoCredito.diaVencimentoCartao);

                    } else if (vm.pagamentoBandeiraDropdownTempholder.length == 0 && vm.pagamentoBandeiraDropdown) {
                        vm.pagamentoBandeiraDropdownTempholder = angular.copy(vm.pagamentoBandeiraDropdown);
                        // Correção do ALM 16993.
                        /*if (vm.proposta.cartoes) {
                            vm.proposta.cartoes.bandeira = null;
                        }*/
                    /*} else if (!flag) {
                        displayError(error);
                    } else {
                        vm.pagamentoBandeiraDropdownTempholder = angular.copy(vm.pagamentoBandeiraDropdown);
                    }*/
                }
            );
        }

        function scrollToTop(e) {
            $location.hash();
            $anchorScroll();
        }

        function openModalAtividade() {
            $modal.open({
                    animation: true,
                    size: 'lg',
                    backdrop: 'static',
                    keyboard: false,
                    templateUrl: 'modules/operacoes/templates/modal.selecionaratividade.template.html',
                    controllerAs: 'modalSelecionarAtividadeCtrl',
                    controller: 'ModalSelecionarAtividadeController',
                    resolve: {
                        atividadeSelecionada: function() {
                            return {
                                codigoValorDominio: vm.proposta.dadosPessoaSegurado.pessoaJuridica.codigoAtividadeEconomica,
                                nomeDominio: vm.proposta.dadosPessoaSegurado.pessoaJuridica.nomeAtividadeEconomica
                            };
                        }
                    }
                })
                .result.then(function(data) {
                    var retorno = angular.fromJson(data);

                    vm.proposta.dadosPessoaSegurado.pessoaJuridica.codigoAtividadeEconomica = (retorno) ? retorno.codigoValorDominio : "";
                    vm.proposta.dadosPessoaSegurado.pessoaJuridica.nomeAtividadeEconomica = (retorno) ? retorno.nomeDominio : "";
                });
        }

        //INIT SM 531/533 - Conversão da lista para Strig - Bloqueio Corretor
        function changeCorretorForBlock(listaCorretor) {
            var stringBloqueio = "";
            for (var i = 0; i < listaCorretor.length; i++) {
                //Valida se é o ultimo item da lista
                if (listaCorretor.length - 1 == i) {
                    stringBloqueio += listaCorretor[i].bloqueio;
                } else {
                    stringBloqueio += listaCorretor[i].bloqueio + ",";
                }
            }
            SelectedOpts.orcamento.stringBloqueio = stringBloqueio;
        }
        //END SM 531/533

        function listarClasseProfissionalProposta() {

            if (vm.proposta && vm.proposta.codigoTipoClassificacaoPessoa == 1 &&
                vm.proposta.dadosPessoaSegurado && vm.proposta.dadosPessoaSegurado.pessoaFisica &&
                vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoOcupacao) {

                blockUI.start();
                CadastroProfissionalService.listarClasseProfissionalLiberal(0, 200, undefined, undefined, vm.proposta.dadosPessoaSegurado.pessoaFisica.codigoOcupacao).then(function(response) {

                    if (response.data) {
                        var isCodigoClasseProfissionalLiberal = false;
                        angular.forEach(response.data, function(classeProfissionalLiberal) {
                            if (classeProfissionalLiberal.codigoClasseProfissionalLiberal && !isCodigoClasseProfissionalLiberal) {
                                vm.proposta.codigoClasseProfissionalLiberal = classeProfissionalLiberal.codigoClasseProfissionalLiberal;
                                isCodigoClasseProfissionalLiberal = true;
                            }
                        });
                        if (!isCodigoClasseProfissionalLiberal) {
                            vm.proposta.codigoClasseProfissionalLiberal = undefined;
                        }
                    } else {
                        vm.proposta.codigoClasseProfissionalLiberal = undefined;
                    }
                    blockUI.stop();
                }, function(error) {
                    blockUI.stop();
                });
            }
        }

        // INICO - SM159

        function getByCpfCnpj() {
            var codigoTipoPessoa = vm.getDefaultDadosSegurado.cossegurado.codigoTipoPessoa;
            var numeroCnpjCpf = OrcamentoUtilityFactory.convertBackCpfCnpj(vm.getDefaultDadosSegurado.cossegurado.numeroCnpjCpf);
            vm.atualizaPessoa = false;
            vm.criaPessoa = false;

            if (codigoTipoPessoa && numeroCnpjCpf) {
                PessoaService.getByCpfcnpj(codigoTipoPessoa, numeroCnpjCpf).then(function(response) {
                    if (response.data && response.data.listaPessoas && response.data.listaPessoas.pessoa) {
                        vm.atualizaPessoa = true;
                        vm.pessoa = response.data.listaPessoas.pessoa[0];

                        var cnpjCpf = ("00000000000000" + vm.pessoa.numeroCnpjCpf).substr(vm.pessoa.codigoTipoPessoa == 1 ? -11 : -14);

                        if (vm.pessoa && cnpjCpf == numeroCnpjCpf.toString()) {
                            vm.getDefaultDadosSegurado.cossegurado.nomeInterveniente = vm.pessoa.nomePessoa;

                            PessoaService.getPessoaPorId(0, 1, vm.pessoa.codigoPessoa).then(
                                function(response) {
                                    if (response && response.data && response.data.listaPessoas &&
                                        response.data.listaPessoas.pessoa && response.data.listaPessoas.pessoa.length > 0) {

                                        vm.pessoaPorId = {};
                                        vm.pessoaPorId.pessoa = response.data.listaPessoas.pessoa[0];

                                        if (codigoTipoPessoa == 1) {
                                            if (response.data.listaPessoas.pessoa[0].pessoaFisica) {
                                                vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.flagVinculoPessoaExpostaPoliticamente = response.data.listaPessoas.pessoa[0].pessoaFisica.codigoTipoExposicaoPessoa;
                                            }
                                        }
                                    }
                                }
                            );
                        }
                    } else {
                        vm.getDefaultDadosSegurado.cossegurado.nomeInterveniente = undefined;
                        vm.getDefaultDadosSegurado.cossegurado.pessoaExpostaPoliticamente.flagVinculoPessoaExpostaPoliticamente = undefined;
                        vm.criaPessoa = true;
                    }
                });
            }
        }
        // FIM - SM159

        // SM 1082 - Alterar regra de preenchimento dos campos de pessoa em proposta
        function isPolicamenteExposta() {

        }

    }
})();
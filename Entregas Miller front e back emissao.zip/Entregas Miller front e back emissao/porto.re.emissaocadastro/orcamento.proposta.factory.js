(function() {
    'use strict';

    angular
        .module('porto.re.emissaocadastro.operacoes')
        .factory('OrcamentoPropostaFactory', OrcamentoPropostaFactory);

    OrcamentoPropostaFactory.$inject = ['$filter', 'Constants', 'OrcamentoUtilityFactory', 'OrcamentoFormFactory', 'UsuarioService', 'EmissaoColaboradoresService'];

    /**
     * @ngdoc service
     * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
     *
     * @description
     *
     * A factory that converts objects into a `OrcamentoProposta` common data model
     *
     * @requires $filter
     * @requires Constants
     * @requires OrcamentoUtilityFactory
     * @requires OrcamentoFormFactory
     **/
    function OrcamentoPropostaFactory($filter, Constants, OrcamentoUtilityFactory, OrcamentoFormFactory, UsuarioService, EmissaoColaboradoresService) {
        // Methods exposed by the factory
        var exports = {
            convertCriticas: convertCriticas,
            convertQuestionario: convertQuestionario,
            addCodigoListaItem: addCodigoListaItem,
            convertDesconto: convertDesconto,
            convertClausulas: convertClausulas,
            defaultDadosSegurado: defaultDadosSegurado,
            defaultEndereco: defaultEndereco,
            constructLocalRiscoList: constructLocalRiscoList,
            convertEnderecosCadastradoList: convertEnderecosCadastradoList,
            defaultEnderecoCobranca: defaultEnderecoCobranca,
            defaultEnderecoCorrespondencia: defaultEnderecoCorrespondencia,
            convertEnderecoCobranca: convertEnderecoCobranca,
            convertEnderecoDeCobrancaDropdown: convertEnderecoDeCobrancaDropdown,
            convertEnderecoDeCorrespondenciaDropdown: convertEnderecoDeCorrespondenciaDropdown,
            convertEnderecoCorrespondencia: convertEnderecoCorrespondencia,
            convertPagamentoForma: convertPagamentoForma,
            //convertpagamentoMelhorData              : convertpagamentoMelhorData,
            convertPagamentoQuantidadeParcela: convertPagamentoQuantidadeParcela,
            convertPessoaExposta: convertPessoaExposta,
            convertClasseProfissional: convertClasseProfissional,
            convertGrauRelacionamento: convertGrauRelacionamento,
            convertClasseTipoDoc: convertClasseTipoDoc,
            convertEnderecoTipoLogradouro: convertEnderecoTipoLogradouro,
            convertTipoContato: convertTipoContato,
            convertPossuiControlador: convertPossuiControlador,
            convertTipoVinculo: convertTipoVinculo,
            defaultCalcularParcela: defaultCalcularParcela,
            convertPagamentoBandeiraDropdown: convertPagamentoBandeiraDropdown,
            convertPagamentoMaisUmPagador: convertPagamentoMaisUmPagador,
            convertDadosDoSeguro: convertDadosDoSeguro,
            convertProdutoCommercialDropdown: convertProdutoCommercialDropdown,
            convertOfertaDropdown: convertOfertaDropdown,
            convertParceiroNegocioDropdown: convertParceiroNegocioDropdown,
            convertFlagEnvioEmailCorretorDropdown: convertFlagEnvioEmailCorretorDropdown,
            convertFlagEnvioEmailCorretorImobiliariaDropdown: convertFlagEnvioEmailCorretorImobiliariaDropdown,
            convertOnusDropdown: convertOnusDropdown,
            convertCodigoOperacaoDropdown: convertCodigoOperacaoDropdown,
            //convertObjetoSeguradoDropdown           : convertObjetoSeguradoDropdown,
            convertPagamentoProfissaoDropdown: convertPagamentoProfissaoDropdown,
            convertPagamentoTipoIdentificacaoDropdown: convertPagamentoTipoIdentificacaoDropdown,
            convertContatoPessoaExpostaDropDown: convertContatoPessoaExpostaDropDown,
            convertPagamentoGrauParentescoDropdown: convertPagamentoGrauParentescoDropdown,
            convertPagamentoTipoEmailDropdown: convertPagamentoTipoEmailDropdown,
            convertPagamentoTipoTelefoneDropdown: convertPagamentoTipoTelefoneDropdown,
            convertDados: convertDados,
            convertDominioList: convertDominioList,
            convertEnderecoList: convertEnderecoList,
            convertTipoContatoList: convertTipoContatoList,

            convertBackPagadorParcelaVersaoProposta: convertBackPagadorParcelaVersaoProposta,
            convertPagadorParcelaVersaoProposta: convertPagadorParcelaVersaoProposta,
            convertPessoa: convertPessoa,
            covertBackModParcela: covertBackModParcela,
            convertBackPagadorParcelaVersaoPropostaForUpdate: convertBackPagadorParcelaVersaoPropostaForUpdate,
            convertPessoaForCreate: convertPessoaForCreate,
            getParcelaFromGrid: getParcelaFromGrid,
            removeFormat: removeFormat,
            createPessoaToUpdate: createPessoaToUpdate,

            //DOMINIO
            convertBanco: convertBanco,
            convertProfissao: convertProfissao,
            convertSexo: convertSexo,
            convertTipoLograduoro: convertTipoLograduoro,

            //Interveniente
            convertIntervenienteList: convertIntervenienteList,
            convertBackIntervenienteVersaoProposta: convertBackIntervenienteVersaoProposta,
            convertBackExposicaoIntervenienteVersaoProposta: convertBackExposicaoIntervenienteVersaoProposta,
            convertModInterveniente: convertModInterveniente,
            convertFaixaRendaList: convertFaixaRendaList,
            constructPropostaVersionList: constructPropostaVersionList,
            convertTipoInterveniente: convertTipoInterveniente,

            //Corretagem
            defaultCorretagem: defaultCorretagem,
            convertCorretagem: convertCorretagem,
            convertBackCorretorVersaoProposta: convertBackCorretorVersaoProposta,
            getNomeCorretor: getNomeCorretor,
            constructCorretoresNomeList: constructCorretoresNomeList,

            getLocalRiscoDropDown: getLocalRiscoDropDown,

            //Proposta
            constructProposta: constructProposta,
            convertProposta: convertProposta,

            //Beneficiario
            defaultBeneficiario: defaultBeneficiario,
            initializeObjetoSeguradoDropdown: initializeObjetoSeguradoDropdown,
            convertBeneficiario: convertBeneficiario,
            constructBeneficiarioList: constructBeneficiarioList,
            convertTipoBemDropdown: convertTipoBemDropdown,
            createBeneficiarioRequest: createBeneficiarioRequest,
            // convertBeneficiarios                    : convertBeneficiarios,
            constructBeneficiarioCoberturaList: constructBeneficiarioCoberturaList,
            constructBeneficiarioCoberturaListChecked: constructBeneficiarioCoberturaListChecked,
            constructObjetoSegurado: constructObjetoSegurado,
            convertEnderecoSolicitacaoCartao: convertEnderecoSolicitacaoCartao,

            filterFormaPagamento: filterFormaPagamento,
            filterQuantidadeParcela: filterQuantidadeParcela,
            getFormaPagamentoFromList: getFormaPagamentoFromList,
            convertTipoDocumento: convertTipoDocumento,
            convertFaixaDeRenda: convertFaixaDeRenda,
            convertPaisResidente: convertPaisResidente,
            convertAtividade: convertAtividade,
            convertGridPagadores: convertGridPagadores,
            ajustaPagadorParcela: ajustaPagadorParcela,
            ajustaGrid: ajustaGrid

        };

        return exports;
        //----------------------------------------------QUESTIONARIO-------------------------------------------------//

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertQuestionario
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs questionario object
         *
         * @param {Object} questao parameter.
         * @param {Object} respostaQuestionario parameter.
         * @returns {Object} converted object of 'questionario'
         **/
        function convertQuestionario(questao, respostaQuestionario) {

            var converted = {};

            converted = {
                codigoQuestao: respostaQuestionario.codigoQuestao,
                codigoQuestionario: respostaQuestionario.codigoQuestionario,
                codigoResposta: respostaQuestionario.codigoResposta,
                codigoTipoQuestao: respostaQuestionario.codigoTipoQuestao,
                dataResposta: respostaQuestionario.dataResposta,
                numeroVersaoQuestionario: respostaQuestionario.numeroVersaoQuestionario,
                textoResposta: respostaQuestionario.textoResposta,
                textoRespostaTime: respostaQuestionario.textoRespostaTime,
                numeroOrdemExibicao: questao.numeroOrdemExibicao,
                codigoListaItem: questao.codigoListaItem,
                textoQuestao: questao.textoQuestao,
                codigoMascaraQuestao: questao.codigoMascaraQuestao,
                codigoListaValor: questao.codigoListaValor,
                multiplaEscolha: respostaQuestionario.multiplaEscolha,
                respostaListaQuestionario: respostaQuestionario.respostaListaQuestionario,
                periodo: respostaQuestionario.periodo,
                respostaListaRow: [],
                dependencias: [],
                dependenciasTo: [],
                isShown: true
            };

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#addListaItem
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * add codigo lista item for respostaQuestionario
         *
         * @param {data} respostaQuestionario parameter.
         * @param {questao} questao that contains listaItem
         **/
        function addCodigoListaItem(data, questao) {
            data.codigoQuestao = questao.codigoQuestao;
            data.codigoListaItem = questao.codigoListaItem;
        }
        //--------------------------------------------END QUESTIONARIO------------------------------------------------//


        function convertBackPagadorParcelaVersaoProposta(numeroProposta, numeroVersaoProposta, codigoPessoa, item, dataMelhorDataPrimeiraParcela) {

            var pagadorParcelaVersaoProposta = {};

            pagadorParcelaVersaoProposta.codigoPessoa = codigoPessoa;
            pagadorParcelaVersaoProposta.numeroProposta = numeroProposta;
            pagadorParcelaVersaoProposta.numeroVersaoProposta = numeroVersaoProposta;
            pagadorParcelaVersaoProposta.quantidadeParcela = item.quantidadeParcela;
            pagadorParcelaVersaoProposta.codigoFormaPagamento = item.codigoFormaPagamento;

            var dataMelhor = null;
            if (dataMelhorDataPrimeiraParcela) {
                var dateHolder = dataMelhorDataPrimeiraParcela.split('/');
                dataMelhor = dateHolder[2] + '-' + dateHolder[1] + '-' + dateHolder[0];
            }

            pagadorParcelaVersaoProposta.dataMelhorDataPrimeiraParcela = dataMelhor;
            // SM 279
            pagadorParcelaVersaoProposta.textoComentario = item.textoComentario;
            // FIM - SM 279

            return pagadorParcelaVersaoProposta;
        }

        function convertBackPagadorParcelaVersaoPropostaForUpdate(grid, parcela, numeroParcela, createdPessoa, existingPessoa, cartao, pessoasGrid) {

            var pagadorParcelaVersaoProposta = grid;
            var applyToAll;
            var lastIndex = (grid.length - 1);

            var pagadorParcela = [];

            angular.forEach(grid, function(item, index) {
                var dadosPessoaPagadorParcela = {};
                var tempHolder = {};
                var numeroContaDataValidade;
                if (numeroParcela === item.numeroParcela && item.numeroParcelaVersao == parcela.numeroParcelaVersao) {

                    dadosPessoaPagadorParcela.codigoPessoa = createdPessoa.codigoPessoa;
                    dadosPessoaPagadorParcela.codigoTipoPessoa = createdPessoa.codigoTipoPessoa;
                    dadosPessoaPagadorParcela.numeroCnpjCpf = removeFormat(createdPessoa.numeroCnpjCpf);

                    dadosPessoaPagadorParcela.nomePessoa = createdPessoa.nomePessoa;
                    dadosPessoaPagadorParcela.nomeResumidoPessoa = createdPessoa.nomeResumidoPessoa;
                    dadosPessoaPagadorParcela.flagAtivo = createdPessoa.flagAtivo;
                    pessoasGrid.push(dadosPessoaPagadorParcela);
                    tempHolder.codigoPessoa = createdPessoa.codigoPessoa;
                    tempHolder.dadosPessoaPagadorParcela = dadosPessoaPagadorParcela;
                    tempHolder.numeroParcela = parcela.numeroParcela;
                    tempHolder.dataVencimento = convertDateOnly(parcela.dataVencimento);
                    tempHolder.codigoTipoCartao = item.codigoTipoCartao;
                    tempHolder.codigoBanco = parcela.codigoBanco;
                    tempHolder.numeroAgenciaBancaria = parcela.numeroAgenciaBancaria;
                    tempHolder.numeroContaBancaria = parcela.numeroContaBancaria;
                    tempHolder.digitoContaBancaria = parcela.digitoContaBancaria;
                    tempHolder.valorParcela = item.valorParcela;
                    tempHolder.dataPagamentoContabilizado = convertDateOnly(item.dataPagamentoContabilizado);
                    tempHolder.dataCancelamento = convertDateOnly(item.dataCancelamento);
                    tempHolder.codigoStatusParcela = item.codigoStatusParcela;
                    tempHolder.dataPrazoCobertura = convertDateOnly(parcela.dataPrazoCobertura);
                    tempHolder.numeroParcelaVersao = parcela.numeroParcelaVersao;
                    // SM 279
                    tempHolder.textoComentario = parcela.textoComentario;
                    // FIM - SM 279
                    if (cartao) {
                        tempHolder.codigoBandeiraCartao = cartao.codigoBandeiraCartao;
                        if (angular.isDefined(cartao.numeroConta) && cartao.numeroConta !== null) {
                            tempHolder.codigoIdentificacaoCartao = cartao.numeroConta;
                        }

                        if (angular.isDefined(cartao.anoValidadeCartao) && cartao.anoValidadeCartao !== null &&
                            angular.isDefined(cartao.mesValidadeCartao) && cartao.mesValidadeCartao !== null &&
                            /[*]/g.test(cartao.anoValidadeCartao) === false) {
                            numeroContaDataValidade = cartao.anoValidadeCartao + '-' + cartao.mesValidadeCartao + '-' + '01';
                            tempHolder.dataPagamento = convertDateOnly(numeroContaDataValidade);
                        }
                    }

                    pagadorParcela.push(tempHolder);

                    if (parcela.seguradoResponsavelPagamento) {
                        applyToAll = parcela;
                    }
                } else {
                    if (applyToAll && item.codigoTipoPessoa == 1 && item.numeroParcela != parcela.numeroParcela) {

                        // var dadosPessoaPagadorParcela = {};
                        // var tempHolder = {};
                        dadosPessoaPagadorParcela.codigoPessoa = createdPessoa.codigoPessoa;
                        dadosPessoaPagadorParcela.codigoTipoPessoa = createdPessoa.codigoTipoPessoa;
                        dadosPessoaPagadorParcela.numeroCnpjCpf = createdPessoa.numeroCnpjCpf;
                        dadosPessoaPagadorParcela.nomePessoa = createdPessoa.nomePessoa;
                        dadosPessoaPagadorParcela.nomeResumidoPessoa = createdPessoa.nomeResumidoPessoa;
                        dadosPessoaPagadorParcela.flagAtivo = createdPessoa.flagAtivo;

                        tempHolder.codigoPessoa = createdPessoa.codigoPessoa;
                        tempHolder.dadosPessoaPagadorParcela = dadosPessoaPagadorParcela;
                        tempHolder.numeroParcela = item.numeroParcela;
                        tempHolder.dataVencimento = convertDateOnly(item.dataVencimento);
                        tempHolder.codigoTipoCartao = item.codigoTipoCartao;
                        tempHolder.codigoBanco = applyToAll.codigoBanco;
                        tempHolder.numeroAgenciaBancaria = applyToAll.numeroAgenciaBancaria;
                        tempHolder.numeroContaBancaria = applyToAll.numeroContaBancaria;
                        tempHolder.digitoContaBancaria = applyToAll.digitoContaBancaria;
                        tempHolder.valorParcela = item.valorParcela;
                        tempHolder.dataPagamentoContabilizado = convertDateOnly(item.dataPagamentoContabilizado);
                        tempHolder.dataCancelamento = convertDateOnly(item.dataCancelamento);
                        tempHolder.codigoStatusParcela = item.codigoStatusParcela;
                        //tempHolder.dataPrazoCobertura = convertDateOnly(parcela.dataPrazoCobertura);

                        if (grid[index] && grid[index].dataPrazoCobertura) {
                            tempHolder.dataPrazoCobertura = grid[index].dataPrazoCobertura;
                            // SM 279
                            tempHolder.textoComentario = grid[index].textoComentario;
                            // FIM - SM 279
                        } else {
                            tempHolder.dataPrazoCobertura = convertDateOnly(parcela.dataPrazoCobertura);
                            // SM 279
                            tempHolder.textoComentario = parcela.textoComentario;
                            // FIM - SM 279
                        }

                        if (cartao) {
                            tempHolder.codigoBandeiroCartao = cartao.bandeira;
                            if (angular.isDefined(cartao.numeroConta) && cartao.numeroConta !== null) {
                                tempHolder.codigoIdentificacaoCartao = cartao.numeroConta;
                            }
                            if (angular.isDefined(cartao.anoValidadeCartao) && cartao.anoValidadeCartao !== null &&
                                angular.isDefined(cartao.mesValidadeCartao) && cartao.mesValidadeCartao !== null) {
                                numeroContaDataValidade = cartao.anoValidadeCartao + '-' + cartao.mesValidadeCartao + '-' + '01';
                                tempHolder.dataPagamento = convertDateOnly(numeroContaDataValidade);
                            }
                        }

                        pagadorParcela.push(tempHolder);
                    } else {
                        dadosPessoaPagadorParcela.numeroCnpjCpf = removeFormat(item.cpf || item.cnpj);
                        dadosPessoaPagadorParcela.codigoPessoa = item.codigoPessoa;
                        dadosPessoaPagadorParcela.codigoTipoPessoa = item.codigoTipoPessoa;
                        dadosPessoaPagadorParcela.nomePessoa = item.nomePessoa;
                        dadosPessoaPagadorParcela.nomeResumidoPessoa = item.nomeResumidoPessoa;
                        dadosPessoaPagadorParcela.flagAtivo = item.flagAtivo;

                        tempHolder.codigoPessoa = item.codigoPessoa;
                        pessoasGrid.push(dadosPessoaPagadorParcela);
                        tempHolder.dadosPessoaPagadorParcela = dadosPessoaPagadorParcela;
                        tempHolder.numeroParcela = item.numeroParcela;
                        tempHolder.dataVencimento = convertDateOnly(item.dataVencimento);
                        tempHolder.codigoTipoCartao = item.codigoTipoCartao;
                        if (applyToAll) {
                            tempHolder.codigoBanco = applyToAll.codigoBanco;
                            tempHolder.numeroAgenciaBancaria = applyToAll.numeroAgenciaBancaria;
                            tempHolder.numeroContaBancaria = applyToAll.numeroContaBancaria;
                            tempHolder.digitoContaBancaria = applyToAll.digitoContaBancaria;
                        } else {
                            tempHolder.codigoBanco = null;
                            tempHolder.numeroAgenciaBancaria = null;
                            tempHolder.numeroContaBancaria = null;
                            tempHolder.digitoContaBancaria = null;
                        }
                        tempHolder.valorParcela = item.valorParcela;
                        tempHolder.dataPagamentoContabilizado = convertDateOnly(item.dataPagamentoContabilizado);
                        tempHolder.dataCancelamento = convertDateOnly(item.dataCancelamento);
                        tempHolder.codigoStatusParcela = item.codigoStatusParcela;
                        tempHolder.dataPrazoCobertura = convertDateOnly(item.dataPrazoCobertura);
                        tempHolder.numeroParcelaVersao = item.numeroParcelaVersao;
                        // SM 279
                        tempHolder.textoComentario = item.textoComentario;
                        // FIM - SM 279
                        if (cartao) {
                            tempHolder.codigoBandeiroCartao = cartao.bandeira;
                            if (angular.isDefined(cartao.numeroConta) && cartao.numeroConta !== null) {
                                tempHolder.codigoIdentificacaoCartao = cartao.numeroConta;
                            }
                            if (angular.isDefined(cartao.anoValidadeCartao) && cartao.anoValidadeCartao !== null &&
                                angular.isDefined(cartao.mesValidadeCartao) && cartao.mesValidadeCartao !== null) {
                                numeroContaDataValidade = cartao.anoValidadeCartao + '-' + cartao.mesValidadeCartao + '-' + '01';
                                tempHolder.dataPagamento = convertDateOnly(numeroContaDataValidade);
                            }
                        }

                        pagadorParcela.push(tempHolder);
                    }
                }
            });

            return pagadorParcela;
        }

        function getDadosPessoaPagador(pessoa) {
            var dadosPessoaPagadorParcela = {};
            if (pessoa) {
                dadosPessoaPagadorParcela.numeroCnpjCpf = removeFormat(pessoa.numeroCnpjCpf.toString());
                dadosPessoaPagadorParcela.codigoPessoa = pessoa.codigoPessoa;
                dadosPessoaPagadorParcela.codigoTipoPessoa = pessoa.codigoTipoPessoa;
                dadosPessoaPagadorParcela.nomePessoa = pessoa.nomePessoa;
                dadosPessoaPagadorParcela.nomeResumidoPessoa = pessoa.nomeResumidoPessoa;
                dadosPessoaPagadorParcela.flagAtivo = pessoa.flagAtivo;
            }

            return dadosPessoaPagadorParcela;
        }

        function filterPessoaPagador(pessoaArr, gridItem) {
            var pessoaFiltered;
            if (angular.isArray(pessoaArr)) {
                pessoaFiltered = pessoaArr.filter(function(pessoa) {
                    return pessoa.codigoPessoa === gridItem.codigoPessoa;
                })[0];
            }
            return pessoaFiltered;

        }

        function convertGridPagadores(grid, pessoaArr, cartao, dataVencimento) {
            var dadosPessoaPagadorParcela;
            var pagadorParcela = [];
            var numeroContaDataValidade;

            angular.forEach(grid, function(item) {
                var tempHolder = {};

                var pessoaFiltered = filterPessoaPagador(pessoaArr, item);

                tempHolder.dadosPessoaPagadorParcela = getDadosPessoaPagador(pessoaFiltered);

                tempHolder.numeroParcela = item.numeroParcela;
                tempHolder.dataVencimento = item.dataVencimento ? convertDateOnly(item.dataVencimento) : convertDateOnly(dataVencimento);

                if (item.codigoTipoCartao) {
                    tempHolder.codigoTipoCartao = item.codigoTipoCartao;
                } else if (cartao && cartao.codigoTipoCartao) {
                    tempHolder.codigoTipoCartao = cartao.codigoTipoCartao;
                } else {
                    tempHolder.codigoTipoCartao = null;
                }

                //tempHolder.codigoTipoCartao = item.codigoTipoCartao ? item.codigoTipoCartao : cartao && cartao.codigoTipoCartao ? cartao.codigoTipoCartao : null;
                tempHolder.codigoBanco = item.codigoBanco;
                tempHolder.numeroAgenciaBancaria = item.numeroAgenciaBancaria;
                tempHolder.numeroContaBancaria = item.numeroContaBancaria;
                tempHolder.digitoContaBancaria = item.digitoContaBancaria;
                tempHolder.valorParcela = item.valorParcela;
                tempHolder.dataPagamentoContabilizado = convertDateOnly(item.dataPagamentoContabilizado);
                tempHolder.dataCancelamento = convertDateOnly(item.dataCancelamento);
                tempHolder.codigoStatusParcela = item.codigoStatusParcela;
                tempHolder.dataPrazoCobertura = convertDateOnly(item.dataPrazoCobertura);
                tempHolder.numeroParcelaVersao = item.numeroParcelaVersao;
                // SM 279
                tempHolder.textoComentario = item.textoComentario;
                // FIM - SM 279
                if (cartao) {
                    tempHolder.codigoBandeiroCartao = cartao.bandeira;
                    if (angular.isDefined(cartao.numeroConta) && cartao.numeroConta !== null) {
                        tempHolder.codigoIdentificacaoCartao = cartao.numeroConta;
                    }
                    if (angular.isDefined(cartao.anoValidadeCartao) && cartao.anoValidadeCartao !== null &&
                        angular.isDefined(cartao.mesValidadeCartao) && cartao.mesValidadeCartao !== null) {
                        numeroContaDataValidade = cartao.anoValidadeCartao + '-' + cartao.mesValidadeCartao + '-' + '01';
                        tempHolder.dataPagamento = convertDateOnly(numeroContaDataValidade);
                    }
                }
                pagadorParcela.push(tempHolder);
            });


            return pagadorParcela;
        }

        /*ns {Array.<Object>} results Array of converted `FaixaRenda` common data model objects.
         **/
        function convertFaixaRendaList(items) {
            var results = [];
            var resultItem = {};

            angular.forEach(items, function(item) {
                results.push({
                    codigoFaixaRenda: item.codigoFaixaRenda,
                    nomeFaixaRenda: item.nomeFaixaRenda
                });
            });

            results = OrcamentoUtilityFactory.sortCollection(results, ['nomeFaixaRenda']);

            return results;
        }

        function convertPagadorParcelaVersaoProposta(items, pessoas, statusParcelas, nomeFormaPagamento) {

            var pagadorVersaoProposta = {};
            pagadorVersaoProposta.nomeFormaPagamento = nomeFormaPagamento;
            pagadorVersaoProposta.codigoFormaPagamento = items[0].codigoFormaPagamento;
            pagadorVersaoProposta.quantidadeParcela = items[0].quantidadeParcela;
            pagadorVersaoProposta.codigoPessoa = items[0].codigoPessoa;
            pagadorVersaoProposta.numeroProposta = items[0].numeroProposta;
            pagadorVersaoProposta.numeroVersaoProposta = items[0].numeroVersaoProposta;
            pagadorVersaoProposta.grid = [];
            pagadorVersaoProposta.parcela = [];

            var gridValue = [];

            angular.forEach(items, function(item) {
                var pessoaObject = getNomePessoa(item.codigoPessoa, pessoas);
                var numeroCpf;
                var numeroCnpj;
                var codBanco = null;
                var codAgencia = null;
                var numeroContaBanc = null;
                var digitoContaBanc = null;
                var valorPago = null;
                var valorParcela = null;

                if (pessoaObject) {

                    if (pessoaObject.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA) {
                        numeroCpf = cpfFormat(pad(pessoaObject.numeroCnpjCpf.toString(), 11));
                    } else {
                        numeroCnpj = cnpjFormat(pad(pessoaObject.numeroCnpjCpf.toString(), 14));
                    }

                    if (angular.isDefined(item.codigoBanco) && angular.isDefined(item.numeroAgenciaBancaria)) {
                        codBanco = parseInt(item.codigoBanco);
                        codAgencia = parseInt(item.numeroAgenciaBancaria);
                    }

                    if (angular.isDefined(item.numeroContaBancaria)) {
                        var contaBancaria = parseInt(item.numeroContaBancaria);
                        numeroContaBanc = contaBancaria;
                    }

                    if (angular.isDefined(item.digitoContaBancaria)) {
                        digitoContaBanc = item.digitoContaBancaria;
                    }

                    if (item.codigoStatusParcela === Constants.CODIGO_STATUS_PARCELA.LIQUIDADA) {
                        valorPago = formatValorParcela(item.valorPago);
                    }

                    valorParcela = formatValorParcela(item.valorParcela);

                    gridValue.push({
                        //Grid Value Main
                        numeroParcela: item.numeroParcela,
                        numeroParcelaVersao: item.numeroParcelaVersao,
                        dataPagamento: item.dataPagamento ? $filter('date')(Date.parse(OrcamentoUtilityFactory.formatDate(item.dataPagamento)), 'dd/MM/yyyy') : '',
                        dataPagamentoContabilizado: item.dataPagamentoContabilizado ? $filter('date')(Date.parse(OrcamentoUtilityFactory.formatDate(item.dataPagamentoContabilizado)), 'dd/MM/yyyy') : '',
                        dataCancelamento: item.dataCancelamento ? $filter('date')(Date.parse(OrcamentoUtilityFactory.formatDate(item.dataCancelamento)), 'dd/MM/yyyy') : '',
                        dataVencimento: item.dataVencimento, //valorParcela >= 0 ? item.dataVencimento : '',
                        dataPrazoCobertura: item.dataPrazoCobertura,
                        codigoPessoa: item.codigoPessoa,
                        valorParcela: valorParcela,
                        valorPago: valorPago,
                        nomePessoa: pessoaObject.nomePessoa,
                        nomeResumidoPessoa: pessoaObject.nomeResumidoPessoa,
                        flagAtivo: pessoaObject.flagAtivo,
                        codigoBanco: codBanco,
                        numeroAgenciaBancaria: codAgencia,
                        numeroContaBancaria: numeroContaBanc,
                        digitoContaBancaria: digitoContaBanc,
                        codigoTipoPessoa: pessoaObject.codigoTipoPessoa,
                        cpf: numeroCpf,
                        cnpj: numeroCnpj,
                        codigoStatusParcela: item.codigoStatusParcela,
                        statusParcela: setStatusParcela(statusParcelas, item.codigoStatusParcela),
                        flagOrgaoSubvencao: !pessoaObject.flagOrgaoSubvencao ? "N" : pessoaObject.flagOrgaoSubvencao,
                        textoComentario: item.textoComentario // SM 279
                    });
                }
            });

            pagadorVersaoProposta.grid = gridValue;

            return pagadorVersaoProposta;
        }

        function setStatusParcela(statusParcelas, codigo) {

            var nomeStatusParcela = null;

            angular.forEach(statusParcelas, function(statusParcela) {
                if (statusParcela.codigoValorDominio === codigo) {
                    nomeStatusParcela = statusParcela.nomeDominio;
                }
            });

            return nomeStatusParcela;
        }

        function formatValorParcela(valorParcela) {
            if ((valorParcela % 1) !== 0) {
                var valor = valorParcela.toString();

                return valor.split('.')[1].length === 1 ? (valor + '0') : valor;

            } else {
                return valorParcela;
            }

        }

        function isOrgaoSubvencao(pessoa) {
            return pessoa.pessoaJuridica && pessoa.pessoaJuridica.flagOrgaoSubvencao;
        }

        function convertPessoa(items) {

            var pessoas = [];

            angular.forEach(items, function(pessoa) {

                pessoas.push({
                    nomePessoa: pessoa.nomePessoa,
                    codigoTipoPessoa: pessoa.codigoTipoPessoa,
                    codigoPessoa: pessoa.codigoPessoa,
                    numeroCnpjCpf: pessoa.numeroCnpjCpf,
                    flagOrgaoSubvencao: isOrgaoSubvencao(pessoa)
                });
            });

            return pessoas;
        }

        function getNomePessoa(codigoPessoa, pessoas) {

            var nomePessoa;

            angular.forEach(pessoas, function(pessoa) {
                if (codigoPessoa === pessoa.codigoPessoa) {
                    nomePessoa = pessoa;
                    return false;
                }
            });

            return nomePessoa;
        }

        function covertBackModParcela(modParcela, itemPagadorParcela) {

            var parcela = itemPagadorParcela;
            parcela.codigoBanco = modParcela.codigoBanco;
            parcela.numeroAgenciaBancaria = modParcela.numeroAgenciaBancaria;
            parcela.numeroContaBancaria = modParcela.numeroContaBancaria;
            parcela.digitoContaBancaria = modParcela.digitoContaBancaria;
            parcela.codigoTipoPessoa2 = modParcela.codigoTipoPessoa2;
            var nome2;

            if (modParcela.codigoTipoPessoa2 == 1) {
                parcela.numeroCnpjCpf2 = modParcela.cpf;
            } else {
                parcela.numeroCnpjCpf2 = modParcela.cnpj;
            }

            parcela.nomePessoa2 = modParcela.nomePessoa2;
            parcela.applyToAll = modParcela.applyToAll;

            return parcela;
        }

        function convertBanco(bancos) {

            var bancoReturn = [];

            angular.forEach(bancos, function(banco) {
                bancoReturn.push({
                    codigoBanco: banco.codigoValorDominio,
                    nomeBanco: banco.nomeDominio,
                    flagAtivo: banco.flagAtivo
                });
            });

            bancoReturn = OrcamentoUtilityFactory.sortCollection(bancoReturn, ['nomeBanco']);

            return bancoReturn;
        }

        function convertProfissao(profissaos) {

            var profissaoReturn = [];

            angular.forEach(profissaos, function(profissao) {
                profissaoReturn.push({
                    codigoProfissao: profissao.codigoValorDominio,
                    nomeProfissao: profissao.nomeDominio
                });
            });

            profissaoReturn = OrcamentoUtilityFactory.sortCollection(profissaoReturn, ['nomeProfissao']);

            return profissaoReturn;
        }

        function convertSexo(sexos) {

            var sexoReturn = [];

            angular.forEach(sexos, function(sexo) {
                sexoReturn.push({
                    codigoSexo: sexo.codigoValorDominio,
                    nomeSexo: sexo.nomeDominio
                });
            });

            sexoReturn = OrcamentoUtilityFactory.sortCollection(sexoReturn, ['nomeSexo']);

            return sexoReturn;
        }

        function convertTipoLograduoro(tipoLograduoros) {
            var tipoReturn = [];

            angular.forEach(tipoLograduoros, function(tipoLograduoro) {
                tipoReturn.push({
                    codigoTipoLograduoro: tipoLograduoro.codigoValorDominio,
                    nomeTipoLograduoro: tipoLograduoro.nomeDominio
                });
            });

            tipoReturn = OrcamentoUtilityFactory.sortCollection(tipoReturn, ['nomeTipoLograduoro']);

            return tipoReturn;
        }

        //----------------------------------------CLÁUSULAS PARTICULARES------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertClausulas
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Clausulas object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Clausulas'
         **/
        function convertClausulas(clausula, clausulaOrcamento) {
            var converted;
            converted = {
                codigo: clausula.codigoClausula,
                nome: clausula.nomeResumidoClausula,
                selected: clausulaOrcamento.flagAtivo === 'S' ? true : false,
                textoClausula: clausulaOrcamento.textoClausula
                    //Rebaseline 99.48.27 R2_Rebase - Begin
                    //Checar se esses valores devem ser setados no objeto clausula ou clausulaOrcamento
                    //codigoAbrangenciaImpressao  : clausulaOrcamento.codigoAbrangenciaImpressao,
                    //numeroOrdemExibicao : clausulaOrcamento.numeroOrdemExibicao,
                    //flagAdendo :clausulaOrcamento.flagAdendo
                    //Rebaseline 99.48.27 R2_Rebase - End
            };
            return converted;
        }
        //--------------------------------------END CLÁUSULAS PARTICULARES----------------------------------------//

        //-----------------------------------------------DESCONTOS----------------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertDesconto
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Desconto object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Desconto'
         **/
        function convertDesconto(descontoAgravo, descontoAgravoOrcamento) {
            var converted;
            converted = {
                codigo: descontoAgravo.codigoDescontoAgravo,
                nome: descontoAgravo.nomeResumidoDescontoAgravo,
                selected: descontoAgravoOrcamento.checked,
                percentual: descontoAgravoOrcamento.percentualDescontoAgravo > 0 ? descontoAgravoOrcamento.percentualDescontoAgravo : null
            };
            return converted;
        }
        //----------------------------------------------END DESCONTOS-------------------------------------------------//

        //----------------------------------------------CRITICAS------------------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertCriticas
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Criticas object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Criticas'
         **/
        function convertCriticas(items) {
            var converted = [{
                descricao: "Negociação/ Concessão eletrônica pré-aprovada",
                devolutiva: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sed condimentum lacus.",
                status: "Liberado",
                acao: "Liberar Todas"
            }, {
                descricao: "Bloqueio RE por CPF/CNPJ",
                devolutiva: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sed condimentum lacus.",
                status: "Nao",
                acao: "Liberar"
            }];

            return converted;
        }
        //------------------------------------------END OF CRITICAS-------------------------------------------------//

        //-------------------------------------------CO CORRETAGEM---------------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#defaultCorretagem
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Corretagem object
         *
         * @returns {Object} data object of 'Corretagem' containing default values
         **/
        function defaultCorretagem() {
            var data = {
                codigoCorretor: null,
                percentualParticipacao: null,
                nome: "",
                existing: false,
                codigoSucursal: null,
                flagPrincipal: "N",
                valorComissao: null,
                flagAtivo: "N"
            };
            return data;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertCorretagem
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Corretagem object
         *
         * @param {Array.<Object>} items object to be converted.
         * @returns {Array.<Object>} converted object of 'Corretagem'
         **/
        function convertCorretagem(item, codigoCorretorMain) {
            var converted = {};

            if (item !== undefined && item !== null) {
                converted.numeroProposta = item.numeroProposta;
                converted.numeroVersaoProposta = item.numeroVersaoProposta;
                converted.corretores = null;
                if (angular.isDefined(item.corretores) && item.corretores !== null) {
                    converted.corretores = constructCorretorList(item.corretores.corretor, codigoCorretorMain);
                }
            } else {
                converted.numeroProposta = null;
                converted.numeroVersaoProposta = null;
                converted.corretores = [];
            }

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#constructCorretorList
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs corretor list object
         *
         * @param {Array.<Object>} items object to be converted.
         * @returns {Array.<Object>} converted object of 'Corretagem'
         **/
        function constructCorretorList(items, codigoCorretorMain) {

            var converted = [{
                existing: true,
                codigoCorretor: null,
                codigoSucursal: null,
                flagPrincipal: "N",
                percentualPrinicpal: 100,
                valorComissao: null,
                nomeCorretor: null,
                flagAtivo: "N"
            }];

            var principal = {};
            // var secondarios = [];

            if (items !== undefined && items !== null) {
                var percentualPrinicpal = 100;

                angular.forEach(items, function(item) {
                    var corretagem = {};
                    if (item.codigoCorretor === codigoCorretorMain) {
                        converted[0] = item;
                        converted[0].nomeCorretor = null;
                        converted[0].existing = true;
                    } else {
                        corretagem.existing = false;
                        corretagem.codigoCorretor = item.codigoCorretor;
                        corretagem.codigoSucursal = item.codigoSucursal;
                        corretagem.flagPrincipal = item.flagPrincipal;
                        corretagem.valorComissao = item.valorComissao;
                        corretagem.flagAtivo = item.flagAtivo;
                        corretagem.percentualParticipacao = item.percentualParticipacao;
                        corretagem.nomeCorretor = null;

                        //calculate percentual participacao
                        percentualPrinicpal -= item.percentualParticipacao;
                        converted[0].percentualParticipacao = percentualPrinicpal;
                        converted.push(corretagem);
                    }

                });
            }

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#constructCorretoresNomeList
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         *
         * Constructs the `Nome` for display
         *
         * @param {Array.<Object>} susepList The susepList.
         * @returns {Array.<Object>} corretores The constructed object list.
         **/
        function constructCorretoresNomeList(susepList) {
            var corretores = [];
            var cor = {};
            var corretorItem = null;

            angular.forEach(susepList, function(corretor) {
                cor = {};
                corretorItem = null;

                corretorItem = corretor.listaCorretores.corretor[0];
                cor.codigo = corretor.susepPorto;
                cor.nomeCorretor = corretorItem.nome;
                corretores.push(cor);
            });

            return corretores;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertBackCorretorVersaoProposta
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * Convert Corretor into an object for create and update
         *
         * @param {Number} numeroProposta Proposta number of object to be converted.
         * @param {Number} numeroVersaoProposta Version number of object to be converted.
         * @param {Object} item object to be converted.
         * @returns {Array.<Object>} converted object of 'Corretagem'
         **/
        function convertBackCorretorVersaoProposta(numeroProposta, numeroVersaoProposta, item) {

            var converted = {
                documentoEmissao: {
                    numeroProposta: numeroProposta,
                    numeroVersaoProposta: numeroVersaoProposta,
                    corretores: convertBackCorretores(numeroProposta, numeroVersaoProposta, item.corretores)
                }
            };

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertBackCorretores
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * Convert Corretor into an object for create and update
         *
         * @param {Number} numeroProposta Proposta number of object to be converted.
         * @param {Number} numeroVersaoProposta Version number of object to be converted.
         * @param {Array.<Object>} items object to be converted.
         * @returns {Array.<Object>} converted object of 'Corretagem'
         **/
        function convertBackCorretores(numeroProposta, numeroVersaoProposta, items) {
            var converted = {};
            var corretores = [];

            angular.forEach(items, function(item) {
                var corretagem = {};
                corretagem.numeroProposta = numeroProposta;
                corretagem.numeroVersaoProposta = numeroVersaoProposta;
                corretagem.codigoCorretor = item.codigoCorretor;
                if (item.codigoSucursal !== null && item.codigoSucursal !== undefined) {
                    corretagem.codigoSucursal = item.codigoSucursal;
                } else {
                    corretagem.codigoSucursal = 1;
                }
                corretagem.flagPrincipal = item.flagPrincipal;
                corretagem.percentualParticipacao = item.percentualParticipacao;
                corretagem.valorComissao = item.valorComissao;
                corretagem.flagAtivo = item.flagAtivo;
                corretores.push(corretagem);
                converted.corretor = corretores;
            });

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#getNomeCorretor
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         *
         * Construct corretagem object with nome corretor based on codigo corretor
         *
         * @param {Object} corretagem The corretagem object
         * @param {Array.<Object>} corretoresList The corretores list with nomecorretor
         *
         * @returns {Object} data object of 'Endereco' containing default values
         **/
        function getNomeCorretor(corretagem, corretoresList) {

            var converted = [];
            converted = corretagem;

            angular.forEach(corretagem, function(item1, index) {
                // angular.forEach(corretoresList, function(item2){
                //     if(item1.codigoCorretor === item2.codigo){
                //         converted[index].nomeCorretor = item2.nomeCorretor;
                //     }
                // });
                for (var i = 0; i < corretoresList.length; i++) {
                    if (item1.codigoCorretor === corretoresList[i].codigo) {
                        converted[index].nomeCorretor = corretoresList[i].nomeCorretor;
                        break;
                    }
                }
            });

            return converted;
        }
        //-----------------------------------------END OF CO CORRETAGEM----------------------------------------------//

        //-------------------------------------------------ENDERECO--------------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#defaultEndereco
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs default Endereco object
         *
         * @returns {Object} data object of 'Endereco' containing default values
         **/
        function defaultEndereco() {
            var data = {
                enderecoEmpresarial: {
                    flagEnderecoEmpresarial: null,
                    localDeRisco: null,
                    localDeRiscoList: []
                },
                enderecoCobranca: {
                    flagEnderecoCobranca: null,
                    localDeRisco: null,
                    localDeRiscoList: [],
                    enderecosCadastrado: null,
                    enderecosCadastradoList: [],
                    codigoEndereco: null
                },
                enderecoCorrespondencia: {
                    flagEnderecoCorrespondencia: null,
                    localDeRisco: null,
                    localDeRiscoList: [],
                    enderecosCadastrado: null,
                    enderecosCadastradoList: [],
                    codigoEndereco: null
                }
            };
            return data;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#defaultEnderecoCobranca
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs default Endereco Cobranca object
         *
         * @returns {Object} data object of 'Endereco Cobranca' containing default values
         **/
        function defaultEnderecoCobranca() {
            var data = {
                logradouroBusca: null,
                cep: null,
                logradouro: null,
                tipoEndereco: null,
                tipoLogradouro: null,
                _logradouro: null,
                semNumero: null,
                numero: null,
                complemento: null,
                bairro: null,
                cidade: null,
                uf: null,
                pais: null,
                latitude: null,
                longtitude: null,
                pontoReferencia: null
            };
            return data;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#defaultEnderecoCorrespondencia
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs default Endereco Correspondencia object
         *
         * @returns {Object} data object of 'Endereco Correspondencia' containing default values
         **/
        function defaultEnderecoCorrespondencia() {
            var data = {
                logradouroBusca: null,
                cep: null,
                logradouro: null,
                tipoEndereco: null,
                tipoLogradouro: null,
                _logradouro: null,
                semNumero: null,
                numero: null,
                complemento: null,
                bairro: null,
                cidade: null,
                uf: null,
                pais: null,
                latitude: null,
                longtitude: null,
                pontoReferencia: null
            };
            return data;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertEnderecoCobranca
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Endereco Cobranca object
         *
         * @param {Object} item object to be converted.
         * @returns {Object} converted object of 'Endereco Cobranca'
         **/
        function convertEnderecoCobranca(item) {
            var converted = {
                logradouroBusca: 1,
                cep: 123,
                logradouro: 1,
                tipoEndereco: 1,
                tipoLogradouro: 1,
                _logradouro: 1,
                semNumero: "N",
                numero: 1,
                complemento: "casa",
                bairro: "Campos Eliseos",
                cidade: "São Paulo",
                uf: "SP",
                pais: "",
                latitude: "",
                longtitude: "",
                pontoReferencia: ""
            };
            return converted;
        }


        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertEnderecoDeCobrancaDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description constructs Endereco Correspondencia object
         *
         * @param {Object}
         *            item object to be converted.
         * @returns {Object} converted object of 'Endereco Correspondencia'
         */
        function convertEnderecoDeCobrancaDropdown(items) {
            var converted = [{
                codigo: 1,
                nome: "Endereço de Local de Risco"
            }, {
                codigo: 2,
                nome: "Endereço da Pessoa"
            }, {
                codigo: 3,
                nome: "Novo Endereço"
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertEnderecoDeCorrespondenciaDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description constructs Endereco Correspondencia object
         *
         * @param {Object}
         *            item object to be converted.
         * @returns {Object} converted object of 'Endereco Correspondencia'
         */
        function convertEnderecoDeCorrespondenciaDropdown(items) {
            var converted = [{
                codigo: 0,
                nome: "Selecione"
            }, {
                codigo: 1,
                nome: "Endereço de Local de Risco"
            }, {
                codigo: 2,
                nome: "Endereço da Pessoa"
            }, {
                codigo: 3,
                nome: "Novo Endereço"
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertEnderecoCorrespondencia
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description constructs Endereco Correspondencia object
         *
         * @param {Object}
         *            item object to be converted.
         * @returns {Object} converted object of 'Endereco Correspondencia'
         */
        function convertEnderecoCorrespondencia(item) {
            var converted = {
                logradouroBusca: 1,
                cep: 123,
                logradouro: 1,
                tipoEndereco: 1,
                tipoLogradouro: 1,
                _logradouro: 1,
                semNumero: "S",
                numero: 1,
                complemento: "casa",
                bairro: "Campos Eliseos",
                cidade: "São Paulo",
                uf: "SP",
                pais: "",
                latitude: "",
                longtitude: "",
                pontoReferencia: ""
            };
            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#constructLocalRiscoList
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Local De Risco List
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Local De Risco'
         **/
        function constructLocalRiscoList(itemOrcamento) {

            var localRiscoObject = {};
            var localRiscoList = [];
            var localRiscoMap = {};

            angular.forEach(itemOrcamento, function(itemOrcamentoObject) {
                if (angular.isDefined(itemOrcamentoObject.categoriasRisco)) {
                    angular.forEach(itemOrcamentoObject.categoriasRisco.categoriaRisco, function(categoriaRiscoObject) {
                        if (angular.isDefined(categoriaRiscoObject.objetosRisco) &&
                            angular.isDefined(categoriaRiscoObject.objetosRisco.objetoRisco) &&
                            categoriaRiscoObject.objetosRisco.objetoRisco[0] !== null) {
                            if (angular.isDefined(categoriaRiscoObject.objetosRisco.objetoRisco[0].localRisco) &&
                                angular.isDefined(categoriaRiscoObject.objetosRisco.objetoRisco[0].localRisco.codigoLocalRisco) &&
                                categoriaRiscoObject.objetosRisco.objetoRisco[0].localRisco.codigoLocalRisco !== null) {
                                var localRisco = categoriaRiscoObject.objetosRisco.objetoRisco[0].localRisco;
                                var codigoLocalRisco = localRisco.codigoLocalRisco;

                                localRisco.flagAtivo = 'S';
                                localRisco.flagPrincipal = 'N';
                                localRisco.codigoTipoEndereco = 1;

                                localRiscoMap[codigoLocalRisco] = localRisco;

                                localRiscoList.push(localRisco);
                            }

                        }
                    });
                }
            });

            localRiscoObject.localRiscoMap = localRiscoMap;
            localRiscoObject.localRiscoList = localRiscoList;

            return localRiscoObject;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#getLocalRiscoDropDown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Local De Risco List
         *
         * get local risco Dropdown.
         **/
        function getLocalRiscoDropDown(localRisco, tipoLogradouroOptions) {
            var localRiscoObject = {};
            var nomeLocalRisco = null;

            for (var i = 0; tipoLogradouroOptions.length > i; i++) {
                if (tipoLogradouroOptions[i].codigoValorDominio === localRisco.codigoTipoLogradouro) {
                    var nomeTipoLogradouro = tipoLogradouroOptions[i].nomeDominio + ', ',
                        nomeLogradouro = localRisco.nomeLogradouro + ', ',
                        numeroLogradouro = localRisco.numeroLogradouro + ', ',
                        nomeBairro = localRisco.nomeBairro + ', ',
                        nomeCidadeUF = localRisco.nomeCidade + ' - ' + localRisco.nomeUnidadeFederacao + ' ',
                        nomePais = localRisco.nomePais + ', ',
                        CEP = 'CEP: ' + formatCep(localRisco.numeroCep);
                    var complemento = localRisco.nomeComplemento ? (localRisco.nomeComplemento + ', ') : '';

                    nomeLocalRisco = nomeTipoLogradouro + nomeLogradouro + numeroLogradouro +
                        complemento + nomeBairro + nomeCidadeUF + nomePais + CEP;
                    break;
                }
            }

            localRiscoObject.nome = nomeLocalRisco;
            localRiscoObject.codigo = localRisco.codigoLocalRisco;

            return localRiscoObject;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertEnderecosCadastradoList
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Enderecos Cadastrado List
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Enderecos Cadastrado'
         **/
        function convertEnderecosCadastradoList(items) {
            var converted = [];

            angular.forEach(items, function(item) {
                converted.push({
                    codigo: item.codigoEndereco,
                    nome: item.nomeEndereco
                });
            });

            converted = OrcamentoUtilityFactory.sortCollection(converted, ['nome']);

            return converted;
        }
        //----------------------------------------------END OF ENDERECO----------------------------------------------//

        //-----------------------------------------------PAGAMENTO-----------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertPagamentoForma
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Pagamento Forma list
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Pagamento Forma'
         **/
        function convertPagamentoForma(items) {
            var converted = [];
            var newList = [];

            angular.forEach(items, function(item) {
                if (item.flagImpressaoFormaPagamento === "S") {
                    newList.push(item);
                }
            });

            if (newList.length  ==  0) {                
                newList  =  items;            
            }


            angular.forEach(newList, function(currentItem) {
                if (!$filter('filter')(converted, {
                        nome: currentItem.nomeResumidoFormaPagamento
                    }, true)[0]) {
                    converted.push({
                        nome: currentItem.nomeResumidoFormaPagamento,
                        codigo: currentItem.codigoFormaPagamento
                    });
                }
            });

            return converted;
        }


        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertpagamentoMelhorData
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Pagamento Forma list
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Pagamento Forma'
         **/
        /*function convertpagamentoMelhorData(items){
            var converted = [{
                codigo  : 3,
                nome    : "03"
            },{
                codigo  : 7,
                nome    : "07"
            },{
                codigo  : 15,
                nome    : "15"
            },{
                codigo  : 23,
                nome    : "23"
            },{
                codigo  : 26,
                nome    : "26"
            }];

            return converted;
        }*/

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertPagamentoQuantidadeParcela
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Pagamento Forma list
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Pagamento Forma'
         **/
        function convertPagamentoQuantidadeParcela(items) {
            var converted = [{
                codigo: 1,
                nome: "01"
            }, {
                codigo: 2,
                nome: "02"
            }, {
                codigo: 3,
                nome: "03"
            }, {
                codigo: 4,
                nome: "04"
            }, {
                codigo: 5,
                nome: "05"
            }, {
                codigo: 6,
                nome: "06"
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#defaultCalcularParcela
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs default Calcular Parcela object
         *
         * @returns {Object} data object of 'Calcular Parcela' containing default values
         **/
        function defaultCalcularParcela() {
            var data = {
                forma: null,
                //melhor          : null,
                dataMelhorDataPrimeiraParcela: null,
                parcelas: null,
                isBoleto: false,
                isDemais: false,
                isADC: false,
                isCartao: false,
                boleto: [],
                demais: {},
                adc: {},
                cartao: {},
                quantidadeParcela: null,
                codigoFormaPagamento: null,
                nomeFormaPagamento: null
            };
            return data;
        }


        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertPagamentoBandeiraDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Pagamento Bandeira Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Pagamento Bandeira'
         **/
        function convertPagamentoBandeiraDropdown(items) {
            var converted = [{
                codigo: 1,
                nome: "Master Card (Stub Data)"
            }, {
                codigo: 2,
                nome: "Visa (Stub Data)"
            }, {
                codigo: 3,
                nome: "Amex (Stub Data)"
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertPagamentoMaisUmPagador
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Pagamento Mais Um Pagador Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Pagamento Mais Um Pagador'
         **/
        function convertPagamentoMaisUmPagador(items) {
            var converted = [{
                codigo: 1,
                nome: "Não"
            }, {
                codigo: 2,
                nome: "Pagadores diferentes em parcelas distintas"
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertPagamentoProfissaoDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Pagamento Profissao Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Pagamento Profissao'
         **/
        function convertPagamentoProfissaoDropdown(items) {
            var converted = [{
                codigo: 1,
                nome: "test 1"
            }, {
                codigo: 2,
                nome: "test 2"
            }, {
                codigo: 3,
                nome: "test 3"
            }];

            return converted;
        }
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertPagamentoTipoIdentificacaoDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Pagamento Tipo Identificacao Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Pagamento Tipo Identificacao'
         **/
        function convertPagamentoTipoIdentificacaoDropdown(items) {
            var converted = [{
                codigo: 1,
                nome: "test 1"
            }, {
                codigo: 2,
                nome: "test 2"
            }, {
                codigo: 3,
                nome: "test 3"
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertContatoPessoaExpostaDropDown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Pagamento Tipo Identificacao Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'ContatoPessoaExposta'
         **/
        function convertContatoPessoaExpostaDropDown(items) {
            var converted = [{
                codigo: 1,
                nome: "Sim"
            }, {
                codigo: 2,
                nome: "Nao"
            }, {
                codigo: 3,
                nome: "Relacionamento Proximo"
            }];

            return converted;
        }


        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertPagamentoGrauParentescoDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Pagamento Grau Parentesco Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Pagamento Grau Parentesco'
         **/
        function convertPagamentoGrauParentescoDropdown(items) {
            var converted = [{
                codigo: 1,
                nome: "test 1"
            }, {
                codigo: 2,
                nome: "test 2"
            }, {
                codigo: 3,
                nome: "test 3"
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertPagamentoTipoEmailDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Pagamento Tipo Email Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Pagamento Tipo Email'
         **/
        function convertPagamentoTipoEmailDropdown(items) {
            var converted = [{
                codigo: 1,
                nome: "test 1"
            }, {
                codigo: 2,
                nome: "test 2"
            }, {
                codigo: 3,
                nome: "test 3"
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertPagamentoTipoTelefoneDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Pagamento Tipo Telefone Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Pagamento Tipo Telefone'
         **/
        function convertPagamentoTipoTelefoneDropdown(items) {
            var converted = [{
                codigo: 1,
                nome: "test 1"
            }, {
                codigo: 2,
                nome: "test 2"
            }, {
                codigo: 3,
                nome: "test 3"
            }];

            return converted;
        }

        //--------------------------------------------END OF PAGAMENTO-------------------------------------------//

        //--------------------------------------------DADOS DO SEGURADO------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertDadosDoSeguro
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Dados Do Seguro Object
         *
         * @param {Object} items array of objects to be converted.
         * @returns {Object} converted object of 'Dados Do Seguro'
         **/
        function convertDadosDoSeguro(orcamento) {

            var dadosDoSeguro = new DadosDoSeguro();

            dadosDoSeguro.produtoCommercial = orcamento.codigoProdutoComercial; // Dropdown
            dadosDoSeguro.oferta = orcamento.ofertaId; // Dropdown
            dadosDoSeguro.parceiroDeNegocio = orcamento.codigoParceiroNegocio; // Dropdown
            dadosDoSeguro.tipoSeguro = orcamento.codigoTipoSeguro; // Dropdown
            dadosDoSeguro.tipoEndosso = orcamento.codigoTipoEndosso; // Dropdown
            dadosDoSeguro.origem = orcamento.codigoOrigemRenovacao;
            dadosDoSeguro.susepCorretor = orcamento.codigoCorretorPrincipal;
            dadosDoSeguro.nomeCorretor = null;
            dadosDoSeguro.alterarCalculo = orcamento.flagDataCalculoManual;
            dadosDoSeguro.dataDeCalculo = convertToDateString(orcamento.dataCalculo);
            dadosDoSeguro.dataInicial = convertToDateString(orcamento.dataInicioVigenciaSeguro);
            dadosDoSeguro.dataFinal = convertToDateString(orcamento.dataFimVigenciaSeguro);
            dadosDoSeguro.dataProtocolo = convertToDateString(orcamento.dataProtocolo);
            dadosDoSeguro.onus = orcamento.codigoOnus;
            dadosDoSeguro.dataValidade = convertToDateString(orcamento.dataValidade);
            dadosDoSeguro.canal = orcamento.codigoCanal; // Dropdown
            dadosDoSeguro.moeda = orcamento.codigoMoeda; // Dropdown
            dadosDoSeguro.tipoCalculo = orcamento.codigoTipoCalculo; // Dropdown
            dadosDoSeguro.codigoOperacao = orcamento.codigoOperacao; // Dropdown
            dadosDoSeguro.imprimirOrcamento = orcamento.flagImpressaoOperacao;
            dadosDoSeguro.flagEnvioEmailCorretor = null;
            dadosDoSeguro.desEnvFisSegViaDocumento = null;

            //SM 393
            dadosDoSeguro.flagVinculoSeguroAuto = null;
            dadosDoSeguro.flagVinculoSeguroOutroNegocio = null;
            dadosDoSeguro.quantidadeSeguroOutroNegocio = null;

            return dadosDoSeguro;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#DadosDoSeguro
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         *
         * DadosDoSeguro object.
         *
         **/
        function DadosDoSeguro() {

            var dadosDoSeguro = this;

            dadosDoSeguro.produtoCommercial = null;
            dadosDoSeguro.oferta = null;
            dadosDoSeguro.parceiroDeNegocio = null;
            dadosDoSeguro.tipoSeguro = null;
            dadosDoSeguro.tipoEndosso = null;
            dadosDoSeguro.origem = null;
            dadosDoSeguro.susepCorretor = null;
            dadosDoSeguro.nomeCorretor = null;
            dadosDoSeguro.alterarCalculo = null;
            dadosDoSeguro.dataDeCalculo = null;
            dadosDoSeguro.dataInicial = null;
            dadosDoSeguro.dataFinal = null;
            dadosDoSeguro.onus = null;
            dadosDoSeguro.dataValidade = null;
            dadosDoSeguro.dataProtocolo = null;
            dadosDoSeguro.canal = null;
            dadosDoSeguro.moeda = null;
            dadosDoSeguro.tipoCalculo = null;
            dadosDoSeguro.codigoOperacao = null;
            dadosDoSeguro.imprimirOrcamento = null;
            dadosDoSeguro.flagEnvioEmailCorretor = null;
            dadosDoSeguro.desEnvFisSegViaDocumento = null;

            //SM 393
            dadosDoSeguro.flagVinculoSeguroAuto = null;
            dadosDoSeguro.flagVinculoSeguroOutroNegocio = null;
            dadosDoSeguro.quantidadeSeguroOutroNegocio = null;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertToDateString
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         *
         * Converts Date Only from Date Time format.
         *
         * @param {Object} dateTime The object to be converted.
         * @returns {Object} date The constructed object.
         **/
        function convertToDateString(dateTime) {
            var dateString = '';
            if (angular.isDefined(dateTime) && dateTime !== null) {
                // Day
                var day = (dateTime.getDate() < 10) ? ('0' + dateTime.getDate()) : (dateTime.getDate());
                // Month
                var initMonth = dateTime.getMonth() + 1;
                var month = (initMonth < 10) ? ('0' + initMonth) : (initMonth);
                // Year
                var year = dateTime.getFullYear();
                dateString = day + '/' + month + '/' + year;
            }
            return dateString;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertProdutoCommercialDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Produto Commercial Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Produto Commercial'
         **/
        function convertProdutoCommercialDropdown(items) {
            var converted = [{
                codigo: 1,
                nome: "Test 1"
            }, {
                codigo: 2,
                nome: "Test 2"
            }, {
                codigo: 3,
                nome: "Test 3"
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertOfertaDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Oferta Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Oferta'
         **/
        function convertOfertaDropdown(items) {
            var converted = [{
                codigo: 1,
                nome: "Test 1"
            }, {
                codigo: 2,
                nome: "Test 2"
            }, {
                codigo: 3,
                nome: "Test 3"
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertParceiroNegocioDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Parceiro Negocio Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Parceiro Negocio'
         **/
        function convertParceiroNegocioDropdown(items) {
            var converted = [{
                codigo: 1,
                nome: "Test 1"
            }, {
                codigo: 2,
                nome: "Test 2"
            }, {
                codigo: 3,
                nome: "Test 3"
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertFlagEnvioEmailCorretorDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Parceiro Negocio Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Parceiro Negocio'
         **/
        function convertFlagEnvioEmailCorretorDropdown(items) {
            var converted = [{
                codigo: 'S',
                nome: 'Sim'
            }, {
                codigo: 'N',
                nome: 'Não'
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertFlagEnvioEmailCorretorImobiliariaDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Parceiro Negocio Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Parceiro Negocio'
         **/
        function convertFlagEnvioEmailCorretorImobiliariaDropdown(items) {
            var converted = [{
                codigo: 'N',
                nome: 'Segurado'
            },{
                codigo: 'S',
                nome: 'Corretor'
            }, {
                codigo: 'I',
                nome: 'Imobiliaria'
            }, {
                codigo: 'T',
                nome: 'Ambos'
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertOnusDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Onus Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Onus'
         **/
        function convertOnusDropdown(items) {
            var converted = [{
                codigo: 1,
                nome: 'Apenas IOF'
            }, {
                codigo: 2,
                nome: 'Isenção Total'
            }, {
                codigo: 3,
                nome: 'Apenas Adicional Frac.'
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertCodigoOperacaoDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Codigo Operacao Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Codigo Operacao'
         **/
        function convertCodigoOperacaoDropdown(items) {
            var converted = [];

            for (var i = 1; i < 21; i++) {
                var operacao = {};
                operacao.codigo = i;
                operacao.nome = "Código Operação " + i.toString();
                converted.push(operacao);
            }

            return converted;
        }
        //----------------------------------------END OF DADOS DO SEGURO---------------------------------------//

        //------------------------------------------DADOS DO SEGURADO--------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertDados
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Dados Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Dados'
         **/
        function convertDados(items) {
            var converted = {
                codigoTipoPessoa: 1,
                numeroCnpjCpf: 1234567,
                pessoaFisica: {
                    nomePessoaFisica: 'xx',
                    codigoEstadoCivil: 1, // Dominio
                    dataNascimiento: '10/10/1993',
                    nomePreferencial: 'exo',
                    codigoSexoPessoa: {
                        feminino: true,
                        masculino: false
                    },
                    tipoClassificacao: 'classificacao',
                    nomeProfissao: 'profissao'
                },
                pessoaJuridica: {
                    codigoTipoPessoa: 2,
                    nomePessoaJuridica: 'yy',
                    orgaoPublico: 'Orgao',
                    processoLicitacao: 'Licitacao',
                    numeroLicitacao: 123,
                    atividade: 'Atividade',
                    codigoTipoDocumentoPessoa: 'RG', // Dominio
                    numeroDocumento: 111,
                    dataEmissaoDocumento: '01/01/2015',
                    dataValidade: '01/02/2015',
                    nomeOrgaoExpedidor: 'sds',
                    codigoUnidadeFederacao: 1,
                    flagAtivo: {
                        sim: false,
                        nao: true
                    }
                },
                documentos: {
                    grid: [{
                        codigoDocumentoPessoa: 123,
                        codigoTipoDocumentoPessoa: 'RG', // Dominio
                        numeroDocumento: 111,
                        dataEmissaoDocumento: '01/01/2015',
                        dataValidade: '01/02/2015',
                        nomeOrgaoExpedidor: 'sds',
                        codigoUnidadeFederacao: 1,
                        flagAtivo: {
                            sim: false,
                            nao: true
                        }
                    }, {
                        codigoDocumentoPessoa: 123,
                        codigoTipoDocumentoPessoa: 'RG', // Dominio
                        numeroDocumento: 222,
                        dataEmissaoDocumento: '01/03/2015',
                        dataValidade: '01/04/2015',
                        nomeOrgaoExpedidor: 'sds2',
                        codigoUnidadeFederacao: 2,

                        flagAtivo: {
                            sim: true,
                            nao: false

                        }
                    }]
                },
                enderecos: {
                    logradouroBusca: 1,
                    grid: [{
                        textoEndereco: '740 Evergreen Terrace, Springfield',
                        codigoTipoEndereco: 1, // Dominio
                        flagPrincipal: 'Sim', // Sim or Nao
                        flagAtivo: {
                            sim: true,
                            nao: false
                        }
                    }, {
                        textoEndereco: '221 B Baker St, London, England',
                        codigoTipoEndereco: 2, // Dominio
                        flagPrincipal: 'Sim', // Sim or Nao
                        flagAtivo: {
                            sim: false,
                            nao: true
                        }
                    }, {
                        textoEndereco: '124 Conch Street, Bikini Bottom',
                        codigoTipoEndereco: 2, // Dominio
                        flagPrincipal: 'Sim', // Sim or Nao
                        flagAtivo: {
                            sim: true,
                            nao: false
                        }
                    }],
                    flagPossuiCossegurado: {
                        sim: true,
                        nao: false
                    },
                    codigoTipoPessoa: 1
                },
                contatos: {
                    pessoaFisica: {
                        grid: [{
                            nomeControlador: 'Dan Molenilla',
                            numeroCnpjCpf: '111.111.111-11'
                        }, {
                            nomeControlador: 'Emil Molenilla',
                            numeroCnpjCpf: '111.111.111-12'
                        }],
                        flagVinculoPessoaExpostaPoliticamente: false
                    },
                    cossegurado: {
                        codigoTipoPessoa: 1
                    },
                    grid: [{
                        codigoContatoPessoa: 2,
                        codigoTipoContato: 2, // Dominio
                        numeroDdi: 55,
                        numeroDdd: 81,
                        numeroContato: 123,
                        numeroRamal: 4444,
                        textoContato: '+55 (81) 0000-0000',
                        flagPrincipal: 'Sim', // Sim or Nao
                        flagAtivo: {
                            sim: true,
                            nao: false
                        }
                    }, {
                        codigoContatoPessoa: 1,
                        codigoTipoContato: 1, // Dominio
                        numeroDdi: 55,
                        numeroDdd: 81,
                        numeroContato: 123,
                        numeroRamal: 4444,
                        textoContato: '+55 (81) 00000-0000',
                        flagPrincipal: 'Sim', // Sim or Nao
                        flagAtivo: {
                            sim: false,
                            nao: true
                        }
                    }, {
                        codigoContatoPessoa: 4,
                        codigoTipoContato: 4, // Dominio
                        numeroDdi: 55,
                        numeroDdd: 81,
                        numeroContato: 123,
                        numeroRamal: 4444,
                        textoContato: 'facebook.com/dsmolenilla',
                        flagPrincipal: 'Sim', // Sim or Nao
                        flagAtivo: {
                            sim: true,
                            nao: false
                        }
                    }, {
                        codigoContatoPessoa: 5,
                        codigoTipoContato: 5, // Dominio
                        numeroDdi: 55,
                        numeroDdd: 81,
                        numeroContato: 123,
                        numeroRamal: 4444,
                        textoContato: 'twitter.com/dandankun',
                        flagPrincipal: 'Sim', // Sim or Nao
                        flagAtivo: {
                            sim: true,
                            nao: false
                        }
                    }, {
                        codigoContatoPessoa: 3,
                        codigoTipoContato: 3, // Dominio
                        numeroDdi: 55,
                        numeroDdd: 81,
                        numeroContato: 123,
                        numeroRamal: 4444,
                        textoContato: 'danmole@yahoo.com',
                        flagPrincipal: 'Sim', // Sim or Nao
                        flagAtivo: {
                            sim: false,
                            nao: true
                        }
                    }]
                }
            };
            return converted;
        }
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#defaultDadosSegurado
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs default Dados Segurado Object
         *
         * @returns {Array.<Object>} data object of 'Dados Segurado' with default values
         **/
        function defaultDadosSegurado() {
            var data = {
                numeroCnpjCpf: null,
                pessoaFisica: {
                    nomePessoaFisica: null,
                    codigoEstadoCivil: null,
                    textoNacionalidade: null,
                    codigoPais: null,
                    codigoFaixaRenda: null,
                    flagPessoaExposta: null,
                    politicaCpf: null,
                    politicaNome: null,
                    grauRelacionamento: null,
                    classeProfissionalLiberal: null,
                    tipoDocumentoClasse: null,
                    numeroDocumento: null,
                    orgaoExpedidor: null,
                    dataExpedicao: null,
                    flagTituloCapitalizacao: null,
                    numeroSorte: null
                },
                pessoaJuridica: {
                    razaoSocial: null,
                    numeroFaixaPatrimonioLiquido: null,
                    numeroFaixaReceitaOperacionalAnual: null,
                    dataRegistroAbertura: null,
                    textoNaturezaJuridica: null,
                    fieldFlagOrgaoPublico: {
                        sim: true,
                        nao: false
                    }
                },
                documentos: {
                    dataEmissaoDocumento: null,
                    dataValidade: null,
                    codigoDocumentoPessoa: null,
                    codigoTipoDocumentoPessoa: null,
                    numeroDocumento: null,
                    nomeOrgaoExpedidor: null,
                    codigoUnidadeFederacao: null,
                    flagAtivo: null,
                    grid: {
                        flagAtivo: {
                            sim: true,
                            nao: false
                        }
                    }
                },
                enderecos: {
                    codigoCEP: null,
                    nomeLogradouro: null,
                    flagAtivo: null,
                    flagPrincipal: null,
                    codigoTipoEndereco: null,
                    codigoTipoLogradouro: null,
                    logradouro: null,
                    flagSemNumero: 'N',
                    numero: null,
                    complemento: null,
                    bairro: null,
                    cidade: null,
                    codigoUnidadeFederacao: null,
                    codigoPais: null,
                    latitude: null,
                    longitude: null,
                    pontoReferencia: null
                },
                contatos: {
                    codigoTipoContato: null,
                    codigoTipoPessoa: null,
                    textoContato: null,
                    textoDDI: null,
                    textoDDD: null,
                    numero: null,
                    flagContatoPrincipal: null,
                    flagAtivo: null,
                    flagPossuiControlador: 1,
                    nomePessoa: null,
                    codigoTipoVinculo: null
                },
                cossegurado: {
                    flagPossuiCossegurado: null,
                    codigoTipoPessoa: null,
                    numeroCnpjCpf: null,
                    nomeInterveniente: null,
                    pessoaExpostaPoliticamente: {
                        flagPessoaExposta: null,
                        numeroCnpjCpfPessoaExposto: null,
                        nomePessoaExposto: null,
                        codigoTipoVinculo: null
                    }
                },
                controladores: {
                    flagPossuiControlador: null,
                    codigoTipoPessoa: null,
                    numeroCnpjCpf: null,
                    nomeInterveniente: null,
                    codigoTipoInterveniente: null,
                    razaoSocial: null,
                    codigoMotivoAusenciaCnpjCpf: null,
                    pessoaExpostaPoliticamente: {
                        flagVinculoPessoaExpostaPoliticamente: null,
                        numeroCnpjCpfPessoaExposto: null,
                        nomePessoaExposto: null,
                        codigoTipoVinculo: null
                    }
                }
            };
            return data;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertPessoaExposta
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Pessoa Exposta Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Pessoa Exposta'
         **/
        function convertPessoaExposta(items) {
            var converted = [{
                codigo: 1,
                nome: "Sim"
            }, {
                codigo: 2,
                nome: "Não"
            }, {
                codigo: 3,
                nome: "Relacionamento Próximo"
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertClasseProfissional
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Classe Profissional Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Classe Profissional'
         **/
        function convertClasseProfissional(items) {
            var converted = [{
                codigo: 1,
                nome: "Test1"
            }, {
                codigo: 2,
                nome: "Test2"
            }, {
                codigo: 3,
                nome: "Test3"
            }, {
                codigo: 4,
                nome: "Test4"
            }];

            return converted;
        }
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertGrauRelacionamento
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Grau Relacionamento Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Grau Relacionamento'
         **/
        function convertGrauRelacionamento(items) {
            var converted = [{
                codigo: 1,
                nome: "01"
            }, {
                codigo: 2,
                nome: "02"
            }, {
                codigo: 3,
                nome: "03"
            }, {
                codigo: 4,
                nome: "04"
            }];

            return converted;
        }
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertClasseTipoDoc
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Classe Tipo Doc Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Classe Tipo Doc'
         **/
        function convertClasseTipoDoc(items) {
            var converted = [{
                codigo: 1,
                nome: "Doc Classe 1"
            }, {
                codigo: 2,
                nome: "Doc Classe 2"
            }, {
                codigo: 3,
                nome: "Doc Classe 3"
            }, {
                codigo: 4,
                nome: "Doc Classe 4"
            }];

            return converted;
        }
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertEnderecoTipoLogradouro
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Endereco Tipo Logradouro Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Endereco Tipo Logradouro'
         **/
        function convertEnderecoTipoLogradouro(items) {
            var converted = [{
                codigo: 1,
                nome: "Tipo 1"
            }, {
                codigo: 2,
                nome: "Tipo 2"
            }, {
                codigo: 3,
                nome: "Tipo 3"
            }, {
                codigo: 4,
                nome: "Tipo 4"
            }];

            return converted;
        }
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertTipoContato
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Tipo Contato Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Tipo Contato'
         **/
        function convertTipoContato(items) {
            var converted = [{
                codigo: 1,
                nome: "Telefone fixo"
            }, {
                codigo: 2,
                nome: "Telefone Móvel"
            }, {
                codigo: 3,
                nome: "Email"
            }, {
                codigo: 4,
                nome: "Facebook"
            }, {
                codigo: 5,
                nome: "Twitter"
            }, {
                codigo: 6,
                nome: "Linkedin"
            }];

            return converted;
        }
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertPossuiControlador
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Possui Controlador Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Possui Controlador'
         **/
        function convertPossuiControlador(items) {
            var converted = [{
                codigo: 1,
                nome: "Há Administradores, controladores e procuradores"
            }, {
                codigo: 2,
                nome: "Não há administradores, controladores e procuradores"
            }, {
                codigo: 3,
                nome: "Não desejo informar os administradores, controladores e procuradores"
            }];

            return converted;
        }
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertTipoVinculo
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Tipo Vinculo Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Tipo Vinculo'
         **/
        function convertTipoVinculo(items) {
            var converted = [{
                codigo: 1,
                nome: "Administrador"
            }, {
                codigo: 2,
                nome: "Controlador"
            }, {
                codigo: 3,
                nome: "Procurador"
            }];

            return converted;
        }
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertDominioList
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Dominio Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Dominio'
         **/
        function convertDominioList(items) {
            var results = [];

            angular.forEach(items, function(item) {
                var resultItem = {};

                resultItem.codigoValorDominio = item.codigoValorDominio;
                resultItem.nomeDominio = item.nomeDominio;

                results.push(resultItem);
            });

            return results;
        }
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertEnderecoList
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Endereco Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Endereco'
         **/
        function convertEnderecoList(items, enderecos) {
            var converted = [];
            var holder = [];
            var nomeTipoEndereco = "";

            angular.forEach(items.enderecos.grid, function(item, i) {
                angular.forEach(enderecos, function(endereco, i) {
                    if (endereco.codigoValorDominio === item.codigoTipoEndereco) {
                        nomeTipoEndereco = endereco.nomeDominio;
                    }
                });

                holder = {
                    endereco: {
                        codigoEndereco: item.codigoTipoEndereco,
                        nomeTipoEndereco: nomeTipoEndereco
                    },
                    textoEndereco: item.textoEndereco,
                    codigoTipoEndereco: item.codigoTipoEndereco, // Dominio
                    flagPrincipal: item.flagPrincipal, // Sim or Nao
                    flagAtivo: item.flagAtivo
                };

                converted.push(holder);
            });

            return converted;
        }
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertDominioList
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Dominio Object
         *
         * @param {Array.<Object>} items array of objects to be convertedo, // Dominio
        			flagPrincipal: item.flagPrincipal, // Sim or Nao
        			flagAtivo: item.flagAtivo
        		};

        		converted.push(holder);
        	});

        	return converted;
        }
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertTipoContatoList
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Tipo Contato Object
         *
         * @param {Array.<Object>} contatos array of objects to get names of contatos.
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Tipo Contato'
         **/
        function convertTipoContatoList(items, contatos) {
            var converted = [];
            var holder = [];
            var nomeTipoContato = "";

            angular.forEach(items.contatos.grid, function(item, i) {
                angular.forEach(contatos, function(contato, i) {
                    if (contato.codigo === item.codigoTipoContato) {
                        nomeTipoContato = contato.nome;
                    }
                });

                holder = {
                    contato: {
                        codigoTipoContato: item.codigoTipoContato,
                        nomeTipoContato: nomeTipoContato
                    },
                    textoContato: item.textoContato,
                    flagPrincipal: item.flagPrincipal, // Sim or Nao
                    flagAtivo: item.flagAtivo
                };

                converted.push(holder);
            });

            return converted;
        }

        //--------------------------------------END OF DADOS DO SEGURADO------------------------------------------//

        //-------------------------------------------COSSEGURADO--------------------------------------------------//

        function convertIntervenienteList(item) {
            var converted = {};

            if (item) {
                converted.numeroProposta = item.numeroProposta;
                converted.numeroVersaoProposta = item.numeroVersaoProposta;
                converted.cossegurados = constructCosseguradoList(item.intervenientes.interveniente);
                converted.controladores = constructControladorList(item.intervenientes.interveniente);
            }

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#constructControladorList
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Controlador Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Cossegurado'
         **/
        function constructControladorList(items) {
            var converted = [];

            angular.forEach(items, function(item) {
                var controlador = {};
                if (item.codigoTipoInterveniente === 3 || item.codigoTipoInterveniente === 4 || item.codigoTipoInterveniente === 5) {
                    if (item.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA) {
                        if (angular.isDefined(item.numeroCnpjCpf)) {
                            controlador.numeroCnpjCpf = cpfFormat(pad(item.numeroCnpjCpf.toString(), 11));
                        }
                    } else {
                        if (angular.isDefined(item.numeroCnpjCpf)) {
                            controlador.numeroCnpjCpf = cnpjFormat(pad(item.numeroCnpjCpf.toString(), 14));
                        }
                    }
                    controlador.codigoInterveniente = item.codigoInterveniente;
                    controlador.codigoTipoInterveniente = item.codigoTipoInterveniente;
                    controlador.codigoTipoPessoa = item.codigoTipoPessoa;
                    controlador.nomeInterveniente = item.nomeInterveniente;
                    controlador.codigoTipoExposicaoPessoa = item.codigoTipoExposicaoPessoa;
                    controlador.codigoMotivoAusenciaCnpjCpf = item.codigoMotivoAusenciaCnpjCpf;
                    controlador.percentualParticipacao = item.percentualParticipacao;
                    controlador.flagAtivo = item.flagAtivo;
                    controlador.exposicoes = {};
                    if (item.exposicoes && item.exposicoes.esposicao &&
                        item.exposicoes.esposicao.length > 0) {
                        controlador.exposicoes.esposicao = convertExposicoes(item.exposicoes.exposicao);
                    }
                    converted.push(controlador);
                }
            });

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#constructCosseguradoList
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Controlador Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Cossegurado'
         **/
        function constructCosseguradoList(items) {
            var converted = [];


            angular.forEach(items, function(item) {
                var cossegurado = {};
                if (item.codigoTipoInterveniente === 1) {
                    if (item.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA) {
                        cossegurado.numeroCnpjCpf = cpfFormat(pad(item.numeroCnpjCpf.toString(), 11));
                    } else {
                        cossegurado.numeroCnpjCpf = cnpjFormat(pad(item.numeroCnpjCpf.toString(), 14));
                    }
                    cossegurado.codigoInterveniente = item.codigoInterveniente;
                    cossegurado.codigoTipoAtualizacao = item.codigoTipoAtualizacao;
                    cossegurado.codigoTipoInterveniente = item.codigoTipoInterveniente;
                    cossegurado.codigoTipoPessoa = item.codigoTipoPessoa;
                    cossegurado.nomeInterveniente = item.nomeInterveniente;
                    cossegurado.codigoTipoExposicaoPessoa = item.codigoTipoExposicaoPessoa;
                    cossegurado.codigoMotivoAusenciaCnpjCpf = item.codigoMotivoAusenciaCnpjCpf;
                    cossegurado.percentualParticipacao = item.percentualParticipacao;
                    cossegurado.flagAtivo = item.flagAtivo;
                    cossegurado.exposicoes = {};
                    if (item.exposicoes && item.exposicoes.exposicao &&
                        item.exposicoes.exposicao.length > 0) {
                        cossegurado.exposicoes.exposicao = convertExposicoes(item.exposicoes.exposicao);
                    }
                    converted.push(cossegurado);
                }
            });

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#cnpjFormat
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         *
         * Format the value to cnpj format.
         *
         * @param {String} value that needs to be formatted.
         * @returns {String} formatted string
         **/
        function cnpjFormat(num) {
            String.prototype.splice = function(idx, rem, s) {
                return (this.slice(0, idx) + s + this.slice(idx + Math.abs(rem)));
            };

            num = num.splice(2, 0, '.');
            num = num.splice(6, 0, '.');
            num = num.splice(10, 0, '/');
            num = num.splice(15, 0, '-');

            return num;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertExposicoes
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Exposicoes Object
         *
         * @param {Object} items object to be converted.
         * @returns {Array.<Object>} converted object of 'Exposicoes'
         **/
        function convertExposicoes(items) {
            var converted = [];
            angular.forEach(items, function(item) {
                var exposicao = {};
                exposicao.codigoExposicaoInterveniente = item.codigoExposicaoInterveniente;
                exposicao.codigoTipoVinculo = item.codigoTipoVinculo;
                exposicao.codigoPessoaExposto = item.codigoPessoaExposto;
                exposicao.codigoTipoPessoaExposto = item.codigoTipoPessoaExposto;
                exposicao.numeroCnpjCpf = item.numeroCnpjCpfPessoaExposto;
                exposicao.nomePessoaExposto = item.nomePessoaExposto;
                exposicao.flagAtivo = item.flagAtivo;
                converted.push(exposicao);
            });
            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertModInterveniente
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * convert interveniente object from modal
         *
         * @returns {Array.<Object>} data object of 'Dados Segurado' with default values
         **/
        function convertModInterveniente(item) {

            var converted = {};
            if (item && item.intervenientes &&
                item.intervenientes.interveniente &&
                item.intervenientes.interveniente.length > 0) {

                var interveniente = item.intervenientes.interveniente[0];
                var exposicao = {};

                if (interveniente.exposicoes &&
                    interveniente.exposicoes.exposicao &&
                    interveniente.exposicoes.exposicao.length > 0) {
                    exposicao = interveniente.exposicoes.exposicao[0];
                }

                converted.numeroProposta = item.numeroProposta;
                converted.numeroVersaoProposta = item.numeroVersaoProposta;

                converted.codigoMotivoAusenciaCnpjCpf = interveniente.codigoMotivoAusenciaCnpjCpf;
                converted.codigoInterveniente = interveniente.codigoInterveniente;
                converted.codigoTipoPessoa = interveniente.codigoTipoPessoa;
                converted.codigoTipoInterveniente = interveniente.codigoTipoInterveniente;
                converted.nomeInterveniente = interveniente.nomeInterveniente;
                converted.codigoTipoExposicaoPessoa = interveniente.codigoTipoExposicaoPessoa;

                if (interveniente.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA) {
                    if (interveniente.numeroCnpjCpf) {
                        converted.numeroCnpjCpf = cpfFormat(pad(interveniente.numeroCnpjCpf.toString(), 11));
                    }
                } else {
                    if (interveniente.numeroCnpjCpf) {
                        converted.numeroCnpjCpf = cnpjFormat(pad(interveniente.numeroCnpjCpf.toString(), 14));
                    }
                }

                var flagPessoaExposta = 'N';

                var isArray = false;

                if (interveniente.exposicoes &&
                    interveniente.exposicoes.exposicao) {
                    isArray = angular.isArray(interveniente.exposicoes.exposicao);
                }

                var cpfHolder = null;

                if (!isNullEmptyOrUndefined(interveniente.numeroCnpjCpf)) {
                    cpfHolder = cpfFormat(pad(interveniente.numeroCnpjCpf.toString(), 11));
                }

                if (isArray) {
                    if (interveniente.exposicoes.exposicao.length > 0 && exposicao) {
                        converted.pessoaExpostaPoliticamente = {
                            codigoExposicaoInterveniente: exposicao.codigoExposicaoInterveniente,
                            flagAtivo: exposicao.flagAtivo,
                            codigoTipoPessoaExposto: exposicao.codigoTipoPessoaExposto,
                            codigoPessoaExposto: exposicao.codigoPessoaExposto,
                            numeroCnpjCpfPessoaExposto: cpfFormat(pad(exposicao.numeroCnpjCpfPessoaExposto.toString(), 11)),
                            nomePessoaExposto: exposicao.nomePessoaExposto,
                            codigoTipoVinculo: exposicao.codigoTipoVinculo
                        };
                        flagPessoaExposta = 'S';
                    } else {
                        converted.pessoaExpostaPoliticamente = defaultPessoaExpostaPoliticamente();
                    }
                } else {
                    converted.pessoaExpostaPoliticamente = defaultPessoaExpostaPoliticamente();
                }

                if (!converted.pessoaExpostaPoliticamente.codigoTipoPessoaExposto &&
                    interveniente.codigoTipoExposicaoPessoa == 1) {
                    flagPessoaExposta = 'S';
                    converted.pessoaExpostaPoliticamente = {
                        codigoExposicaoInterveniente: null,
                        flagAtivo: 'S',
                        codigoTipoPessoaExposto: null,
                        codigoPessoaExposto: null,
                        numeroCnpjCpfPessoaExposto: null,
                        nomePessoaExposto: null,
                        codigoTipoVinculo: null,
                        flagPessoaExposta: 'S'
                    };
                }

                converted.flagPessoaExposta = flagPessoaExposta;
            }
            return converted;
        }

        function defaultPessoaExpostaPoliticamente() {
            var pessoaExpostaPoliticamente = {};
            pessoaExpostaPoliticamente = {
                codigoExposicaoInterveniente: null,
                flagAtivo: 'N',
                codigoTipoPessoaExposto: null,
                codigoPessoaExposto: null,
                numeroCnpjCpfPessoaExposto: null,
                nomePessoaExposto: null,
                codigoTipoVinculo: null,
                flagPessoaExposta: 'N'
            };
            return pessoaExpostaPoliticamente;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertBackCossegurado
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * convert documento emissao object
         *
         * @returns {Array.<Object>} data object of 'Dados Segurado' with default values
         **/
        function convertBackIntervenienteVersaoProposta(codigoTipoInterveniente, numeroProposta, numeroVersaoProposta, item, fromModal, codigoEmpresa) {
            var converted = {
                numeroProposta: numeroProposta,
                numeroVersaoProposta: numeroVersaoProposta,
                codigoEmpresa: codigoEmpresa,
                documentoEmissao: {
                    numeroProposta: numeroProposta,
                    numeroVersaoProposta: numeroVersaoProposta,
                    intervenientes: convertIntervenientes(item, codigoTipoInterveniente, fromModal)
                }
            };

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertIntervenientes
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * convert intervenientes object
         *
         * @returns {Array.<Object>} data object of 'Dados Segurado' with default values
         **/
        function convertIntervenientes(item, codigoTipoInterveniente, fromModal) {
            var items = {
                interveniente: []
            };
            var converted = {};

            if (item.codigoInterveniente !== null && item.codigoInterveniente !== undefined) {
                converted.codigoInterveniente = item.codigoInterveniente;
            } else {
                converted.codigoInterveniente = null;
            }
            converted.codigoTipoInterveniente = codigoTipoInterveniente;
            converted.dadosPessoaInterveniente = convertDadosPessoaInterveniente(item);
            converted.codigoTipoPessoa = item.codigoTipoPessoa;
            converted.numeroCnpjCpf = null;

            if (item.numeroCnpjCpf) {
                converted.numeroCnpjCpf = OrcamentoUtilityFactory.convertBackCpfCnpj(item.numeroCnpjCpf);
            }

            converted.nomeInterveniente = item.nomeInterveniente;
            converted.flagAtivo = "S";

            var flagVinculoPessoaExpostaPoliticamente = item.pessoaExpostaPoliticamente.flagVinculoPessoaExpostaPoliticamente;

            if (flagVinculoPessoaExpostaPoliticamente !== null &&
                flagVinculoPessoaExpostaPoliticamente !== undefined) {
                converted.codigoTipoExposicaoPessoa = flagVinculoPessoaExpostaPoliticamente;
            } else {
                converted.codigoTipoExposicaoPessoa = null;
            }
            if (item.codigoMotivoAusenciaCnpjCpf !== null && item.codigoMotivoAusenciaCnpjCpf !== undefined) {
                converted.codigoMotivoAusenciaCnpjCpf = item.codigoMotivoAusenciaCnpjCpf;
            } else {
                converted.codigoMotivoAusenciaCnpjCpf = null;
            }
            converted.percentualParticipacao = null;
            converted.exposicoes = {};

            if (fromModal) {
                if (item.codigoTipoPessoa === 1 && item.flagPessoaExposta === 'S') {
                    converted.exposicoes = convertBackExposicaoIntervenienteVersaoProposta(item);
                } else if (item.codigoTipoPessoa === 1 && item.flagPessoaExposta === 'N') {
                    converted.exposicoes = {};
                }
            } else {
                if (item.codigoTipoPessoa === 1 && flagVinculoPessoaExpostaPoliticamente === 3) {
                    converted.exposicoes = convertBackExposicaoIntervenienteVersaoProposta(item);
                } else if (item.codigoTipoPessoa === 1 && item.pessoaExpostaPoliticamente.flagVinculoPessoaExpostaPoliticamente !== 3) {
                    converted.exposicoes = {};
                }
            }

            items.interveniente.push(converted);

            return items;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertBackCosseguradoExposicao
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * convert cossegurado pessoa exposta politicamente
         *
         * @returns {Array.<Object>} data object of 'Dados Segurado' with default values
         **/
        function convertBackExposicaoIntervenienteVersaoProposta(exposicao) {
            var exposicoes = {
                exposicao: []
            };
            var converted = {};
            var item = exposicao.pessoaExpostaPoliticamente;

            if (item.codigoExposicaoInterveniente !== null && item.codigoExposicaoInterveniente !== undefined) {
                converted.codigoExposicaoInterveniente = item.codigoExposicaoInterveniente;
            } else {
                converted.codigoExposicaoInterveniente = null;
            }

            if (item.codigoPessoaExposto !== null && item.codigoPessoaExposto !== undefined) {
                converted.codigoPessoaExposto = exposicao.codigoPessoaExposto;
            } else {
                converted.codigoPessoaExposto = null;
            }
            converted.codigoTipoPessoaExposto = exposicao.codigoTipoPessoa;
            converted.numeroCnpjCpfPessoaExposto = null;
            if (null !== item.numeroCnpjCpfPessoaExposto && undefined !== item.numeroCnpjCpfPessoaExposto && '' !== item.numeroCnpjCpfPessoaExposto) {
                converted.numeroCnpjCpfPessoaExposto = OrcamentoUtilityFactory.convertBackCpfCnpj(item.numeroCnpjCpfPessoaExposto);
            }

            converted.nomePessoaExposto = item.nomePessoaExposto;

            if (item.flagAtivo !== null && item.flagAtivo !== undefined) {
                converted.flagAtivo = item.flagAtivo;
            } else {
                converted.flagAtivo = "S";
            }
            if (item.codigoTipoVinculo !== null && item.codigoTipoVinculo !== undefined) {
                converted.codigoTipoVinculo = item.codigoTipoVinculo;
            } else {
                converted.codigoTipoVinculo = null;
            }
            exposicoes.exposicao.push(converted);

            return exposicoes;
        }

        function convertDadosPessoaInterveniente(item) {
            var converted = {};
            if (item.codigoPessoa !== null && item.codigoPessoa !== undefined) {
                converted.codigoPessoa = item.codigoPessoa;
            } else {
                converted.codigoPessoa = 1;
            }
            return converted;
        }

        function convertTipoInterveniente(items) {

            var tipoIntervenientes = [];

            angular.forEach(items, function(item) {
                var converted = {};
                if (item.codigoValorDominio === 3 || item.codigoValorDominio === 4 || item.codigoValorDominio === 5) {
                    converted.codigo = item.codigoValorDominio;
                    converted.nome = item.nomeDominio;
                    tipoIntervenientes.push(converted);
                }
            });

            return tipoIntervenientes;
        }

        //-------------------------------------------END COSSEGURADO---------------------------------------------//

        //-------------------------------------------START BENEFICIARIO-------------------------------------------------//
        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#defaultBeneficiario
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs default Beneficiario Object
         *
         * @returns {Object} converted object of 'Beneficiarios' with default object
         **/
        function defaultBeneficiario(numeroProposta, numeroVersaoProposta) {
            var data = {
                flagBeneficiario: null,
                nomeBeneficiario: null,
                codigoTipoPessoa: null,
                codigoPessoa: null,
                objetoSegurado: null,
                codigoTipoBem: null,
                numeroItemVersaoOrcamento: null,
                quantidadeBens: parseFloat(0),
                valorTotalBens: parseFloat(0),
                nomeDoBem: null,
                valorDoBem: null,
                valorTipoBem: null,
                numeroCnpjCpf: "",
                codigoBeneficiario: null,
                /*coberturas : [],*/
                /*beneficiarios : [],*/
                tipoBemDropdown: convertTipoBemDropdown(),
                objetoSeguradoDropdown: [],
                codigoListaIten: null,
                componentes: [],
                isEditMode: false
            };
            return data;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#initializeObjetoSeguradoDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Objeto Segurado Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Objeto Segurado'
         **/
        function initializeObjetoSeguradoDropdown(items) {
            var objetoSeguradoDropdown = [];

            angular.forEach(items, function(itemOrcamento) {
                var objetoSegurado = {
                    numeroItemVersaoOrcamento: itemOrcamento.numeroItemVersaoOrcamento,
                    codigoObjetoRisco: itemOrcamento.codigoObjetoRisco,
                    nomeResumidoObjetoRisco: itemOrcamento.textoDescricaoObjetoRisco
                };
                objetoSeguradoDropdown.push(objetoSegurado);
            });

            return objetoSeguradoDropdown;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertBeneficiario
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * converts Beneficiario Object
         *
         * @param {Object} beneficiario to be converted.
         * @param {Integer} codigoBeneficiario parameter.
         * @param {Array.<Object>} tipoBemList array of tipoBem items.
         * @param {Object} pessoa Pessoa seguro object to be converted.
         * @return {Object} beneficiario object that was converted.
         **/
        function convertBeneficiario(beneficiario, codigoBeneficiario, tipoBemList, pessoa) {
            var data = {
                flagBeneficiario: 'S',
                numeroProposta: beneficiario.numeroProposta,
                numeroVersaoProposta: beneficiario.numeroVersaoProposta,
                numeroItemVersaoProposta: beneficiario.numeroItemVersaoProposta,
                numeroOrcamento: beneficiario.numeroOrcamento,
                numeroVersaoOrcamento: beneficiario.numeroVersaoOrcamento,
                numeroItemVersaoOrcamento: beneficiario.numeroItemVersaoOrcamento,
                codigoTipoBem: null,
                quantidadeBens: 0,
                valorTotalBens: 0,
                nomeDoBem: null,
                valorDoBem: null,
                valorTipoBem: null,
                numeroCnpjCpf: "",
                codigoBeneficiario: null,
                codigoListaIten: null,
                coberturas: [],
                componentes: []
            };

            // Construct Cobertura
            angular.forEach(beneficiario.coberturasItem.listaCoberturasItem.coberturaItemDocumento, function(cobertura) {
                var includeCobertura = {
                    codigoCobertura: cobertura.codigoCobertura,
                    beneficiarios: []
                };
                angular.forEach(cobertura.beneficiarios.beneficiario, function(beneficiario) {
                    if (codigoBeneficiario === beneficiario.codigoBeneficiario) {

                        var includeBeneficiario = {
                            codigoBeneficiario: beneficiario.codigoBeneficiario,
                            dadosPessoa: {
                                codigoPessoa: beneficiario.dadosPessoa.codigoPessoa,
                                nomePessoa: pessoa.nomePessoa,
                                codigoTipoPessoa: pessoa.codigoTipoPessoa,
                                numeroCnpjCpf: pessoa.numeroCnpjCpf
                            },
                            codigoListaItem: beneficiario.codigoListaItem,
                            codigoTipoBem: beneficiario.codigoTipoBem,
                            valorTipoBem: beneficiario.valorTipoBem
                        };

                        switch (includeBeneficiario.codigoTipoBem) {
                            case Constants.CODIGO_TIPO_BEM.BENS_ESPECIFICOS:
                                data.valorTipoBem = OrcamentoUtilityFactory.convertDecimal(includeBeneficiario.valorTipoBem);
                                break;
                            case Constants.CODIGO_TIPO_BEM.CONTEUDO:
                                data.valorTipoBem = OrcamentoUtilityFactory.convertDecimal(includeBeneficiario.valorTipoBem);
                                break;
                            case Constants.CODIGO_TIPO_BEM.EDIFICIO:
                                data.valorTipoBem = OrcamentoUtilityFactory.convertDecimal(includeBeneficiario.valorTipoBem);
                                break;
                            default:
                                break;
                        }

                        var tipoBem = $filter('filter')(tipoBemList, {
                            codigo: includeBeneficiario.codigoTipoBem
                        }, true)[0];
                        if (angular.isObject(tipoBem)) {
                            includeBeneficiario.nomeTipoBem = tipoBem.nome;
                        }

                        data.nomeBeneficiario = includeBeneficiario.dadosPessoa.nomePessoa;
                        data.codigoTipoPessoa = includeBeneficiario.dadosPessoa.codigoTipoPessoa;
                        data.codigoTipoBem = includeBeneficiario.codigoTipoBem;
                        data.codigoPessoa = includeBeneficiario.dadosPessoa.codigoPessoa;

                        if (includeBeneficiario.dadosPessoa.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA) {
                            data.isFisicaBeneficiario = true;
                            data.numeroCnpjCpf = OrcamentoUtilityFactory.convertCpf(pad(includeBeneficiario.dadosPessoa.numeroCnpjCpf, 11));
                        } else {
                            data.isFisicaBeneficiario = false;
                            data.numeroCnpjCpf = OrcamentoUtilityFactory.convertCnpj(pad(includeBeneficiario.dadosPessoa.numeroCnpjCpf, 14));
                        }

                        includeCobertura.beneficiarios.push(includeBeneficiario);
                        data.codigoBeneficiario = beneficiario.codigoBeneficiario;
                    }

                });
                data.coberturas.push(includeCobertura);
            });

            // Construct ListIten when codigoTipoBem === 1
            var valorTotalBens = 0;
            var quantidadeBens = 0;
            if (angular.isDefined(beneficiario.listaItens) && beneficiario.listaItens !== null) {
                data.codigoListaItem = beneficiario.listaItens.codigoListaItem;
                data.nomeListaItem = beneficiario.listaItens.nomeListaItem;

                if (angular.isDefined(beneficiario.listaItens.ComponentesListaItem) && 
                    angular.isDefined(beneficiario.listaItens.ComponentesListaItem.componentesListaItem)) {
                    angular.forEach(beneficiario.listaItens.ComponentesListaItem.componentesListaItem, function(componente) {
                        var componenteItemObj = {
                            codigoListaIten: componente.codigoComponenteListaItem,
                            nomeDoBem: componente.nomeComponenteListaItem,
                            quantidadeBens: componente.quantidadeComponenteListaItem,
                            valorDoBem: componente.valorComponenteListaItem
                        };
                        valorTotalBens = parseFloat(valorTotalBens) + parseFloat(componenteItemObj.valorDoBem);

                        data.componentes.push(componenteItemObj);
                    });
                }
            }
            data.valorTotalBens = OrcamentoUtilityFactory.convertDecimal(valorTotalBens);
            data.quantidadeBens = data.componentes.length;

            return data;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#constructBeneficiarioList
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Beneficiario Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @param {Array.<Object>} tipoBemList array of tipoBem items.
         * @param {Array.<Object>} tipoPessoaList array of tipoPessoa items.
         * @returns {Array.<Object>} converted object of 'Beneficiario'
         **/
        function constructBeneficiarioList(itemPropostas, tipoBemList) {
            var beneficiarios = [];
            var beneficiarioIds = [];
            angular.forEach(itemPropostas, function(itemProposta) {
                angular.forEach(itemProposta.coberturasItem.listaCoberturasItem.coberturaItemDocumento, function(listaCoberturaItem) {
                    if (listaCoberturaItem.beneficiarios) {
                        if (listaCoberturaItem.beneficiarios.beneficiario) {
                            angular.forEach(listaCoberturaItem.beneficiarios.beneficiario, function(beneficiario) {
                                    var beneficiarioId = beneficiario.codigoBeneficiario;
                                    var exist = $filter('filter')(beneficiarioIds, {
                                        $: beneficiarioId
                                    }, true)[0];
                                    if (angular.isUndefined(exist)) {
                                        var converted = {
                                            numeroItemVersaoProposta: itemProposta.numeroItemVersaoProposta,
                                            codigoBeneficiario: beneficiarioId,
                                            nomePessoa: '',
                                            codigoPessoa: beneficiario.dadosPessoa.codigoPessoa,
                                            codigoTipoPessoa: null,
                                            numeroCnpjCpf: null,
                                            codigoListaItem: beneficiario.codigoListaITem,
                                            codigoTipoBem: beneficiario.codigoTipoBem,
                                            valorTipoBem: OrcamentoUtilityFactory.convertDecimal(beneficiario.valorTipoBem)
                                        };

                                        if (angular.isArray(tipoBemList) && tipoBemList.length > 0) {
                                            var tipoBem = $filter('filter')(tipoBemList, {
                                                codigo: converted.codigoTipoBem
                                            }, true)[0];
                                            if (angular.isObject(tipoBem)) {
                                                converted.nomeTipoBem = tipoBem.nome;
                                            }
                                        }

                                        beneficiarios.push(converted);
                                        beneficiarioIds.push(beneficiarioId);
                                    }
                                }

                            );
                        }
                    }
                });
            });

            return beneficiarios;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertTipoBemDropdown
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Tipo Bem Dropdown Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Tipo Bem'
         **/
        function convertTipoBemDropdown(items) {
            var convertedList = [];

            angular.forEach(items, function(item) {
                var converted = {};
                converted.codigo = item.codigoValorDominio;
                converted.nome = item.nomeDominio;
                convertedList.push(converted);
            });

            convertedList = $filter('orderBy')(convertedList, ['nome']);

            return convertedList;
        }

        function createBeneficiarioRequest(numeroProposta, numeroVersaoProposta, numeroOrcamento, numeroVersaoOrcamento, beneficiario, beneficiarioCoberturas) {
            var data = {
                numeroProposta: numeroProposta,
                numeroVersaoProposta: numeroVersaoProposta,
                numeroItemVersaoProposta: beneficiario.numeroItemVersaoProposta,
                numeroOrcamento: numeroOrcamento,
                numeroVersaoOrcamento: numeroVersaoOrcamento,
                numeroItemVersaoOrcamento: beneficiario.numeroItemVersaoOrcamento,
                coberturasItem: {
                    listaCoberturasItem: {
                        coberturaItemDocumento: []
                    }
                },
                codigoBeneficiario: beneficiario.codigoBeneficiario
            };

            // Construct Cobertura
            angular.forEach(beneficiarioCoberturas, function(cobertura) {
                if (cobertura.isChecked) {
                    var includeCobertura = {
                        codigoCobertura: cobertura.codigoCobertura,
                        beneficiarios: {
                            beneficiario: [{
                                codigoBeneficiario: beneficiario.codigoBeneficiario,
                                dadosPessoa: {
                                    codigoPessoa: beneficiario.codigoPessoa,
                                    nomePessoa: beneficiario.nomeBeneficiario,
                                    codigoTipoPessoa: beneficiario.codigoTipoPessoa,
                                    numeroCnpjCpf: OrcamentoUtilityFactory.convertBackCpfCnpj(beneficiario.numeroCnpjCpf),
                                    flagAtivo: 'S'
                                },
                                codigoListaItem: beneficiario.codigoListaItem,
                                codigoTipoBem: beneficiario.codigoTipoBem,
                                valorTipoBem: OrcamentoUtilityFactory.convertBackDecimal(beneficiario.valorTipoBem)
                            }]
                        }

                    };
                    if (beneficiario.codigoTipoBem === Constants.CODIGO_TIPO_BEM.BENS_ESPECIFICOS) {
                        includeCobertura.beneficiarios.beneficiario[0].valorTipoBem = OrcamentoUtilityFactory.convertBackDecimal(beneficiario.valorTotalBens);
                    }
                    data.coberturasItem.listaCoberturasItem.coberturaItemDocumento.push(includeCobertura);
                }
            });

            // Construct ListIten when codigoTipoBem === 3
            if (beneficiario.codigoTipoBem === Constants.CODIGO_TIPO_BEM.BENS_ESPECIFICOS) {
                var listaItens = {
                    codigoListaItem: beneficiario.codigoListaItem,
                    nomeListaItem: beneficiario.nomeListaItem,
                    ComponentesListaItem: {
                        componentesListaItem: []
                    }
                };
                angular.forEach(beneficiario.componentes, function(componente) {
                    var componenteItemObj = {
                        codigoComponenteListaItem: componente.codigoListaIten,
                        nomeComponenteListaItem: componente.nomeDoBem,
                        quantidadeComponenteListaItem: beneficiario.quantidadeBens,
                        valorComponenteListaItem: OrcamentoUtilityFactory.convertBackDecimal(componente.valorDoBem)
                    };
                    listaItens.ComponentesListaItem.componentesListaItem.push(componenteItemObj);
                });
                data.listaItens = listaItens;
            }

            var itemDocumentoEmissao = {};
            itemDocumentoEmissao.itemDocumentoEmissao = data;
            angular.forEach(itemDocumentoEmissao.itemDocumentoEmissao.coberturasItem.listaCoberturasItem.coberturaItemDocumento, function(item) {
                item.beneficiarios.beneficiario[0].dadosPessoa.nomeResumidoPessoa = item.beneficiarios.beneficiario[0].dadosPessoa.nomePessoa;
            });

            return itemDocumentoEmissao;
        }

        function constructBeneficiarioCoberturaList(coberturas, coberturaOfertaList) {
            var converted = [];

            angular.forEach(coberturas, function(coberturaItem) {
                var cobertura = {
                    isChecked: false,
                    codigoCobertura: coberturaItem.codigoCobertura,
                    valorLimiteMaximoIndenizacao: coberturaItem.valorLimiteMaximoIndenizacao,
                    listaTipoBemBeneficiario: coberturaItem.listaTipoBemBeneficiario,
                    valorTotalDosBens: ""
                };

                if (coberturaOfertaList.length > 0) {
                    var coberturaOferta = $filter('filter')(
                        coberturaOfertaList, {
                            codigoCobertura: coberturaItem.codigoCobertura
                        }, true)[0];
                    if (angular.isObject(coberturaOferta)) {
                        cobertura.nomeResumidoCobertura = coberturaOferta.nomeResumidoCobertura;
                    }
                }

                converted.push(cobertura);
            });
            return converted;
        }

        function constructBeneficiarioCoberturaListChecked(coberturas, beneficiarioCoberturas) {
            var converted = [];
            angular.forEach(coberturas, function(coberturaItem) {
                angular.forEach(beneficiarioCoberturas, function(benCobItm) {
                    if (coberturaItem.codigoCobertura === benCobItm.codigoCobertura) {
                        coberturaItem.valorTotalDosBens = benCobItm.beneficiarios[0].valorTipoBem;
                        coberturaItem.isChecked = true;
                    }
                });
                converted.push(coberturaItem);
            });
            return converted;
        }

        function constructObjetoSegurado(initialObjetoSeguroDropdown) {
            var constructed = [];
            angular.forEach(initialObjetoSeguroDropdown, function(objetoSeguroDropdown) {
                var objetoRiscoXItmOrcamento = {
                    codigo: objetoSeguroDropdown.numeroItemVersaoOrcamento,
                    nome: objetoSeguroDropdown.nomeResumidoObjetoRisco
                };
                constructed.push(objetoRiscoXItmOrcamento);
            });

            constructed = $filter('orderBy')(constructed, ['nome']);

            return constructed;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertBeneficiarios
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Beneficiarios Object
         *
         * @param {Object} items object to be converted.
         * @returns {Object} converted object of 'Beneficiarios'
         **/
        function convertBeneficiariosOld(items) {

            var converted = {
                quantidadeBens: 2,
                valorTotalBens: 5,
                relacaoBens: {
                    grid: [{
                        nomeBem: 'Dan dan',
                        valorBem: 'R$ 900,00'
                    }, {
                        nomeBem: 'Dan dan 2',
                        valorBem: 'R$ 900,00'
                    }]
                },
                cobertura: {
                    grid: [{
                        nomeCobertura: 'Incêndio',
                        valorEdificio: 'R$ 1000,00',
                        valorConteudo: 'R$ 1000,00',
                        valorTotalBens: ''
                    }, {
                        nomeCobertura: 'Danos elétricos',
                        valorEdificio: 'R$ 1000,00',
                        valorConteudo: 'R$ 1000,00',
                        valorTotalBens: ''
                    }, {
                        nomeCobertura: 'Tumultos',
                        valorEdificio: 'R$ 1000,00',
                        valorConteudo: 'R$ 1000,00',
                        valorTotalBens: ''
                    }, {
                        nomeCobertura: 'Equipamentos eletrônicos sem subtração',
                        valorEdificio: 'R$ 1000,00',
                        valorConteudo: 'R$ 1000,00',
                        valorTotalBens: ''
                    }]
                }
            };
            return converted;
        }
        //------------------------------------END BENIFICIARIO-------------------------------------------------//


        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#constructOrcamentoVersionList
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         *
         * Construct the list of Proposta version to be displayed.
         *
         * @param {Array} versions The list to be constructed.
         * @returns {Array} propostaVersionList The constructed list.
         **/
        function constructPropostaVersionList(versions) {
            var propostaVersionList = [];

            angular.forEach(versions, function(version) {
                var versaoProposta = new VersaoProposta();

                versaoProposta.name = version.numeroProposta;
                versaoProposta.version = version.numeroVersaoProposta;
                versaoProposta.inicio = OrcamentoUtilityFactory.formatDateForView(version.dataInicioVigencia);
                versaoProposta.fim = OrcamentoUtilityFactory.formatDateForView(version.dataFimVigencia);
                version.auditoria.dataUltimaAlteracao = $filter('date')(Date.parse(version.auditoria.dataUltimaAlteracao), 'dd/MM/yyyy HH:mm:ss');
                version.auditoria.matriculaUsuarioUltimaAlteracao = UsuarioService.getMatriculaComposta(version.auditoria.codigoTipoUsuarioUltimaAlteracao, version.auditoria.codigoEmpresaUsuarioUltimaAlteracao, version.auditoria.codigoMatriculaUsuarioUltimaAlteracao);
                versaoProposta.auditoria = version.auditoria;
                
                /** redeploy */
                if(!version.auditoria.matriculaUsuarioUltimaAlteracao) {
                    version.auditoria.matriculaUsuarioUltimaAlteracao = version.auditoria.codigoTipoUsuarioUltimaAlteracao + version.auditoria.codigoEmpresaUsuarioUltimaAlteracao + version.auditoria.codigoMatriculaUsuarioUltimaAlteracao;
                }

                var matricula = version.auditoria.codigoTipoUsuarioUltimaAlteracao + "" + version.auditoria.matriculaUsuarioUltimaAlteracao.substring(1);

                EmissaoColaboradoresService.getColaboradores(matricula).success(function(data) {
                    if (data && data.dadosColaboradorRH) {
                        version.auditoria.colaborador = data.dadosColaboradorRH.nome;
                    }
                }).error(function(data, status, headers, config) {
                    $log.error('Erro na obtenção do EmissaoColaboradoresService.');
                });

                propostaVersionList.push(versaoProposta);
            });

            return propostaVersionList;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#VersaoProposta
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         *
         * VersaoProposta object.
         *
         **/
        function VersaoProposta() {
            var versaoProposta = this;
            versaoProposta.name = null;
            versaoProposta.version = null;
            versaoProposta.inicio = null;
            versaoProposta.fim = null;
            versaoProposta.auditoria = null;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertProposta
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         *
         * Convert frontend object to backend format.
         *
         **/
        function convertProposta(item, isCreate, formasPagamento) {
            var proposta = {};
            proposta.formasPagamento = {};

            proposta.numeroProposta = item.numeroProposta;
            proposta.numeroOrcamento = item.numeroOrcamento;
            proposta.codigoEmpresaUsuarioBloqueio = item.codigoEmpresaUsuarioBloqueio; //Proposta

            if (item.enderecoCobranca) {
                proposta.enderecoCobranca = {
                    codigoEndereco: item.enderecoCobranca.codigoEndereco
                };
            } else {
                proposta.enderecoCobranca = {};
            }
            if (item.enderecoCorrespondencia) {
                proposta.enderecoCorrespondencia = {
                    codigoEndereco: item.enderecoCorrespondencia.codigoEndereco
                };
            } else {
                proposta.enderecoCorrespondencia = {};
            }
            proposta.formasPagamento.formaPagamento = convertFormaPagamento(item.formaPagamento, formasPagamento);
            proposta.codigoMatriculaUsuarioBloqueio = item.codigoMatriculaUsuarioBloqueio; //Proposta

            if (item.codigoOrigemEmissao !== undefined) {
                proposta.codigoOrigemEmissao = item.codigoOrigemEmissao; //Proposta
            }

            proposta.codigoStatusProposta = item.codigoStatusProposta; //Proposta
            proposta.codigoTipoDistribuicaoPagamento = item.codigoTipoDistribuicaoPagamento; //Proposta
            proposta.codigoTipoOrganizacao = item.codigoTipoOrganizacao; //Proposta
            proposta.codigoTipoUsuarioBloqueio = item.codigoTipoUsuarioBloqueio; //Proposta
            proposta.dataBloqueio = convertDateOnly(item.dataBloqueio); //Proposta
            proposta.dataEmissao = convertDateOnly(item.dataEmissao); //Proposta

            if (angular.isDefined(item.dataInicioStatusProposta)) {
                proposta.dataInicioStatusProposta = convertDateOnly(item.dataInicioStatusProposta);
            }

            if (angular.isDefined(item.dataFimStatusProposta)) {
                proposta.dataFimStatusProposta = convertDateOnly(item.dataFimStatusProposta);
            }

            if (angular.isDefined(item.dataInicioVigencia)) {
                proposta.dataInicioVigencia = convertDateOnly(item.dataInicioVigencia);
            }

            if (angular.isDefined(item.dataFimVigencia)) {
                proposta.dataFimVigencia = convertDateOnly(item.dataFimVigencia);
            }

            proposta.dataMelhorDataPrimeiraParcela = convertDateOnly(item.dataMelhorDataPrimeiraParcela);
            proposta.dataProtocolo = convertDateOnly(item.dataProtocolo);
            proposta.descricaoStatus = item.descricaoStatus;

            if (angular.isDefined(item.flagBloqueio)) {
                proposta.flagBloqueio = item.flagBloqueio; //Proposta
            }

            if (angular.isDefined(item.flagEnvioEmailCorretor)) {
                proposta.flagEnvioEmailCorretor = item.flagEnvioEmailCorretor;
            }

            if (angular.isDefined(item.flagPossuiBeneficiario)) {
                proposta.flagPossuiBeneficiario = item.flagPossuiBeneficiario; //Proposta
            }

            if (angular.isDefined(item.flagPossuiCorretorSecundario)) {
                proposta.flagPossuiCorretorSecundario = item.flagPossuiCorretorSecundario;
            }

            if (angular.isDefined(item.flagPossuiSinistro)) {
                proposta.flagPossuiSinistro = item.flagPossuiSinistro; //Proposta
            }

            if (angular.isDefined(item.flagPossuiTituloCapitalizacao)) {
                proposta.flagPossuiTituloCapitalizacao = item.flagPossuiTituloCapitalizacao; //Proposta
            }

            if (angular.isDefined(item.flagPrimeiraCompraCartaoEmpresa)) {
                proposta.flagPrimeiraCompraCartaoEmpresa = item.flagPrimeiraCompraCartaoEmpresa; //Proposta
            }

            if (angular.isDefined(item.flagRenovacaoAutomatico)) {
                proposta.flagRenovacaoAutomatico = item.flagRenovacaoAutomatico; //Proposta
            }
            //Rebaseline 96.44.15 - Begin
            // if (angular.isDefined(item.numeroSequenciaRegistroTituloCapitalizacao)){
            //     proposta.numeroSequenciaRegistroTituloCapitalizacao = item.numeroSequenciaRegistroTituloCapitalizacao; //Proposta
            // }
            // if (angular.isDefined(item.flagSolicitacaoCartaoCredito)){
            //     proposta.flagSolicitacaoCartaoCredito = item.flagSolicitacaoCartaoCredito; //Proposta
            // }
            if (angular.isDefined(item.codigoFaixaResgatePonto)) {
                proposta.codigoFaixaResgatePonto = item.codigoFaixaResgatePonto; //Proposta
            }
            //Rebaseline 96.44.15 - End
            //Rebaseline 99.48.27 R2_Rebase - Begin
            // if (angular.isDefined(item.codigoTipoPessoaProponente)){
            //     proposta.codigoTipoPessoaProponente = item.codigoTipoPessoaProponente; //Proposta
            // }

            //Rebaseline 99.48.27 R2_Rebase - Begin

            proposta.nomeProcessoSistemaGerenciamentoProcesso = item.nomeProcessoSistemaGerenciamentoProcesso; //Proposta
            proposta.numeroOrcamento = item.numeroOrcamento;
            proposta.numeroPropostaAutomovel = item.numeroPropostaAutomovel; //Proposta
            proposta.numeroSequenciaProposta = item.numeroSequenciaProposta;
            proposta.numeroSorteTituloCapitalizacao = item.numeroSorteTituloCapitalizacao; //Proposta
            proposta.numeroVersaoOrcamento = item.numeroVersaoOrcamento;
            proposta.numeroVersaoProposta = item.numeroVersaoProposta;

            var dadosPessoaSegurado = {};
            if (angular.isDefined(item.dadosPessoaSegurado)) {

                if (angular.isDefined(isCreate) && isCreate === true) {
                    dadosPessoaSegurado = getDadosPessoaSeguradoEBO(item.dadosPessoaSegurado);
                } else {
                    dadosPessoaSegurado.codigoPessoa = item.dadosPessoaSegurado.codigoPessoa;
                }

                proposta.dadosPessoaSegurado = dadosPessoaSegurado;
            }

            if (item.enderecoCobranca) {
                proposta.enderecoCobranca.codigoEndereco = item.enderecoCobranca.codigoEndereco;
                dadosPessoaSegurado.enderecoCobranca = item.enderecoCobranca;
            }
            if (item.enderecoCorrespondencia) {
                proposta.enderecoCorrespondencia.codigoEndereco = item.enderecoCorrespondencia.codigoEndereco;
            }

            if (item.pagadores && item.pagadores.pagador) {
                proposta.pagadores = getPagadoresEBO(item.pagadores.pagador, dadosPessoaSegurado, item.cartoes);
            }

            //added fields
            proposta.flagEndossoAlteracaoDadoCadastralSegurado = item.flagEndossoAlteracaoDadoCadastralSegurado;
            proposta.nomeProcessoSistemaGerenciamentoProcesso = item.nomeProcessoSistemaGerenciamentoProcesso;
            proposta.flagBloqueio = item.flagBloqueio;
            proposta.dataBloqueio = item.dataBloqueio;
            proposta.codigoTipoUsuarioBloqueio = item.codigoTipoUsuarioBloqueio;
            proposta.codigoEmpresaUsuarioBloqueio = item.codigoEmpresaUsuarioBloqueio;
            proposta.codigoMatriculaUsuarioBloqueio = item.codigoMatriculaUsuarioBloqueio;

            if (item.destinatarioEnvioFisicoSegundaViaDocumento) {
                proposta.codigoTipoDestinario = item.destinatarioEnvioFisicoSegundaViaDocumento;
            }

            //SM 393 - inclusão de campos
            proposta.flagVinculoSeguroAuto = item.flagVinculoSeguroAuto;
            proposta.flagVinculoSeguroOutroNegocio = item.flagVinculoSeguroOutroNegocio;
            proposta.quantidadeSeguroOutroNegocio = item.quantidadeSeguroOutroNegocio;

            return proposta;
        }

        function convertFormaPagamento(itemFormaPagamento, formasPagamento) {
            var list, selected = [];
            angular.forEach(formasPagamento, function(forma) {
                angular.forEach(forma, function(pagamento) {
                    angular.forEach(pagamento, function(item) {
                        if (item.flagImpressaoFormaPagamento === true || item.flagImpressaoFormaPagamento === "S") {
                            list = setFlagForma(itemFormaPagamento, item, selected);
                        }
                    });

                });
            });

            return list;
        }

        function setFlagForma(itemFormaPagamento, forma, selected) {

            angular.forEach(itemFormaPagamento, function(item) {
                if (item.codigoFormaPagamento === forma.codigoFormaPagamento) {
                    item.flagImpressaoFormaPagamento = "S";
                    selected.push(item);
                }
            });

            return selected;
        }

        function getDadosPessoaSeguradoEBO(dadosPessoaSegurado) {
            var dadosSeguadoEBO = {};

            dadosSeguadoEBO.codigoPessoa = dadosPessoaSegurado.codigoPessoa;
            dadosSeguadoEBO.codigoTipoPessoa = dadosPessoaSegurado.codigoTipoPessoa;
            dadosSeguadoEBO.numeroCnpjCpf =
                OrcamentoUtilityFactory.convertBackCpfCnpj(dadosPessoaSegurado.numeroCnpjCpf);

            dadosSeguadoEBO.nomePessoa = dadosPessoaSegurado.nomePessoa;
            dadosSeguadoEBO.nomeResumidoPessoa = dadosPessoaSegurado.nomeResumidoPessoa;
            dadosSeguadoEBO.flagAtivo = dadosPessoaSegurado.flagAtivo;

            if (dadosPessoaSegurado.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA && dadosPessoaSegurado.pessoaFisica !== null && angular.isDefined(dadosPessoaSegurado.pessoaFisica)) {
                dadosSeguadoEBO.pessoaFisica = setValueToPessoaFisica(dadosPessoaSegurado.pessoaFisica);
                dadosSeguadoEBO.pessoaJuridica = null;
                if (!dadosPessoaSegurado.vinculos) {
                    delete dadosPessoaSegurado.vinculos;
                } else {
                    dadosSeguadoEBO.vinculos = getVinculosEBO(dadosPessoaSegurado.vinculos, dadosPessoaSegurado.codigoTipoPessoa);
                }
            } else if (dadosPessoaSegurado.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.JURIDICA && dadosPessoaSegurado.pessoaJuridica !== null && angular.isDefined(dadosPessoaSegurado.pessoaJuridica)) {
                dadosSeguadoEBO.pessoaFisica = null;
                dadosSeguadoEBO.pessoaJuridica = setValueToPessoaJuridica(dadosPessoaSegurado.pessoaJuridica);

            } else {
                dadosSeguadoEBO.pessoaFisica = null;
                dadosSeguadoEBO.pessoaJuridica = null;
            }

            return dadosSeguadoEBO;
        }

        function getVinculosEBO(values, codigoTipoPessoa) {
            var vinculos = {
                vinculo: []
            };

            if (values && values.vinculo && values.vinculo.length > 0) {
                angular.forEach(values.vinculo, function(value) {
                    value.codigoTipoPessoaVinculo = codigoTipoPessoa;
                    var vinculo = setValueToVinculo(value);
                    vinculos.vinculo.push(vinculo);
                });
            }

            return vinculos;
        }

        function getPagadoresEBO(values, dadosPessoaSegurado, cartao) {
            var pagadors = {
                pagador: []
            };

            if (values) {
                angular.forEach(values, function(value) {
                    var pagador = getPagadorEBO(value, dadosPessoaSegurado, cartao);
                    pagadors.pagador.push(pagador);
                });
            }

            return pagadors;
        }

        function getPagadorEBO(value, dadosPessoaSegurado, cartao) {
            var pagador = {
                dadosPessoaPagador: {},
                enderecoCobranca: {},
                pagadoresParcela: {
                    pagadorParcela: []
                }
            };

            if (value) {
                //PessoaEBO
                pagador.dadosPessoaPagador = value.dadosPessoaPagador;

                //EnderecoEBO
                if (value.enderecoCobranca) {
                    pagador.enderecoCobranca = getEnderecoEBO(value.enderecoCobranca);
                } else if (dadosPessoaSegurado.enderecoCobranca) {
                    pagador.enderecoCobranca = getEnderecoEBO(dadosPessoaSegurado.enderecoCobranca);
                }

                pagador.pagadoresParcela.pagadorParcela = [];
                //PagadorParcelaEBO
                if (value.pagadoresParcela && angular.isArray(value.pagadoresParcela.pagadorParcela) && value.pagadoresParcela.pagadorParcela.length > 0)
                    angular.forEach(value.pagadoresParcela.pagadorParcela, function(parcela) {
                        pagador.pagadoresParcela.pagadorParcela.push(getPagadoresParcelaEBO(parcela, cartao));
                    });
            } else {
                // 	pagador.dadosPessoaPagador = null;
                // 	pagador.enderecoCobranca = null;
                pagador.pagadoresParcela = null;
            }

            if (pagador &&
                pagador.pagadoresParcela &&
                pagador.pagadoresParcela.pagadorParcela) {
                angular.forEach(pagador.pagadoresParcela.pagadorParcela, function(pagador) {
                    if (!pagador.codigoTipoCartao && pagador.codigoBandeiraCartao) {
                        pagador.codigoTipoCartao = pagador.codigoBandeiraCartao;
                    } else if (pagador.codigoTipoCartao && !pagador.codigoBandeiraCartao) {
                        pagador.codigoBandeiraCartao = pagador.codigoTipoCartao;
                    }
                });
            }

            return pagador;
        }

        function getPagadoresParcelaEBO(parcela, cartao) {
            var pagadorParcela = {};

            if (parcela) {
                pagadorParcela.dadosPessoaPagadorParcela =
                    setValueToDadosPessoaPagadorParcela(parcela.dadosPessoaPagadorParcela);

                if (pagadorParcela.dadosPessoaPagadorParcela) {
                    pagadorParcela.dadosPessoaPagadorParcela.numeroCnpjCpf =
                        removeFormat(pagadorParcela.dadosPessoaPagadorParcela.numeroCnpjCpf);
                }

                if (cartao) {
                    pagadorParcela.codigoBandeiraCartao = cartao.bandeira;
                    pagadorParcela.codigoTipoCartao = cartao.codigoTipoCartao ? cartao.codigoTipoCartao : cartao.bandeira;
                    if (angular.isDefined(cartao.codigoIdentificacaoCartao) && cartao.codigoIdentificacaoCartao !== null) {
                        pagadorParcela.codigoIdentificacaoCartao = cartao.codigoIdentificacaoCartao;
                    }
                    if (angular.isDefined(cartao.anoValidadeCartao) && cartao.anoValidadeCartao !== null &&
                        angular.isDefined(cartao.mesValidadeCartao) && cartao.mesValidadeCartao !== null) {
                        var numeroCartaoDataValidade = cartao.anoValidadeCartao + '-' + cartao.mesValidadeCartao + '-' + '01';
                        pagadorParcela.dataPagamento = convertDateOnly(numeroCartaoDataValidade);
                    }
                }

                pagadorParcela.numeroParcela = parcela.numeroParcela;
                pagadorParcela.dataVencimento = convertDateOnly(parcela.dataVencimento);
                pagadorParcela.codigoBanco = parcela.codigoBanco;
                pagadorParcela.numeroAgenciaBancaria = parcela.numeroAgenciaBancaria;
                pagadorParcela.numeroContaBancaria = parcela.numeroContaBancaria;
                pagadorParcela.digitoContaBancaria = parcela.digitoContaBancaria;
                pagadorParcela.valorParcela = parcela.valorParcela;

                //added fields
                pagadorParcela.dataPagamentoContabilizado = convertDateOnly(parcela.dataPagamentoContabilizado);
                pagadorParcela.dataCancelamento = convertDateOnly(parcela.dataCancelamento);
                pagadorParcela.codigoStatusParcela = parcela.codigoStatusParcela;
                pagadorParcela.dataPrazoCobertura = convertDateOnly(parcela.dataPrazoCobertura);
                // SM 279
                pagadorParcela.textoComentario = parcela.textoComentario;
                // FIM - SM 279
            } else {
                pagadorParcela.numeroParcela = null;
                pagadorParcela.dataVencimento = null;
                pagadorParcela.codigoTipoCartao = null;
                pagadorParcela.codigoIdentificacaoCartao = null;
                pagadorParcela.codigoBanco = null;
                pagadorParcela.numeroAgenciaBancaria = null;
                pagadorParcela.numeroContaBancaria = null;
                pagadorParcela.digitoContaBancaria = null;
                pagadorParcela.valorParcela = null;

                //added fields
                pagadorParcela.dataPagamento = null;
                pagadorParcela.dataPagamentoContabilizado = null;
                pagadorParcela.dataCancelamento = null;
                pagadorParcela.codigoStatusParcela = null;
                pagadorParcela.dataPrazoCobertura = null;
                // SM 279
                pagadorParcela.textoComentario = null;
                // FIM - SM 279
            }

            return pagadorParcela;
        }

        function getEnderecoEBO(endereco) {
            var enderecoEBO = {};

            if (endereco) {

                enderecoEBO.codigoEndereco = endereco.codigoEndereco;
                enderecoEBO.codigoTipoLogradouro = endereco.codigoTipoLogradouro;
                enderecoEBO.codigoLogradouro = endereco.codigoLogradouro;
                enderecoEBO.nomeLogradouro = endereco.nomeLogradouro;
                enderecoEBO.numeroLogradouro = endereco.numeroLogradouro;
                enderecoEBO.flagSemNumero = endereco.flagSemNumero;
                enderecoEBO.numeroCep = endereco.numeroCep;
                enderecoEBO.nomeComplemento = endereco.nomeComplemento;
                enderecoEBO.codigoBairro = endereco.codigoBairro;
                enderecoEBO.nomeBairro = endereco.nomeBairro;
                enderecoEBO.codigoCidade = endereco.codigoCidade;
                enderecoEBO.nomeCidade = endereco.nomeCidade;
                enderecoEBO.codigoUnidadeFederacao = endereco.codigoUnidadeFederacao;
                enderecoEBO.codigoPais = endereco.codigoPais;
                enderecoEBO.textoPontoReferencia = endereco.textoComentario;
                enderecoEBO.numeroLatitude = endereco.numeroLatitude;
                enderecoEBO.numeroLongitude = endereco.numeroLongitude;
                enderecoEBO.codigoTipoEndereco = endereco.codigoTipoEndereco;
                enderecoEBO.flagPrincipal = endereco.flagPrincipal;
                enderecoEBO.flagAtivo = endereco.flagAtivo;
            }
            return enderecoEBO;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertDadosPessoaSegurado
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         *
         * Construct submission object for DadosPessoaSegurado.
         *
         * @param {Object} dadosPessoaSegurado The object to be constructed.
         * @returns {Object} dadosPessoaSeguradoType The constructed object.
         **/
        function convertDadosPessoaSegurado(dadosPessoaSegurado) {
            var dadosPessoaSeguradoType = new DadosPessoaSegurado();
            dadosPessoaSeguradoType.codigoPessoa = dadosPessoaSegurado.codigoPessoa;
            dadosPessoaSeguradoType.codigoTipoPessoa = dadosPessoaSegurado.codigoTipoPessoa;
            dadosPessoaSeguradoType.numeroCnpjCpf =
                OrcamentoUtilityFactory.convertBackCpfCnpj(dadosPessoaSegurado.numeroCnpjCpf);

            dadosPessoaSeguradoType.nomePessoa = dadosPessoaSegurado.nomePessoa;
            dadosPessoaSeguradoType.nomeResumidoPessoa = dadosPessoaSegurado.nomeResumidoPessoa;
            dadosPessoaSeguradoType.flagAtivo = dadosPessoaSegurado.flagAtivo;

            if (dadosPessoaSegurado.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA && dadosPessoaSegurado.pessoaFisica !== null && angular.isDefined(dadosPessoaSegurado.pessoaFisica)) {
                dadosPessoaSeguradoType.pessoaFisica = setValueToPessoaFisica(dadosPessoaSegurado.pessoaFisica);
                dadosPessoaSeguradoType.pessoaJuridica = null;
                dadosPessoaSeguradoType.vinculos = setValueToVinculosList(dadosPessoaSegurado.vinculos);
            } else if (dadosPessoaSegurado.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.JURIDICA && dadosPessoaSegurado.pessoaJuridica !== null && angular.isDefined(dadosPessoaSegurado.pessoaJuridica)) {
                dadosPessoaSeguradoType.pessoaFisica = null;
                dadosPessoaSeguradoType.pessoaJuridica = setValueToPessoaJuridica(dadosPessoaSegurado.pessoaJuridica);

            } else {
                dadosPessoaSeguradoType.pessoaFisica = null;
                dadosPessoaSeguradoType.pessoaJuridica = null;
            }

            return dadosPessoaSeguradoType;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertDateOnly
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         *
         * Converts Date Only from Date Time format.
         *
         * @param {Object} dateTime The object to be converted.
         * @returns {Object} date The constructed object.
         **/
        function convertDateOnly(dateTime) {
            var date = null;
            if (dateTime) {
                if (angular.isString(dateTime)) {
                    date = new Date($filter('date')(dateTime, Constants.DATE_FORMAT_BE));
                    // Check if the type of string of the passed dateTime value was not parsed correctly.
                    if (isNaN(Date.parse(date))) {
                        var dateTimeArray = dateTime.split("+");
                        var dateArray = dateTimeArray[0].split("-");
                        var month = parseInt(dateArray[1]) - 1;
                        date = new Date(dateArray[0], month, dateArray[2]);
                    }
                } else if (angular.isDate(dateTime)) {
                    date = dateTime;
                }
            }

            return date;
        }

        function convertDate(dateFromBE) {
            //from 2016-04-09+08:00 format to 09/04/2016 format
            if (dateFromBE) {
                var date = null;
                var dateArray = dateFromBE.split("-");
                var dateWithTimeArray = dateArray[2].split("+");
                date = dateWithTimeArray[0] + "/" + dateArray[1] + "/" + dateArray[0];
                return date;
            }

        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#constructProposta
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         *
         * Convert Backend object to Frontend format.
         *
         **/
        function constructProposta(value) {
            return new DocumentoEmissao(value);
        }

        function DocumentoEmissao(value) {
            var DocumentoEmissaoEBO = this;
            var defVal = defaultEndereco();

            DocumentoEmissaoEBO.enderecoCobranca = defVal.enderecoCobranca;
            DocumentoEmissaoEBO.enderecoCorrespondencia = defVal.enderecoCorrespondencia;

            if (value) {
                DocumentoEmissaoEBO.numeroApolice = value.numeroApolice;
                DocumentoEmissaoEBO.codigoSucursal = value.codigoSucursal;
                DocumentoEmissaoEBO.numeroSequenciaApolice = value.numeroSequenciaApolice;
                DocumentoEmissaoEBO.digitoVerificacao = value.digitoVerificacao;
                DocumentoEmissaoEBO.numeroEndosso = value.numeroEndosso;
                DocumentoEmissaoEBO.numeroApoliceSemNumeroEndosso = value.numeroApoliceSemNumeroEndosso;
                DocumentoEmissaoEBO.numeroApoliceExterno = value.numeroApoliceExterno;
                DocumentoEmissaoEBO.numeroApoliceAnterior = value.numeroApoliceAnterior;
                DocumentoEmissaoEBO.dataEnvioEmail = value.dataEnvioEmail;
                DocumentoEmissaoEBO.dataEnvioImpressao = value.dataEnvioImpressao;
                DocumentoEmissaoEBO.codigoFaixaResgatePonto = value.codigoFaixaResgatePonto;
                DocumentoEmissaoEBO.codigoDevolutivaOfertaCartao = value.codigoDevolutivaOfertaCartao;
                /**
                 * Rebaseline 99.55.35_r2/100.58.36_r2 --> modificação do campo codigoIdentificacaoApolice para codigoIdentificacaoExternaApolice
                 * Quando add o campo no EBO codigoIdentificacaoExternaApolice, descomentar e remover o codigoIdentificacaoApolice
                 **/
                DocumentoEmissaoEBO.codigoIdentificacaoApolice = value.codigoIdentificacaoApolice;
                // DocumentoEmissaoEBO.codigoIdentificacaoExternaApolice = value.codigoIdentificacaoExternaApolice;
                DocumentoEmissaoEBO.codigoIdentificacaoCondicaoGeral = value.codigoIdentificacaoCondicaoGeral;
                DocumentoEmissaoEBO.numeroProposta = value.numeroProposta;
                DocumentoEmissaoEBO.numeroVersaoProposta = value.numeroVersaoProposta;
                DocumentoEmissaoEBO.numeroSequenciaProposta = value.numeroSequenciaProposta;
                DocumentoEmissaoEBO.codigoOrigemEmissao = value.codigoOrigemEmissao;
                DocumentoEmissaoEBO.codigoTipoDistribuicaoPagamento = value.codigoTipoDistribuicaoPagamento;
                DocumentoEmissaoEBO.dataProtocolo = value.dataProtocolo;
                DocumentoEmissaoEBO.dataEmissao = value.dataEmissao;
                DocumentoEmissaoEBO.numeroPropostaAutomovel = value.numeroPropostaAutomovel;
                DocumentoEmissaoEBO.flagPossuiCorretorSecundario = value.flagPossuiCorretorSecundario;
                DocumentoEmissaoEBO.flagPossuiBeneficiario = value.flagPossuiBeneficiario;
                DocumentoEmissaoEBO.flagPossuiSinistro = value.flagPossuiSinistro;
                DocumentoEmissaoEBO.flagPrimeiraCompraCartaoEmpresa = value.flagPrimeiraCompraCartaoEmpresa;
                DocumentoEmissaoEBO.flagEnvioEmailCorretor = value.flagEnvioEmailCorretor;
                DocumentoEmissaoEBO.flagOfertaCartaoCredito = value.flagOfertaCartaoCredito;
                DocumentoEmissaoEBO.codigoBandeiraCartao = value.codigoBandeiraCartao;
                DocumentoEmissaoEBO.flagPossuiTituloCapitalizacao = value.flagPossuiTituloCapitalizacao;
                DocumentoEmissaoEBO.numeroSorteTituloCapitalizacao = value.numeroSorteTituloCapitalizacao;
                DocumentoEmissaoEBO.dataInicioVigencia = value.dataInicioVigencia;
                DocumentoEmissaoEBO.dataFimVigencia = value.dataFimVigencia;
                DocumentoEmissaoEBO.codigoStatusProposta = value.codigoStatusProposta;
                DocumentoEmissaoEBO.dataInicioStatusProposta = value.dataInicioStatusProposta;
                DocumentoEmissaoEBO.dataFimStatusProposta = value.dataFimStatusProposta;
                DocumentoEmissaoEBO.numeroOrcamento = value.numeroOrcamento;
                DocumentoEmissaoEBO.numeroVersaoOrcamento = value.numeroVersaoOrcamento;
                DocumentoEmissaoEBO.numeroOrcamentoExterno = value.numeroOrcamentoExterno;
                DocumentoEmissaoEBO.flagDataCalculoManual = value.flagDataCalculoManual;
                DocumentoEmissaoEBO.flagImpressaoOperacao = value.flagImpressaoOperacao;
                DocumentoEmissaoEBO.flagLicitacao = value.flagLicitacao;
                DocumentoEmissaoEBO.codigoOferta = value.codigoOferta;
                DocumentoEmissaoEBO.numeroVersaoOferta = value.numeroVersaoOferta;
                DocumentoEmissaoEBO.numeroSequenciaVersaoOferta = value.numeroSequenciaVersaoOferta;
                DocumentoEmissaoEBO.codigoEmpresa = value.codigoEmpresa;
                DocumentoEmissaoEBO.codigoRamo = value.codigoRamo;
                DocumentoEmissaoEBO.codigoModalidade = value.codigoModalidade;
                DocumentoEmissaoEBO.codigoGrupoComercial = value.codigoGrupoComercial;
                DocumentoEmissaoEBO.numeroVersaoProdutoComercial = value.numeroVersaoProdutoComercial;
                DocumentoEmissaoEBO.numeroSequenciaVersaoProdutoComercial = value.numeroSequenciaVersaoProdutoComercial;
                DocumentoEmissaoEBO.nomeOferta = value.nomeOferta;
                DocumentoEmissaoEBO.nomeProdutoComercial = value.nomeProdutoComercial;
                DocumentoEmissaoEBO.flagSimulacao = value.flagSimulacao;
                DocumentoEmissaoEBO.codigoStatusOrcamento = value.codigoStatusOrcamento;
                DocumentoEmissaoEBO.dataInicioStatusOrcamento = value.dataInicioStatusOrcamento;
                DocumentoEmissaoEBO.dataFimStatusOrcamento = value.dataFimStatusOrcamento;
                DocumentoEmissaoEBO.numeroApoliceEndosso = value.numeroApoliceEndosso;
                DocumentoEmissaoEBO.nomePessoaProponente = value.nomePessoaProponente;
                DocumentoEmissaoEBO.dataNascimentoPessoaProponente = value.dataNascimentoPessoaProponente;
                DocumentoEmissaoEBO.numeroCalculoCnpjCpfProponente = value.numeroCalculoCnpjCpfProponente;
                DocumentoEmissaoEBO.codigoCorretorPrincipal = value.codigoCorretorPrincipal;
                DocumentoEmissaoEBO.dataCalculo = value.dataCalculo;
                DocumentoEmissaoEBO.dataValidade = value.dataValidade;
                DocumentoEmissaoEBO.dataMelhorDataPrimeiraParcela = convertDate(value.dataMelhorDataPrimeiraParcela);
                DocumentoEmissaoEBO.dataInicioVigenciaSeguro = value.dataInicioVigenciaSeguro;
                DocumentoEmissaoEBO.dataFimVigenciaSeguro = value.dataFimVigenciaSeguro;
                DocumentoEmissaoEBO.codigoParceiroNegocio = value.codigoParceiroNegocio;
                DocumentoEmissaoEBO.numeroVersaoParceiroNegocio = value.numeroVersaoParceiroNegocio;
                DocumentoEmissaoEBO.codigoOnus = value.codigoOnus;
                DocumentoEmissaoEBO.codigoFormaPagamento = value.codigoFormaPagamento;
                DocumentoEmissaoEBO.codigoClasseProfissionalLiberal = value.codigoClasseProfissionalLiberal;
                DocumentoEmissaoEBO.codigoCanal = value.codigoCanal;
                DocumentoEmissaoEBO.codigoMoeda = value.codigoMoeda;
                DocumentoEmissaoEBO.codigoMotivoRecusa = value.codigoMotivoRecusa;
                DocumentoEmissaoEBO.codigoTipoCalculo = value.codigoTipoCalculo;
                DocumentoEmissaoEBO.codigoTipoClassificacaoPessoa = value.codigoTipoClassificacaoPessoa;
                DocumentoEmissaoEBO.codigoTipoEndosso = value.codigoTipoEndosso;
                DocumentoEmissaoEBO.codigoTipoSeguro = value.codigoTipoSeguro;
                DocumentoEmissaoEBO.codigoTipoVigencia = value.codigoTipoVigencia;
                DocumentoEmissaoEBO.codigoTipoRenovacao = value.codigoTipoRenovacao;
                DocumentoEmissaoEBO.numeroProcessoLicitacao = value.numeroProcessoLicitacao;
                DocumentoEmissaoEBO.codigoTipoLicitacao = value.codigoTipoLicitacao;
                DocumentoEmissaoEBO.codigoOrigemRenovacao = value.codigoOrigemRenovacao;
                DocumentoEmissaoEBO.codigoOperacao = value.codigoOperacao;
                DocumentoEmissaoEBO.dataInicioVigenciaVersaoOrcamento = value.dataInicioVigenciaVersaoOrcamento;
                DocumentoEmissaoEBO.dataFimVigenciaVersaoOrcamento = value.dataFimVigenciaVersaoOrcamento;
                DocumentoEmissaoEBO.valorAdicionalFracionamento = value.valorAdicionalFracionamento;
                DocumentoEmissaoEBO.valorCustoApolice = value.valorCustoApolice;
                DocumentoEmissaoEBO.valorEncargo = value.valorEncargo;
                DocumentoEmissaoEBO.valorPremio = value.valorPremio;
                DocumentoEmissaoEBO.textoComentario = value.textoComentario;
                DocumentoEmissaoEBO.codigoClassificacaoCreditoPessoa = value.codigoClassificacaoCreditoPessoa;
                DocumentoEmissaoEBO.quantidadeDiaVigenciaSeguro = value.quantidadeDiaVigenciaSeguro;
                DocumentoEmissaoEBO.codigoTipoDocumento = value.codigoTipoDocumento;
                DocumentoEmissaoEBO.codigoMotivoEndossoCancelamento = value.codigoMotivoEndossoCancelamento;

                if (value.codigoTipoDestinario) {
                    DocumentoEmissaoEBO.destinatarioEnvioFisicoSegundaViaDocumento = value.codigoTipoDestinario;
                }

                if (value.solicitacaoCartaoCredito) {
                    DocumentoEmissaoEBO.solicitacaoCartaoCredito = value.solicitacaoCartaoCredito;
                }

                //Rebaseline 96.44.15 - Begin
                // DocumentoEmissaoEBO.numeroSequenciaRegistroTituloCapitalizacao = value.numeroSequenciaRegistroTituloCapitalizacao;
                // DocumentoEmissaoEBO.flagSolicitacaoCartaoCredito = value.flagSolicitacaoCartaoCredito;
                // DocumentoEmissaoEBO.codigoFaixaResgatePonto = value.codigoFaixaResgatePonto;
                //Rebaseline 96.44.15 - End
                //Rebaseline 99.48.27 R2_Rebase- Begin
                // DocumentoEmissaoEBO.codigoTipoPessoaProponente = value.codigoTipoPessoaProponente;
                //Rebaseline 99.48.27 R2_Rebase- End
                // DocumentoEmissaoEBO.enderecoCorrespondencia = setValueToEnderecoCorrespondencia(value.enderecoCorrespondencia);

                if (value.enderecoCorrespondencia) {
                    DocumentoEmissaoEBO.enderecoCorrespondencia.codigoEndereco = value.enderecoCorrespondencia.codigoEndereco;
                }
                DocumentoEmissaoEBO.dadosPessoaSegurado = setValueToDadosPessoaSegurado(value.dadosPessoaSegurado);

                DocumentoEmissaoEBO.pagadores = {};
                if (value.pagadores && value.pagadores.pagador && value.pagadores.pagador.length > 0) {
                    DocumentoEmissaoEBO.pagadores.pagador = setValueToPagadorsList(value.pagadores.pagador, value.dadosPessoaSegurado, value.cartoes);
                    if (DocumentoEmissaoEBO.pagadores.pagador[0].enderecoCobranca) {
                        DocumentoEmissaoEBO.enderecoCobranca.codigoEndereco = DocumentoEmissaoEBO.pagadores.pagador[0].enderecoCobranca.codigoEndereco;
                    }
                }
                DocumentoEmissaoEBO.analises = {};
                if (value.analises && value.analises.analise &&
                    value.analises.analise.length > 0) {
                    DocumentoEmissaoEBO.analises.analise = setValueToAnalisesList(value.analises.analise);
                }

                DocumentoEmissaoEBO.corretores = {};
                if (value.corretores && value.corretores.corretor &&
                    value.corretores.corretor.length > 0) {
                    DocumentoEmissaoEBO.corretores.corretor = setValueToCorretorsList(value.corretores.corretor);
                }

                DocumentoEmissaoEBO.intervenientes = {};
                if (value.intervenientes && value.intervenientes.interveniente &&
                    value.intervenientes.interveniente.length > 0) {
                    DocumentoEmissaoEBO.intervenientes.interveniente = setValueToIntervenientesList(value.intervenientes.interveniente);
                }

                DocumentoEmissaoEBO.pendencias = {};
                if (value.pendencias && value.pendencias.pendencia &&
                    value.pendencias.pendencia.length > 0) {
                    DocumentoEmissaoEBO.pendencias.pendencia = setValueToPendenciasList(value.pendencias.pendencia);
                }
                //DocumentoEmissaoEBO.clausula = [];
                //DocumentoEmissaoEBO.beneficio = [];

                DocumentoEmissaoEBO.formasPagamento = {};
                if (value.formasPagamento && value.formasPagamento.formaPagamento &&
                    value.formasPagamento.formaPagamento.length > 0) {
                    DocumentoEmissaoEBO.formasPagamento.formaPagamento = setValueToFormaPagamentosList(value.formasPagamento.formaPagamento);
                }

                DocumentoEmissaoEBO.criticas = {};
                if (value.criticas && value.criticas.critica &&
                    value.criticas.critica.length > 0) {
                    DocumentoEmissaoEBO.criticas.critica = setValueToCriticasList(value.criticas.critica);
                }

                DocumentoEmissaoEBO.auditoria = setValueToAuditoria(value.auditoria);
                //DocumentoEmissaoEBO.ItemDocumentoEmissaoEBO = setValueToItemDocumentoEmissaoEBOsList(value.ItemDocumentoEmissaoEBO);

                DocumentoEmissaoEBO.ItensDocumentoEmissao = {
                    itemDocumentoEmissao: []
                };

                if (value && value.ItensDocumentoEmissao) {
                    DocumentoEmissaoEBO.ItensDocumentoEmissao.itemDocumentoEmissao = setValueToItemDocumentoEmissaoEBOsList(value.ItensDocumentoEmissao.itemDocumentoEmissao);
                }

                //added fields
                DocumentoEmissaoEBO.flagEndossoAlteracaoDadoCadastralSegurado = value.flagEndossoAlteracaoDadoCadastralSegurado;
                DocumentoEmissaoEBO.nomeProcessoSistemaGerenciamentoProcesso = value.nomeProcessoSistemaGerenciamentoProcesso;
                DocumentoEmissaoEBO.flagBloqueio = value.flagBloqueio;
                DocumentoEmissaoEBO.dataBloqueio = value.dataBloqueio;
                DocumentoEmissaoEBO.codigoTipoUsuarioBloqueio = value.codigoTipoUsuarioBloqueio;
                DocumentoEmissaoEBO.codigoEmpresaUsuarioBloqueio = value.codigoEmpresaUsuarioBloqueio;
                DocumentoEmissaoEBO.codigoMatriculaUsuarioBloqueio = value.codigoMatriculaUsuarioBloqueio;
                DocumentoEmissaoEBO.orcamento = OrcamentoFormFactory.constructOrcamento(value);

                DocumentoEmissaoEBO.historicoEndossoList = convertHistoricoEndosso(value.historicoEndosso);
                if (DocumentoEmissaoEBO.orcamento && DocumentoEmissaoEBO.orcamento.ItemDocumentoEmissaoEBO &&
                    DocumentoEmissaoEBO.orcamento.ItemDocumentoEmissaoEBO.length > 0 &&
                    DocumentoEmissaoEBO.orcamento.ItemDocumentoEmissaoEBO[0]) {
                    DocumentoEmissaoEBO.nomeObjetoRisco = value.ItemDocumentoEmissaoEBO[0].textoDescricaoObjetoRisco;
                }

                //SM 393 - inclusão de campos
                DocumentoEmissaoEBO.flagVinculoSeguroAuto = value.flagVinculoSeguroAuto;
                DocumentoEmissaoEBO.flagVinculoSeguroOutroNegocio = value.flagVinculoSeguroOutroNegocio;
                DocumentoEmissaoEBO.quantidadeSeguroOutroNegocio = value.quantidadeSeguroOutroNegocio;

            } else {
                DocumentoEmissaoEBO.numeroApolice = null;
                DocumentoEmissaoEBO.codigoSucursal = null;
                DocumentoEmissaoEBO.numeroSequenciaApolice = null;
                DocumentoEmissaoEBO.digitoVerificacao = null;
                DocumentoEmissaoEBO.numeroEndosso = null;
                DocumentoEmissaoEBO.numeroApoliceSemNumeroEndosso = null;
                DocumentoEmissaoEBO.numeroApoliceExterno = null;
                DocumentoEmissaoEBO.numeroApoliceAnterior = null;
                DocumentoEmissaoEBO.dataEnvioEmail = null;
                DocumentoEmissaoEBO.dataEnvioImpressao = null;
                // DocumentoEmissaoEBO.codigoIdentificacaoApolice = null;
                // Rebaseline 99.55.35_r2/100.58.36_r2 --> modificação do campo codigoIdentificacaoApolice para codigoIdentificacaoExternaApolice
                DocumentoEmissaoEBO.codigoIdentificacaoExternaApolice = null;
                DocumentoEmissaoEBO.codigoIdentificacaoCondicaoGeral = null;
                DocumentoEmissaoEBO.numeroProposta = null;
                DocumentoEmissaoEBO.numeroVersaoProposta = null;
                DocumentoEmissaoEBO.numeroSequenciaProposta = null;
                DocumentoEmissaoEBO.codigoOrigemEmissao = null;
                DocumentoEmissaoEBO.codigoTipoDistribuicaoPagamento = null;
                DocumentoEmissaoEBO.dataProtocolo = null;
                DocumentoEmissaoEBO.dataEmissao = null;
                DocumentoEmissaoEBO.numeroPropostaAutomovel = null;
                DocumentoEmissaoEBO.flagPossuiCorretorSecundario = null;
                DocumentoEmissaoEBO.flagPossuiBeneficiario = null;
                DocumentoEmissaoEBO.flagPossuiSinistro = null;
                DocumentoEmissaoEBO.flagPrimeiraCompraCartaoEmpresa = null;
                DocumentoEmissaoEBO.flagEnvioEmailCorretor = null;
                DocumentoEmissaoEBO.flagPossuiTituloCapitalizacao = null;
                DocumentoEmissaoEBO.numeroSorteTituloCapitalizacao = null;
                DocumentoEmissaoEBO.dataInicioVigencia = null;
                DocumentoEmissaoEBO.dataFimVigencia = null;
                DocumentoEmissaoEBO.codigoStatusProposta = null;
                DocumentoEmissaoEBO.dataInicioStatusProposta = null;
                DocumentoEmissaoEBO.dataFimStatusProposta = null;
                DocumentoEmissaoEBO.numeroOrcamento = null;
                DocumentoEmissaoEBO.numeroVersaoOrcamento = null;
                DocumentoEmissaoEBO.numeroOrcamentoExterno = null;
                DocumentoEmissaoEBO.flagDataCalculoManual = null;
                DocumentoEmissaoEBO.flagImpressaoOperacao = null;
                DocumentoEmissaoEBO.flagLicitacao = null;
                DocumentoEmissaoEBO.codigoOferta = null;
                DocumentoEmissaoEBO.numeroVersaoOferta = null;
                DocumentoEmissaoEBO.numeroSequenciaVersaoOferta = null;
                DocumentoEmissaoEBO.codigoEmpresa = null;
                DocumentoEmissaoEBO.codigoRamo = null;
                DocumentoEmissaoEBO.codigoModalidade = null;
                DocumentoEmissaoEBO.codigoGrupoComercial = null;
                DocumentoEmissaoEBO.numeroVersaoProdutoComercial = null;
                DocumentoEmissaoEBO.numeroSequenciaVersaoProdutoComercial = null;
                DocumentoEmissaoEBO.nomeOferta = null;
                DocumentoEmissaoEBO.nomeProdutoComercial = null;
                DocumentoEmissaoEBO.flagSimulacao = null;
                DocumentoEmissaoEBO.codigoStatusOrcamento = null;
                DocumentoEmissaoEBO.dataInicioStatusOrcamento = null;
                DocumentoEmissaoEBO.dataFimStatusOrcamento = null;
                DocumentoEmissaoEBO.numeroApoliceEndosso = null;
                DocumentoEmissaoEBO.nomePessoaProponente = null;
                DocumentoEmissaoEBO.dataNascimentoPessoaProponente = null;
                DocumentoEmissaoEBO.numeroCalculoCnpjCpfProponente = null;
                DocumentoEmissaoEBO.codigoCorretorPrincipal = null;
                DocumentoEmissaoEBO.dataCalculo = null;
                DocumentoEmissaoEBO.dataValidade = null;
                DocumentoEmissaoEBO.dataMelhorDataPrimeiraParcela = null;
                DocumentoEmissaoEBO.dataInicioVigenciaSeguro = null;
                DocumentoEmissaoEBO.dataFimVigenciaSeguro = null;
                DocumentoEmissaoEBO.codigoParceiroNegocio = null;
                DocumentoEmissaoEBO.numeroVersaoParceiroNegocio = null;
                DocumentoEmissaoEBO.codigoOnus = null;
                DocumentoEmissaoEBO.codigoFormaPagamento = null;
                DocumentoEmissaoEBO.codigoClasseProfissionalLiberal = null;
                DocumentoEmissaoEBO.codigoCanal = null;
                DocumentoEmissaoEBO.codigoMoeda = null;
                DocumentoEmissaoEBO.codigoMotivoRecusa = null;
                DocumentoEmissaoEBO.codigoTipoCalculo = null;
                DocumentoEmissaoEBO.codigoTipoClassificacaoPessoa = null;
                DocumentoEmissaoEBO.codigoTipoEndosso = null;
                DocumentoEmissaoEBO.codigoTipoSeguro = null;
                DocumentoEmissaoEBO.codigoTipoVigencia = null;
                DocumentoEmissaoEBO.codigoTipoRenovacao = null;
                DocumentoEmissaoEBO.numeroProcessoLicitacao = null;
                DocumentoEmissaoEBO.codigoTipoLicitacao = null;
                DocumentoEmissaoEBO.codigoOrigemRenovacao = null;
                DocumentoEmissaoEBO.codigoOperacao = null;
                DocumentoEmissaoEBO.dataInicioVigenciaVersaoOrcamento = null;
                DocumentoEmissaoEBO.dataFimVigenciaVersaoOrcamento = null;
                DocumentoEmissaoEBO.valorAdicionalFracionamento = null;
                DocumentoEmissaoEBO.valorCustoApolice = null;
                DocumentoEmissaoEBO.valorEncargo = null;
                DocumentoEmissaoEBO.valorPremio = null;
                DocumentoEmissaoEBO.textoComentario = null;
                DocumentoEmissaoEBO.codigoClassificacaoCreditoPessoa = null;
                DocumentoEmissaoEBO.quantidadeDiaVigenciaSeguro = null;
                DocumentoEmissaoEBO.codigoTipoDocumento = null;
                DocumentoEmissaoEBO.codigoMotivoEndossoCancelamento = null;
                //Rebaseline 96.44.15 - Begin
                // DocumentoEmissaoEBO.numeroSequenciaRegistroTituloCapitalizacao = null;
                // DocumentoEmissaoEBO.flagSolicitacaoCartaoCredito = null;
                // DocumentoEmissaoEBO.codigoFaixaResgatePonto = null;
                //Rebaseline 96.44.15 - End
                //Rebaseline 96.48.27 R2_Rebase - Begin
                // DocumentoEmissaoEBO.codigoTipoPessoaProponente = null;
                //Rebaseline 96.48.27 R2_Rebase - End
                DocumentoEmissaoEBO.enderecoCobranca = {};
                DocumentoEmissaoEBO.enderecoCorrespondencia = {};
                DocumentoEmissaoEBO.dadosPessoaSegurado = {};
                DocumentoEmissaoEBO.pagador = [];
                DocumentoEmissaoEBO.analise = [];
                DocumentoEmissaoEBO.corretor = [];
                DocumentoEmissaoEBO.interveniente = [];
                DocumentoEmissaoEBO.pendencia = [];
                //DocumentoEmissaoEBO.clausula = [];
                //DocumentoEmissaoEBO.beneficio = [];
                DocumentoEmissaoEBO.formasPagamento = {};
                DocumentoEmissaoEBO.criticas = {};
                //DocumentoEmissaoEBO.respostaQuestionario = [];
                //DocumentoEmissaoEBO.descontoAgravo = [];
                DocumentoEmissaoEBO.auditoria = {};
                DocumentoEmissaoEBO.ItensDocumentoEmissao = {};

                //added fields
                DocumentoEmissaoEBO.flagEndossoAlteracaoDadoCadastralSegurado = null;
                DocumentoEmissaoEBO.nomeProcessoSistemaGerenciamentoProcesso = null;
                DocumentoEmissaoEBO.flagBloqueio = null;
                DocumentoEmissaoEBO.dataBloqueio = null;
                DocumentoEmissaoEBO.codigoTipoUsuarioBloqueio = null;
                DocumentoEmissaoEBO.codigoEmpresaUsuarioBloqueio = null;
                DocumentoEmissaoEBO.codigoMatriculaUsuarioBloqueio = null;

                //SM 393 - inclusão de campos
                DocumentoEmissaoEBO.flagVinculoSeguroAuto = null;
                DocumentoEmissaoEBO.flagVinculoSeguroOutroNegocio = null;
                DocumentoEmissaoEBO.quantidadeSeguroOutroNegocio = null;

            }
            var documentoEmissao = angular.copy(DocumentoEmissaoEBO);
            return documentoEmissao;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertHistoricoEndosso
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         *
         * Converts the Historico Endosso List.
         *
         **/
        function convertHistoricoEndosso(items) {

            var convertedItems = [];
            angular.forEach(items, function(item) {
                var convertedItem = {};
                convertedItem.codigoTipoMovimentoEndosso = item.codigoTipoMovimentoEndosso;
                convertedItem.textoDescricaoOcorrencia = item.textoDescricaoOcorrencia;
                convertedItem.numeroItemVersaoOrcamento = item.numeroItemVersaoOrcamento;

                convertedItems.push(convertedItem);
            });

            return convertedItems;
        }

        function setValueToComponenteListaItemsList(values) {
            var componenteListaItems = [];
            if (angular.isDefined(values)) {
                angular.forEach(values, function(value) {
                    var componenteListaItem = setValueToComponenteListaItem(value);
                    componenteListaItems.push(componenteListaItem);
                });
            }
            return componenteListaItems;
        }

        function setValueToComponenteListaItem(value) {
            return new ComponenteListaItem(value);
        }

        //ComponenteListaItemEBO
        function ComponenteListaItem(value) {
            var componenteListaItem = this;
            if (value !== undefined && value !== null) {
                componenteListaItem.codigoComponenteListaItem = value.codigoComponenteListaItem;
                componenteListaItem.codigoListaValor = value.codigoListaValor;
                componenteListaItem.codigoMascaraQuestao = value.codigoMascaraQuestao;
                componenteListaItem.codigoTipoQuestao = value.codigoTipoQuestao;
                componenteListaItem.flagAtivo = value.flagAtivo;
                componenteListaItem.textoComentario = value.textoComentario;
            } else {
                componenteListaItem.codigoComponenteListaItem = null;
                componenteListaItem.codigoListaValor = null;
                componenteListaItem.codigoMascaraQuestao = null;
                componenteListaItem.codigoTipoQuestao = null;
                componenteListaItem.flagAtivo = null;
                componenteListaItem.textoComentario = null;
            }
            return componenteListaItem;
        }

        function setValueToCoberturaItemsList(values) {
            var coberturaItems = [];
            if (angular.isDefined(values)) {
                angular.forEach(values, function(value) {
                    var coberturaItem = setValueToCoberturaItem(value);
                    coberturaItems.push(coberturaItem);
                });
            }
            return coberturaItems;
        }

        function setValueToCoberturaItem(value) {
            return new CoberturaItem(value);
        }

        //CoberturaItemDocumentoEBO
        function CoberturaItem(value) {
            var coberturaItem = this;
            if (value !== undefined && value !== null) {
                coberturaItem.codigoCobertura = value.codigoCobertura;
                coberturaItem.codigoEmpresa = value.codigoEmpresa;
                coberturaItem.codigoRamo = value.codigoRamo;
                coberturaItem.codigoModalidade = value.codigoModalidade;
                coberturaItem.codigoTextoParticipacaoSegurado = value.codigoTextoParticipacaoSegurado;
                coberturaItem.numeroVersaoTextoParticipacaoSegurado = value.numeroVersaoTextoParticipacaoSegurado;
                coberturaItem.textoParticipacaoSegurado = value.textoParticipacaoSegurado;
                coberturaItem.valorLimiteMaximoIndenizacao = value.valorLimiteMaximoIndenizacao;
                coberturaItem.valorPremio = value.valorPremio;
                coberturaItem.valorImpostoOperacaoFinanceira = value.valorImpostoOperacaoFinanceira;
                coberturaItem.percentualTaxaFixo = value.percentualTaxaFixo;
                coberturaItem.flagCoberturaBase = value.flagCoberturaBase;
                coberturaItem.percentualParticipacaoSegurado = value.percentualParticipacaoSegurado;
                coberturaItem.valorParticipacaoSegurado = value.valorParticipacaoSegurado;
                coberturaItem.descontosAgravosCoberturaItem =
                    setValueToDescontosAgravosCoberturaItemsList(value.descontosAgravosCoberturaItem);

                coberturaItem.respostasQuestionarioCoberturaItem =
                    setValueToRespostasQuestionarioCoberturaItemsList(value.respostasQuestionarioCoberturaItem);

                coberturaItem.listaItemCobertura = setValueToListaItemCobertura(value.listaItemCobertura);
                coberturaItem.beneficiarios = setValueToBeneficiariossList(value.beneficiarios);
            } else {
                coberturaItem.codigoCobertura = null;
                coberturaItem.codigoEmpresa = null;
                coberturaItem.codigoRamo = null;
                coberturaItem.codigoModalidade = null;
                coberturaItem.codigoTextoParticipacaoSegurado = null;
                coberturaItem.numeroVersaoTextoParticipacaoSegurado = null;
                coberturaItem.textoParticipacaoSegurado = null;
                coberturaItem.valorLimiteMaximoIndenizacao = null;
                coberturaItem.valorPremio = null;
                coberturaItem.valorImpostoOperacaoFinanceira = null;
                coberturaItem.percentualTaxaFixo = null;
                coberturaItem.flagCoberturaBase = null;
                coberturaItem.percentualParticipacaoSegurado = null;
                coberturaItem.valorParticipacaoSegurado = null;
                coberturaItem.descontosAgravosCoberturaItem = [];
                coberturaItem.respostasQuestionarioCoberturaItem = [];
                coberturaItem.listaItemCobertura = {};
                coberturaItem.beneficiarios = [];
            }
            return coberturaItem;
        }

        function setValueToListaItemCobertura(value) {
            return new ListaItemCobertura(value);
        }

        //ListaItemCoberturaEBO
        function ListaItemCobertura(value) {
            var listaItemCobertura = this;
            if (value !== undefined && value !== null) {
                listaItemCobertura.codigoListaItem = value.codigoListaItem;
            } else {
                listaItemCobertura.codigoListaItem = null;
            }
            return listaItemCobertura;
        }


        function setValueToListaItens(value) {
            return new ListaItens(value);
        }

        //ListaItensEBO
        function ListaItens(value) {
            var listaItens = this;
            if (value !== undefined && value !== null) {
                listaItens.codigoListaItem = value.codigoListaItem;
                listaItens.nomeListaItem = value.nomeListaItem;
                listaItens.componentesListaItem = setValueToComponenteListaItemsList(value.componentesListaItem);
            } else {
                listaItens.codigoListaItem = null;
                listaItens.nomeListaItem = null;
                listaItens.componentesListaItem = [];
            }
            return listaItens;
        }


        function setValueToBeneficiariossList(values) {
            var beneficiarioss = [];
            if (angular.isDefined(values)) {
                angular.forEach(values, function(value) {
                    var beneficiarios = setValueToBeneficiarios(value);
                    beneficiarioss.push(beneficiarios);
                });
            }
            return beneficiarioss;
        }

        function setValueToBeneficiarios(value) {
            return new Beneficiarios(value);
        }

        //BeneficiarioEBO
        function Beneficiarios(value) {
            var beneficiarios = this;
            if (value) {
                beneficiarios.codigoBeneficiario = value.codigoBeneficiario;
                beneficiarios.dadosPessoa = value.dadosPessoa;
                beneficiarios.codigoListaItem = value.codigoListaItem;
                beneficiarios.codigoTipoBem = value.codigoTipoBem;
                beneficiarios.valorTipoBem = value.valorTipoBem;
            } else {
                beneficiarios.codigoBeneficiario = null;
                beneficiarios.dadosPessoa = null;
                beneficiarios.codigoListaItem = null;
                beneficiarios.codigoTipoBem = null;
                beneficiarios.valorTipoBem = null;
            }
            return beneficiarios;
        }


        function setValueToRespostasListaQuestionariosList(values) {
            var respostasListaQuestionarios = [];
            if (angular.isDefined(values)) {
                angular.forEach(values, function(value) {
                    var respostasListaQuestionario = setValueToRespostasListaQuestionario(value);
                    respostasListaQuestionarios.push(respostasListaQuestionario);
                });
            }
            return respostasListaQuestionarios;
        }

        function setValueToRespostasListaQuestionario(value) {
            return new RespostasListaQuestionario(value);
        }

        //RespostaListaItemEBO
        function RespostasListaQuestionario(value) {
            var respostasListaQuestionario = this;
            if (value !== undefined && value !== null) {
                respostasListaQuestionario.codigoListaItem = value.codigoListaItem;
                respostasListaQuestionario.componenteListaItem = setValueToComponenteListaItem(value.componenteListaItem);
                respostasListaQuestionario.codigoItem = value.codigoItem;
                respostasListaQuestionario.dataResposta = value.dataResposta;
                respostasListaQuestionario.textoResposta = value.textoResposta;
            } else {
                respostasListaQuestionario.codigoListaItem = null;
                respostasListaQuestionario.componenteListaItem = {};
                respostasListaQuestionario.codigoItem = null;
                respostasListaQuestionario.dataResposta = null;
                respostasListaQuestionario.textoResposta = null;
            }
            return respostasListaQuestionario;
        }

        function setValueToDescontosAgravosCoberturaItemsList(values) {
            var descontosAgravosCoberturaItems = [];
            if (angular.isDefined(values)) {
                angular.forEach(values, function(value) {
                    var descontosAgravosCoberturaItem = setValueToDescontosAgravosCoberturaItem(value);
                    descontosAgravosCoberturaItems.push(descontosAgravosCoberturaItem);
                });
            }
            return descontosAgravosCoberturaItems;
        }

        function setValueToDescontosAgravosCoberturaItem(value) {
            return new DescontosAgravosCoberturaItem(value);
        }

        function setValueToRespostasQuestionarioCoberturaItemsList(values) {
            var respostasQuestionarioCoberturaItems = [];
            if (angular.isDefined(values)) {
                angular.forEach(values, function(value) {
                    var respostasQuestionarioCoberturaItem = setValueToRespostasQuestionarioCoberturaItem(value);
                    respostasQuestionarioCoberturaItems.push(respostasQuestionarioCoberturaItem);
                });
            }
            return respostasQuestionarioCoberturaItems;
        }

        function setValueToRespostasQuestionarioCoberturaItem(value) {
            return new RespostasQuestionarioCoberturaItem(value);
        }

        //RespostaQuestionarioEBO
        function RespostasQuestionarioCoberturaItem(value) {
            var respostasQuestionarioCoberturaItem = this;
            if (value !== undefined && value !== null) {
                respostasQuestionarioCoberturaItem.codigoQuestionario = value.codigoQuestionario;
                respostasQuestionarioCoberturaItem.numeroVersaoQuestionario = value.numeroVersaoQuestionario;
                respostasQuestionarioCoberturaItem.codigoQuestao = value.codigoQuestao;
                respostasQuestionarioCoberturaItem.codigoTipoQuestao = value.codigoTipoQuestao;
                respostasQuestionarioCoberturaItem.codigoResposta = value.codigoResposta;
                respostasQuestionarioCoberturaItem.dataResposta = value.dataResposta;
                respostasQuestionarioCoberturaItem.textoResposta = value.textoResposta;
                respostasQuestionarioCoberturaItem.respostasListaQuestionario =
                    setValueToRespostasListaQuestionariosList(value.respostasListaQuestionario);
            } else {
                respostasQuestionarioCoberturaItem.codigoQuestionario = null;
                respostasQuestionarioCoberturaItem.numeroVersaoQuestionario = null;
                respostasQuestionarioCoberturaItem.codigoQuestao = null;
                respostasQuestionarioCoberturaItem.codigoTipoQuestao = null;
                respostasQuestionarioCoberturaItem.codigoResposta = null;
                respostasQuestionarioCoberturaItem.dataResposta = null;
                respostasQuestionarioCoberturaItem.textoResposta = null;
                respostasQuestionarioCoberturaItem.respostasListaQuestionario = {};
            }
            return respostasQuestionarioCoberturaItem;
        }

        //DescontoAgravoEBO
        function DescontosAgravosCoberturaItem(value) {
            var descontosAgravosCoberturaItem = this;
            if (value !== undefined && value !== null) {
                descontosAgravosCoberturaItem.codigoDescontoAgravo = value.codigoDescontoAgravo;
                descontosAgravosCoberturaItem.percentualDescontoAgravo = value.percentualDescontoAgravo;
                descontosAgravosCoberturaItem.valorDescontoAgravo = value.valorDescontoAgravo;
                descontosAgravosCoberturaItem.codigoTipoDescontoAgravo = value.codigoTipoDescontoAgravo;
            } else {
                descontosAgravosCoberturaItem.codigoDescontoAgravo = null;
                descontosAgravosCoberturaItem.percentualDescontoAgravo = null;
                descontosAgravosCoberturaItem.valorDescontoAgravo = null;
                descontosAgravosCoberturaItem.codigoTipoDescontoAgravo = null;
            }
            return descontosAgravosCoberturaItem;
        }


        function setValueToCoberturasItem(value) {
            return new CoberturasItem(value);
        }

        //CoberturasItemEBO
        function CoberturasItem(value) {
            var coberturasItem = this;
            if (value !== undefined && value !== null) {
                coberturasItem.valorPremioCobertura = value.valorPremioCobertura;
                coberturasItem.coberturaItem = setValueToCoberturaItemsList(value.coberturaItem);
            } else {
                coberturasItem.valorPremioCobertura = null;
                coberturasItem.coberturaItem = [];
            }
            return coberturasItem;
        }

        function setValueToItemDocumentoEmissaoEBOsList(values) {
            var itensDocumentoEmissao = [];
            if (values && values.length > 0) {
                angular.forEach(values, function(value) {
                    var itemDocumentoEmissao = setValueToItemDocumentoEmissaoEBO(value);
                    itensDocumentoEmissao.push(itemDocumentoEmissao);
                });
            }
            return itensDocumentoEmissao;
        }

        function setValueToItemDocumentoEmissaoEBO(value) {
            return new ItemDocumentoEmissaoEBO(value);
        }

        //ItemDocumentoEmissaoEBO
        function ItemDocumentoEmissaoEBO(value) {
            //var itemDocumentoEmissao = this;
            var itemDocumentoEmissao = [];
            //if (value !== undefined && value !== null)
            if (value) {
                itemDocumentoEmissao.numeroProposta = value.numeroProposta;
                itemDocumentoEmissao.codigoPessoa = value.codigoPessoa;
                itemDocumentoEmissao.numeroVersaoProposta = value.numeroVersaoProposta;
                itemDocumentoEmissao.numeroItemVersaoProposta = value.numeroItemVersaoProposta;
                itemDocumentoEmissao.numeroApoliceAnterior = value.numeroApoliceAnterior;
                itemDocumentoEmissao.codigoOferta = value.codigoOferta;
                itemDocumentoEmissao.numeroVersaoOferta = value.numeroVersaoOferta;
                itemDocumentoEmissao.numeroSequenciaVersaoOferta = value.numeroSequenciaVersaoOferta;
                itemDocumentoEmissao.codigoPlanoCobertura = value.codigoPlanoCobertura;
                itemDocumentoEmissao.codigoObjetoRisco = value.codigoObjetoRisco;
                itemDocumentoEmissao.dataInicioVigenciaSeguro = value.dataInicioVigenciaSeguro;
                itemDocumentoEmissao.dataFimVigenciaSeguro = value.dataFimVigenciaSeguro;
                itemDocumentoEmissao.numeroApoliceCongenere = value.numeroApoliceCongenere;
                itemDocumentoEmissao.textoDescricaoObjetoRisco = value.textoDescricaoObjetoRisco;
                itemDocumentoEmissao.valorPremio = value.valorPremio;
                itemDocumentoEmissao.nomeProgramaCalculo = value.nomeProgramaCalculo;
                itemDocumentoEmissao.numeroVersaoProgramaCalculo = value.numeroVersaoProgramaCalculo;
                itemDocumentoEmissao.quantidadeItem = value.quantidadeItem;
                itemDocumentoEmissao.codigoTipoDocumento = value.codigoTipoDocumento;
                itemDocumentoEmissao.coberturasItem = setValueToCoberturasItem(value.coberturasItem);
                itemDocumentoEmissao.listaItens = setValueToListaItens(value.listaItens);
                itemDocumentoEmissao.criticasItem = setValueToCriticasList(value.criticasItem);
                itemDocumentoEmissao.analisesItem = setValueToAnalisesList(value.analisesItem);
                itemDocumentoEmissao.codigoTipoAtualizacao = value.codigoTipoAtualizacao;
            } else {
                itemDocumentoEmissao.numeroProposta = null;
                itemDocumentoEmissao.codigoPessoa = null;
                itemDocumentoEmissao.numeroVersaoProposta = null;
                itemDocumentoEmissao.numeroItemVersaoProposta = null;
                itemDocumentoEmissao.numeroApoliceAnterior = null;
                itemDocumentoEmissao.codigoOferta = null;
                itemDocumentoEmissao.numeroVersaoOferta = null;
                itemDocumentoEmissao.numeroSequenciaVersaoOferta = null;
                itemDocumentoEmissao.codigoPlanoCobertura = null;
                itemDocumentoEmissao.codigoObjetoRisco = null;
                itemDocumentoEmissao.dataInicioVigenciaSeguro = null;
                itemDocumentoEmissao.dataFimVigenciaSeguro = null;
                itemDocumentoEmissao.numeroApoliceCongenere = null;
                itemDocumentoEmissao.textoDescricaoObjetoRisco = null;
                itemDocumentoEmissao.valorPremio = null;
                itemDocumentoEmissao.nomeProgramaCalculo = null;
                itemDocumentoEmissao.numeroVersaoProgramaCalculo = null;
                itemDocumentoEmissao.quantidadeItem = null;
                itemDocumentoEmissao.codigoTipoDocumento = null;
                itemDocumentoEmissao.coberturasItem = {};
                itemDocumentoEmissao.listaItens = {};
                itemDocumentoEmissao.criticasItem = {};
                itemDocumentoEmissao.analisesItem = [];
                itemDocumentoEmissao.codigoTipoAtualizacao = null;
            }
            return itemDocumentoEmissao;
        }

        function setValueToDevolutivasList(values) {
            var devolutivas = [];
            if (angular.isDefined(values)) {
                angular.forEach(values, function(value) {
                    var devolutiva = setValueToDevolutiva(value);
                    devolutivas.push(devolutiva);
                });
            }
            return devolutivas;
        }

        function setValueToDevolutiva(value) {
            return new Devolutiva(value);
        }

        //DevolutivaEBO
        function Devolutiva(value) {
            var devolutiva = this;
            if (value !== undefined && value !== null) {
                devolutiva.codigoDevolutiva = value.codigoDevolutiva;
                devolutiva.nomeDevolutiva = value.nomeDevolutiva;
                devolutiva.nomeResumidoDevolutiva = value.nomeResumidoDevolutiva;
                devolutiva.codigoTipoDevolutiva = value.codigoTipoDevolutiva;
                devolutiva.codigoModeloCarta = value.codigoModeloCarta;
                devolutiva.flagAtivo = value.flagAtivo;
                devolutiva.textoComentario = value.textoComentario;
            } else {
                devolutiva.codigoDevolutiva = null;
                devolutiva.nomeDevolutiva = null;
                devolutiva.nomeResumidoDevolutiva = null;
                devolutiva.codigoTipoDevolutiva = null;
                devolutiva.codigoModeloCarta = null;
                devolutiva.flagAtivo = null;
                devolutiva.textoComentario = null;
            }
            return devolutiva;
        }

        function setValueToCriticasList(values) {
            var criticas = [];
            if (angular.isDefined(values)) {
                angular.forEach(values, function(value) {
                    var critica = setValueToCritica(value);
                    criticas.push(critica);
                });
            }
            return criticas;
        }

        function setValueToCritica(value) {
            return new Critica(value);
        }

        //CriticaEBO
        function Critica(value) {
            var critica = this;
            if (value !== undefined && value !== null) {
                critica.codigoCritica = value.codigoCritica;
                critica.dataCritica = value.dataCritica;
                critica.textoRetornoCritica = value.textoRetornoCritica;
                critica.nomeResumidoCritica = value.nomeResumidoCritica;
                critica.nomeCritica = value.nomeCritica;
                critica.codigoTipoCritica = value.codigoTipoCritica;
                critica.codigoStatusCritica = value.codigoStatusCritica;
                critica.codigoGrupoAcesso = value.codigoGrupoAcesso;
                critica.textoCritica = value.textoCritica;
                critica.flagJustificativaLiberacaoObrigatorio = value.flagJustificativaLiberacaoObrigatorio;
                critica.flagAtivo = value.flagAtivo;
                critica.textoComentario = value.textoComentario;
                critica.devolutiva = setValueToDevolutivasList(value.devolutiva);
            } else {
                critica.codigoCritica = null;
                critica.dataCritica = null;
                critica.textoRetornoCritica = null;
                critica.nomeResumidoCritica = null;
                critica.nomeCritica = null;
                critica.codigoTipoCritica = null;
                critica.codigoStatusCritica = null;
                critica.codigoGrupoAcesso = null;
                critica.textoCritica = null;
                critica.flagJustificativaLiberacaoObrigatorio = null;
                critica.flagAtivo = null;
                critica.textoComentario = null;
                critica.devolutiva = [];
            }
            return critica;
        }


        function setValueToFormaPagamentosList(values) {
            var formaPagamentos = [];
            if (angular.isDefined(values)) {
                angular.forEach(values, function(value) {
                    var formaPagamento = setValueToFormaPagamento(value);
                    formaPagamentos.push(formaPagamento);
                });
            }
            return formaPagamentos;
        }

        function setValueToFormaPagamento(value) {
            return new FormaPagamento(value);
        }

        //FormaPagamentoEBO
        function FormaPagamento(value) {
            var formaPagamento = this;
            if (value !== undefined && value !== null) {
                formaPagamento.codigoFormaPagamento = value.codigoFormaPagamento;
                formaPagamento.valorPrimeiraParcela = value.valorPrimeiraParcela;
                formaPagamento.valorDemaisParcela = value.valorDemaisParcela;
                formaPagamento.valorImpostoOperacaoFinanceira = value.valorImpostoOperacaoFinanceira;
                formaPagamento.valorAdicionalFracionamento = value.valorAdicionalFracionamento;
                formaPagamento.valorEncargo = value.valorEncargo;
                formaPagamento.valorPremioCobertura = value.valorPremioCobertura;
                formaPagamento.valorPremioClausula = value.valorPremioClausula;
                formaPagamento.valorPremioServico = value.valorPremioServico;
                formaPagamento.flagImpressaoFormaPagamento = value.flagImpressaoFormaPagamento;
                formaPagamento.codigoMeioPagamentoPrimeiraParcela = value.codigoMeioPagamentoPrimeiraParcela;
                formaPagamento.codigoMeioPagamentoDemaisParcela = value.codigoMeioPagamentoDemaisParcela;
                formaPagamento.nomeResumidoFormaPagamento = value.nomeResumidoFormaPagamento;
                formaPagamento.nomeFormaPagamento = value.nomeFormaPagamento;
                formaPagamento.quantidadeParcela = value.quantidadeParcela;
                formaPagamento.flagAtivo = value.flagAtivo;
                formaPagamento.textoComentario = value.textoComentario;
                formaPagamento.valorPremioSubvencaoEstadualAgronegocio = value.valorPremioSubvencaoEstadualAgronegocio;
                formaPagamento.valorPremioSubvencaoFederalAgronegocio = value.valorPremioSubvencaoFederalAgronegocio;
                formaPagamento.numeroOrdemExibicao = value.numeroOrdemExibicao;
            } else {
                formaPagamento.codigoFormaPagamento = null;
                formaPagamento.valorPrimeiraParcela = null;
                formaPagamento.valorDemaisParcela = null;
                formaPagamento.valorImpostoOperacaoFinanceira = null;
                formaPagamento.valorAdicionalFracionamento = null;
                formaPagamento.valorEncargo = null;
                formaPagamento.valorPremioCobertura = null;
                formaPagamento.valorPremioClausula = null;
                formaPagamento.valorPremioServico = null;
                formaPagamento.flagImpressaoFormaPagamento = null;
                formaPagamento.codigoMeioPagamentoPrimeiraParcela = null;
                formaPagamento.codigoMeioPagamentoDemaisParcela = null;
                formaPagamento.nomeResumidoFormaPagamento = null;
                formaPagamento.nomeFormaPagamento = null;
                formaPagamento.quantidadeParcela = null;
                formaPagamento.flagAtivo = null;
                formaPagamento.textoComentario = null;
                formaPagamento.valorPremioSubvencaoEstadualAgronegocio = null;
                formaPagamento.valorPremioSubvencaoFederalAgronegocio = null;
                formaPagamento.numeroOrdemExibicao = null;
            }
            return formaPagamento;
        }

        function setValueToRespostaPendenciasList(values) {
            var respostaPendencias = [];
            if (values) {
                angular.forEach(values, function(value) {
                    var respostaPendencia = setValueToRespostaPendencia(value);
                    respostaPendencias.push(respostaPendencia);
                });
            }
            return respostaPendencias;
        }

        function setValueToRespostaPendencia(value) {
            return new RespostaPendencia(value);
        }

        //RespostaPendenciaEBO
        function RespostaPendencia(value) {
            var respostaPendencia = this;
            if (value) {
                respostaPendencia.numeroSequenciaRespostaPendencia = value.numeroSequenciaRespostaPendencia;
                respostaPendencia.codigoCorretor = value.codigoCorretor;
                respostaPendencia.dataResposta = value.dataResposta;
                respostaPendencia.textoRespostaPendencia = value.textoRespostaPendencia;
                respostaPendencia.flagPossuiAnexo = value.flagPossuiAnexo;
                respostaPendencia.codigoIdentificacaoDocumento = value.codigoIdentificacaoDocumento;
                respostaPendencia.auditoria = setValueToAuditoria(value.auditoria);
            } else {
                respostaPendencia.numeroSequenciaRespostaPendencia = null;
                respostaPendencia.codigoCorretor = null;
                respostaPendencia.dataResposta = null;
                respostaPendencia.textoRespostaPendencia = null;
                respostaPendencia.flagPossuiAnexo = null;
                respostaPendencia.codigoIdentificacaoDocumento = null;
                respostaPendencia.auditoria = {};
            }
            return respostaPendencia;
        }

        function setValueToPendenciasList(values) {
            var pendencias = [];
            if (values) {
                angular.forEach(values, function(value) {
                    var pendencia = setValueToPendencia(value);
                    pendencias.push(pendencia);
                });
            }
            return pendencias;
        }

        function setValueToPendencia(value) {
            return new Pendencia(value);
        }

        //PendenciaEBO
        function Pendencia(value) {
            var pendencia = this;
            if (value) {
                pendencia.codigoPendencia = value.codigoPendencia;
                pendencia.numeroSequenciaPendencia = value.numeroSequenciaPendencia;
                pendencia.codigoStatusPendencia = value.codigoStatusPendencia;
                pendencia.codigoDevolutiva = value.codigoDevolutiva;
                pendencia.codigoCorretor = value.codigoCorretor;
                pendencia.textoPendencia = value.textoPendencia;
                pendencia.dataRegistroAbertura = value.dataRegistroAbertura;
                pendencia.respostaPendencia = setValueToRespostaPendenciasList(value.respostaPendencia);
            } else {
                pendencia.codigoPendencia = null;
                pendencia.numeroSequenciaPendencia = null;
                pendencia.codigoStatusPendencia = null;
                pendencia.codigoDevolutiva = null;
                pendencia.codigoCorretor = null;
                pendencia.textoPendencia = null;
                pendencia.dataRegistroAbertura = null;
                pendencia.respostaPendencia = {};
            }
            return pendencia;
        }

        function setValueToIntervenientesList(values) {
            var intervenientes = [];
            if (angular.isDefined(values)) {
                angular.forEach(values, function(value) {
                    var interveniente = setValueToInterveniente(value);
                    intervenientes.push(interveniente);
                });
            }
            return intervenientes;
        }

        function setValueToDadosPessoaInterveniente(value) {
            return new DadosPessoaSegurado(value);
        }

        function setValueToInterveniente(value) {
            return new Interveniente(value);
        }

        function Interveniente(value) {
            var interveniente = this;
            if (value) {
                interveniente.codigoInterveniente = value.codigoInterveniente;
                interveniente.codigoTipoInterveniente = value.codigoTipoInterveniente;
                interveniente.codigoTipoPessoa = value.codigoTipoPessoa;
                interveniente.numeroCnpjCpf = value.numeroCnpjCpf;
                interveniente.nomeInterveniente = value.nomeInterveniente;
                interveniente.codigoTipoExposicaoPessoa = value.codigoTipoExposicaoPessoa;
                interveniente.codigoMotivoAusenciaCnpjCpf = value.codigoMotivoAusenciaCnpjCpf;
                interveniente.percentualParticipacao = value.percentualParticipacao;
                interveniente.flagAtivo = value.flagAtivo;

                interveniente.dadosPessoaInterveniente = setValueToDadosPessoaInterveniente(value.dadosPessoaInterveniente);
                interveniente.exposicoes = {};
                if (value.exposicoes && angular.isArray(value.exposicoes.exposicao)) {
                    interveniente.exposicoes.exposicao = setValueToExposicaosList(value.exposicoes.exposicao);
                }

            } else {
                interveniente.codigoInterveniente = null;
                interveniente.codigoTipoInterveniente = null;
                interveniente.dadosPessoaInterveniente = {};
                interveniente.codigoTipoPessoa = null;
                interveniente.numeroCnpjCpf = null;
                interveniente.nomeInterveniente = null;
                interveniente.codigoTipoExposicaoPessoa = null;
                interveniente.codigoMotivoAusenciaCnpjCpf = null;
                interveniente.percentualParticipacao = null;
                interveniente.flagAtivo = null;
                interveniente.exposicoes = {};
            }
            return interveniente;
        }

        function setValueToExposicaosList(values) {
            var exposicaos = [];
            if (values) {
                angular.forEach(values, function(value) {
                    var exposicao = setValueToExposicao(value);
                    exposicaos.push(exposicao);
                });
            }
            return exposicaos;
        }

        function setValueToExposicao(value) {
            return new Exposicao(value);
        }

        //ExposicaoEBO
        function Exposicao(value) {
            var exposicao = this;
            if (value) {
                exposicao.codigoExposicaoInterveniente = value.codigoExposicaoInterveniente;
                exposicao.codigoTipoVinculo = value.codigoTipoVinculo;
                exposicao.codigoPessoaExposto = value.codigoPessoaExposto;
                exposicao.codigoTipoPessoaExposto = value.codigoTipoPessoaExposto;
                exposicao.numeroCnpjCpfPessoaExposto = value.numeroCnpjCpfPessoaExposto;
                exposicao.nomePessoaExposto = value.nomePessoaExposto;
                exposicao.flagAtivo = value.flagAtivo;
            } else {
                exposicao.codigoExposicaoInterveniente = null;
                exposicao.codigoTipoVinculo = null;
                exposicao.codigoPessoaExposto = null;
                exposicao.codigoTipoPessoaExposto = null;
                exposicao.numeroCnpjCpfPessoaExposto = null;
                exposicao.nomePessoaExposto = null;
                exposicao.flagAtivo = null;
            }
            return exposicao;
        }

        function setValueToCorretorsList(values) {
            var corretors = [];
            if (angular.isDefined(values)) {
                angular.forEach(values, function(value) {
                    var corretor = setValueToCorretor(value);
                    corretors.push(corretor);
                });
            }
            return corretors;
        }

        function setValueToCorretor(value) {
            return new Corretor(value);
        }

        //CorretorEBO
        function Corretor(value) {
            var corretor = this;
            if (value) {
                corretor.codigoCorretor = value.codigoCorretor;
                corretor.codigoSucursal = value.codigoSucursal;
                corretor.flagPrincipal = value.flagPrincipal;
                corretor.percentualParticipacao = value.percentualParticipacao;
                corretor.valorComissao = value.valorComissao;
                corretor.flagAtivo = value.flagAtivo;
            } else {
                corretor.codigoCorretor = null;
                corretor.codigoSucursal = null;
                corretor.flagPrincipal = null;
                corretor.percentualParticipacao = null;
                corretor.valorComissao = null;
                corretor.flagAtivo = null;
            }
            return corretor;
        }

        function setValueToAnalisesList(values) {
            var analises = [];
            if (angular.isDefined(values)) {
                angular.forEach(values, function(value) {
                    var analise = setValueToAnalise(value);
                    analises.push(analise);
                });
            }
            return analises;
        }

        function setValueToAnalise(value) {
            return new Analise(value);
        }

        //AnaliseEBO
        function Analise(value) {
            var analise = this;
            if (value !== undefined && value !== null) {
                analise.numeroSequenciaAnalise = value.numeroSequenciaAnalise;
                analise.codigoTipoParecer = value.codigoTipoParecer;
                analise.codigoStatusParecer = value.codigoStatusParecer;
                analise.textoAnalise = value.textoAnalise;

            } else {
                analise.numeroSequenciaAnalise = null;
                analise.codigoTipoParecer = null;
                analise.codigoStatusParecer = null;
                analise.textoAnalise = null;
            }
            return analise;
        }

        function setValueToPagadorsList(values, dadosPessoaSegurado, cartao) {
            var pagadors = [];

            if (angular.isDefined(values)) {
                angular.forEach(values, function(value) {
                    var pagador = setValueToPagador(value, dadosPessoaSegurado, cartao);
                    pagadors.push(pagador);
                });
            }

            return pagadors;
        }

        function setValueToPagador(value, dadosPessoaSegurado, cartao) {
            return new Pagador(value, dadosPessoaSegurado, cartao);
        }

        //PagadorEBO
        function Pagador(value, dadosPessoaSegurado, cartao) {
            var pagador = this;

            if (value) {
                //PessoaEBO
                pagador.dadosPessoaPagador = setValueToDadosPessoaPagador(value.dadosPessoaPagador);

                //EnderecoEBO
                pagador.enderecoCobranca = value.enderecoCobranca;
                //pagador.enderecoCobranca = setValueToEnderecoCobranca(value.enderecoCobranca);

                //PagadorParcelaEBO
                pagador.pagadoresParcela = {};
                if (value.pagadoresParcela &&
                    angular.isArray(value.pagadoresParcela.pagadorParcela)) {
                    pagador.pagadoresParcela.pagadorParcela = setValueToPagadorParcelasList(value.pagadoresParcela.pagadorParcela, cartao);
                } else {
                    //pagador.dadosPessoaPagador = null;
                    //pagador.enderecoCobranca = null;
                    pagador.pagadoresParcela = null;
                }

                return pagador;
            }
        }

        function setValueToPagadorParcelasList(values, cartao) {
            var pagadorParcelas = [];

            if (values && values.length > 0) {
                angular.forEach(values, function(value) {
                    var pagadorParcela = setValueToPagadorParcela(value, cartao);
                    pagadorParcelas.push(pagadorParcela);
                });
            }

            return pagadorParcelas;
        }

        function setValueToPagadorParcela(value, cartao) {
            return new PagadorParcela(value, cartao);
        }

        //PagadorParcelaEBO
        function PagadorParcela(value, cartao) {
            var pagadorParcela = this;

            if (value) {

                pagadorParcela.dadosPessoaPagadorParcela =
                    setValueToDadosPessoaPagadorParcela(value.dadosPessoaPagadorParcela);

                if (pagadorParcela.dadosPessoaPagadorParcela) {
                    pagadorParcela.dadosPessoaPagadorParcela.numeroCnpjCpf =
                        removeFormat(pagadorParcela.dadosPessoaPagadorParcela.numeroCnpjCpf);
                }

                if (cartao) {
                    pagadorParcela.codigoBandeiroCartao = cartao.bandeira;
                    if (angular.isDefined(cartao.codigoIdentificacaoCartao) && cartao.codigoIdentificacaoCartao !== null) { //numeroConta
                        pagadorParcela.codigoIdentificacaoCartao = cartao.codigoIdentificacaoCartao; //analisar4
                    }
                    if (angular.isDefined(cartao.anoValidadeCartao) && cartao.anoValidadeCartao !== null &&
                        angular.isDefined(cartao.mesValidadeCartao) && cartao.mesValidadeCartao !== null) {
                        var numeroContaDataValidade = cartao.anoValidadeCartao + '-' + cartao.mesValidadeCartao + '-' + '01';
                        pagadorParcela.dataPagamento = convertDateOnly(numeroContaDataValidade);
                    }
                } else {
                    pagadorParcela.codigoIdentificacaoCartao = value.codigoIdentificacaoCartao;
                }

                pagadorParcela.numeroParcela = value.numeroParcela;
                pagadorParcela.dataVencimento = convertDateOnly(value.dataVencimento);

                if (pagadorParcela.codigoBandeiroCartao) {
                    pagadorParcela.codigoTipoCartao = pagadorParcela.codigoBandeiroCartao;
                } else {
                    pagadorParcela.codigoTipoCartao = value.codigoTipoCartao;
                }
                pagadorParcela.codigoBanco = value.codigoBanco;
                pagadorParcela.numeroAgenciaBancaria = value.numeroAgenciaBancaria;
                pagadorParcela.numeroContaBancaria = value.numeroContaBancaria;
                pagadorParcela.digitoContaBancaria = value.digitoContaBancaria;
                pagadorParcela.valorParcela = value.valorParcela;

                //added fields
                pagadorParcela.dataPagamentoContabilizado = convertDateOnly(value.dataPagamentoContabilizado);
                pagadorParcela.dataCancelamento = convertDateOnly(value.dataCancelamento);
                pagadorParcela.codigoStatusParcela = value.codigoStatusParcela;
                pagadorParcela.dataPrazoCobertura = convertDateOnly(value.dataPrazoCobertura);
                // SM 279
                pagadorParcela.textoComentario = value.textoComentario;
                // FIM - SM 279
            } else {
                pagadorParcela.numeroParcela = null;
                pagadorParcela.dataVencimento = null;
                pagadorParcela.codigoTipoCartao = null;
                pagadorParcela.codigoIdentificacaoCartao = null; //analisar5
                pagadorParcela.codigoBanco = null;
                pagadorParcela.numeroAgenciaBancaria = null;
                pagadorParcela.numeroContaBancaria = null;
                pagadorParcela.digitoContaBancaria = null;
                pagadorParcela.valorParcela = null;

                //added fields
                pagadorParcela.dataPagamento = null;
                pagadorParcela.dataPagamentoContabilizado = null;
                pagadorParcela.dataCancelamento = null;
                pagadorParcela.codigoStatusParcela = null;
                pagadorParcela.dataPrazoCobertura = null;
                // FIM - SM 279
                pagadorParcela.textoComentario = null;
                // FIM - SM 279
            }

            return pagadorParcela;
        }

        function validateDate(date) {
            return (new Date(Date.parse(date)) instanceof Date);
        }

        function convertToDate(date) {

        }

        function setValueToDadosPessoaPagadorParcela(value) {
            return new DadosPessoaSegurado(value);
        }

        function setValueToDadosPessoaPagador(value) {
            return new DadosPessoaSegurado(value);
        }

        function setValueToEnderecoCorrespondencia(value) {
            return new Endereco(value);
        }

        function setValueToEnderecoCobranca(value) {
            return new Endereco(value);
        }

        //EnderecoEBO
        function Endereco(value) {
            var endereco = this;

            if (value !== undefined && value !== null) {
                endereco.codigoEndereco = value.codigoEndereco;
                endereco.codigoTipoLogradouro = value.codigoTipoLogradouro;
                endereco.codigoLogradouro = value.codigoLogradouro;
                endereco.nomeLogradouro = value.nomeLogradouro;
                endereco.numeroLogradouro = value.numeroLogradouro;
                endereco.flagSemNumero = value.flagSemNumero;
                endereco.numeroCep = value.numeroCep;
                endereco.nomeComplemento = value.nomeComplemento;
                endereco.codigoBairro = value.codigoBairro;
                endereco.nomeBairro = value.nomeBairro;
                endereco.codigoCidade = value.codigoCidade;
                endereco.nomeCidade = value.nomeCidade;
                endereco.codigoUnidadeFederacao = value.codigoUnidadeFederacao;
                endereco.codigoPais = value.codigoPais;
                endereco.textoPontoReferencia = value.textoComentario;
                endereco.numeroLatitude = value.numeroLatitude;
                endereco.numeroLongitude = value.numeroLongitude;
                endereco.codigoTipoEndereco = value.codigoTipoEndereco;
                endereco.flagPrincipal = value.flagPrincipal;
                endereco.flagAtivo = value.flagAtivo;
            } else {
                endereco.codigoEndereco = null;
                endereco.codigoTipoLogradouro = null;
                endereco.codigoLogradouro = null;
                endereco.nomeLogradouro = null;
                endereco.numeroLogradouro = null;
                endereco.flagSemNumero = 'N';
                endereco.numeroCep = null;
                endereco.nomeComplemento = null;
                endereco.codigoBairro = null;
                endereco.nomeBairro = null;
                endereco.codigoCidade = null;
                endereco.nomeCidade = null;
                endereco.codigoUnidadeFederacao = null;
                endereco.codigoPais = null;
                endereco.textoPontoReferencia = null;
                endereco.numeroLatitude = null;
                endereco.numeroLongitude = null;
                endereco.codigoTipoEndereco = null;
                endereco.flagPrincipal = null;
                endereco.flagAtivo = null;
            }

            return endereco;
        }

        function setValueToDadosPessoaSegurado(value) {
            return new DadosPessoaSegurado(value);
        }

        //PessoaEBO
        function DadosPessoaSegurado(value) {
            var dadosPessoaSegurado = this;

            if (value) {
                dadosPessoaSegurado.codigoPessoa = value.codigoPessoa;
                dadosPessoaSegurado.codigoTipoPessoa = value.codigoTipoPessoa;
                if (value.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA) {
                    if (value.numeroCnpjCpf && !(value.numeroCnpjCpf.length > 11)) {
                        dadosPessoaSegurado.numeroCnpjCpf = cpfFormat(pad(value.numeroCnpjCpf.toString(), 11));
                    } else {
                        dadosPessoaSegurado.numeroCnpjCpf = value.numeroCnpjCpf;
                    }
                } else if (value.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.JURIDICA) {
                    if (value.numeroCnpjCpf && !(value.numeroCnpjCpf.length > 14)) {
                        dadosPessoaSegurado.numeroCnpjCpf = cnpjFormat(pad(value.numeroCnpjCpf.toString(), 14));
                    } else {
                        dadosPessoaSegurado.numeroCnpjCpf = value.numeroCnpjCpf;
                    }
                }
                dadosPessoaSegurado.nomePessoa = value.nomePessoa;
                dadosPessoaSegurado.nomeResumidoPessoa = value.nomeResumidoPessoa;
                dadosPessoaSegurado.flagAtivo = value.flagAtivo;
                dadosPessoaSegurado.pessoaFisica = setValueToPessoaFisica(value.pessoaFisica);
                dadosPessoaSegurado.pessoaJuridica = setValueToPessoaJuridica(value.pessoaJuridica);
                if (value.documentos !== undefined && value.documentos !== null) {
                    dadosPessoaSegurado.documentos = setValueToDocumentosList(value.documentos.documento);
                } else {
                    dadosPessoaSegurado.documentos = [];
                }
                if (value.enderecosPessoa) {
                    dadosPessoaSegurado.enderecosPessoa = setValueToEnderecosPessoaList(value.enderecosPessoa.enderecoPessoa);
                } else {
                    dadosPessoaSegurado.enderecosPessoa = [];
                }
                if (value.contatos) {
                    dadosPessoaSegurado.contatos = setValueToContatosList(value.contatos.contato);
                } else {
                    dadosPessoaSegurado.contatos = [];
                }
                if (value.vinculos) {
                    dadosPessoaSegurado.vinculos = setValueToVinculosList(value.vinculos.vinculo);
                } else {
                    dadosPessoaSegurado.vinculos = [];
                }
                dadosPessoaSegurado.auditoria = setValueToAuditoria(value.auditoria);

            } else {
                dadosPessoaSegurado.codigoPessoa = null;
                dadosPessoaSegurado.codigoTipoPessoa = null;
                dadosPessoaSegurado.numeroCnpjCpf = null;
                dadosPessoaSegurado.nomePessoa = null;
                dadosPessoaSegurado.nomeResumidoPessoa = null;
                dadosPessoaSegurado.flagAtivo = null;
                dadosPessoaSegurado.pessoaFisica = {};
                dadosPessoaSegurado.pessoaJuridica = {};
                dadosPessoaSegurado.documentos = [];
                dadosPessoaSegurado.enderecosPessoa = [];
                dadosPessoaSegurado.contatos = [];
                dadosPessoaSegurado.vinculos = [];
                dadosPessoaSegurado.auditoria = {};
            }

            return dadosPessoaSegurado;
        }

        function setValueToAuditoria(value) {
            return new Auditoria(value);
        }

        //AuditoriaEBO
        function Auditoria(value) {
            var auditoria = this;

            if (value) {
                auditoria.dataUltimaAlteracao = value.dataUltimaAlteracao;
                auditoria.codigoTipoUsuarioUltimaAlteracao = value.codigoTipoUsuarioUltimaAlteracao;
                auditoria.codigoEmpresaUsuarioUltimaAlteracao = value.codigoEmpresaUsuarioUltimaAlteracao;
                auditoria.codigoMatriculaUsuarioUltimaAlteracao = value.codigoMatriculaUsuarioUltimaAlteracao;
            } else {
                auditoria.dataUltimaAlteracao = null;
                auditoria.codigoTipoUsuarioUltimaAlteracao = null;
                auditoria.codigoEmpresaUsuarioUltimaAlteracao = null;
                auditoria.codigoMatriculaUsuarioUltimaAlteracao = null;
            }

            return auditoria;
        }

        function setValueToVinculosList(values) {
            var vinculos = [];

            if (values && values.length > 0) {
                angular.forEach(values, function(value) {
                    var vinculo = setValueToVinculo(value);
                    vinculos.push(vinculo);
                });
            } else {
                vinculos.push({
                    nomePessoaVinculo: null,
                    numeroCnpjCpfPessoaVinculo: null,
                    codigoTipoVinculo: null
                });
            }

            return vinculos;
        }

        function setValueToVinculo(value) {
            return new Vinculo(value);
        }

        //VinculoEBO
        function Vinculo(value) {
            var vinculo = this;

            if (value) {
                vinculo.codigoTipoVinculo = value.codigoTipoVinculo;
                vinculo.codigoPessoaVinculo = value.codigoPessoaVinculo;
                vinculo.codigoTipoPessoaVinculo = value.codigoTipoPessoaVinculo;
                vinculo.numeroCnpjCpfPessoaVinculo = value.numeroCnpjCpfPessoaVinculo;

                // if (value.numeroCnpjCpfPessoaVinculo && value.codigoTipoPessoaVinculo === 1) {
                // 	vinculo.numeroCnpjCpfPessoaVinculo = cpfFormat(pad(value.numeroCnpjCpfPessoaVinculo.toString(), 11));
                // } else if (value.numeroCnpjCpfPessoaVinculo && value.codigoTipoPessoaVinculo === 2) {
                // 	vinculo.numeroCnpjCpfPessoaVinculo = cnpjFormat(pad(value.numeroCnpjCpfPessoaVinculo.toString(), 14));
                // } else {
                // 	vinculo.numeroCnpjCpfPessoaVinculo = null;
                // }

                vinculo.nomePessoaVinculo = value.nomePessoaVinculo;
                vinculo.flagVinculoPessoaExpostaPoliticamente = value.flagVinculoPessoaExpostaPoliticamente;
                vinculo.flagAtivo = value.flagAtivo;
            } else {
                vinculo.codigoTipoVinculo = null;
                vinculo.codigoPessoaVinculo = null;
                vinculo.codigoTipoPessoaVinculo = null;
                vinculo.numeroCnpjCpfPessoaVinculo = null;
                vinculo.nomePessoaVinculo = null;
                vinculo.flagVinculoPessoaExpostaPoliticamente = null;
                vinculo.flagAtivo = null;
            }
        }

        function setValueToPessoaFisica(value) {
            return new PessoaFisica(value);
        }

        //PessoaFisicaEBO
        function PessoaFisica(value) {
            var pessoaFisica = this;

            if (value) {
                pessoaFisica.codigoEstadoCivil = value.codigoEstadoCivil;
                pessoaFisica.codigoFaixaRenda = value.codigoFaixaRenda;
                pessoaFisica.codigoNacionalidade = value.codigoNacionalidade;
                pessoaFisica.codigoOcupacao = value.codigoOcupacao;
                pessoaFisica.codigoSexoPessoa = value.codigoSexoPessoa;
                pessoaFisica.codigoTipoExposicaoPessoa = value.codigoTipoExposicaoPessoa;
                pessoaFisica.dataNascimento = convertDateOnly(value.dataNascimento);
                // pessoaFisica.dataNascimento = convertData(convertDateOnly(value.dataNascimento), value.dataNascimento);
                pessoaFisica.codigoPais = value.codigoPais;
            } else {
                pessoaFisica.codigoEstadoCivil = null;
                pessoaFisica.codigoFaixaRenda = null;
                pessoaFisica.codigoNacionalidade = null;
                pessoaFisica.codigoOcupacao = null;
                pessoaFisica.codigoSexoPessoa = null;
                pessoaFisica.codigoTipoExposicaoPessoa = null;
                pessoaFisica.dataNascimento = null;
                pessoaFisica.codigoPais = null;
            }

            return pessoaFisica;
        }

        function convertData(data, dataEbo) {
            var dataRetorno = this;
            if (data == "Invalid Date" && angular.isString(dataEbo) && dataEbo.toString().match("/") !== null) {
                dataRetorno = convertDateOnly(dataEbo.split("/").reverse().join("/"));
            } else {
                dataRetorno = data;
            }
            return dataRetorno;
        }

        function setValueToPessoaJuridica(value) {
            return new PessoaJuridica(value);
        }

        //PessoaJuridicaEBO
        function PessoaJuridica(value) {
            var pessoaJuridica = this;

            if (value) {
                pessoaJuridica.codigoAtividadeEconomica = value.codigoAtividadeEconomica;
                pessoaJuridica.codigoFaixaReceitaOperacionalAno = value.codigoFaixaReceitaOperacionalAno;
                pessoaJuridica.codigoFaixaPatrimonioLiquido = value.codigoFaixaPatrimonioLiquido;
                pessoaJuridica.codigoNaturezaJuridica = value.codigoNaturezaJuridica;
                pessoaJuridica.flagPossuiControlador = value.flagPossuiControlador;

                if ((angular.isUndefined(value.flagCongenere) || value.flagCongenere === '' ||
                        value.flagCongenere === null) && value.codigoAtividadeEconomica !== null &&
                    value.codigoFaixaPatrimonioLiquido !== null && value.codigoNaturezaJuridica !== null) {
                    pessoaJuridica.flagCongenere = 'N';
                } else {
                    pessoaJuridica.flagCongenere = value.flagCongenere;
                }
                pessoaJuridica.codigoSusepCongenere = value.codigoSusepCongenere;
                pessoaJuridica.dataRegistroAbertura = convertDateOnly(value.dataRegistroAbertura);
            } else {
                pessoaJuridica.codigoAtividadeEconomica = null;
                pessoaJuridica.codigoFaixaReceitaOperacionalAno = null;
                pessoaJuridica.codigoFaixaPatrimonioLiquido = null;
                pessoaJuridica.codigoNaturezaJuridica = null;
                pessoaJuridica.flagPossuiControlador = null;
                pessoaJuridica.flagCongenere = null;
                pessoaJuridica.codigoSusepCongenere = null;
                pessoaJuridica.dataRegistroAbertura = null;
            }

            return pessoaJuridica;
        }

        function setValueToDocumentosList(values) {
            var documentos = [];

            if (values) {
                angular.forEach(values, function(value) {
                    var documento = setValueToDocumento(value);
                    documentos.push(documento);
                });
            }

            return documentos;
        }

        function setValueToDocumento(value) {
            return new Documento(value);
        }

        //DocumentoEBO
        function Documento(value) {
            var documento = this;

            if (value) {
                documento.codigoDocumentoPessoa = value.codigoDocumentoPessoa;
                documento.codigoTipoDocumentoPessoa = value.codigoTipoDocumentoPessoa;
                documento.numeroDocumento = value.numeroDocumento;
                documento.dataEmissaoDocumento = value.dataEmissaoDocumento;
                documento.dataValidade = value.dataValidade;
                documento.nomeOrgaoExpedidor = value.nomeOrgaoExpedidor;
                documento.codigoUnidadeFederacao = parseInt(value.codigoUnidadeFederacao);
                documento.flagAtivo = value.flagAtivo;
            } else {
                documento.codigoDocumentoPessoa = null;
                documento.codigoTipoDocumentoPessoa = null;
                documento.numeroDocumento = null;
                documento.dataEmissaoDocumento = null;
                documento.dataValidade = null;
                documento.nomeOrgaoExpedidor = null;
                documento.codigoUnidadeFederacao = null;
                documento.flagAtivo = null;
            }

            return documento;
        }

        function setValueToEnderecosPessoaList(values) {
            var enderecosPessoa = [];

            if (values) {
                angular.forEach(values, function(value) {
                    var enderecoPessoa = setValueToEnderecoPessoa(value);
                    enderecosPessoa.push(enderecoPessoa);
                });
            }

            return enderecosPessoa;
        }

        //EnderecoEBO
        function setValueToEnderecoPessoa(value) {
            return new Endereco(value);
        }

        function setValueToContatosList(values) {
            var contatos = [];

            if (values) {
                angular.forEach(values, function(value) {
                    var contato = setValueToContato(value);
                    contatos.push(contato);
                });
            }

            return contatos;
        }

        function setValueToContato(value) {
            return new Contato(value);
        }

        //ContatoEBO
        function Contato(value) {
            var contato = this;

            if (value) {
                contato.codigoContatoPessoa = value.codigoContatoPessoa;
                contato.codigoTipoContato = value.codigoTipoContato;
                contato.numeroDdi = value.numeroDdi;
                contato.numeroDdd = value.numeroDdd;
                contato.numeroContato = value.numeroContato;
                contato.numeroRamal = value.numeroRamal;
                contato.textoContato = value.textoContato;
                contato.flagPrincipal = value.flagPrincipal;
                contato.textoComentario = value.textoComentario;
                contato.flagAtivo = value.flagAtivo;
            } else {
                contato.codigoContatoPessoa = null;
                contato.codigoTipoContato = null;
                contato.numeroDdi = null;
                contato.numeroDdd = null;
                contato.numeroContato = null;
                contato.numeroRamal = null;
                contato.textoContato = null;
                contato.flagPrincipal = null;
                contato.textoComentario = null;
                contato.flagAtivo = null;
            }

            return contato;
        }

        function convertPessoaForCreate(pessoaItem) {

            var converted = {};
            converted.pessoa = {};
            var pessoa = {};

            if (pessoaItem.cnpj) {
                pessoa.numeroCnpjCpf = removeFormat(pessoaItem.cnpj);
            } else if (pessoaItem.cpf) {
                pessoa.numeroCnpjCpf = removeFormat(pessoaItem.cpf);
                pessoa.pessoaFisica = {};
                pessoa.pessoaFisica.codigoTipoExposicaoPessoa = null;
            }

            pessoa.codigoPessoa = null;
            pessoa.nomePessoa = pessoaItem.nomePessoa;
            pessoa.nomeResumidoPessoa = pessoaItem.nomePessoa;
            pessoa.flagAtivo = 'S';
            pessoa.codigoTipoPessoa = pessoaItem.codigoTipoPessoa;

            converted.pessoa = pessoa;

            return converted;
        }

        function getParcelaFromGrid(numeroParcela, gridData) {

            var parcelaReturn = {};

            angular.forEach(gridData.parcela, function(parcela) {

                if (numeroParcela === parcela.numeroParcela) {
                    parcelaReturn.codigoBanco = parcela.codigoBanco;
                    parcelaReturn.codigoPessoa = parcela.codigoPessoa;
                    parcelaReturn.codigoTipoPessoa = parcela.codigoTipoPessoa;
                    parcelareturn.nomePessoa = parcela.nomePessoa;
                    parcelaReturn.numeroContaBancaria = parcela.numeroContaBancaria;
                    parcelaReturn.digitoContaBancaria = parcela.digitoContaBancaria;
                    parcelaReturn.numeroAgenciaBancaria = parcela.numeroAgenciaBancaria;
                    parcelaReturn.numeroParcela = parcela.numeroParcela;
                    if (parcela.codigoTipoPessoa === Constants.CODIGO_TIPO_PESSOA.FISICA) {
                        parcelaReturn.cpf = parcela.numeroCnpjCpf;
                    } else {
                        parcelaReturn.cnpj = parcela.numeroCnpjCpf;
                    }
                }
            });
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#pad
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         *
         * Add leading zeros to value when needed.
         *
         * @param {Long} value that needs to be formatted.
         * @param {Integer} expected size of string to be returned.
         * @returns {String} formatted string
         **/
        function pad(num, size) {
            var value = num + "";
            while (value.length < size) {
                value = "0" + value;
            }
            return value;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#cpfFormat
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         *
         * Format the value to cpf format.
         *
         * @param {String} value that needs to be formatted.
         * @returns {String} formatted string
         **/
        function cpfFormat(num) {
            String.prototype.splice = function(idx, rem, s) {
                return (this.slice(0, idx) + s + this.slice(idx + Math.abs(rem)));
            };

            num = num.splice(3, 0, '.');
            num = num.splice(7, 0, '.');
            num = num.splice(11, 0, '-');

            return num;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#cnpjFormat
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         *
         * Format the value to cnpj format.
         *
         * @param {String} value that needs to be formatted.
         * @returns {String} formatted string
         **/
        // function cnpjFormat(num) {
        // 	String.prototype.splice = function(idx, rem, s) {
        // 		return (this.slice(0, idx) + s + this.slice(idx + Math.abs(rem)));
        // 	};
        //
        // 	num = num.splice(2, 0, '.');
        // 	num = num.splice(6, 0, '.');
        // 	num = num.splice(10, 0, '/');
        // 	num = num.splice(15, 0, '-');
        //
        // 	return num;
        // }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#removeFormat
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         *
         * Removed the format to be sent in backend.
         *
         * @param {String} value that needs to be unformatted.
         * @returns {String} Unformatted string
         **/
        function removeFormat(num) {

            if (angular.isString(num)) {
                num = num.replace(/[./-]/g, '');
            }
            return num;
        }

        function formatCep(cep) {

            if (!cep) {
                return;
            }

            var filteredDataString = cep.toString();
            var lastIndex = filteredDataString.length;

            while (lastIndex < 8) {
                filteredDataString = '0' + filteredDataString;
                lastIndex++;
            }

            return filteredDataString.substring(0, 5) + '-' + filteredDataString.substring(5, lastIndex);
        }

        function createPessoaToUpdate(pessoaItem) {

            var converted = {
                pessoa: {}
            };
            var pessoa = {};

            pessoa.numeroCnpjCpf = removeFormat(pessoaItem.numeroCnpjCpf);
            pessoa.codigoPessoa = pessoaItem.codigoPessoa;
            pessoa.nomePessoa = pessoaItem.nomePessoa;
            pessoa.nomeResumidoPessoa = pessoaItem.nomePessoa;
            pessoa.flagAtivo = 'S';
            pessoa.codigoTipoPessoa = pessoaItem.codigoTipoPessoa;

            converted.pessoa = pessoa;

            return converted;
        }

        //------------------------------------END PROPOSTA-----------------------------------------------------//

        function isNullEmptyOrUndefined(item) {
            var hasError = false;
            if (angular.isUndefined(item) || item === '' || item === null) {
                hasError = true;
            }
            return hasError;
        }

        function filterFormaPagamento(items) {

            var formaPagamento = [];
            formaPagamento.push({
                adcList: []
            });
            formaPagamento.push({
                cartaoPortoList: []
            });
            formaPagamento.push({
                demaisList: []
            });
            formaPagamento.push({
                boletoList: []
            });

            angular.forEach(items, function(item) {
                var existing = false;
                if (((item.codigoMeioPagamentoPrimeiraParcela && item.codigoMeioPagamentoDemaisParcela) !== 3) &&
                    ((item.codigoMeioPagamentoPrimeiraParcela && item.codigoMeioPagamentoDemaisParcela) !== 8) &&
                    ((item.codigoMeioPagamentoPrimeiraParcela && item.codigoMeioPagamentoDemaisParcela) !== 9)) {
                    if (item.codigoMeioPagamentoPrimeiraParcela === 2) {

                        if ($filter('filter')(formaPagamento[0].adcList, {
                                codigoFormaPagamento: item.codigoFormaPagamento,
                                quantidadeParcela: item.quantidadeParcela
                            }).length === 0) {
                            formaPagamento[0].adcList.push(item);
                        }

                    } else if (item.codigoMeioPagamentoPrimeiraParcela === 6) {

                        if ($filter('filter')(formaPagamento[1].cartaoPortoList, {
                                codigoFormaPagamento: item.codigoFormaPagamento,
                                quantidadeParcela: item.quantidadeParcela
                            }).length === 0) {
                            formaPagamento[1].cartaoPortoList.push(item);
                        }

                    } else if (item.codigoMeioPagamentoPrimeiraParcela === 7) {

                        if ($filter('filter')(formaPagamento[2].demaisList, {
                                codigoFormaPagamento: item.codigoFormaPagamento,
                                quantidadeParcela: item.quantidadeParcela
                            }).length === 0) {
                            formaPagamento[2].demaisList.push(item);
                        }

                    } else if (item.codigoMeioPagamentoDemaisParcela === 1 ||
                        item.codigoMeioPagamentoDemaisParcela === 4 ||
                        item.codigoMeioPagamentoDemaisParcela === 5) {

                        if ($filter('filter')(formaPagamento[3].boletoList, {
                                codigoFormaPagamento: item.codigoFormaPagamento,
                                quantidadeParcela: item.quantidadeParcela
                            }).length === 0) {
                            formaPagamento[3].boletoList.push(item);
                        }
                    }
                }
            });

            return formaPagamento;
        }

        function filterQuantidadeParcela(formaList, nomeFormaPagamento) {

            var quantidadeList = [],
                newList = [];
            if (nomeFormaPagamento &&
                $filter('filter')(formaList, {
                    nomeFormaPagamento: nomeFormaPagamento
                }, true).length > 0) {
                quantidadeList = $filter('filter')(formaList, {
                    nomeFormaPagamento: nomeFormaPagamento
                }, true);
            }

            angular.forEach(quantidadeList, function(quantidade) {
                if (quantidade.flagImpressaoFormaPagamento === "S") {
                    newList.push(quantidade)
                }
            });

            if (newList.length == 0) {
                newList = quantidadeList;
            }

            return newList;
        }

        function getFormaPagamentoFromList(items, codigoFormaPagamento) {

            var returnValue = null;

            var adcReturn = $filter('filter')(items[0].adcList, {
                codigoFormaPagamento: codigoFormaPagamento
            }, true)[0];
            var cartaoPortoReturn = $filter('filter')(items[1].cartaoPortoList, {
                codigoFormaPagamento: codigoFormaPagamento
            }, true)[0];
            var demaisReturn = $filter('filter')(items[2].demaisList, {
                codigoFormaPagamento: codigoFormaPagamento
            }, true)[0];
            var boletoReturn = $filter('filter')(items[3].boletoList, {
                codigoFormaPagamento: codigoFormaPagamento
            }, true)[0];

            if (angular.isDefined(adcReturn)) {
                returnValue = adcReturn;
            } else if (angular.isDefined(cartaoPortoReturn)) {
                returnValue = cartaoPortoReturn;
            } else if (angular.isDefined(demaisReturn)) {
                returnValue = demaisReturn;
            } else if (angular.isDefined(boletoReturn)) {
                returnValue = boletoReturn;
            }

            return returnValue;
        }

        function convertEnderecoSolicitacaoCartao(item) {
            var enderecoCartao = {};

            if (item) {
                enderecoCartao.numeroCep = item.numeroCep;
                enderecoCartao.nomeLogradouro = item.nomeLogradouro;
                enderecoCartao.codigoTipoLogradouro = item.codigoTipoLogradouro;
                enderecoCartao.flagSemNumero = item.flagSemNumero;
                enderecoCartao.numeroLogradouro = item.numeroLogradouro;
                enderecoCartao.nomeComplemento = item.nomeComplemento;
                enderecoCartao.nomeBairro = item.nomeBairro;
                enderecoCartao.nomeCidade = item.nomeCidade;
                enderecoCartao.codigoUnidadeFederacao = item.codigoUnidadeFederacao;

            }
            return enderecoCartao;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertTipoDocumento
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Tipo Documento Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Tipo Documento'
         **/
        function convertTipoDocumento(items) {
            var converted = [{
                codigo: 1,
                nome: "RG"
            }, {
                codigo: 2,
                nome: "CNH"
            }, {
                codigo: 3,
                nome: "RNE"
            }, {
                codigo: 4,
                nome: "Passaporte"
            }];
            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertFaixaDeRenda
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Faixa de Renda Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Faixa de Renda'
         **/
        function convertFaixaDeRenda(items) {
            var converted = [{
                codigo: 1,
                nome: "Test1"
            }, {
                codigo: 2,
                nome: "Test2"
            }, {
                codigo: 3,
                nome: "Test3"
            }, {
                codigo: 4,
                nome: "Test4"
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertPaisResidente
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Pais Residente Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Pais Residente'
         **/
        function convertPaisResidente(items) {
            var converted = [{
                codigo: 1,
                nome: "Test1"
            }, {
                codigo: 2,
                nome: "Test2"
            }, {
                codigo: 3,
                nome: "Test3"
            }, {
                codigo: 4,
                nome: "Test4"
            }];

            return converted;
        }

        /**
         * @ngdoc method
         * @name porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory#convertAtividade
         * @methodOf porto.re.emissaocadastro.operacoes.factory:OrcamentoPropostaFactory
         * @description
         * constructs Pais Residente Object
         *
         * @param {Array.<Object>} items array of objects to be converted.
         * @returns {Array.<Object>} converted object of 'Pais Residente'
         **/
        function convertAtividade(items) {
            var converted = [{
                codigo: 1,
                nome: "Test1"
            }, {
                codigo: 2,
                nome: "Test2"
            }, {
                codigo: 3,
                nome: "Test3"
            }, {
                codigo: 4,
                nome: "Test4"
            }];

            return converted;
        }

        function ajustaPagadorParcela(pagadorVersaoPropostas, enderecoCobranca) {
            var pagadorEstrutura = montaPagadores(pagadorVersaoPropostas, enderecoCobranca);
            return montaParcelas(pagadorEstrutura, pagadorVersaoPropostas);
        }

        function ajustaGrid(pagadorVersaoPropostas, pagamentoCalcularParcela, pessoas, statusParcelas) {
            pagadorVersaoPropostas[0].codigoFormaPagamento = pagamentoCalcularParcela.codigoFormaPagamento;
            pagadorVersaoPropostas[0].quantidadeParcela = pagamentoCalcularParcela.quantidadeParcela;
            pagadorVersaoPropostas[0].numeroProposta = pagamentoCalcularParcela.numeroProposta;
            pagadorVersaoPropostas[0].numeroVersaoProposta = pagamentoCalcularParcela.numeroVersaoProposta;
            return convertPagadorParcelaVersaoProposta(pagadorVersaoPropostas, pessoas, statusParcelas, pagamentoCalcularParcela.nomeFormaPagamento);
        }

        function montaPagadores(parcelasVersao, enderecoCobranca) {
            var pagadores = [];
            var pagadorMap = [];
            var codigosPessoaArr = parcelasVersao.map(function(item) {
                return item.dadosPessoaPagadorParcela.codigoPessoa;
            });
            codigosPessoaArr = removePagadoresIguais(codigosPessoaArr);
            angular.forEach(codigosPessoaArr, function(codigo, index) {
                var pagador = {};
                pagador.dadosPessoaPagador = {};
                pagador.dadosPessoaPagador.codigoPessoa = codigo;
                pagador.enderecoCobranca = {};
                if (enderecoCobranca.enderecosCadastrado) {
                    pagador.enderecoCobranca.codigoEndereco = enderecoCobranca.enderecosCadastrado;
                } else if (enderecoCobranca.codigoEndereco) {
                    pagador.enderecoCobranca.codigoEndereco = enderecoCobranca.codigoEndereco;
                }
                pagador.pagadoresParcela = {};
                pagador.pagadoresParcela.pagadorParcela = [];
                pagadores.push(pagador);
                pagadorMap[codigo] = index;
            });
            return {
                pagador: pagadores,
                pagadorMap: pagadorMap
            };
        }

        function removePagadoresIguais(codigosPessoaArr) {
            var itens = {};
            return codigosPessoaArr.filter(function(codigo) {
                return itens[codigo] ? false : (itens[codigo] = true);
            });
        }

        function montaParcelas(pagadorEstrutura, pagadorVersaoPropostas) {
            var pagadorReturn = pagadorEstrutura.pagador.concat();
            angular.forEach(pagadorVersaoPropostas, function(pagadorVersao) {
                var index = pagadorVersao.dadosPessoaPagadorParcela.codigoPessoa;
                pagadorReturn[pagadorEstrutura.pagadorMap[index]].pagadoresParcela.pagadorParcela.push(pagadorVersao);
            });
            return pagadorReturn;
        }

    } //end factory
})();